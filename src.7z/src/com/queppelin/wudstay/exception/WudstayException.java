
package com.queppelin.wudstay.exception;

import java.text.MessageFormat;

import org.slf4j.Logger;

import com.queppelin.wudstay.util.MessageReader;
import com.queppelin.wudstay.util.WudstayConstants;

public class WudstayException extends Exception{

	private static final long serialVersionUID = 4636687359960045306L;

	private String message;

	private Throwable nestedException;
	
	String propValue = null;

	public String getMessage() {
		return message;
	}

	public Throwable getNestedException() {
		return nestedException;
	}

	public WudstayException(Logger logger, String methodName, String msgKey, Object[] args) {

		try {
			logger.debug("msgKey: " + msgKey);
			propValue = readProperty(msgKey.toString());
			message = MessageFormat.format(propValue, args);
			logger.error(message);
		} catch (NullPointerException e) {
			message = WudstayConstants.MESSAGE_KEY_NOT_FOUND;
			logger.error("error:", e);
		} catch (Exception e) {
			logger.error("error:", e);
		}
	}

	public String readProperty(String key){
		return MessageReader.getInstance().getProperty(key);
	}

	public WudstayException(Logger logger, String methodName,
			String msgKey, String[] args, Exception ex) {
		try {
			this.nestedException = ex;
			logger.error("error:", ex);
			try {
				propValue = readProperty(msgKey.toString());
				message = MessageFormat.format(propValue, args);
			} catch (NullPointerException e) {
				message = WudstayConstants.MESSAGE_KEY_NOT_FOUND;
				logger.error("error:", e);
			}
			logger.error(message);
		} catch (Exception e) {
			logger.error("error:", e);
		}
	}


	public WudstayException(Logger logger, String msgKey, String entityName) {

		try {
			logger.debug("msgKey: " + msgKey);
			propValue = readProperty(msgKey);
			message = MessageFormat.format(propValue, entityName);
			logger.error(message);
		} catch (NullPointerException e) {
			message = WudstayConstants.MESSAGE_KEY_NOT_FOUND;
			logger.error("error:", e);
		} catch (Exception e) {
			logger.error("error:", e);
		}
	}

	public WudstayException(Logger logger, String methodName,
			String msgKey, Exception ex) {
		try {
			logger.error("error:", ex);
			try {
				message = readProperty(msgKey.toString());
			} catch (NullPointerException e) {
				message = WudstayConstants.MESSAGE_KEY_NOT_FOUND;
				logger.error("error:", e);
			}
			logger.error(message);
		} catch (Exception e) {
			logger.error("error:", e);
		}
	}

}
