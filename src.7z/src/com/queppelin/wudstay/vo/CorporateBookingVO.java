package com.queppelin.wudstay.vo;

import javax.persistence.*;
import java.util.*;

import static javax.persistence.GenerationType.IDENTITY;

/*
DROP TABLE IF EXISTS corporate_booking;

CREATE TABLE corporate_booking (
  corp_booking_id 			int(11) NOT NULL AUTO_INCREMENT,
  corp_id 					int(11) DEFAULT NULL,

  booking_name 				varchar(100) NOT NULL,
  check_in 					datetime NOT NULL,
  check_out 				datetime NOT NULL,
  booking_date 				datetime NOT NULL,

  location_id 					int(11) NOT NULL,
  is_cancelled 				tinyint(1) DEFAULT '0',

  last_updated_by 			varchar(50) DEFAULT NULL,
  last_updated_date 		date DEFAULT NULL,

  unique_ref_key 			VARCHAR(50) NOT NULL,



  room_type 				varchar(100)  NULL,
  city 						varchar(100)  NULL,
  location 					varchar(100)  NULL,
  per_room_rate 			tinyint(1) DEFAULT '0',
  is_approved 				tinyint(1) DEFAULT '0',

  PRIMARY KEY (corp_booking_id),
  KEY corp_id (corp_id),
  CONSTRAINT booking_corp_id_fk_1 FOREIGN KEY (corp_id) REFERENCES corporate (corp_id)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS corporate_booking;

CREATE TABLE corporate_booking (
  corp_booking_id 			int(11) NOT NULL AUTO_INCREMENT,
  corp_id 					int(11) 		NOT NULL,
  booking_name 				varchar(100) 	DEFAULT NULL,
  location_id 				int(11)  		NOT NULL,
  check_in 					datetime 		DEFAULT NULL,
  check_out 				datetime 		DEFAULT NULL,

  booking_date 				datetime 		DEFAULT NULL,
  room_type 				varchar(25)  	DEFAULT NULL,

  is_approved 				tinyint(1) 		DEFAULT '0',
  is_cancelled 				tinyint(1) 		DEFAULT '0',

  last_updated_by 			varchar(50) 	DEFAULT NULL,
  last_updated_date 		datetime 		DEFAULT NULL,

  PRIMARY KEY (corp_booking_id),
  KEY corp_id (corp_id),
  CONSTRAINT booking_corp_id_fk_1 FOREIGN KEY (corp_id) REFERENCES corporate (corp_id)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

Alter price


ALTER TABLE corporate ADD COLUMN corpLoginUser_id int(11) DEFAULT NULL ;

ALTER TABLE corporate_booking ADD COLUMN billPayAt tinyint(1) DEFAULT '0';
*/

@Entity
@Table(name = "corporate_booking" )
public class CorporateBookingVO implements java.io.Serializable {
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "corp_booking_id", unique = true, nullable = false)
	private Long corpBookingId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "corp_id")
	private Corporate corporate;

	/*@Column(name = "corpLoginUser_id")
	private Long corpLoginUserId;*/

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "corpLoginUser_id")
	private CorporateLoginVO corporateUser;

	@Column(name = "booking_name")
	private String bookingName;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "location_id")
	private Location location;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "check_in", nullable = false, length = 19)
	private Date checkIn;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "check_out", nullable = false, length = 19)
	private Date checkOut;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "booking_date", nullable = false, length = 19)
	private Date bookingDate;

	@Column(name = "room_type")
	private String roomType;

	/*@Column(name = "city")
	private String city;*/


	@Column(name = "is_approved")
	private Integer isApproved=0;

	@Column(name = "is_cancelled")
	private Integer  isCancelled=0;

	@Column(name = "last_updated_by", length = 100)
	private String lastUpdatedBy;
	@Temporal(TemporalType.DATE)
	@Column(name = "last_updated_date", length = 10)
	private Date   lastUpdatedDate;

	@OneToMany(fetch = FetchType.LAZY )
	@JoinColumn(name="corp_booking_id")
	private Set<CorporateEmployeeVO> listOfEmployee = new LinkedHashSet<CorporateEmployeeVO>();


	@Column(name = "price")
	private Integer  price=0;

	@Column(name = "billPayAt")
	private Integer  billPayAt=0;

	@Column(name = "guest_request")
	private String guestRequest="";


	public CorporateBookingVO() {
	}
	/*public CorporateBookingVO(Corporate corporate, Long corpLoginUserId, String bookingName, Date checkIn, Date checkOut, Date bookingDate, Location location, String roomType) {
		this.corporate = corporate;
		this.corpLoginUserId=corpLoginUserId;
		this.location=location;
		this.bookingName = bookingName;
		this.checkIn = checkIn;
		this.checkOut = checkOut;
		this.bookingDate = bookingDate;
		this.location = location;
		this.roomType=roomType;
	}*/
	public CorporateBookingVO(Corporate corporate, CorporateLoginVO corporateUser, String bookingName, Date checkIn, Date checkOut, Date bookingDate, Location location, String roomType) {
		this.corporate = corporate;
		this.corporateUser=corporateUser;
		this.location=location;
		this.bookingName = bookingName;
		this.checkIn = checkIn;
		this.checkOut = checkOut;
		this.bookingDate = bookingDate;
		this.location = location;
		this.roomType=roomType;
	}
	public Long getCorpBookingId() {
		return corpBookingId;
	}

	public void setCorpBookingId(Long corpBookingId) {
		this.corpBookingId = corpBookingId;
	}

	public Corporate getCorporate() {
		return corporate;
	}

	public void setCorporate(Corporate corporate) {
		this.corporate = corporate;
	}

	/*public Long getCorpLoginUserId() {
		return corpLoginUserId;
	}

	public void setCorpLoginUserId(Long corpLoginUserId) {
		this.corpLoginUserId = corpLoginUserId;
	}*/

	public CorporateLoginVO getCorporateUser() {
		return corporateUser;
	}

	public void setCorporateUser(CorporateLoginVO corporateUser) {
		this.corporateUser = corporateUser;
	}

	public String getBookingName() {
		return bookingName;
	}

	public void setBookingName(String bookingName) {
		this.bookingName = bookingName;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public Date getCheckIn() {
		return checkIn;
	}

	public void setCheckIn(Date checkIn) {
		this.checkIn = checkIn;
	}

	public Date getCheckOut() {
		return checkOut;
	}

	public void setCheckOut(Date checkOut) {
		this.checkOut = checkOut;
	}

	public Date getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(Date bookingDate) {
		this.bookingDate = bookingDate;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public Integer getIsApproved() {
		return isApproved;
	}

	public void setIsApproved(Integer isApproved) {
		this.isApproved = isApproved;
	}

	public Integer getIsCancelled() {
		return isCancelled;
	}

	public void setIsCancelled(Integer isCancelled) {
		this.isCancelled = isCancelled;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public Set<CorporateEmployeeVO> getListOfEmployee() {
		return listOfEmployee;
	}

	public void setListOfEmployee(Set<CorporateEmployeeVO> listOfEmployee) {
		this.listOfEmployee = listOfEmployee;
	}


	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public Integer getBillPayAt() {
		if(billPayAt==null)
			billPayAt=0;
		return billPayAt;
	}

	public void setBillPayAt(Integer billPayAt) {
		if(billPayAt==null)
			billPayAt=0;
		this.billPayAt = billPayAt;
	}

	public String getGuestRequest() {
		return guestRequest;
	}

	public void setGuestRequest(String guestRequest) {
		this.guestRequest = guestRequest;
	}
}
