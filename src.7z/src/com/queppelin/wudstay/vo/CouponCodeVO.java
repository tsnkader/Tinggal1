package com.queppelin.wudstay.vo;

import javax.persistence.*;
import java.util.*;

import static javax.persistence.GenerationType.IDENTITY;

/**
 * Created by hp on 10/1/2015.

DROP TABLE IF EXISTS tblCouponCode;

 CREATE TABLE tblCouponCode (
     coupon_Id 				    int(11) 	NOT NULL AUTO_INCREMENT,
     coupon_Code 				varchar(25) NOT NULL,
     coupon_AmtValue 			int(11) 	NOT NULL,
     coupon_PercentageMode 	    tinyint(1)  DEFAULT '0',
     coupon_ValidDate 			datetime 	DEFAULT NULL,
     coupon_ValidTillTimes		int(11) 	DEFAULT NULL,
     coupon_ValidityMode		tinyint(4) 	DEFAULT '1',
     PRIMARY KEY (coupon_Id),
     UNIQUE KEY coupon_Code_Key (coupon_Code)
 ) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

 SELECT * FROM tblCouponCode;
 ALTER TABLE tblCouponCode ADD COLUMN coupon_ValidFromDate datetime 	DEFAULT NULL;
 ALTER TABLE tblCouponCode ADD COLUMN coupon_ValidityDateApplyOnCheckout tinyint(1)  DEFAULT '0',

 ALTER TABLE tblCouponCode ADD COLUMN last_updated_by varchar(100) 	DEFAULT NULL;
 ALTER TABLE tblCouponCode ADD COLUMN last_updated_date datetime 	DEFAULT NULL;
 Unknown column 'couponId' in 'where clause'; SQL [n/a]
 ALTER TABLE tblCouponCode ADD COLUMN coupon_allcity tinyint(1)  DEFAULT '1';

 ALTER TABLE tblCouponCode ADD COLUMN coupon_upperLimit int(11) 	DEFAULT 0;

 ALTER TABLE tblCouponCode ADD COLUMN coupon_valid_for_unique_user tinyint(1)  DEFAULT '0';
 ALTER TABLE tblCouponCode ADD COLUMN coupon_valid_for_bookingsource int(11) 	DEFAULT 0;

 ALTER TABLE tblCouponCode ADD COLUMN coupon_valid_for_onlinepayment tinyint(1)  DEFAULT '0';



 */

@Entity
@Table(name = "tblcouponcode" )
public class CouponCodeVO implements java.io.Serializable {
    private static final long serialVersionUID = 3085841545652604425L;
    @Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "coupon_Id", unique = true, nullable = false)
    private Long    couponId;
    @Column(name = "coupon_Code")
    private String  couponCode;
    @Column(name = "coupon_AmtValue")
    private Integer couponAmtValue;
    @Column(name = "coupon_PercentageMode")
    private Integer isDiscountPercentageMode=0;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "coupon_ValidFromDate", nullable = false, length = 19)
    private Date    couponValidFromDate;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "coupon_ValidDate", nullable = false, length = 19)
    private Date    couponValidTillDate;
    @Column(name = "coupon_ValidTillTimes")
    private Integer couponValidTillTimes=0;
    @Column(name = "coupon_ValidityMode")//private Integer couponValidityMode=1;
    private Integer couponIgnoreValidityDate=0;
    @Column(name = "coupon_ValidityDateApplyOnCheckout")//private Integer couponValidityMode=1;
    private Integer couponValidityDateApplyOnCheckout=0;
    @Column(name = "coupon_allcity")
    private Integer couponValidForAllCities=1;
//@OneToMany(fetch = FetchType.LAZY, mappedBy = "amenity") coupon_Id
    /*@OneToMany(fetch = FetchType.LAZY )
    @JoinColumn(name="coupon_Id")
    private Set<CouponCodeUsedVO> listOfEmployee = new HashSet<CouponCodeUsedVO>();*/

    @OneToMany(fetch = FetchType.LAZY )
    @JoinColumn(name="coupon_Id")
    private Set<CouponCodeInCityVO> cities = new HashSet<CouponCodeInCityVO>();

    @Column(name = "last_updated_by", length = 100)
    private String lastUpdatedBy;
    @Temporal(TemporalType.DATE)
    @Column(name = "last_updated_date", length = 10)
    private Date   lastUpdatedDate;

    @Column(name = "coupon_upperLimit")
    private Integer   discountUpperLimit=0;

    @Column(name = "coupon_valid_for_unique_user")
    private Integer isValidForUniqueUser=0;
    @Column(name = "coupon_valid_for_bookingsource")
    private Integer  validForBookingsource=0 ;

    @Column(name = "coupon_valid_for_onlinepayment")
    private Integer isValidForOnlinePaymentOnly=0;


    public CouponCodeVO(){}

    public CouponCodeVO(String couponCode, Integer couponAmtValue, Integer isDiscountPercentageMode, Date couponValidTillDate, Integer couponValidTillTimes, Integer couponIgnoreValidityDate) {
        this.couponCode = couponCode;
        this.couponAmtValue = couponAmtValue;
        this.isDiscountPercentageMode = isDiscountPercentageMode;
        this.couponValidTillDate = couponValidTillDate;
        this.couponValidTillTimes = couponValidTillTimes;
        this.couponIgnoreValidityDate = couponIgnoreValidityDate;
    }

    public CouponCodeVO(CouponCodeVO otherObject) {
        this.couponCode = otherObject.getCouponCode();
        this.couponAmtValue = otherObject.getCouponAmtValue();
        this.isDiscountPercentageMode = otherObject.getIsDiscountPercentageMode();
        this.couponValidFromDate = otherObject.getCouponValidFromDate();
        this.couponValidTillDate = otherObject.getCouponValidTillDate();
        this.couponValidTillTimes = otherObject.getCouponValidTillTimes();
        this.couponIgnoreValidityDate = otherObject.getCouponIgnoreValidityDate();
        this.couponValidityDateApplyOnCheckout = otherObject.getCouponValidityDateApplyOnCheckout();
        this.couponValidForAllCities = otherObject.getCouponValidForAllCities();
        this.lastUpdatedDate = new Date();
    }

    public Long getCouponId() {
        return couponId;
    }

    public void setCouponId(Long couponId) {
        this.couponId = couponId;
    }

    public String getCouponCode() {
        return couponCode;
    }

    public void setCouponCode(String couponCode) {
        this.couponCode = couponCode;
    }

    public Integer getCouponAmtValue() {
        return couponAmtValue;
    }

    public void setCouponAmtValue(Integer couponAmtValue) {
        this.couponAmtValue = couponAmtValue;
    }

    public Integer getIsDiscountPercentageMode() {
        return isDiscountPercentageMode;
    }

    public void setIsDiscountPercentageMode(Integer isDiscountPercentageMode) {
        this.isDiscountPercentageMode = isDiscountPercentageMode;
    }

    public Date getCouponValidFromDate() {
        return couponValidFromDate;
    }

    public void setCouponValidFromDate(Date couponValidFromDate) {
        this.couponValidFromDate = couponValidFromDate;
    }

    public Date getCouponValidTillDate() {
        return couponValidTillDate;
    }

    public void setCouponValidTillDate(Date couponValidTillDate) {
        this.couponValidTillDate = couponValidTillDate;
    }

    public Integer getCouponValidTillTimes() {
        return couponValidTillTimes;
    }

    public void setCouponValidTillTimes(Integer couponValidTillTimes) {
        this.couponValidTillTimes = couponValidTillTimes;
    }

    public Integer getCouponIgnoreValidityDate() {
        return couponIgnoreValidityDate;
    }

    public void setCouponIgnoreValidityDate(Integer couponIgnoreValidityDate) {
        this.couponIgnoreValidityDate = couponIgnoreValidityDate;
    }

    public Integer getCouponValidityDateApplyOnCheckout() {
        return couponValidityDateApplyOnCheckout;
    }

    public void setCouponValidityDateApplyOnCheckout(Integer couponValidityDateApplyOnCheckout) {
        this.couponValidityDateApplyOnCheckout = couponValidityDateApplyOnCheckout;
    }

    public Integer getCouponValidForAllCities() {
        return couponValidForAllCities;
    }

    public void setCouponValidForAllCities(Integer couponValidForAllCities) {
        this.couponValidForAllCities = couponValidForAllCities;
    }
/*public Set<CouponCodeUsedVO> getListOfEmployee() {
        return listOfEmployee;
    }

    public void setListOfEmployee(Set<CouponCodeUsedVO> listOfEmployee) {
        this.listOfEmployee = listOfEmployee;
    }*/

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public Date getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate(Date lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }

    public Set<CouponCodeInCityVO> getCities() {
        return cities;
    }

    public void setCities(Set<CouponCodeInCityVO> cities) {
        this.cities = cities;
    }

    public Integer getDiscountUpperLimit() {
        return discountUpperLimit;
    }

    public void setDiscountUpperLimit(Integer discountUpperLimit) {
        this.discountUpperLimit = discountUpperLimit;
    }

    public Integer getIsValidForUniqueUser() {
        return isValidForUniqueUser;
    }

    public void setIsValidForUniqueUser(Integer isValidForUniqueUser) {
        this.isValidForUniqueUser = isValidForUniqueUser;
    }

    public Integer getValidForBookingsource() {
        return validForBookingsource;
    }

    public void setValidForBookingsource(Integer validForBookingsource) {
        this.validForBookingsource = validForBookingsource;
    }

    public Integer getIsValidForOnlinePaymentOnly() {
        return isValidForOnlinePaymentOnly;
    }

    public void setIsValidForOnlinePaymentOnly(Integer isValidForOnlinePaymentOnly) {
        this.isValidForOnlinePaymentOnly = 0;
        if(isValidForOnlinePaymentOnly!=null)
            this.isValidForOnlinePaymentOnly = isValidForOnlinePaymentOnly;
    }
}
