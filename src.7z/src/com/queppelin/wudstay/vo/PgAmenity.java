package com.queppelin.wudstay.vo;

// Generated 25-Apr-2015 18:44:33 by Hibernate Tools 3.4.0.CR1

import javax.persistence.*;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import static javax.persistence.GenerationType.IDENTITY;

/**

 DROP TABLE IF EXISTS  pg_amenity ;

 CREATE TABLE  pg_amenity  (
	 amenity_id  int(11) NOT NULL AUTO_INCREMENT,
	 amenity_name  varchar(100) NOT NULL,
	 amenity_image  varchar(100) DEFAULT NULL,
	 is_active  tinyint(1) DEFAULT '1',
	 last_updated_by  varchar(50) DEFAULT NULL,
	 last_updated_date  date DEFAULT NULL,
	 PRIMARY KEY ( amenity_id )
 ) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

 INSERT INTO pg_amenity (amenity_id, amenity_name, amenity_image, is_active, last_updated_by, last_updated_date)
 	SELECT amenity_id, amenity_name, amenity_image, is_active, last_updated_by, last_updated_date FROM amenity
 */
@Entity
@Table(name = "pg_amenity")
public class PgAmenity implements java.io.Serializable {
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "amenity_id", unique = true, nullable = false)
	private Long amenityId;
	@Column(name = "amenity_name", nullable = false, length = 100)
	private String amenityName;
	@Column(name = "amenity_image", length = 100)
	private String amenityImage;
	@Column(name = "is_active")
	private Boolean isActive;
	@Column(name = "last_updated_by", length = 50)
	private String lastUpdatedBy;
	@Temporal(TemporalType.DATE)
	@Column(name = "last_updated_date", length = 10)
	private Date lastUpdatedDate;
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "amenity")
	private Set<HotelAmenity> hotelAmenities = new HashSet<HotelAmenity>(0);

	@Transient
	private Boolean isAvailable = Boolean.FALSE;

	public PgAmenity() {
	}

	public PgAmenity(String amenityName) {
		this.amenityName = amenityName;
	}

	public PgAmenity(String amenityName, String amenityImage, Boolean isActive,
					 String lastUpdatedBy, Date lastUpdatedDate,
					 Set<HotelAmenity> hotelAmenities) {
		this.amenityName = amenityName;
		this.amenityImage = amenityImage;
		this.isActive = isActive;
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdatedDate = lastUpdatedDate;
		this.hotelAmenities = hotelAmenities;
	}


	public Long getAmenityId() {
		return this.amenityId;
	}

	public void setAmenityId(Long amenityId) {
		this.amenityId = amenityId;
	}


	public String getAmenityName() {
		return this.amenityName;
	}

	public void setAmenityName(String amenityName) {
		this.amenityName = amenityName;
	}


	public String getAmenityImage() {
		return this.amenityImage;
	}

	public void setAmenityImage(String amenityImage) {
		this.amenityImage = amenityImage;
	}


	public Boolean getIsActive() {
		return this.isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}


	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}


	public Date getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}


	public Set<HotelAmenity> getHotelAmenities() {
		return this.hotelAmenities;
	}

	public void setHotelAmenities(Set<HotelAmenity> hotelAmenities) {
		this.hotelAmenities = hotelAmenities;
	}


	public Boolean getIsAvailable() {
		return isAvailable;
	}

	public void setIsAvailable(Boolean isAvailable) {
		this.isAvailable = isAvailable;
	}

}
