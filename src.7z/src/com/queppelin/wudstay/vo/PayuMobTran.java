package com.queppelin.wudstay.vo;

import javax.persistence.*;

import java.util.Date;

import static javax.persistence.GenerationType.IDENTITY;

/**
 * Created by hp on 12/3/2015.
 *
 drop table tbl_payu_mob_tran_log;
 CREATE TABLE tbl_payu_mob_tran_log(
 log_id         INT(11) PRIMARY KEY auto_increment,
 merchantKey	VARCHAR(100)  DEFAULT NULL,
 transactionId	VARCHAR(100)  DEFAULT NULL,
 amount	INT(11)  DEFAULT NULL,
 productInfo	VARCHAR(100)  DEFAULT NULL,
 firstName	VARCHAR(100)  DEFAULT NULL,
 email	VARCHAR(100)  DEFAULT NULL,
 salt	VARCHAR(100)  DEFAULT NULL,
 hash	VARCHAR(400)  DEFAULT NULL,
 surl	VARCHAR(100)  DEFAULT NULL,
 furl	VARCHAR(100)  DEFAULT NULL,
 curl	VARCHAR(100)  DEFAULT NULL,
 phone	VARCHAR(100)  DEFAULT NULL,
 udf1	VARCHAR(100)  DEFAULT NULL,
 udf2	VARCHAR(100)  DEFAULT NULL,
 log_time			timestamp,
 payu_response    VARCHAR(50)  DEFAULT NULL,
 payu_res_log_time timestamp

 )

 ALTER TABLE tbl_payu_mob_tran_log ADD COLUMN coupon_code VARCHAR(50) DEFAULT NULL ;
 ALTER TABLE tbl_payu_mob_tran_log ADD COLUMN source VARCHAR(50) DEFAULT NULL ;



 drop table tbl_payu_mob_tran_log;

 CREATE TABLE tbl_payu_mob_tran_log (
     log_id  INT(11) PRIMARY KEY auto_increment,
     name	    VARCHAR(100)  DEFAULT NULL,
     email	    VARCHAR(100)  DEFAULT NULL,
     phone	    VARCHAR(25)  DEFAULT NULL,
     source	    VARCHAR(50)   DEFAULT NULL,
     coupon_code	VARCHAR(50)  DEFAULT NULL,
     cityName    VARCHAR(50),
     hotel_id    INT(11),
     check_in	VARCHAR(50)  DEFAULT NULL,
     check_out	VARCHAR(50)  DEFAULT NULL,
     rooms       INT(11),
     persons     INT(11),
     total_amount      INT(11),
     log_time	      timestamp,
     payu_response     VARCHAR(50)  DEFAULT NULL,
     payu_res_log_time timestamp,
     booking_id     VARCHAR(50)  DEFAULT NULL,
     booking_time timestamp
 )

 CREATE TABLE tbl_payu_mob_tran_log( log_id INT(11) NOT NULL AUTO_INCREMENT, name VARCHAR(100)  DEFAULT NULL, email VARCHAR(100)  DEFAULT NULL, phone VARCHAR(25)  DEFAULT NULL, source  VARCHAR(50) DEFAULT NULL, coupon_code	VARCHAR(50)  DEFAULT NULL, cityName    VARCHAR(50), hotel_id  INT(11), check_in VARCHAR(50)  DEFAULT NULL, check_out	VARCHAR(50)  DEFAULT NULL, rooms INT(11), persons INT(11), total_amount INT(11), log_time timestamp, payu_response VARCHAR(50) DEFAULT NULL, payu_res_log_time timestamp, booking_id VARCHAR(50)  DEFAULT NULL, booking_time timestamp, PRIMARY KEY ( log_id ) ) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=latin1;

 ALTER TABLE tbl_payu_mob_tran_log ADD COLUMN payment_source VARCHAR(50) DEFAULT 'PAYU' ;

 */
@Entity
@Table(name = "tbl_payu_mob_tran_log" )
public class PayuMobTran implements java.io.Serializable {
    @Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "log_id", nullable = false)
    private Long logId;
    @Column(name = "name" )
    private String firstName;
    @Column(name = "email" )
    private String email;
    @Column(name = "phone" )
    private String phone;
    @Column(name = "coupon_code" )
    private String couponCode;
    @Column(name = "source" )
    private String source;

    @Column(name = "city_name" )
    private String cityName;
    @Column(name = "hotel_id" )
    private Long hotelId;
    @Column(name = "check_in" )
    String checkIn;
    @Column(name = "check_out" )
    String checkOut;
    @Column(name = "rooms" )
    Integer rooms;
    @Column(name = "persons" )
    Integer persons;
    @Column(name = "total_amount" )
    Integer totalAmount;

    @Column(name = "log_time", columnDefinition="DATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date logTime =  new Date();

    @Column(name = "payu_response" )
    private String payuResponse="WAITING";
    @Column(name = "payu_res_log_time", columnDefinition="DATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date payuResponseTime =  new Date();

    @Column(name = "booking_id" )
    String bookingId;
    @Column(name = "booking_time", columnDefinition="DATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date bookingTime =  new Date();

    @Column(name = "payment_source" )
    private String paymentSource="PAYU";

    @Transient
    String transactionId = null;
    @Transient
    String payuTransactionId = null;
    @Transient
    String payuAmount=null;



    public Long getLogId() {
        return logId;
    }

    public void setLogId(Long logId) {
        this.logId = logId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCouponCode() {
        return couponCode;
    }

    public void setCouponCode(String couponCode) {
        this.couponCode = couponCode;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public Long getHotelId() {
        return hotelId;
    }

    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }

    public String getCheckIn() {
        return checkIn;
    }

    public void setCheckIn(String checkIn) {
        this.checkIn = checkIn;
    }

    public String getCheckOut() {
        return checkOut;
    }

    public void setCheckOut(String checkOut) {
        this.checkOut = checkOut;
    }

    public Integer getRooms() {
        return rooms;
    }

    public void setRooms(Integer rooms) {
        this.rooms = rooms;
    }

    public Integer getPersons() {
        return persons;
    }

    public void setPersons(Integer persons) {
        this.persons = persons;
    }

    public Integer getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(Integer totalAmount) {
        this.totalAmount = totalAmount;
    }

    public Date getLogTime() {
        return logTime;
    }

    public void setLogTime(Date logTime) {
        this.logTime = logTime;
    }

    public String getPayuResponse() {
        return payuResponse;
    }

    public void setPayuResponse(String payuResponse) {
        this.payuResponse = payuResponse;
    }

    public Date getPayuResponseTime() {
        return payuResponseTime;
    }

    public void setPayuResponseTime(Date payuResponseTime) {
        this.payuResponseTime = payuResponseTime;
    }

    public String getBookingId() {
        return bookingId;
    }

    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }

    public Date getBookingTime() {
        return bookingTime;
    }

    public void setBookingTime(Date bookingTime) {
        this.bookingTime = bookingTime;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getPayuTransactionId() {
        return payuTransactionId;
    }

    public void setPayuTransactionId(String payuTransactionId) {
        this.payuTransactionId = payuTransactionId;
    }

    public String getPayuAmount() {
        return payuAmount;
    }

    public void setPayuAmount(String payuAmount) {
        this.payuAmount = payuAmount;
    }

    public String getPaymentSource() {
        return paymentSource;
    }

    public void setPaymentSource(String paymentSource) {
        this.paymentSource = paymentSource;
    }
}
