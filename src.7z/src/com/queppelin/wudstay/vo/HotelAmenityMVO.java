package com.queppelin.wudstay.vo;

import javax.persistence.*;

import static javax.persistence.GenerationType.IDENTITY;

/**
 * Created by hp on 12/23/2015.

 DROP VIEW v_hotel_amenities;

 CREATE or replace VIEW v_hotel_amenities AS
 SELECT  hotel_amenity_id, hotel_id, hotel_amenity.amenity_id , amenity.amenity_name,  amenity.amenity_image, amenity_listing_order
 FROM hotel_amenity  LEFT OUTER JOIN amenity ON ( hotel_amenity.amenity_id = amenity.amenity_id)
 WHERE hotel_amenity.is_active = TRUE
 ORDER BY hotel_id, amenity_listing_order;

 DROP PROCEDURE sp_hotel_amenities;

 CREATE PROCEDURE sp_hotel_amenities(in  v_hotel_id int(11))
 BEGIN
 SELECT hotel_amenity_id, hotel_id, amenity_id, amenity_name, amenity_image, amenity_listing_order  FROM v_hotel_amenities WHERE  hotel_id =  v_hotel_id
 ORDER BY hotel_id, amenity_listing_order ;
 END



 CREATE or replace VIEW v_pg_amenities AS
 select hotel_amenity.pg_amenity_id AS hotel_amenity_id,hotel_amenity.pg_hotel_id AS hotel_id,hotel_amenity.pg_amenity_id AS amenity_id,
 amenity.amenity_name AS amenity_name,amenity.amenity_image AS amenity_image,hotel_amenity.amenity_listing_order AS amenity_listing_order
 from pg_hotel_amenity AS hotel_amenity  left join pg_amenity AS amenity on(hotel_amenity.pg_amenity_id = amenity.amenity_id)
 where (hotel_amenity.is_active = 1)
 order by hotel_amenity.pg_hotel_id,hotel_amenity.amenity_listing_order;


 CREATE PROCEDURE sp_pg_amenities(in  v_hotel_id int(11))
 BEGIN
 SELECT hotel_amenity_id, hotel_id, amenity_id, amenity_name, amenity_image, amenity_listing_order  FROM v_pg_amenities WHERE  hotel_id =  v_hotel_id
 ORDER BY hotel_id, amenity_listing_order ;
 END

 */
@NamedNativeQueries({
        @NamedNativeQuery(
                name = "callSpHotelAmenities",
                query = "CALL sp_hotel_amenities(:v_hotelid )",
                resultClass = HotelAmenityMVO.class
        ),
        @NamedNativeQuery(
        name = "callSpPgAmenities",
        query = "CALL sp_pg_amenities(:v_hotelid )",
        resultClass = HotelAmenityMVO.class
)
})
@Entity
@Table(name = "v_hotel_amenities")
public class HotelAmenityMVO implements java.io.Serializable {
    private static final long serialVersionUID = -6959932263821965109L;
    @Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "hotel_amenity_id", unique = true, nullable = false)
    private Long hotelAmenityId;
    @Column(name = "amenity_id" )
    private Long amenityId;
    @Column(name = "hotel_id")
    private Long hotelId;
    @Column(name = "amenity_name" )
    private String amenityName;
    @Column(name = "amenity_image" )
    private String amenityImage;

    public Long getHotelAmenityId() {
        return hotelAmenityId;
    }

    public void setHotelAmenityId(Long hotelAmenityId) {
        this.hotelAmenityId = hotelAmenityId;
    }

    public Long getAmenityId() {
        return amenityId;
    }

    public void setAmenityId(Long amenityId) {
        this.amenityId = amenityId;
    }

    public Long getHotelId() {
        return hotelId;
    }

    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }

    public String getAmenityName() {
        return amenityName;
    }

    public void setAmenityName(String amenityName) {
        this.amenityName = amenityName;
    }

    public String getAmenityImage() {
        return amenityImage;
    }

    public void setAmenityImage(String amenityImage) {
        this.amenityImage = amenityImage;
    }
}
