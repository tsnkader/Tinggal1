package com.queppelin.wudstay.vo;

import com.queppelin.wudstay.vo.custom.RoomsInventoryForm;

import javax.persistence.*;
import java.util.Date;

import static javax.persistence.GenerationType.IDENTITY;

/**
 * Created by hp on 10/24/2015.

 DROP TABLE IF EXISTS rooms_inventory;

 CREATE TABLE rooms_inventory (
     id          	int(11)     NOT NULL AUTO_INCREMENT,
     hotel_id    	int(11)     NOT NULL,
     no_of_rooms 	int(11)     NOT NULL,
     inv_lngdate 	int(11)     NOT NULL,
     inv_date    	date        NOT NULL,
     last_updated	date DEFAULT NULL,
     PRIMARY KEY (`id`)
 ) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

 *
 */
@Entity
@Table(name = "rooms_inventory" )
public class RoomsInventoryVO implements java.io.Serializable {
    @Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "id", unique = true, nullable = false)
    private Long    id;
    @Column(name = "hotel_id")
    private Long    hotelId;
    @Column(name = "no_of_rooms")
    private Integer    noOfRooms;
    @Column(name = "inv_lngdate")
    private Long  inventoryLongDate;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "inv_date", nullable = false, length = 19)
    private Date    inventoryDate;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "last_updated", nullable = false, length = 19)
    private Date    lastUpdatedDate;


    public RoomsInventoryVO() {
    }

    public RoomsInventoryVO(RoomsInventoryVO vo) {
        long lng = vo.getHotelId();
        this.hotelId = lng;
        int i = vo.getNoOfRooms();
        this.noOfRooms = i;
        lng = vo.getInventoryLongDate();
        this.inventoryLongDate = lng;
        lng = vo.getInventoryDate().getTime();
        this.inventoryDate = new Date(lng);
    }

    public RoomsInventoryVO(RoomsInventoryForm form) {
        this.id = form.getId();
        this.hotelId = form.getHotelId();
        this.noOfRooms = form.getNoOfRooms();
        this.inventoryLongDate = form.getInventoryLongDate().longValue();
        this.inventoryDate = form.getInventoryDate();
        lastUpdatedDate= new Date();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getHotelId() {
        return hotelId;
    }

    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }

    public Integer getNoOfRooms() {
        return noOfRooms;
    }

    public void setNoOfRooms(Integer noOfRooms) {
        this.noOfRooms = noOfRooms;
    }

    public Long getInventoryLongDate() {
        return inventoryLongDate;
    }

    public void setInventoryLongDate(Long inventoryLongDate) {
        this.inventoryLongDate = inventoryLongDate;
    }

    public Date getInventoryDate() {
        return inventoryDate;
    }

    public void setInventoryDate(Date inventoryDate) {
        this.inventoryDate = inventoryDate;
    }

    public Date getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate(Date lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }
}
