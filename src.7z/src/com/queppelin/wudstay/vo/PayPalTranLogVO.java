package com.queppelin.wudstay.vo;

import com.queppelin.wudstay.util.HdfcPaymentUtil;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.util.WudstayMappings;

import javax.persistence.*;
import java.util.Date;

import static javax.persistence.GenerationType.IDENTITY;

/*
drop table paypal_tran_log;

CREATE TABLE paypal_tran_log( log_id INT(11) NOT NULL AUTO_INCREMENT,
name VARCHAR(100)  DEFAULT NULL, phone VARCHAR(25)  DEFAULT NULL, email VARCHAR(100)  DEFAULT NULL, amount VARCHAR(25)  DEFAULT NULL, local_token VARCHAR(60)  DEFAULT NULL, description VARCHAR(250)  DEFAULT NULL,
secure_call_resp_msg VARCHAR(100)  DEFAULT NULL, secure_token_id VARCHAR(60)  DEFAULT NULL, secure_token VARCHAR(60)  DEFAULT NULL, secure_call_result VARCHAR(25)  DEFAULT NULL,
res_pnref VARCHAR(50)  DEFAULT NULL, res_result VARCHAR(25)  DEFAULT NULL, res_trans_time VARCHAR(50)  DEFAULT NULL,
res_txt VARCHAR(25)  DEFAULT NULL, res_country_to_ship VARCHAR(25)  DEFAULT NULL, res_avs_data VARCHAR(25)  DEFAULT NULL, res_amt VARCHAR(25)  DEFAULT NULL,
res_country VARCHAR(25)  DEFAULT NULL, res_acct VARCHAR(25)  DEFAULT NULL, res_tender VARCHAR(25)  DEFAULT NULL, res_trx_type VARCHAR(25)  DEFAULT NULL,
res_ship_to_country VARCHAR(25)  DEFAULT NULL, res_bill_to_country VARCHAR(25)  DEFAULT NULL, res_exp_date VARCHAR(25)  DEFAULT NULL,
res_fps_prexml_data VARCHAR(100)  DEFAULT NULL, res_res_msg VARCHAR(25)  DEFAULT NULL, res_method VARCHAR(25)  DEFAULT NULL, res_card_type VARCHAR(25)  DEFAULT NULL,
res_type VARCHAR(25)  DEFAULT NULL, res_pre_fps_msg VARCHAR(100) DEFAULT NULL, res_others  VARCHAR(500)  DEFAULT NULL , PRIMARY KEY ( log_id ) ) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=latin1;

log_time			timestamp

ALTER TABLE hdfc_tran_log MODIFY reference_no VARCHAR(50);

ALTER TABLE paypal_tran_log ADD COLUMN log_time timestamp; -- DEFAULT NULL;
 */
@Entity
@Table(name = "paypal_tran_log")
public class PayPalTranLogVO implements java.io.Serializable {
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "log_id", nullable = false)
	private Long logId;
	//---------------------------------------------------------
	@Column(name = "log_time", columnDefinition="DATETIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Date logTime =  new Date();
	//---------------------------------------------------------
	@Column(name = "name" )
	private String name = "-";
	@Column(name = "phone" )
	private String phone = "+62822 8539 0099";
	@Column(name = "email" )
	private String email = "support@tinggal.com";
	@Column(name = "amount" )
	private String amount = "0";
	@Column(name = "local_token" )
	private String localToken =""; // 8IsrdYEo9nEWJA7luioOl6wFW
	@Column(name = "description" )
	private String description = ""; //"-";
	//---------------------------------------------------------

	//RESULT=0&RESPMSG=Approved&SECURETOKEN=9hGmbx938mUC7dYgaoyuFrgJ0&SECURETOKENID=eeae8f325729e980ed1c0c6146751656
	@Column(name = "secure_call_resp_msg" )
	private String secureCallRespMsg;       // RESPMSG=Approved
	@Column(name = "secure_token_id" )
	private String secureTokenId = "-";     // SECURETOKENID ---> b941b8aa68132f88bacbfbd42915df67
	@Column(name = "secure_token" )
	private String secureToken;             // SECURETOKEN ---> 8IsrdYEo9nEWJA7luioOl6wFW
	@Column(name = "secure_call_result" )
	private String secureCallResult;        // RESULT=0
	//---------------------------------------------------------

	@Column(name = "res_pnref" )
	private String pnref;               // PNREF ---> A10A8FB568B0  <-- TransactionId
	@Column(name = "res_result" )
	private String result;              // RESULT ---> Param Value: 4 <-- ResponseCode
	@Column(name = "res_trans_time" )
	private String transTime;           // TRANSTIME ---> Param Value: 2016-03-08 04:51:49
	//---------------------------------------------------------

	@Column(name = "res_txt" )
	private String tax;
	@Column(name = "res_country_to_ship" )
	private String countryToShip;
	@Column(name = "res_avs_data" )
	private String avsData;
	@Column(name = "res_amt" )
	private String amt;
	@Column(name = "res_country" )
	private String country;
	@Column(name = "res_acct" )
	private String acct;
	@Column(name = "res_tender" )
	private String tender;
	@Column(name = "res_trx_type" )
	private String trxType;
	@Column(name = "res_ship_to_country" )
	private String shipToCountry;
	@Column(name = "res_bill_to_country" )
	private String billTocountry;
	@Column(name = "res_exp_date" )
	private String expDate;
	@Column(name = "res_fps_prexml_data" )
	private String fpsPrexmlData;
	@Column(name = "res_res_msg" )
	private String respMsg;
	@Column(name = "res_method" )
	private String method;
	@Column(name = "res_card_type" )
	private String cardType;
	@Column(name = "res_type" )
	private String type;
	@Column(name = "res_pre_fps_msg" )
	private String preFpsMsg;

	//---------------------------------------------------------
	@Column(name = "res_others" )
	private String others;


	public Long getLogId() {
		return logId;
	}

	public void setLogId(Long logId) {
		this.logId = logId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getLogTime() {
		return logTime;
	}

	public void setLogTime(Date logTime) {
		this.logTime = logTime;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getLocalToken() {
		return localToken;
	}

	public void setLocalToken(String localToken) {
		this.localToken = localToken;
	}

	public String getSecureCallRespMsg() {
		return secureCallRespMsg;
	}

	public void setSecureCallRespMsg(String secureCallRespMsg) {
		this.secureCallRespMsg = secureCallRespMsg;
	}

	public String getSecureTokenId() {
		return secureTokenId;
	}

	public void setSecureTokenId(String secureTokenId) {
		this.secureTokenId = secureTokenId;
	}

	public String getSecureToken() {
		return secureToken;
	}

	public void setSecureToken(String secureToken) {
		this.secureToken = secureToken;
	}

	public String getSecureCallResult() {
		return secureCallResult;
	}

	public void setSecureCallResult(String secureCallResult) {
		this.secureCallResult = secureCallResult;
	}

	public String getPnref() {
		return pnref;
	}

	public void setPnref(String pnref) {
		this.pnref = pnref;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getTransTime() {
		return transTime;
	}

	public void setTransTime(String transTime) {
		this.transTime = transTime;
	}

	public String getTax() {
		return tax;
	}

	public void setTax(String tax) {
		this.tax = tax;
	}

	public String getCountryToShip() {
		return countryToShip;
	}

	public void setCountryToShip(String countryToShip) {
		this.countryToShip = countryToShip;
	}

	public String getAvsData() {
		return avsData;
	}

	public void setAvsData(String avsData) {
		this.avsData = avsData;
	}

	public String getAmt() {
		return amt;
	}

	public void setAmt(String amt) {
		this.amt = amt;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getAcct() {
		return acct;
	}

	public void setAcct(String acct) {
		this.acct = acct;
	}

	public String getTender() {
		return tender;
	}

	public void setTender(String tender) {
		this.tender = tender;
	}

	public String getTrxType() {
		return trxType;
	}

	public void setTrxType(String trxType) {
		this.trxType = trxType;
	}

	public String getShipToCountry() {
		return shipToCountry;
	}

	public void setShipToCountry(String shipToCountry) {
		this.shipToCountry = shipToCountry;
	}

	public String getBillTocountry() {
		return billTocountry;
	}

	public void setBillTocountry(String billTocountry) {
		this.billTocountry = billTocountry;
	}

	public String getExpDate() {
		return expDate;
	}

	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}

	public String getFpsPrexmlData() {
		return fpsPrexmlData;
	}

	public void setFpsPrexmlData(String fpsPrexmlData) {
		this.fpsPrexmlData = fpsPrexmlData;
	}

	public String getRespMsg() {
		return respMsg;
	}

	public void setRespMsg(String respMsg) {
		this.respMsg = respMsg;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getPreFpsMsg() {
		return preFpsMsg;
	}

	public void setPreFpsMsg(String preFpsMsg) {
		this.preFpsMsg = preFpsMsg;
	}

	public String getOthers() {
		return others;
	}

	public void setOthers(String others) {
		this.others = others;
	}
}
