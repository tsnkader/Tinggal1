package com.queppelin.wudstay.vo;

// Generated 25-Apr-2015 18:44:33 by Hibernate Tools 3.4.0.CR1

import javax.persistence.*;

import static javax.persistence.GenerationType.IDENTITY;

/**
 *
 *
 DROP TABLE IF EXISTS  logs_table ;

 CREATE TABLE  logs_table  (
	 id          int(11)       NOT NULL AUTO_INCREMENT,
	 ref_long    int(11)       DEFAULT NULL,
	 ref_string  varchar(100) DEFAULT NULL,
     description  varchar(1000) DEFAULT NULL,
	 PRIMARY KEY ( id )
 ) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

 CREATE TABLE logs_table ( id int(11) NOT NULL AUTO_INCREMENT, ref_long    int(11) DEFAULT NULL, ref_string  varchar(100) DEFAULT NULL, description  varchar(1000) DEFAULT NULL, PRIMARY KEY (id) ) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;


 */
@Entity
@Table(name = "logs_table")
public class LogsTable implements java.io.Serializable {
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "id", unique = true, nullable = false)
	private Long id;
	@Column(name = "ref_long")
	private Long refLong;
	@Column(name = "ref_string")
	private String refString;
	@Column(name = "description")
	private String description;


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getRefLong() {
		return refLong;
	}

	public void setRefLong(Long refLong) {
		this.refLong = refLong;
	}

	public String getRefString() {
		return refString;
	}

	public void setRefString(String refString) {
		this.refString = refString;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
