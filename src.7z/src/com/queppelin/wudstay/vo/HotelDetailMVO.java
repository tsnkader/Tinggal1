package com.queppelin.wudstay.vo;

import javax.persistence.*;

import static javax.persistence.GenerationType.IDENTITY;

/**
 * Created by hp on 12/23/2015.

 select `hotel_amenity`.`hotel_id` AS `hotel_id`,group_concat(`hotel_amenity`.`amenity_id`
 order by `hotel_amenity`.`amenity_listing_order` ASC separator '# ') AS `amenityIds`,group_concat(`amenity`.`amenity_name`
 order by `hotel_amenity`.`amenity_listing_order` ASC separator ', ') AS `amenityNames`,group_concat(`amenity`.`amenity_image`
 order by `hotel_amenity`.`amenity_listing_order` ASC separator '# ') AS `amenityImages`
 from (`hotel_amenity` left join `amenity` on((`hotel_amenity`.`amenity_id` = `amenity`.`amenity_id`)))
 where (`hotel_amenity`.`is_active` = 1)
 group by `hotel_amenity`.`hotel_id`;


 CREATE VIEW v_pg_amenitys_hotel_wise AS
 select pg_hotel_amenity.pg_hotel_id AS hotel_id,
 group_concat(pg_hotel_amenity.pg_amenity_id order by pg_hotel_amenity.amenity_listing_order ASC separator '# ') AS amenityIds,
 group_concat(pg_amenity.amenity_name     order by pg_hotel_amenity.amenity_listing_order ASC separator ', ') AS amenityNames,
 group_concat(pg_amenity.amenity_image    order by pg_hotel_amenity.amenity_listing_order ASC separator '# ') AS amenityImages
 from pg_hotel_amenity left join pg_amenity on(pg_hotel_amenity.pg_amenity_id = pg_amenity.amenity_id)
 where pg_hotel_amenity.is_active = 1
 group by pg_hotel_amenity.pg_hotel_id;






 DROP VIEW v_hotel_detail;
 CREATE or replace VIEW v_hotel_detail AS
 SELECT  star_rating,
 single_occupancy_price, double_occupancy_price, triple_occupancy_price,
 hotel_display_name, hotel_display_address ,
 hotel.hotel_id AS hotel_id, hotel.location_id AS location_id, location.city_id AS city_id,
 hotel.latitude AS latitude, hotel.longitude AS longitude, hotel.map_link AS map_link
 FROM hotel
 LEFT OUTER JOIN  location ON (hotel.location_id = location.location_id);


 DROP VIEW v_hotel_detail;
 CREATE or replace VIEW v_hotel_detail AS
 SELECT  hotel.hotel_id AS hotel_id, hotel.location_id AS location_id, location.city_id AS city_id,  hotel_display_name, hotel_display_address
 FROM hotel
 LEFT OUTER JOIN  location ON (hotel.location_id = location.location_id);

 DROP PROCEDURE sp_hotel_detail;
 CREATE PROCEDURE sp_hotel_detail(  in  v_city_id int(11),  in  v_sort_on int(11) )
 BEGIN
 SELECT  hotel.hotel_id AS hotel_id, hotel.location_id AS location_id, location.city_id AS city_id,  hotel_display_name, hotel_display_address
 FROM hotel
 LEFT OUTER JOIN  location ON (hotel.location_id = location.location_id);
 END;




 CREATE PROCEDURE `sp_hotel_detail_bycity`(  in  v_city_id int(11),  in  v_sort_on int(11) )
 BEGIN

 IF v_sort_on = 1 THEN
 SELECT  star_rating,
 single_occupancy_price, double_occupancy_price, triple_occupancy_price,
 hotel_display_name, hotel_display_address ,
 hotel.hotel_id AS hotel_id, hotel.location_id AS location_id, location.city_id AS city_id,
 hotel.latitude AS latitude, hotel.longitude AS longitude, hotel.map_link AS map_link,
 amenityIds, amenityNames, amenityImages, room_type_id, how_to_reach
 FROM hotel
 LEFT OUTER JOIN  location ON (hotel.location_id = location.location_id)
 LEFT OUTER JOIN  v_amenitys_hotel_wise amenity ON (hotel.hotel_id = amenity.hotel_id)
 WHERE location.city_id = v_city_id
 ORDER BY star_rating DESC, hotel_display_name ;

 ELSEIF v_sort_on = 2 THEN
 SELECT  star_rating,
 single_occupancy_price, double_occupancy_price, triple_occupancy_price,
 hotel_display_name, hotel_display_address ,
 hotel.hotel_id AS hotel_id, hotel.location_id AS location_id, location.city_id AS city_id,
 hotel.latitude AS latitude, hotel.longitude AS longitude, hotel.map_link AS map_link,
 amenityIds, amenityNames, amenityImages, room_type_id, how_to_reach
 FROM hotel
 LEFT OUTER JOIN  location ON (hotel.location_id = location.location_id)
 LEFT OUTER JOIN  v_amenitys_hotel_wise amenity ON (hotel.hotel_id = amenity.hotel_id)
 WHERE location.city_id = v_city_id
 ORDER BY single_occupancy_price DESC, hotel_display_name;

 ELSEIF v_sort_on = 3 THEN
 SELECT  star_rating,
 single_occupancy_price, double_occupancy_price, triple_occupancy_price,
 hotel_display_name, hotel_display_address ,
 hotel.hotel_id AS hotel_id, hotel.location_id AS location_id, location.city_id AS city_id,
 hotel.latitude AS latitude, hotel.longitude AS longitude, hotel.map_link AS map_link,
 amenityIds, amenityNames, amenityImages, room_type_id, how_to_reach
 FROM hotel
 LEFT OUTER JOIN  location ON (hotel.location_id = location.location_id)
 LEFT OUTER JOIN  v_amenitys_hotel_wise amenity ON (hotel.hotel_id = amenity.hotel_id)
 WHERE location.city_id = v_city_id
 ORDER BY single_occupancy_price ASC, hotel_display_name;

 END IF;
 END;
-- ---------------------------------------
 CREATE PROCEDURE `sp_hotel_detail_byhotelid`(  in  v_hotelid int(11))
 BEGIN

 SELECT  star_rating,
 single_occupancy_price, double_occupancy_price, triple_occupancy_price,
 hotel_display_name, hotel_display_address ,
 hotel.hotel_id AS hotel_id, hotel.location_id AS location_id, location.city_id AS city_id,
 hotel.latitude AS latitude, hotel.longitude AS longitude, hotel.map_link AS map_link,
 amenityIds, amenityNames, amenityImages, room_type_id, how_to_reach
 FROM hotel
 LEFT OUTER JOIN  location ON (hotel.location_id = location.location_id)
 LEFT OUTER JOIN  v_amenitys_hotel_wise amenity ON (hotel.hotel_id = amenity.hotel_id)
 WHERE hotel.hotel_id = v_hotelid
 ORDER BY star_rating DESC, hotel_display_name ;

 END;



 CREATE PROCEDURE sp_pg_detail_bycity(  in  v_city_id int(11),  in  v_sort_on int(11) )
 BEGIN

 IF v_sort_on = 1 THEN
 SELECT  star_rating,
 single_occupancy_wprice as single_occupancy_price, double_occupancy_wprice as double_occupancy_price, triple_occupancy_wprice as triple_occupancy_price,
 pg_display_name AS hotel_display_name, pg_display_address AS hotel_display_address ,
 hotel.pg_id AS hotel_id, hotel.location_id AS location_id, location.city_id AS city_id,
 hotel.latitude AS latitude, hotel.longitude AS longitude, hotel.map_link AS map_link,
 amenityIds, amenityNames, amenityImages, pg_type_id AS room_type_id, how_to_reach
 FROM pg_hotel hotel
 LEFT OUTER JOIN  location ON (hotel.location_id = location.location_id)
 LEFT OUTER JOIN  v_pg_amenitys_hotel_wise amenity ON (hotel.pg_id = amenity.hotel_id)
 WHERE location.city_id = v_city_id
 ORDER BY star_rating DESC, hotel_display_name ;

 ELSEIF v_sort_on = 2 THEN
 SELECT  star_rating,
 single_occupancy_wprice as single_occupancy_price, double_occupancy_wprice as double_occupancy_price, triple_occupancy_wprice as triple_occupancy_price,
 pg_display_name AS hotel_display_name, pg_display_address AS hotel_display_address ,
 hotel.pg_id AS hotel_id, hotel.location_id AS location_id, location.city_id AS city_id,
 hotel.latitude AS latitude, hotel.longitude AS longitude, hotel.map_link AS map_link,
 amenityIds, amenityNames, amenityImages, pg_type_id AS room_type_id, how_to_reach
 FROM pg_hotel hotel
 LEFT OUTER JOIN  location ON (hotel.location_id = location.location_id)
 LEFT OUTER JOIN  v_pg_amenitys_hotel_wise amenity ON (hotel.pg_id = amenity.hotel_id)
 WHERE location.city_id = v_city_id
 ORDER BY single_occupancy_price DESC, hotel_display_name;

 ELSEIF v_sort_on = 3 THEN
 SELECT  star_rating,
 single_occupancy_wprice as single_occupancy_price, double_occupancy_wprice as double_occupancy_price, triple_occupancy_wprice as triple_occupancy_price,
 pg_display_name AS hotel_display_name, pg_display_address AS hotel_display_address ,
 hotel.pg_id AS hotel_id, hotel.location_id AS location_id, location.city_id AS city_id,
 hotel.latitude AS latitude, hotel.longitude AS longitude, hotel.map_link AS map_link,
 amenityIds, amenityNames, amenityImages, pg_type_id AS room_type_id, how_to_reach
 FROM pg_hotel hotel
 LEFT OUTER JOIN  location ON (hotel.location_id = location.location_id)
 LEFT OUTER JOIN  v_pg_amenitys_hotel_wise amenity ON (hotel.pg_id = amenity.hotel_id)
 WHERE location.city_id = v_city_id
 ORDER BY single_occupancy_price ASC, hotel_display_name;

 END IF;

 END;



 CREATE PROCEDURE  sp_pg_detail_byhotelid (  in  v_hotelid int(11))
 BEGIN

 SELECT  star_rating,
 single_occupancy_wprice as single_occupancy_price, double_occupancy_wprice as double_occupancy_price, triple_occupancy_wprice as triple_occupancy_price,
 pg_display_name AS hotel_display_name, pg_display_address AS hotel_display_address ,
 hotel.pg_id AS hotel_id, hotel.location_id AS location_id, location.city_id AS city_id,
 hotel.latitude AS latitude, hotel.longitude AS longitude, hotel.map_link AS map_link,
 amenityIds, amenityNames, amenityImages, pg_type_id AS room_type_id, how_to_reach
 FROM pg_hotel hotel
 LEFT OUTER JOIN  location ON (hotel.location_id = location.location_id)
 LEFT OUTER JOIN  v_pg_amenitys_hotel_wise amenity ON (hotel.pg_id = amenity.hotel_id)
 WHERE hotel.pg_id = v_hotelid
 ORDER BY single_occupancy_price ASC, hotel_display_name;

 END;
 */
@NamedNativeQueries({
        @NamedNativeQuery(
                name = "callSpHotelDetailByCity",
                query = "CALL sp_hotel_detail_bycity(:v_city_id, :v_sort_on)",
                resultClass = HotelDetailMVO.class
        ),
        @NamedNativeQuery(
                name = "callSpHotelDetail",
                query = "CALL sp_hotel_detail_byhotelid(:v_hotelid)",
                resultClass = HotelDetailMVO.class
        ),
        @NamedNativeQuery(
                name = "callSpPgDetailByCity",
                query = "CALL sp_pg_detail_bycity(:v_city_id, :v_sort_on)",
                resultClass = HotelDetailMVO.class
        ),
        @NamedNativeQuery(
                name = "callSpPgDetail",
                query = "CALL sp_pg_detail_byhotelid(:v_hotelid)",
                resultClass = HotelDetailMVO.class
        )
})

@Entity
@Table(name = "v_hotel_detail")
public class HotelDetailMVO implements java.io.Serializable {
    private static final long serialVersionUID = 4191179348356472894L;

    @Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "hotel_id", unique = true, nullable = false)
    private Long hotelId;
    @Column(name = "location_id" )
    private Long locationId;
    @Column(name = "city_id" )
    private Long cityId;
    @Column(name = "hotel_display_name" )
    private String hotelDisplayName;
    @Column(name = "hotel_display_address" )
    private String hotelDisplayAddress;
    @Column(name = "star_rating" )
    private Integer starRating;

    @Column(name = "latitude" )
    private Double latitude;
    @Column(name = "longitude" )
    private Double longitude;
    @Column(name = "map_link" )
    private String mapLink;
    @Column(name = "single_occupancy_price" )
    private Integer singleOccupancyPrice;
    @Column(name = "double_occupancy_price" )
    private Integer doubleOccupancyPrice;
    @Column(name = "triple_occupancy_price" )
    private Integer tripleOccupancyPrice;

    @Column(name = "amenityIds" )
    private String amenityIds;
    @Column(name = "amenityNames" )
    private String amenityNames;
    @Column(name = "amenityImages" )
    private String amenityImages;
    @Column(name = "room_type_id" )
    private Long roomTypeId;
    @Column(name = "how_to_reach" )
    private String howToReach;



    public Long getHotelId() {
        return hotelId;
    }

    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }

    public Long getLocationId() {
        return locationId;
    }

    public void setLocationId(Long locationId) {
        this.locationId = locationId;
    }

    public Long getCityId() {
        return cityId;
    }

    public void setCityId(Long cityId) {
        this.cityId = cityId;
    }

    public String getHotelDisplayName() {
        return hotelDisplayName;
    }

    public void setHotelDisplayName(String hotelDisplayName) {
        this.hotelDisplayName = hotelDisplayName;
    }

    public String getHotelDisplayAddress() {
        return hotelDisplayAddress;
    }

    public void setHotelDisplayAddress(String hotelDisplayAddress) {
        this.hotelDisplayAddress = hotelDisplayAddress;
    }

    public Integer getStarRating() {
        return starRating;
    }

    public void setStarRating(Integer starRating) {
        this.starRating = starRating;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public String getMapLink() {
        return mapLink;
    }

    public void setMapLink(String mapLink) {
        this.mapLink = mapLink;
    }

    public Integer getSingleOccupancyPrice() {
        return singleOccupancyPrice;
    }

    public void setSingleOccupancyPrice(Integer singleOccupancyPrice) {
        this.singleOccupancyPrice = singleOccupancyPrice;
    }

    public Integer getDoubleOccupancyPrice() {
        return doubleOccupancyPrice;
    }

    public void setDoubleOccupancyPrice(Integer doubleOccupancyPrice) {
        this.doubleOccupancyPrice = doubleOccupancyPrice;
    }

    public Integer getTripleOccupancyPrice() {
        return tripleOccupancyPrice;
    }

    public void setTripleOccupancyPrice(Integer tripleOccupancyPrice) {
        this.tripleOccupancyPrice = tripleOccupancyPrice;
    }

    public String getAmenityIds() {
        return amenityIds;
    }

    public void setAmenityIds(String amenityIds) {
        this.amenityIds = amenityIds;
    }

    public String getAmenityNames() {
        return amenityNames;
    }

    public void setAmenityNames(String amenityNames) {
        this.amenityNames = amenityNames;
    }

    public String getAmenityImages() {
        return amenityImages;
    }

    public void setAmenityImages(String amenityImages) {
        this.amenityImages = amenityImages;
    }

    public Long getRoomTypeId() {
        return roomTypeId;
    }

    public void setRoomTypeId(Long roomTypeId) {
        this.roomTypeId = roomTypeId;
    }

    public String getHowToReach() {
        return howToReach;
    }

    public void setHowToReach(String howToReach) {
        this.howToReach = howToReach;
    }
}
