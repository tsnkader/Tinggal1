package com.queppelin.wudstay.vo.custom;

public class BookingGuest {
	public String guestName;
	public String guestEmail;
	public String guestContactNumber;

	public BookingGuest(){}
	public BookingGuest(String guestName, String guestEmail, String guestContactNumber) {
		this.guestName = guestName;
		this.guestEmail = guestEmail;
		this.guestContactNumber = guestContactNumber;
	}

	public String getGuestName() {
		return guestName;
	}

	public void setGuestName(String guestName) {
		this.guestName = guestName;
	}

	public String getGuestEmail() {
		return guestEmail;
	}

	public void setGuestEmail(String guestEmail) {
		this.guestEmail = guestEmail;
	}

	public String getGuestContactNumber() {
		return guestContactNumber;
	}

	public void setGuestContactNumber(String guestContactNumber) {
		this.guestContactNumber = guestContactNumber;
	}
}
