package com.queppelin.wudstay.vo.custom;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.queppelin.wudstay.vo.RoomTypeMaster;

public class HotelVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1828134899734827816L;
	
	private Long hotelId;
	
	private Long userId;	
	
	private Long cityId;
	
	private Long locationId;
	
	private Long roomTypeId;
	
	private Long roomTypeMasterId;
	
	public Long getRoomTypeMasterId() {
		return roomTypeMasterId;
	}

	public void setRoomTypeMasterId(Long roomTypeMasterId) {
		this.roomTypeMasterId = roomTypeMasterId;
	}

	private String hotelName;
	
	private String hotelDisplayName;
	
	private String hotelAddress;
	
	private String howToReach;
	
	private Integer starRating;
	
	private String amenities[];
	
	private String username;
	
	private String userFullName;
	
	private String email;
	
	private String mobileNumber;
	
	private String password;
	
	private Boolean isActiveUser;
	
	private Boolean isActiveHotel;

	private int breakfastIncludedInPrice;
	
	private String cityName;
	
	private String locationName;
	
	private Double latitude;
	
	private Double longitude;
	
	private MultipartFile hotelImages[];
	
	private MultipartFile roomImage;
	
	//private Integer price;
	
	private Integer singleOccupancyPrice;
	
	private Integer doubleOccupancyPrice;
	
	private Integer tripleOccupancyPrice;
	
	private Integer singleOccupancyContractualPrice;
	
	private Integer doubleOccupancyContractualPrice;
	
	private Integer tripleOccupancyContractualPrice;
	
	private Integer maxBookingPerMobNum;
	
	private String mapLink;
	
	private String hotelDisplayAddress;
	
	private String contactPersonName1;
	
	private String contactPersonName2;
	
	private String contactPersonNumber1;
	
	private String contactPersonNumber2;
	
	private String contactPersonEmail1;
	
	private String contactPersonEmail2;
	
	private List<RoomTypeVO> roomTypeVOList = new ArrayList<RoomTypeVO>();
	private List<SurchargeOnPrice> surchargeOnPriceList = new ArrayList<SurchargeOnPrice>();
	
	public List<RoomTypeMasterVO> getRoomTypeMasterVOList() {
		return roomTypeMasterVOList;
	}


	public void setRoomTypeMasterVOList(List<RoomTypeMasterVO> roomTypeMasterVOList) {
		this.roomTypeMasterVOList = roomTypeMasterVOList;
	}

	private List<RoomTypeMasterVO> roomTypeMasterVOList = new ArrayList<RoomTypeMasterVO>();
	
	private List<HotelDescriptionVO> hotelDescriptionVOList = new ArrayList<HotelDescriptionVO>();
	
	private List<HotelRoomVO> hotelRoomVOList = new ArrayList<HotelRoomVO>();

	private Integer noOfRooms;
	private String validFromDate;
	private String validToDate;
	private Integer allowTripleOccupancy = 1;

	public Integer getSingleOccupancyContractualPrice() {
		return singleOccupancyContractualPrice;
	}

	public void setSingleOccupancyContractualPrice(
			Integer singleOccupancyContractualPrice) {
		this.singleOccupancyContractualPrice = singleOccupancyContractualPrice;
	}

	public Integer getDoubleOccupancyContractualPrice() {
		return doubleOccupancyContractualPrice;
	}

	public void setDoubleOccupancyContractualPrice(
			Integer doubleOccupancyContractualPrice) {
		this.doubleOccupancyContractualPrice = doubleOccupancyContractualPrice;
	}

	public Integer getTripleOccupancyContractualPrice() {
		return tripleOccupancyContractualPrice;
	}

	public void setTripleOccupancyContractualPrice(
			Integer tripleOccupancyContractualPrice) {
		this.tripleOccupancyContractualPrice = tripleOccupancyContractualPrice;
	}
	
	public Long getCityId() {
		return cityId;
	}

	public void setCityId(Long cityId) {
		this.cityId = cityId;
	}

	public Long getLocationId() {
		return locationId;
	}

	public void setLocationId(Long locationId) {
		this.locationId = locationId;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public String getHotelDisplayName() {
		return hotelDisplayName;
	}

	public void setHotelDisplayName(String hotelDisplayName) {
		this.hotelDisplayName = hotelDisplayName;
	}

	public String getHotelAddress() {
		return hotelAddress;
	}

	public void setHotelAddress(String hotelAddress) {
		this.hotelAddress = hotelAddress;
	}

	public Integer getStarRating() {
		return starRating;
	}

	public void setStarRating(Integer starRating) {
		this.starRating = starRating;
	}

	public String[] getAmenities() {
		return amenities;
	}

	public void setAmenities(String[] amenities) {
		this.amenities = amenities;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Boolean getIsActiveUser() {
		return isActiveUser;
	}

	public void setIsActiveUser(Boolean isActiveUser) {
		this.isActiveUser = isActiveUser;
	}

	public Boolean getIsActiveHotel() {
		return isActiveHotel;
	}

	public void setIsActiveHotel(Boolean isActiveHotel) {
		this.isActiveHotel = isActiveHotel;
	}

	public int getBreakfastIncludedInPrice() {
		return breakfastIncludedInPrice;
	}

	public void setBreakfastIncludedInPrice(int breakfastIncludedInPrice) {
		this.breakfastIncludedInPrice = breakfastIncludedInPrice;
	}

	public List<RoomTypeVO> getRoomTypeVOList() {
		return roomTypeVOList;
	}

	public void setRoomTypeVOList(List<RoomTypeVO> roomTypeVOList) {
		this.roomTypeVOList = roomTypeVOList;
	}

	public List<SurchargeOnPrice> getSurchargeOnPriceList() {
		return surchargeOnPriceList;
	}

	public void setSurchargeOnPriceList(List<SurchargeOnPrice> surchargeOnPriceList) {
		this.surchargeOnPriceList = surchargeOnPriceList;
	}

	public List<HotelDescriptionVO> getHotelDescriptionVOList() {
		return hotelDescriptionVOList;
	}

	public void setHotelDescriptionVOList(
			List<HotelDescriptionVO> hotelDescriptionVOList) {
		this.hotelDescriptionVOList = hotelDescriptionVOList;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public Long getHotelId() {
		return hotelId;
	}

	public void setHotelId(Long hotelId) {
		this.hotelId = hotelId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public List<HotelRoomVO> getHotelRoomVOList() {
		return hotelRoomVOList;
	}

	public void setHotelRoomVOList(List<HotelRoomVO> hotelRoomVOList) {
		this.hotelRoomVOList = hotelRoomVOList;
	}

	public MultipartFile[] getHotelImages() {
		return hotelImages;
	}

	public void setHotelImages(MultipartFile[] hotelImages) {
		this.hotelImages = hotelImages;
	}

	public MultipartFile getRoomImage() {
		return roomImage;
	}

	public void setRoomImage(MultipartFile roomImage) {
		this.roomImage = roomImage;
	}

	public Long getRoomTypeId() {
		return roomTypeId;
	}

	public void setRoomTypeId(Long roomTypeId) {
		this.roomTypeId = roomTypeId;
	}

	public String getHowToReach() {
		return howToReach;
	}

	public void setHowToReach(String howToReach) {
		this.howToReach = howToReach;
	}

	/*public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}*/

	public String getMapLink() {
		return mapLink;
	}

	public void setMapLink(String mapLink) {
		this.mapLink = mapLink;
	}

	public String getHotelDisplayAddress() {
		return hotelDisplayAddress;
	}

	public void setHotelDisplayAddress(String hotelDisplayAddress) {
		this.hotelDisplayAddress = hotelDisplayAddress;
	}

	public String getContactPersonName1() {
		return contactPersonName1;
	}

	public void setContactPersonName1(String contactPersonName1) {
		this.contactPersonName1 = contactPersonName1;
	}

	public String getContactPersonName2() {
		return contactPersonName2;
	}

	public void setContactPersonName2(String contactPersonName2) {
		this.contactPersonName2 = contactPersonName2;
	}

	public String getContactPersonNumber1() {
		return contactPersonNumber1;
	}

	public void setContactPersonNumber1(String contactPersonNumber1) {
		this.contactPersonNumber1 = contactPersonNumber1;
	}

	public String getContactPersonNumber2() {
		return contactPersonNumber2;
	}

	public void setContactPersonNumber2(String contactPersonNumber2) {
		this.contactPersonNumber2 = contactPersonNumber2;
	}

	public String getContactPersonEmail1() {
		return contactPersonEmail1;
	}

	public void setContactPersonEmail1(String contactPersonEmail1) {
		this.contactPersonEmail1 = contactPersonEmail1;
	}

	public String getContactPersonEmail2() {
		return contactPersonEmail2;
	}

	public void setContactPersonEmail2(String contactPersonEmail2) {
		this.contactPersonEmail2 = contactPersonEmail2;
	}

	public Integer getSingleOccupancyPrice() {
		return singleOccupancyPrice;
	}

	public void setSingleOccupancyPrice(Integer singleOccupancyPrice) {
		this.singleOccupancyPrice = singleOccupancyPrice;
	}

	public Integer getDoubleOccupancyPrice() {
		return doubleOccupancyPrice;
	}

	public void setDoubleOccupancyPrice(Integer doubleOccupancyPrice) {
		this.doubleOccupancyPrice = doubleOccupancyPrice;
	}

	public Integer getTripleOccupancyPrice() {
		return tripleOccupancyPrice;
	}

	public void setTripleOccupancyPrice(Integer tripleOccupancyPrice) {
		this.tripleOccupancyPrice = tripleOccupancyPrice;
	}

	public Integer getMaxBookingPerMobNum() {
		return maxBookingPerMobNum;
	}

	public void setMaxBookingPerMobNum(Integer maxBookingPerMobNum) {
		this.maxBookingPerMobNum = maxBookingPerMobNum;
	}

	public Integer getNoOfRooms() {
		return noOfRooms;
	}

	public void setNoOfRooms(Integer noOfRooms) {
		this.noOfRooms = noOfRooms;
	}

	public String getValidFromDate() {
		return validFromDate;
	}

	public void setValidFromDate(String validFromDate) {
		this.validFromDate = validFromDate;
	}

	public String getValidToDate() {
		return validToDate;
	}

	public void setValidToDate(String validToDate) {
		this.validToDate = validToDate;
	}

	public Integer getAllowTripleOccupancy() {
		return allowTripleOccupancy;
	}

	public void setAllowTripleOccupancy(Integer allowTripleOccupancy) {
		this.allowTripleOccupancy = allowTripleOccupancy;
	}
}
