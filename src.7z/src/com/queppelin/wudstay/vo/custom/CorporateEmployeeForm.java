package com.queppelin.wudstay.vo.custom;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CorporateEmployeeForm implements java.io.Serializable {
	//com.queppelin.wudstay.vo.CorporateEmployeeVO
	public String 	bookingId;

	public String 	bookingName;
	public Date 	checkin;
	public Date 	checkout;
	public String 	city;
	public String 	location;
	public String 	roomType;
	public String 	guestRequest="";


	private List<Employee> listEmployee = new ArrayList<Employee>();

	public CorporateEmployeeForm() {
	}
	public CorporateEmployeeForm(List<Employee> listEmployee, String bookingName, Date checkin, Date checkout, String city,
								 String location) {
		this.listEmployee = listEmployee;
		this.bookingName = bookingName;
		this.checkin = checkin;
		this.checkout = checkout;
		this.city = city;
		this.location = location;
	}

	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	public List<Employee> getListEmployee() {
		return listEmployee;
	}

	public void setListEmployee(List<Employee> listEmployee) {
		this.listEmployee = listEmployee;
	}

	public String getBookingName() {
		return bookingName;
	}
	public void setBookingName(String bookingName) {
		this.bookingName = bookingName;
	}
	public Date getCheckin() {
		return checkin;
	}
	public void setCheckin(Date checkin) {
		this.checkin = checkin;
	}
	public Date getCheckout() {
		return checkout;
	}
	public void setCheckout(Date checkout) {
		this.checkout = checkout;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}

	public void addEmployee(Employee bookingGuest) {
		if(listEmployee==null) {
			listEmployee = new ArrayList<Employee>();
		}
		this.listEmployee.add(bookingGuest);
	}

	public void addEmployee(String guestName, String guestEmail, String guestContactNumber) {
		this.listEmployee.add(new Employee(guestName, guestEmail, guestContactNumber));
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public String getGuestRequest() {
		return guestRequest;
	}

	public void setGuestRequest(String guestRequest) {
		this.guestRequest = guestRequest;
	}
}
