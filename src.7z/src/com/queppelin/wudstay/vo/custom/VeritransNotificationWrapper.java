package com.queppelin.wudstay.vo.custom;

import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Created by hp on 5/17/2016.
 */
public class VeritransNotificationWrapper implements java.io.Serializable {
    private String statusCode;        //status_code;
    private String statusMessage;     //status_message;
    private String transactionId;     //transaction_id;
    private String orderId;           //order_id;
    private String paymentType;       //payment_type;
    private String transactionTime;   //transaction_time;
    private String transactionStatus; //transaction_status;
    private String grossAmount;       //gross_amount;
    private String signatureKey;      //signature_key;
//-----------------------------------------------------
    private String maskedCard;        //masked_card;
    private String fraudStatus;       //fraud_status;
    private String approvalCode;      //approval_code;
    private String bank;              //bank;
    private String eci;               //eci;
//-------------------------------------------------------
    private String permataVaNumber;   //permata_va_number;

    private String other="";

    private Map<String, String> map = new HashMap<String, String>();

    private String stringValue(Object obj){
        String val = "EMPTY";
        if(obj==null){
            val = "NULL";
        }else{
            try{
                val = obj.toString();
            }catch (Exception ex){
                //val = "NULL";
                val = "ERROR-" + ex.toString();
            }
        }
        return val.trim();
    }
    /*protected Map<String, Object> getProperties(JSONObject object) throws JSONException {
        Map<String, Object> props = Maps.newHashMapWithExpectedSize(object.length() * 2);
        object = object.getJSONObject(DATA);
        Iterator<?> keys = object.keys();
        while (keys.hasNext()) {
            String key = keys.next().toString();
            Object o = object.get(key);
            props.put(key, o);
        }
        return props;
    }*/

    public void getProperties(JSONObject jsonObject)  throws JSONException {
        statusCode = jsonObject.getString("status_code");
        /*timeStamp = jsonObject.getLong("timeStamp");
        ipAddress = jsonObject.getString("ipAddress");
        countryCode = jsonObject.getString("countryCode");
        zipCode = jsonObject.getString("zipCode");
        itemCategory = jsonObject.getString("itemCategory");
        paymentAmount = jsonObject.getDouble("paymentAmount");
        vendorId = jsonObject.getString("vendorId");
        isCardPresent = jsonObject.getBoolean("isCardPresent");*/
    }

    public VeritransNotificationWrapper(String json) {
        /*try{
            JSONObject json = JSONObject.fromObject(jsonMessage);
            Node(JSONObject object)
            String to = (String) json.get("send_to");
            String title = (String) json.get("email_subject");
            String content = (String) json.get("email_content");
        }*/
        try {
            JSONObject jsonObject = new JSONObject(json);
            getProperties(jsonObject);
            System.out.println("-------------");
        }catch (Exception ex){
            ex.printStackTrace();
        }

        try {
            JsonFactory factory = new JsonFactory();
            ObjectMapper mapper = new ObjectMapper(factory);
            TypeReference<HashMap<String, String>> typeRef = new TypeReference<HashMap<String, String>>() { };
            HashMap<String, String> jsonMap = mapper.readValue(json, typeRef);
            System.out.println("Got " + jsonMap);

            Iterator it = jsonMap.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry pair = (Map.Entry)it.next();
                String key = stringValue(pair.getKey());
                String value = stringValue(pair.getValue());
                //System.out.println(key + " = " + value);

                if("status_code".equalsIgnoreCase(key)){
                    this.statusCode = value; }
                else if("status_message".equalsIgnoreCase(key)){
                    this.statusMessage = value;
                }else if("transaction_id".equalsIgnoreCase(key)) {
                    this.transactionId = value;
                }else if("order_id".equalsIgnoreCase(key)){
                    this.orderId = value;
                }else if("payment_type".equalsIgnoreCase(key)){
                    this.paymentType = value;
                }else if("transaction_time".equalsIgnoreCase(key)){
                    this.transactionTime = value;
                }else if("transaction_status".equalsIgnoreCase(key)){
                    this.transactionStatus = value;
                }else if("gross_amount".equalsIgnoreCase(key)){
                    this.grossAmount = value;
                }else if("signature_key".equalsIgnoreCase(key)){
                    this.signatureKey = value;
                }else if("masked_card".equalsIgnoreCase(key)){
                    this.maskedCard = value;
                }else if("fraud_status".equalsIgnoreCase(key)){
                    this.fraudStatus = value;
                }else if("approval_code".equalsIgnoreCase(key)){
                    this.approvalCode = value;
                }else if("bank".equalsIgnoreCase(key)){
                    this.bank = value;
                }else if("eci".equalsIgnoreCase(key)){
                    this.eci = value;
                }else if("permata_va_number".equalsIgnoreCase(key)){
                    this.permataVaNumber = value;
                }else {
                    map.put(key, value);
                }
            }
        }catch (Exception ex){
            map.put("Error", ex.getMessage());
            map.put("JSON", json);
        }
    }


    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public String getTransactionTime() {
        return transactionTime;
    }

    public void setTransactionTime(String transactionTime) {
        this.transactionTime = transactionTime;
    }

    public String getTransactionStatus() {
        return transactionStatus;
    }

    public void setTransactionStatus(String transactionStatus) {
        this.transactionStatus = transactionStatus;
    }

    public String getGrossAmount() {
        return grossAmount;
    }

    public void setGrossAmount(String grossAmount) {
        this.grossAmount = grossAmount;
    }

    public String getSignatureKey() {
        return signatureKey;
    }

    public void setSignatureKey(String signatureKey) {
        this.signatureKey = signatureKey;
    }

    public String getMaskedCard() {
        return maskedCard;
    }

    public void setMaskedCard(String maskedCard) {
        this.maskedCard = maskedCard;
    }

    public String getFraudStatus() {
        return fraudStatus;
    }

    public void setFraudStatus(String fraudStatus) {
        this.fraudStatus = fraudStatus;
    }

    public String getApprovalCode() {
        return approvalCode;
    }

    public void setApprovalCode(String approvalCode) {
        this.approvalCode = approvalCode;
    }

    public String getBank() {
        return bank;
    }

    public void setBank(String bank) {
        this.bank = bank;
    }

    public String getEci() {
        return eci;
    }

    public void setEci(String eci) {
        this.eci = eci;
    }

    public String getPermataVaNumber() {
        return permataVaNumber;
    }

    public void setPermataVaNumber(String permataVaNumber) {
        this.permataVaNumber = permataVaNumber;
    }

    public String getOther() {
        String json ="{";
        Iterator it = map.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry)it.next();
            String key = (String) pair.getKey();
            String value = (String) pair.getValue();
            json = json + key + ":" + value + ", ";
        }
        json = json + "}";
        return other;
    }

    public void setOther(String other) {
        //this.other = other;
    }
}
