package com.queppelin.wudstay.vo.custom;

import com.queppelin.wudstay.vo.SurchargeOnPriceVO;

import java.util.Date;

/**
 * Created by hp on 4/28/2016.
 */
public class SurchargeOnPrice implements java.io.Serializable {
    private Long id;
    private Long hotelId;

    private Integer singleOccupancySurcharge=0;
    private Integer doubleOccupancySurcharge=0;
    private Integer tripleOccupancySurcharge=0;

    private Date inventoryDate;

    private Date inventoryFromDate;
    private Date inventoryToDate;

    private Long strInventoryDate;
    private Long uniqueKey;

    public SurchargeOnPrice(){}
    public SurchargeOnPrice(SurchargeOnPriceVO surchargeOnPriceVO){
        this.id=surchargeOnPriceVO.getId();
        this.hotelId=surchargeOnPriceVO.getHotelId();
        this.singleOccupancySurcharge=surchargeOnPriceVO.getSingleOccupancySurcharge();
        this.doubleOccupancySurcharge=surchargeOnPriceVO.getDoubleOccupancySurcharge();
        this.tripleOccupancySurcharge=surchargeOnPriceVO.getTripleOccupancySurcharge();
        this.inventoryDate=surchargeOnPriceVO.getInventoryDate();
        this.strInventoryDate=surchargeOnPriceVO.getStrInventoryDate();
        this.uniqueKey=surchargeOnPriceVO.getUniqueKey();

    }


}
