
package com.queppelin.wudstay.vo.custom.wibmo;

import org.codehaus.jackson.map.ObjectMapper;

import java.io.IOException;
import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Preetham
 */
public class DataPickupRequest implements Serializable{
	
	public static final Logger logger = Logger.getLogger(DataPickupRequest.class.getName());
	private static final long serialVersionUID = 1L;
	
	//Format to be used: 
	//wpay|<merchant_id>|<mer_app_id>|<mer_txn_id>|<wibmo_txn_id>|<datapickup_code>|<hashkey>|
	private String msgHash;
	private String wibmoTxnId;
	private String dataPickupCode;
	private String merTxnId;
	private MerchantInfo merchantInfo;

	public DataPickupRequest(String msgHash, String wibmoTxnId, String dataPickupCode, String merTxnId, MerchantInfo merchantInfo) {
		this.msgHash = msgHash;
		this.wibmoTxnId = wibmoTxnId;
		this.dataPickupCode = dataPickupCode;
		this.merTxnId = merTxnId;
		this.merchantInfo = merchantInfo;
	}
	public DataPickupRequest(){}

	public String getMsgHash() {
		return msgHash;
	}

	public void setMsgHash(String msgHash) {
		this.msgHash = msgHash;
	}

	public String getWibmoTxnId() {
		return wibmoTxnId;
	}
	
	public void setWibmoTxnId(String wibmoTxnId) {
		this.wibmoTxnId = wibmoTxnId;
	}

	public String getDataPickupCode() {
		return dataPickupCode;
	}

	public void setDataPickupCode(String dataPickupCode) {
		this.dataPickupCode = dataPickupCode;
	}

	public MerchantInfo getMerchantInfo() {
		return merchantInfo;
	}

	public void setMerchantInfo(MerchantInfo merchantInfo) {
		this.merchantInfo = merchantInfo;
	}
	
	public String getMerTxnId() {
		return merTxnId;
	}

	public void setMerTxnId(String merTxnId) {
		this.merTxnId = merTxnId;
	}
	
    private static final ObjectMapper mapper = new ObjectMapper();
    public String toJSON() throws IOException{
        try {
            return mapper.writeValueAsString(this);
        } catch(IOException e) {
            logger.log(Level.WARNING, "Exception", e);
            throw e;
        }
    }

}
