package com.queppelin.wudstay.vo.custom.wibmo;

import java.io.Serializable;
import java.util.logging.Logger;

/**
 *
 * @author Preetham Hegde
 *
"customerInfo":
{"custEmail":"jpr_surendra@yahoo.co.in","custMobile":"9928092639","custName":"Surendra Singh Rathore", "custDob":null},

 */
public class CustomerInfo implements Serializable{
	
	public static final Logger logger = Logger.getLogger(CustomerInfo.class.getName());
	private static final long serialVersionUID = 1L;
	
	private String custEmail;
	private String custMobile;
	private String custName;
	private String custDob;

    
    public String getCustEmail() {
        return custEmail;
    }
    
    public void setCustEmail(String custEmail) {
        this.custEmail = custEmail;
    }
    
    public String getCustMobile() {
        return custMobile;
    }
    
    public void setCustMobile(String custMobile) {
        this.custMobile = custMobile;
    }
    
    public String getCustName() {
        return custName;
    }
    
    public void setCustName(String custName) {
        this.custName = custName;
    }
    
    public String getCustDob() {
        return custDob;
    }
    
    public void setCustDob(String custDob) {
        this.custDob = custDob;
    }
    
}
