package com.queppelin.wudstay.vo.custom.wibmo;

/**
 * Created by hp on 12/18/2015.
 */
public class PayZappTransactionInfo implements java.io.Serializable {
    private String txnAmount;
    private String txnCurrency = "356";
    private String txnDesc = "";
    private String[] supportedPaymentType = {"w.ds.pt.card_visa","w.ds.pt.card_mastercard"};
    private String merAppData = "";
    private String merTxnId = "";


}
