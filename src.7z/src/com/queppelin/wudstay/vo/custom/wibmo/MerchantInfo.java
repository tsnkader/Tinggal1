package com.queppelin.wudstay.vo.custom.wibmo;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.io.Serializable;

/**
 *
 * @author Preetham
 * {"merId":"35507426706359493372","merCountryCode":"IN","merAppId":"7980"},
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class MerchantInfo  implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String merId;
	private String merCountryCode;
	private String merAppId;

	public MerchantInfo(String merId, String merAppId, String merCountryCode) {
		this.merId = merId;
		this.merCountryCode = merCountryCode;
		this.merAppId = merAppId;
	}
	public MerchantInfo(){}

	public String getMerAppId() {
		return merAppId;
	}

	public void setMerAppId(String merAppId) {
		this.merAppId = merAppId;
	}
	
	public String getMerId() {
		return merId;
	}

	public void setMerId(String merId) {
		this.merId = merId;
	}

	public String getMerCountryCode() {
		return merCountryCode;
	}

	public void setMerCountryCode(String merCountryCode) {
		this.merCountryCode = merCountryCode;
	}
}
