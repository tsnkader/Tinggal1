package com.queppelin.wudstay.vo.custom.wibmo;

import org.codehaus.jackson.map.ObjectMapper;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Preetham
 */
public class WPayDataPickupResponse  extends GenericResponse {
	
	public static final Logger logger = Logger.getLogger(WPayDataPickupResponse.class.getName());
	private static final long serialVersionUID = 1L;
	
	private InAppPickupData data;
	
	public InAppPickupData getData() {
		return data;
	}
	
	public void setData(InAppPickupData data) {
		this.data = data;
	}
	
    private static final ObjectMapper mapper = new ObjectMapper();
    public String toJSON() throws IOException{
        try {
            return mapper.writeValueAsString(this);
        } catch(IOException e) {
            logger.log(Level.WARNING, "Exception", e);
            throw e;
        }
    }
	
}
