package com.queppelin.wudstay.vo.custom.wibmo;

import java.io.Serializable;

/**
 *
 * @author Preetham
 */
public class GenericResponse implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String resCode;
	private String resDesc;

	public String getResCode() {
		return resCode;
	}

	public void setResCode(String resCode) {
		this.resCode = resCode;
	}

	public String getResDesc() {
		return resDesc;
	}

	public void setResDesc(String resDesc) {
		this.resDesc = resDesc;
	}
}
