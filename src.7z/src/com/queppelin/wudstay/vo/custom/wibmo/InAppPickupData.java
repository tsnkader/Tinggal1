package com.queppelin.wudstay.vo.custom.wibmo;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.io.Serializable;

/**
 *
 * @author Preetham
 */

@JsonIgnoreProperties(ignoreUnknown=true)
public class InAppPickupData implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String msgHash;
	private String wibmoTxnId;
	private String merId;
	private String merTxnId;
	private String merAppData;
		
	private String pgStatusCode;
	private String pgTxnId;
	private String pgVoidTxnId;

	private String cardType;
	private String txnAmt;
	private String cardClassificationType;
	private String cardHash;
	private String cardMasked;

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public String getTxnAmt() {
		return txnAmt;
	}

	public void setTxnAmt(String txnAmt) {
		this.txnAmt = txnAmt;
	}

	public String getCardClassificationType() {
		return cardClassificationType;
	}

	public void setCardClassificationType(String cardClassificationType) {
		this.cardClassificationType = cardClassificationType;
	}

	public String getCardHash() {
		return cardHash;
	}

	public void setCardHash(String cardHash) {
		this.cardHash = cardHash;
	}

	public String getCardMasked() {
		return cardMasked;
	}

	public void setCardMasked(String cardMasked) {
		this.cardMasked = cardMasked;
	}

	public String getWibmoTxnId() {
		return wibmoTxnId;
	}

	public void setWibmoTxnId(String wibmoTxnId) {
		this.wibmoTxnId = wibmoTxnId;
	}
	
	public String getPgStatusCode() {
		return pgStatusCode;
	}

	public void setPgStatusCode(String pgStatusCode) {
		this.pgStatusCode = pgStatusCode;
	}

	public String getPgTxnId() {
		return pgTxnId;
	}

	public void setPgTxnId(String pgTxnId) {
		this.pgTxnId = pgTxnId;
	}

	public String getPgVoidTxnId() {
		return pgVoidTxnId;
	}

	public void setPgVoidTxnId(String pgVoidTxnId) {
		this.pgVoidTxnId = pgVoidTxnId;
	}

	public String getMsgHash() {
		return msgHash;
	}

	public void setMsgHash(String msgHash) {
		this.msgHash = msgHash;
	}

	public String getMerId() {
		return merId;
	}

	public void setMerId(String merId) {
		this.merId = merId;
	}

	public String getMerTxnId() {
		return merTxnId;
	}

	public void setMerTxnId(String merTxnId) {
		this.merTxnId = merTxnId;
	}

	public String getMerAppData() {
		return merAppData;
	}

	public void setMerAppData(String merAppData) {
		this.merAppData = merAppData;
	}
	
}
