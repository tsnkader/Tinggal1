package com.queppelin.wudstay.vo.custom.wibmo;

/**
 * Created by hp on 12/18/2015.
 {"merchantInfo":
 {"merId":"35507426706359493372","merCountryCode":"IN","merAppId":"7980"},
 "transactionInfo":
 {"txnAmount":"100","txnCurrency":"356","txnDesc":"Transaction from sample merchant for amount 1",
 "supportedPaymentType":["w.ds.pt.card_visa","w.ds.pt.card_mastercard"],
 "merAppData":"","merTxnId":"SAMPLEW2FA20229021978583259"},
 "customerInfo":
 {"custEmail":"jpr_surendra@yahoo.co.in","custMobile":"9928092639","custName":"Surendra Singh Rathore", "custDob":null},
 "msgHash":"UVPGdNIoNNjPA6A8WSftF/33F3emDGIejXSCjTRACFA="}

 */
public class PayZappData implements java.io.Serializable {
    private MerchantInfo merchantInfo;
    private PayZappTransactionInfo transactionInfo;
    private CustomerInfo customerInfo;
    private String msgHash;

    public MerchantInfo getMerchantInfo() {
        return merchantInfo;
    }

    public void setMerchantInfo(MerchantInfo merchantInfo) {
        this.merchantInfo = merchantInfo;
    }

    public PayZappTransactionInfo getTransactionInfo() {
        return transactionInfo;
    }

    public void setTransactionInfo(PayZappTransactionInfo transactionInfo) {
        this.transactionInfo = transactionInfo;
    }

    public CustomerInfo getCustomerInfo() {
        return customerInfo;
    }

    public void setCustomerInfo(CustomerInfo customerInfo) {
        this.customerInfo = customerInfo;
    }

    public String getMsgHash() {
        return msgHash;
    }

    public void setMsgHash(String msgHash) {
        this.msgHash = msgHash;
    }
}
