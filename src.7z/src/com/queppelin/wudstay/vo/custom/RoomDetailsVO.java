package com.queppelin.wudstay.vo.custom;

import java.io.Serializable;

public class RoomDetailsVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7284722280555495153L;
	
	private String roomName;
	
	private String occupancy;
	
	private Integer totalRoomPrice;

	private Integer totalRoomContractualPrice;
	
	private Integer pax;

	public String getRoomName() {
		return roomName;
	}

	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}

	public String getOccupancy() {
		return occupancy;
	}

	public void setOccupancy(String occupancy) {
		this.occupancy = occupancy;
	}

	public Integer getTotalRoomPrice() {
		return totalRoomPrice;
	}

	public void setTotalRoomPrice(Integer totalRoomPrice) {
		this.totalRoomPrice = totalRoomPrice;
	}

	public void setRoomPrice(int nights, Integer roomPrice, Integer roomContractualPrice) {
		this.totalRoomPrice = roomPrice * nights;
		this.totalRoomContractualPrice = roomContractualPrice  * nights;
	}

	public Integer getTotalRoomContractualPrice() {
		return totalRoomContractualPrice;
	}

	public void setTotalRoomContractualPrice(Integer totalRoomContractualPrice) {
		this.totalRoomContractualPrice = totalRoomContractualPrice;
	}

	public Integer getPax() {
		return pax;
	}

	public void setPax(Integer pax) {
		this.pax = pax;
	}
	
}
