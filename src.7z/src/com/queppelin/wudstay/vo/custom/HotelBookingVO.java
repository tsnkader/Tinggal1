package com.queppelin.wudstay.vo.custom;

import java.io.Serializable;

public class HotelBookingVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6829331924575680975L;
	
	private String cityName;
	
	private String hotelDisplayName;
	
	private String hotelDisplayAddress;
	
	private Integer totalAmount;
	
	private Integer persons;
	
	private Integer rooms;
	
	private Boolean isCancelled;
	
	private String roomImage;
	
	private String stayPeriod;
	
	private String status = "CANCEL";
	
	private Long hotelBookingId;
	
	private Double latitude;
	
	private Double longitude;

	private String hotelContactPerson1;

	private Integer paidAmount = new Integer(0);

	private boolean onlinePaid = Boolean.FALSE;

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getHotelDisplayName() {
		return hotelDisplayName;
	}

	public void setHotelDisplayName(String hotelDisplayName) {
		this.hotelDisplayName = hotelDisplayName;
	}
	
	public String getHotelDisplayAddress() {
		return hotelDisplayAddress;
	}
	
	public void setHotelDisplayAddress(String hotelDisplayAddress) {
		this.hotelDisplayAddress = hotelDisplayAddress;
	}
	
	public Integer getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Integer totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Integer getPersons() {
		return persons;
	}

	public void setPersons(Integer persons) {
		this.persons = persons;
	}

	public Integer getRooms() {
		return rooms;
	}

	public void setRooms(Integer rooms) {
		this.rooms = rooms;
	}

	public Boolean getIsCancelled() {
		return isCancelled;
	}

	public void setIsCancelled(Boolean isCancelled) {
		this.isCancelled = isCancelled;
	}

	public String getRoomImage() {
		return roomImage;
	}

	public void setRoomImage(String roomImage) {
		this.roomImage = roomImage;
	}

	public String getStayPeriod() {
		return stayPeriod;
	}

	public void setStayPeriod(String stayPeriod) {
		this.stayPeriod = stayPeriod;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getHotelBookingId() {
		return hotelBookingId;
	}

	public void setHotelBookingId(Long hotelBookingId) {
		this.hotelBookingId = hotelBookingId;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public String getHotelContactPerson1() {
		return hotelContactPerson1;
	}

	public void setHotelContactPerson1(String hotelContactPerson1) {
		this.hotelContactPerson1 = hotelContactPerson1;
	}

	public Integer getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(Integer paidAmount) {
		this.paidAmount = paidAmount;
	}

	public boolean isOnlinePaid() {
		return onlinePaid;
	}

	public void setOnlinePaid(boolean onlinePaid) {
		this.onlinePaid = onlinePaid;
	}
}
