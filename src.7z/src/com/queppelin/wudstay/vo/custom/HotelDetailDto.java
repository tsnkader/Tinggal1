package com.queppelin.wudstay.vo.custom;

import com.queppelin.wudstay.util.WudstayUtil;
import com.queppelin.wudstay.vo.HotelAmenityMVO;
import com.queppelin.wudstay.vo.HotelDetailMVO;
import com.queppelin.wudstay.vo.Location;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
//room_type_id
public class HotelDetailDto implements java.io.Serializable {
    private static final long serialVersionUID = -3108887611317479355L;
    private Long hotelId;
    private Long locationId;
    private Long cityId;
    private String hotelDisplayName;
    private String hotelDisplayAddress;
    private Integer starRating;
    private Double latitude;
    private Double longitude;
    private String mapLink;
    private Integer singleOccupancyPrice;
    private Integer doubleOccupancyPrice;
    private Integer tripleOccupancyPrice;
    private List<HotelAmenityMVO> hotelAmenities = new ArrayList<HotelAmenityMVO>();
    private String amenityNames;
    private List<String> hotelImageList = new ArrayList<String>();
    private Long roomTypeId;
    private String howToReach; //"how_to_reach
    private boolean isAvailable = true;
    //private String roomAvailablityDisabled = "";//"disabled";



    public HotelDetailDto() {
    }
    public HotelDetailDto(HotelDetailMVO vo,HttpServletRequest request) {
        this.hotelId = vo.getHotelId();
        this.locationId = vo.getLocationId();
        this.cityId = vo.getCityId();
        this.hotelDisplayName = vo.getHotelDisplayName();
        this.hotelDisplayAddress = vo.getHotelDisplayAddress();
        this.starRating =  vo.getStarRating();
        this.latitude =  vo.getLatitude();
        this.longitude =  vo.getLongitude();
        this.mapLink =  vo.getMapLink();
        this.singleOccupancyPrice =  vo.getSingleOccupancyPrice();
        this.doubleOccupancyPrice =  vo.getDoubleOccupancyPrice();
        this.tripleOccupancyPrice =  vo.getTripleOccupancyPrice();
        this.amenityNames= vo.getAmenityNames();
        this.setHotelImageList(WudstayUtil.getHotelImages(this.hotelId,request) );
        this.setRoomTypeId(vo.getRoomTypeId());
        this.setHowToReach(vo.getHowToReach());
    }

    public Long getHotelId() {
        return hotelId;
    }

    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }

    public Long getLocationId() {
        return locationId;
    }

    public void setLocationId(Long locationId) {
        this.locationId = locationId;
    }

    public Long getCityId() {
        return cityId;
    }

    public void setCityId(Long cityId) {
        this.cityId = cityId;
    }

    public String getHotelDisplayName() {
        return hotelDisplayName;
    }

    public void setHotelDisplayName(String hotelDisplayName) {
        this.hotelDisplayName = hotelDisplayName;
    }

    public String getHotelDisplayAddress() {
        return hotelDisplayAddress;
    }

    public void setHotelDisplayAddress(String hotelDisplayAddress) {
        this.hotelDisplayAddress = hotelDisplayAddress;
    }

    public Integer getStarRating() {
        return starRating;
    }

    public void setStarRating(Integer starRating) {
        this.starRating = starRating;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public String getMapLink() {
        return mapLink;
    }

    public void setMapLink(String mapLink) {
        this.mapLink = mapLink;
    }

    public Integer getSingleOccupancyPrice() {
        return singleOccupancyPrice;
    }

    public void setSingleOccupancyPrice(Integer singleOccupancyPrice) {
        this.singleOccupancyPrice = singleOccupancyPrice;
    }

    public Integer getDoubleOccupancyPrice() {
        return doubleOccupancyPrice;
    }

    public void setDoubleOccupancyPrice(Integer doubleOccupancyPrice) {
        this.doubleOccupancyPrice = doubleOccupancyPrice;
    }

    public Integer getTripleOccupancyPrice() {
        return tripleOccupancyPrice;
    }

    public void setTripleOccupancyPrice(Integer tripleOccupancyPrice) {
        this.tripleOccupancyPrice = tripleOccupancyPrice;
    }

    public List<HotelAmenityMVO> getHotelAmenities() {
        return hotelAmenities;
    }

    public void setHotelAmenities(List<HotelAmenityMVO> hotelAmenities) {
        this.hotelAmenities = hotelAmenities;
    }

    public void addHotelAmenity(HotelAmenityMVO  hotelAmenity) {
        this.hotelAmenities.add(hotelAmenity);
    }

    public String getAmenityNames() {
        return amenityNames;
    }

    public void setAmenityNames(String amenityNames) {
        this.amenityNames = amenityNames;
    }

    public List<String> getHotelImageList() {
        return hotelImageList;
    }

    public void setHotelImageList(List<String> hotelImageList) {
        this.hotelImageList = hotelImageList;
    }

    public Long getRoomTypeId() {
        return roomTypeId;
    }

    public void setRoomTypeId(Long roomTypeId) {
        this.roomTypeId = roomTypeId;
    }

    public String getHowToReach() {
        return howToReach;
    }

    public void setHowToReach(String howToReach) {
        this.howToReach = howToReach;
    }

    public boolean isAvailable() {
        return isAvailable;
    }
    public boolean getIsAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean isAvailable) {
        this.isAvailable = isAvailable;
    }

    public String getRoomAvailablityDisabled() {
        return isAvailable==true? "":" disabled";
    }

    public void setRoomAvailablityDisabled(String roomAvailablityDisabled) {
        //this.roomAvailablityDisabled = roomAvailablityDisabled;
    }
}
