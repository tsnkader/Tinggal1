package com.queppelin.wudstay.vo.custom;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class BookingDetailsVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7999477385527289771L;
	
	public String checkInDate;
	
	public String checkOutDate;
	
	public String roomTypeMaster;
	
	private Integer nights;
	
	private Integer totalPrice;
	private Integer totalPriceContractual;

	private Integer totalPriceBeforeDiscount;
	
	private String hotelDisplayName;
	
	private String hotelName;
	
	private String city;
	
	private String address;
	
	private String displayAddress;
	
	private Long hotelId;
	
	private String mapLink;
	
	private Integer maxBookingPerMobNum;
	
	public List<RoomDetailsVO> roomDetailsVOList = new ArrayList<RoomDetailsVO>();
	private Integer persons;

	private DiscountCouponInfo discountCoupon = null ;

	private String breakfastIncludedInPrice ="Yes";

	public DiscountCouponInfo getDiscountCoupon() {
		return discountCoupon;
	}

	public void setDiscountCoupon(DiscountCouponInfo discountCoupon) {
		this.discountCoupon = discountCoupon;
		resetTotalPrice();
	}

	public String getCheckInDate() {
		return checkInDate;
	}

	public void setCheckInDate(String checkInDate) {
		this.checkInDate = checkInDate;
	}

	public String getCheckOutDate() {
		return checkOutDate;
	}

	public void setCheckOutDate(String checkOutDate) {
		this.checkOutDate = checkOutDate;
	}

	public Integer getNights() {
		return nights;
	}

	public void setNights(Integer nights) {
		this.nights = nights;
	}

	public Integer getTotalPrice() {
		//return getTotalPriceAfterDiscount();
		return totalPrice;
	}

	public void setTotalPrice(Integer totalPrice) {
		this.totalPrice = totalPrice;
		this.totalPriceBeforeDiscount = this.totalPrice;
	}

	public void resetTotalPrice() {
		if(discountCoupon != null){
			try {
				if(this.totalPrice.equals(this.totalPriceBeforeDiscount)){
					if(this.totalPrice < discountCoupon.getDiscount())
						discountCoupon.setDiscount(this.totalPrice);
					this.totalPrice = this.totalPrice - discountCoupon.getDiscount();
				}
			}catch (Exception ex){
				ex.printStackTrace();
			}
		}
	}

	public Integer getTotalPriceBeforeDiscount() {
		return totalPriceBeforeDiscount;
	}

	public void setTotalPriceBeforeDiscount(Integer totalPriceBeforeDiscount) {
		this.totalPriceBeforeDiscount = totalPriceBeforeDiscount;
	}

	/*
        //discountCoupon = null ;

        public Integer getTotalPriceAfterDiscount() {
            Integer totalPriceAfterDiscount = totalPrice;
            if(discountCoupon != null){
                try {
                    totalPriceAfterDiscount = totalPriceAfterDiscount - discountCoupon.getDiscount();
                }catch (Exception ex){
                    ex.printStackTrace();
                }
            }
            return totalPriceAfterDiscount;
        }

        public void setTotalPriceAfterDiscount(Integer totalPriceAfterDiscount) {
            //this.totalPriceAfterDiscount = totalPriceAfterDiscount;
        }
    */
	public List<RoomDetailsVO> getRoomDetailsVOList() {
		return roomDetailsVOList;
	}

	public void setRoomDetailsVOList(List<RoomDetailsVO> roomDetailsVOList) {
		this.roomDetailsVOList = roomDetailsVOList;
	}

	public String getHotelDisplayName() {
		return hotelDisplayName;
	}

	public void setHotelDisplayName(String hotelDisplayName) {
		this.hotelDisplayName = hotelDisplayName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Long getHotelId() {
		return hotelId;
	}

	public void setHotelId(Long hotelId) {
		this.hotelId = hotelId;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public String getMapLink() {
		return mapLink;
	}

	public void setMapLink(String mapLink) {
		this.mapLink = mapLink;
	}

	public String getDisplayAddress() {
		return displayAddress;
	}

	public void setDisplayAddress(String displayAddress) {
		this.displayAddress = displayAddress;
	}

	public Integer getMaxBookingPerMobNum() {
		return maxBookingPerMobNum;
	}

	public void setMaxBookingPerMobNum(Integer maxBookingPerMobNum) {
		this.maxBookingPerMobNum = maxBookingPerMobNum;
	}

	public Integer getPersons() {
		return persons;
	}

	public void setPersons(Integer persons) {
		this.persons = persons;
	}

	public String getRoomTypeMaster() {
		return roomTypeMaster;
	}

	public void setRoomTypeMaster(String roomTypeMaster) {
		this.roomTypeMaster = roomTypeMaster;
	}
	public Integer getTotalPriceContractual() {
		return totalPriceContractual;
	}

	public void setTotalPriceContractual(Integer totalPriceContractual) {
		this.totalPriceContractual = totalPriceContractual;
	}

	public String getBreakfastIncludedInPrice() {
		return (breakfastIncludedInPrice==null || "YES".equalsIgnoreCase(breakfastIncludedInPrice) || "TRUE".equalsIgnoreCase(breakfastIncludedInPrice)) ? "Yes" : "No" ;
	}

	public void setBreakfastIncludedInPrice(String breakfastIncludedInPrice) {
		this.breakfastIncludedInPrice = breakfastIncludedInPrice;
	}

	public void setBreakfastIncludedInPrice(Boolean isBreakfastIncludedInPrice) {
		this.breakfastIncludedInPrice = isBreakfastIncludedInPrice==true?"Yes":"No";
	}
}
