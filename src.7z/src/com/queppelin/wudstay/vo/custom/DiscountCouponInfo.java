package com.queppelin.wudstay.vo.custom;

import java.io.Serializable;

/**
 * Created by hp on 10/9/2015.
 */
public class DiscountCouponInfo implements Serializable {
    private static final long serialVersionUID = 2621618857457104413L;
    private Long couponCodeId ;
    private Long couponCodeUsedId ;
    private String couponCode="";
    private Integer discount=0;
    private boolean onlyForOnlinePayment=false;

    public DiscountCouponInfo(){}
    public DiscountCouponInfo(Long couponCodeId, Long couponCodeUsedId, String couponCode, Integer discount) {
        this.couponCodeId = couponCodeId;
        this.couponCodeUsedId = couponCodeUsedId;
        this.couponCode = couponCode;
        this.discount = discount;
    }
    public DiscountCouponInfo(Long couponCodeId, Long couponCodeUsedId, String couponCode, Integer discount, boolean onlyForOnlinePayment) {
        this.couponCodeId = couponCodeId;
        this.couponCodeUsedId = couponCodeUsedId;
        this.couponCode = couponCode;
        this.discount = discount;
        this.onlyForOnlinePayment=onlyForOnlinePayment;
    }

    public Long getCouponCodeId() {
        return couponCodeId;
    }

    public void setCouponCodeId(Long couponCodeId) {
        this.couponCodeId = couponCodeId;
    }

    public void setCouponCodeAndId(String couponCode, Long couponCodeId) {
        this.couponCodeId = couponCodeId;
        this.couponCode = couponCode;
    }

    public Long getCouponCodeUsedId() {
        return couponCodeUsedId;
    }

    public void setCouponCodeUsedId(Long couponCodeUsedId) {
        this.couponCodeUsedId = couponCodeUsedId;
    }

    public String getCouponCode() {
        return couponCode;
    }

    public void setCouponCode(String couponCode) {
        this.couponCode = couponCode;
    }

    public Integer getDiscount() {
        return discount;
    }

    public void setDiscount(Integer discount) {
        this.discount = discount;
    }

    public boolean getOnlyForOnlinePayment() {
        return onlyForOnlinePayment;
    }

    public void setOnlyForOnlinePayment(boolean onlyForOnlinePayment) {
        this.onlyForOnlinePayment = onlyForOnlinePayment;
    }
}
