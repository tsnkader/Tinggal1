package com.queppelin.wudstay.vo.custom;

public class Employee {
	public String empName;
	public String empEmail;
	public String empContactNumber;

	public Employee() {
	}
	public Employee(String empName, String empEmail, String empContactNumber, String bookingName, String checkin,
					String chechout, String city, String location) {
		this.empName = empName;
		this.empEmail = empEmail;
		this.empContactNumber = empContactNumber;
	}
	public Employee(String empName, String empEmail, String empContactNumber) {
		this.empName = empName;
		this.empEmail = empEmail;
		this.empContactNumber = empContactNumber;
	}
	
	
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpEmail() {
		return empEmail;
	}
	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}
	public String getEmpContactNumber() {
		return empContactNumber;
	}
	public void setEmpContactNumber(String empContactNumber) {
		this.empContactNumber = empContactNumber;
	}

}
