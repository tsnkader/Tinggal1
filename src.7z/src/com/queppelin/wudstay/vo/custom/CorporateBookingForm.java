package com.queppelin.wudstay.vo.custom;

import com.queppelin.wudstay.vo.Corporate;
import com.queppelin.wudstay.vo.CorporateBookingVO;
import com.queppelin.wudstay.vo.CorporateEmployeeVO;
import com.queppelin.wudstay.vo.Location;

import java.util.*;

/**
 * Created by hp on 9/25/2015.
 */
public class CorporateBookingForm {
    private Long corpBookingId;
    private Corporate corporate;
    private String bookingName;
    private Date checkIn;
    private Date checkOut;
    private Date bookingDate;
    private Location location;
    private Integer  isCancelled=0;

    private String lastUpdatedBy;
    private Date   lastUpdatedDate;

    private String city;
    private Integer perRoomRate;
    private Integer isApproved;
    private String roomType;
    private String citylocation;

    private Integer noOfGuestsAllottedhotel=0;
    private Integer noOfGuests=0;
    private String cityName="";
    private String locationName="";
    private String hotelId="";
    private Integer price=0;
    private Integer  billPayAt=0;
    private String guestRequest="";

    private List<CorporateEmployeeVO> listOfEmployee = new ArrayList<CorporateEmployeeVO>();
    private List<CorporateEmployeeVO> lListOfEmployeeAllottedhotel = new ArrayList<CorporateEmployeeVO>();
    public CorporateBookingForm(){}

    public CorporateBookingForm(CorporateBookingVO corporateBooking) {
        this.corpBookingId = corporateBooking.getCorpBookingId();
        this.corporate = corporateBooking.getCorporate();
        this.bookingName = corporateBooking.getBookingName();
        this.checkIn = corporateBooking.getCheckIn();
        this.checkOut = corporateBooking.getCheckOut();
        this.bookingDate = corporateBooking.getBookingDate();
        this.location = corporateBooking.getLocation();
        this.isCancelled = corporateBooking.getIsCancelled();
        this.lastUpdatedBy = corporateBooking.getLastUpdatedBy();
        this.lastUpdatedDate = corporateBooking.getLastUpdatedDate();
        //this.city = corporateBooking.getCity();
        //this.perRoomRate = corporateBooking.getPerRoomRate();
        this.isApproved = corporateBooking.getIsApproved();
        this.roomType = corporateBooking.getRoomType();
        this.price= corporateBooking.getPrice();
        this.billPayAt= corporateBooking.getBillPayAt();

        for(CorporateEmployeeVO emp: corporateBooking.getListOfEmployee()){
            listOfEmployee.add(emp);
        }
        Collections.sort(listOfEmployee, new Comparator<CorporateEmployeeVO>() {
            
            public int compare(CorporateEmployeeVO a1, CorporateEmployeeVO a2) {
                return a1.getBookingId().compareTo(a2.getBookingId());
            }
        });
    }

    public String getCitylocation() {
        return citylocation;
    }

    public void setCitylocation(String citylocation) {
        this.citylocation = citylocation;
    }

    public Long getCorpBookingId() {
        return corpBookingId;
    }

    public void setCorpBookingId(Long corpBookingId) {
        this.corpBookingId = corpBookingId;
    }

    public Corporate getCorporate() {
        return corporate;
    }

    public void setCorporate(Corporate corporate) {
        this.corporate = corporate;
    }

    public String getBookingName() {
        return bookingName;
    }

    public void setBookingName(String bookingName) {
        this.bookingName = bookingName;
    }

    public Date getCheckIn() {
        return checkIn;
    }

    public void setCheckIn(Date checkIn) {
        this.checkIn = checkIn;
    }

    public Date getCheckOut() {
        return checkOut;
    }

    public void setCheckOut(Date checkOut) {
        this.checkOut = checkOut;
    }

    public Date getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(Date bookingDate) {
        this.bookingDate = bookingDate;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public Integer getIsCancelled() {
        return isCancelled;
    }

    public void setIsCancelled(Integer isCancelled) {
        this.isCancelled = isCancelled;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public Date getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate(Date lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public Integer getPerRoomRate() {
        return perRoomRate;
    }

    public void setPerRoomRate(Integer perRoomRate) {
        this.perRoomRate = perRoomRate;
    }

    public Integer getIsApproved() {
        return isApproved;
    }

    public void setIsApproved(Integer isApproved) {
        this.isApproved = isApproved;
    }

    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public List<CorporateEmployeeVO> getListOfEmployee() {
        return listOfEmployee;
    }

    public void setListOfEmployee(List<CorporateEmployeeVO> listOfEmployee) {
        this.listOfEmployee = listOfEmployee;
    }

    public List<CorporateEmployeeVO> getlListOfEmployeeAllottedhotel() {
        return lListOfEmployeeAllottedhotel;
    }

    public void setlListOfEmployeeAllottedhotel(List<CorporateEmployeeVO> lListOfEmployeeUnAllottedhotel) {
        this.lListOfEmployeeAllottedhotel = lListOfEmployeeUnAllottedhotel;
    }

    public Integer getNoOfGuestsAllottedhotel() {
        return noOfGuestsAllottedhotel;
    }

    public void setNoOfGuestsAllottedhotel(Integer noOfGuestsAllottedhotel) {
        this.noOfGuestsAllottedhotel = noOfGuestsAllottedhotel;
    }

    public Integer getNoOfGuests() {
        return noOfGuests;
    }

    public void setNoOfGuests(Integer noOfGuests) {
        this.noOfGuests = noOfGuests;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getLocationName() {
        return locationName;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    public String getHotelId() {
        return hotelId;
    }

    public void setHotelId(String hotelId) {
        this.hotelId = hotelId;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public Integer getBillPayAt() {
        return billPayAt;
    }

    public void setBillPayAt(Integer billPayAt) {
        this.billPayAt = billPayAt;
    }

    public String getGuestRequest() {
        return guestRequest;
    }

    public void setGuestRequest(String guestRequest) {
        this.guestRequest = guestRequest;
    }
}
