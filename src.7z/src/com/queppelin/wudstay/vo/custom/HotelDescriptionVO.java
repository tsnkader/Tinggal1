package com.queppelin.wudstay.vo.custom;

import java.io.Serializable;

public class HotelDescriptionVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8107632499408831135L;
	
	private String descriptionTitle;
	
	private String description;

	public String getDescriptionTitle() {
		return descriptionTitle;
	}

	public void setDescriptionTitle(String descriptionTitle) {
		this.descriptionTitle = descriptionTitle;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
}
