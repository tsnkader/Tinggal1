package com.queppelin.wudstay.vo.custom;

import java.io.Serializable;

public class RoomTypeVO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1923665074452927121L;

	private Long roomTypeId;
	
	private Long rooms;
	
	private Integer price;
	
	private String roomType;

	public Long getRoomTypeId() {
		return roomTypeId;
	}

	public void setRoomTypeId(Long roomTypeId) {
		this.roomTypeId = roomTypeId;
	}

	public Long getRooms() {
		return rooms;
	}

	public void setRooms(Long rooms) {
		this.rooms = rooms;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
}
