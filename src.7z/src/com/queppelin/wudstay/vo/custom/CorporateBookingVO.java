package com.queppelin.wudstay.vo.custom;

import com.queppelin.wudstay.vo.Corporate;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class CorporateBookingVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 705880361913549333L;

	private Long corpBookingId;
	private Corporate corporate;
	private String bookingName;
	private Date checkIn;
	private Date checkOut;
	private Date bookingDate;
	private String roomType;
	private String city;
	private String location;
	private Integer isCancelled;
	private Integer perRoomRate;
	private List<EmployeeVO> employeeVO;
	private List<Employee> employees;
	private Long corpId;



	public Long getCorpId() {
		return corpId;
	}

	public void setCorpId(Long corpId) {
		this.corpId = corpId;
	}

	public Long getCorpBookingId() {
		return corpBookingId;
	}

	public void setCorpBookingId(Long corpBookingId) {
		this.corpBookingId = corpBookingId;
	}

	public Corporate getCorporate() {
		return corporate;
	}

	public void setCorporate(Corporate corporate) {
		this.corporate = corporate;
	}
	
	public String getBookingName() {
		return bookingName;
	}

	public void setBookingName(String bookingName) {
		this.bookingName = bookingName;
	}

	public Date getCheckIn() {
		return checkIn;
	}

	public void setCheckIn(Date checkIn) {
		this.checkIn = checkIn;
	}

	public Date getCheckOut() {
		return checkOut;
	}

	public void setCheckOut(Date checkOut) {
		this.checkOut = checkOut;
	}

	public Date getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(Date bookingDate) {
		this.bookingDate = bookingDate;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Integer getIsCancelled() {
		return isCancelled;
	}

	public void setIsCancelled(Integer isCancelled) {
		this.isCancelled = isCancelled;
	}

	public Integer getPerRoomRate() {
		return perRoomRate;
	}

	public void setPerRoomRate(Integer perRoomRate) {
		this.perRoomRate = perRoomRate;
	}

	public List<EmployeeVO> getEmployeeVO() {
		return employeeVO;
	}

	public void setEmployeeVO(List<EmployeeVO> employeeVO) {
		this.employeeVO = employeeVO;
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}

	
}
