package com.queppelin.wudstay.vo.custom;

import com.queppelin.wudstay.util.DateUtil;
import com.queppelin.wudstay.vo.RoomsInventoryVO;

import javax.persistence.Column;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class RoomsDayInventory implements java.io.Serializable {
    private int     noOfRooms = 0;
    private int     bookedRooms = 0;
    private String  strDate="";
    //private int availableRooms=0;

    public RoomsDayInventory(){}
    public RoomsDayInventory(int noOfRooms, int bookedRooms, String strDate) {
        this.noOfRooms = noOfRooms;
        this.bookedRooms = bookedRooms;
        this.strDate = strDate;
    }

    public int getNoOfRooms() {
        return noOfRooms;
    }

    public void setNoOfRooms(int noOfRooms) {
        this.noOfRooms = noOfRooms;
    }

    public int getBookedRooms() {
        return bookedRooms;
    }

    public void setBookedRooms(int bookedRooms) {
        this.bookedRooms = bookedRooms;
    }

    public String getStrDate() {
        return strDate;
    }

    public void setStrDate(String strDate) {
        this.strDate = strDate;
    }

    public int getAvailableRooms() {
        return noOfRooms - bookedRooms;
    }

    public void setAvailableRooms(int availableRooms) {
        //this.availableRooms = availableRooms;
    }
}
