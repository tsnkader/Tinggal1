package com.queppelin.wudstay.vo.custom;

import com.queppelin.wudstay.vo.CouponCodeInCityVO;
import com.queppelin.wudstay.vo.CouponCodeUsedVO;
import com.queppelin.wudstay.vo.CouponCodeVO;

import javax.persistence.Column;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by hp on 10/8/2015.
 */
public class CouponCodeForm implements Serializable {
    private static final long serialVersionUID = -7372967020858016661L;
    public static SimpleDateFormat simpleDateFormatter = new SimpleDateFormat("dd/MM/yyyy"); //09/08/2015 11:07 AM
    private CouponCodeVO newCouponCode ;
    private List<CouponCodeVO> couponCodeList ;
    private String strDate= "";
    //private String dateCheckIn = strDate(new Date());
    //private String dateCheckOut = tomorrowDate(new Date());

    private Set<CouponCodeInCityVO> cities = new HashSet<CouponCodeInCityVO>();


    public CouponCodeForm(){
        newCouponCode = new CouponCodeVO();
        couponCodeList = new ArrayList<CouponCodeVO>();
    }

    public static String tomorrowDate(Date today){
        Calendar c = Calendar.getInstance();
        c.setTime(today);
        c.add(Calendar.DATE, 1);
        Date tomorrow = c.getTime();
        return simpleDateFormatter.format(tomorrow);
    }
    public static String strDate(Date today){ //CouponCodeForm.strDate(new Date())
        return simpleDateFormatter.format(today);
    }

    public Set<CouponCodeInCityVO> getCities() {
        return cities;
    }

    public void setCities(Set<CouponCodeInCityVO> cities) {
        this.cities = cities;
    }

    public String getDateCheckOut() {
        String date =" ";
        try {
            date = simpleDateFormatter.format(newCouponCode.getCouponValidTillDate());
            //date = simpleDateFormatter.format(newCouponCode.getCouponValidFromDate());
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            return date;
        }
    }

    public void setDateCheckOut(String dateCheckOut) {
        //this.dateCheckOut = dateCheckOut;
    }

    public String getDateCheckIn() {
        String date =" ";
        try {
            //date = simpleDateFormatter.format(newCouponCode.getCouponValidTillDate());
            date = simpleDateFormatter.format(newCouponCode.getCouponValidFromDate());
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            return date;
        }
    }

    public void setDateCheckIn(String dateCheckIn) {
        //this.dateCheckIn = dateCheckIn;
    }

    public String getTxtDate() {
        /*try {
            String dateCheckIn = simpleDateFormatter.format(newCouponCode.getCouponValidFromDate());
            String dateCheckOut = simpleDateFormatter.format(newCouponCode.getCouponValidTillDate());
            //return txtDate;
            return dateCheckIn + " - " + dateCheckOut;
        }catch (Exception ex){
            ex.printStackTrace();
            return  " - ";
        }*/
        return null;
    }

    public void setTxtDate(String txtDate) {
        //this.txtDate = txtDate;

        // txtDate = 05/10/2015 - 07/10/2015
        String dateCheckIn = simpleDateFormatter.format(new Date());
        String dateCheckOut = simpleDateFormatter.format(new Date());
        try{
            String []strDates = txtDate.split(" - ");
            dateCheckIn =strDates[0].trim();
            dateCheckOut =strDates[1].trim();
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            //String strDate = getRequestParam(request,"dateCheckIn", simpleDateFormatter.format(new Date()));
            newCouponCode.setCouponValidFromDate(simpleDateFormatter.parse(dateCheckIn));
            //strDate = getRequestParam(request,"dateCheckOut", simpleDateFormatter.format(new Date()));
            newCouponCode.setCouponValidTillDate(simpleDateFormatter.parse(dateCheckOut));
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    public List<CouponCodeVO> getCouponCodeList() {
        return couponCodeList;
    }

    public void setCouponCodeList(List<CouponCodeVO> couponCodeList) {
        this.couponCodeList = couponCodeList;
    }

    public CouponCodeVO getNewCouponCode() {
        return newCouponCode;
    }

    public void setNewCouponCode(CouponCodeVO newCouponCode) {
        this.newCouponCode = newCouponCode;
    }

    public Long getCouponId() {
        return newCouponCode.getCouponId();
    }

    public void setCouponCode(String couponCode) {
        newCouponCode.setCouponCode(couponCode);
    }

    public void setIsDiscountPercentageMode(Integer isDiscountPercentageMode) {
        newCouponCode.setIsDiscountPercentageMode(isDiscountPercentageMode);
    }

    public Date getCouponValidFromDate() {
        return newCouponCode.getCouponValidFromDate();
    }

    public void setLastUpdatedDate(Date lastUpdatedDate) {
        newCouponCode.setLastUpdatedDate(lastUpdatedDate);
    }

    public void setCouponIgnoreValidityDate(Integer couponIgnoreValidityDate) {
        newCouponCode.setCouponIgnoreValidityDate(couponIgnoreValidityDate);
    }



    public String getLastUpdatedBy() {
        return newCouponCode.getLastUpdatedBy();
    }

    public Integer getCouponAmtValue() {
        return newCouponCode.getCouponAmtValue();
    }

    public Integer getCouponValidTillTimes() {
        return newCouponCode.getCouponValidTillTimes();
    }

    public String getCouponCode() {
        return newCouponCode.getCouponCode();
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        newCouponCode.setLastUpdatedBy(lastUpdatedBy);
    }

    public void setCouponValidityDateApplyOnCheckout(Integer couponValidityDateApplyOnCheckout) {
        newCouponCode.setCouponValidityDateApplyOnCheckout(couponValidityDateApplyOnCheckout);
    }

    public Integer getCouponValidityDateApplyOnCheckout() {
        return newCouponCode.getCouponValidityDateApplyOnCheckout();
    }

    public Date getLastUpdatedDate() {
        return newCouponCode.getLastUpdatedDate();
    }

    public void setCouponValidFromDate(Date couponValidFromDate) {
        newCouponCode.setCouponValidFromDate(couponValidFromDate);
    }

    /*public Set<CouponCodeUsedVO> getListOfEmployee() {
        return newCouponCode.getListOfEmployee();
    }

    public void setListOfEmployee(Set<CouponCodeUsedVO> listOfEmployee) {
        newCouponCode.setListOfEmployee(listOfEmployee);
    }*/

    public Integer getIsDiscountPercentageMode() {
        return newCouponCode.getIsDiscountPercentageMode();
    }

    public void setCouponValidTillTimes(Integer couponValidTillTimes) {
        newCouponCode.setCouponValidTillTimes(couponValidTillTimes);
    }

    public Date getCouponValidTillDate() {
        return newCouponCode.getCouponValidTillDate();
    }

    public Integer getCouponIgnoreValidityDate() {
        return newCouponCode.getCouponIgnoreValidityDate();
    }

    public void setCouponValidTillDate(Date couponValidTillDate) {
        newCouponCode.setCouponValidTillDate(couponValidTillDate);
    }

    public void setCouponAmtValue(Integer couponAmtValue) {
        newCouponCode.setCouponAmtValue(couponAmtValue);
    }

    public void setCouponId(Long couponId) {
        newCouponCode.setCouponId(couponId);
    }

    public Integer getDiscountUpperLimit() {
        return newCouponCode.getDiscountUpperLimit();
    }

    public void setDiscountUpperLimit(Integer discountUpperLimit) {
        newCouponCode.setDiscountUpperLimit(discountUpperLimit);
    }

    public Integer getIsValidForUniqueUser() {
        return newCouponCode.getIsValidForUniqueUser();
    }

    public void setIsValidForUniqueUser(Integer isValidForUniqueUser) {
        newCouponCode.setIsValidForUniqueUser(isValidForUniqueUser);
    }

    public int getValidForBookingsource() {
        Integer validForBookingsource = newCouponCode.getValidForBookingsource();
        return validForBookingsource==null ? 0 : validForBookingsource;
    }

    public void setValidForBookingsource(int validForBookingsource) {
        newCouponCode.setValidForBookingsource(validForBookingsource);
    }

    public Integer getIsValidForOnlinePaymentOnly() {
        Integer isValidForOnlinePaymentOnly = newCouponCode.getIsValidForOnlinePaymentOnly();
        return isValidForOnlinePaymentOnly;
    }

    public void setIsValidForOnlinePaymentOnly(Integer isValidForOnlinePaymentOnly) {
        newCouponCode.setIsValidForOnlinePaymentOnly(isValidForOnlinePaymentOnly);
    }
}
