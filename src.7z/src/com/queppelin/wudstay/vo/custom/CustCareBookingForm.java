package com.queppelin.wudstay.vo.custom;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CustCareBookingForm implements java.io.Serializable {
	public static SimpleDateFormat simpleDateFormatter = new SimpleDateFormat("dd/MM/yyyy"); //09/08/2015 11:07 AM
	//com.queppelin.wudstay.vo.CorporateEmployeeVO

	private int noOfRooms=1;
	private int noOfGuest=1;
	private String txtDate;
	private String discountCouponCode="";

	private String strCheckIn = simpleDateFormatter.format(new Date());
	private String strCheckOut = simpleDateFormatter.format(new Date());

	public Date 	checkin;
	public Date 	checkout;
	public String 	city;
	public String 	hotel;

	public String 	guestTitle;
	public String 	guestName;
	public String 	mobileNumber;
	public String 	guestEmail;

	public String 	bookingSource;
	public String 	finalTotalPrice;

	private Boolean isOnlinePaid = Boolean.FALSE;
	private String transactionId = null;
	private String paymentGatewayTransId = null;

	public int getNoOfRooms() {
		return noOfRooms;
	}

	public void setNoOfRooms(int noOfRooms) {
		this.noOfRooms = noOfRooms;
	}

	public int getNoOfGuest() {
		return noOfGuest;
	}

	public void setNoOfGuest(int noOfGuest) {
		this.noOfGuest = noOfGuest;
	}

	public String getStrCheckIn() {
		return strCheckIn;
	}

	public void setStrCheckIn(String strCheckIn) {
		this.strCheckIn = strCheckIn;
	}

	public String getStrCheckOut() {
		return strCheckOut;
	}

	public void setStrCheckOut(String strCheckOut) {
		this.strCheckOut = strCheckOut;
	}

	public String getTxtDate() {
		return txtDate;
	}

	public void setTxtDate(String txtDate) {
		this.txtDate = txtDate;

		//this.txtDate = txtDate;

		// txtDate = 05/10/2015 - 07/10/2015
		try{
			String []strDates = txtDate.split(" - ");
			strCheckIn =strDates[0].trim();
			strCheckOut =strDates[1].trim();
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			//String strDate = getRequestParam(request,"dateCheckIn", simpleDateFormatter.format(new Date()));
			setCheckin(simpleDateFormatter.parse(strCheckIn));
			//strDate = getRequestParam(request,"dateCheckOut", simpleDateFormatter.format(new Date()));
			setCheckout(simpleDateFormatter.parse(strCheckOut));
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	public Date getCheckin() {
		return checkin;
	}

	public void setCheckin(Date checkin) {
		this.checkin = checkin;
	}

	public Date getCheckout() {
		return checkout;
	}

	public void setCheckout(Date checkout) {
		this.checkout = checkout;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getHotel() {
		return hotel;
	}

	public void setHotel(String hotel) {
		this.hotel = hotel;
	}

	public String getGuestTitle() {
		return guestTitle;
	}

	public void setGuestTitle(String guestTitle) {
		this.guestTitle = guestTitle;
	}

	public String getGuestName() {
		return guestName;
	}

	public void setGuestName(String guestName) {
		this.guestName = guestName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getGuestEmail() {
		return guestEmail;
	}

	public void setGuestEmail(String guestEmail) {
		this.guestEmail = guestEmail;
	}

	public String getDiscountCouponCode() {
		return discountCouponCode==null ? "" : discountCouponCode.trim();
	}

	public void setDiscountCouponCode(String discountCouponCode) {
		this.discountCouponCode = discountCouponCode==null ? "" : discountCouponCode.trim();
	}

	public String getBookingSource() {
		if(bookingSource==null || "".equals(bookingSource.trim())){
			bookingSource = "11";
		}
		return bookingSource.trim();
	}

	public void setBookingSource(String bookingSource) {
		this.bookingSource = bookingSource;
	}

	public String getFinalTotalPrice() {
		if(finalTotalPrice==null || "".equals(finalTotalPrice.trim())){
			finalTotalPrice = "0";
		}
		return finalTotalPrice.trim();
	}
	public boolean isEmptyFinalTotalPrice() {
		if(finalTotalPrice==null || "".equals(finalTotalPrice.trim())){
			return true;
		}
		return false;
	}

	public void setFinalTotalPrice(String finalTotalPrice) {
		this.finalTotalPrice = finalTotalPrice;
	}

	public Boolean getIsOnlinePaid() {
		return isOnlinePaid==null || isOnlinePaid==Boolean.FALSE ? Boolean.FALSE : Boolean.TRUE;
	}

	public void setIsOnlinePaid(Boolean isOnlinePaid) {
		this.isOnlinePaid = isOnlinePaid;
	}
	public void setIsOnlinePaid(String strIsOnlinePaid) {
		this.isOnlinePaid = strIsOnlinePaid!=null && "TRUE".equalsIgnoreCase(strIsOnlinePaid.trim()) ? Boolean.TRUE  : Boolean.FALSE;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getPaymentGatewayTransId() {
		return paymentGatewayTransId;
	}

	public void setPaymentGatewayTransId(String paymentGatewayTransId) {
		this.paymentGatewayTransId = paymentGatewayTransId;
	}
}
