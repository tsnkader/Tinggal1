package com.queppelin.wudstay.vo.custom;

import com.queppelin.wudstay.vo.CorporateEmployeeVO;
import com.queppelin.wudstay.vo.Hotel;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class CorporateHotelBookingDetails implements Serializable {
	private Hotel hotel = null;
	private List<CorporateBookingDetails> hotelBookingsDetailsList = new ArrayList<CorporateBookingDetails>();

	private CorporateBookingDetails details = null;

	public CorporateHotelBookingDetails(Hotel hotel) {
		this.hotel = hotel;
	}

	public void addNewCorpBookingDetails(BookingDetailsVO bookingDetailsVO, String bookingId){
		this.details = new CorporateBookingDetails(bookingDetailsVO, bookingId);
	}
	public void addCorpEmployeeToCorpBookingDetails(CorporateEmployeeVO vo){
		this.details.addCorporateEmployee(vo);
	}
	public void addBookingIdToCorpBookingDetails(String bookingId) {
		this.details.addBookingId(bookingId);
	}
	public void freezeCorporateBookingDetails(){
		hotelBookingsDetailsList.add(details);
	}

	public Hotel getHotel() {
		return hotel;
	}

	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}

	public List<CorporateBookingDetails> getHotelBookingsDetailsList() {
		return hotelBookingsDetailsList;
	}

	public void setHotelBookingsDetailsList(List<CorporateBookingDetails> hotelBookingsDetailsList) {
		this.hotelBookingsDetailsList = hotelBookingsDetailsList;
	}


}
