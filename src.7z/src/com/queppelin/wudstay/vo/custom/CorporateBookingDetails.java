package com.queppelin.wudstay.vo.custom;

import com.queppelin.wudstay.vo.CorporateEmployeeVO;
import com.queppelin.wudstay.vo.Hotel;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class CorporateBookingDetails implements Serializable {
	private BookingDetailsVO bookingDetailsVO = null;
	private String bookingId = null;
	private List<CorporateEmployeeVO> corpEmpList = new ArrayList<CorporateEmployeeVO>();


	public CorporateBookingDetails(){}
	public CorporateBookingDetails(BookingDetailsVO bookingDetailsVO) {
		this.bookingDetailsVO = bookingDetailsVO;
	}
	public CorporateBookingDetails(BookingDetailsVO bookingDetailsVO, String bookingId) {
		this.bookingDetailsVO = bookingDetailsVO;
		this.bookingId = bookingId;
	}
	public CorporateBookingDetails(BookingDetailsVO bookingDetailsVO, String bookingId, List<CorporateEmployeeVO> corpEmpList) {
		this.bookingDetailsVO = bookingDetailsVO;
		this.bookingId = bookingId;
		this.corpEmpList = corpEmpList;
	}
	public void addCorporateEmployee(CorporateEmployeeVO vo){
		corpEmpList.add(vo);
	}
	public void addBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	public BookingDetailsVO getBookingDetailsVO() {
		return bookingDetailsVO;
	}

	public void setBookingDetailsVO(BookingDetailsVO bookingDetailsVO) {
		this.bookingDetailsVO = bookingDetailsVO;
	}

	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	public List<CorporateEmployeeVO> getCorpEmpList() {
		return corpEmpList;
	}

	public void setCorpEmpList(List<CorporateEmployeeVO> corpEmpList) {
		this.corpEmpList = corpEmpList;
	}
}
