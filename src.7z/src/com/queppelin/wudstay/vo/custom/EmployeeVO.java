package com.queppelin.wudstay.vo.custom;

import java.io.Serializable;

public class EmployeeVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1785833948795169387L;
	
	public String empName;
	public Integer empId;
	public String empEmail;
	public Long empContactNumber;
	
	
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getEmpEmail() {
		return empEmail;
	}
	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}
	public Long getEmpContactNumber() {
		return empContactNumber;
	}
	public void setEmpContactNumber(Long empContactNumber) {
		this.empContactNumber = empContactNumber;
	}
	

}
