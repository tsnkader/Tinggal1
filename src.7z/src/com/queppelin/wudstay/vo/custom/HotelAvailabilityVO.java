package com.queppelin.wudstay.vo.custom;

import java.io.Serializable;

public class HotelAvailabilityVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2628771570908011484L;
	
	private Integer rooms;
	
	private Boolean isAvailable;
	
	private Boolean status = Boolean.TRUE ;

	private String errMsg = "An error occurred. Please contact support.";

	public Integer getRooms() {
		return rooms;
	}

	public void setRooms(Integer rooms) {
		this.rooms = rooms;
	}

	public Boolean getIsAvailable() {
		return isAvailable;
	}

	public void setIsAvailable(Boolean isAvailable) {
		this.isAvailable = isAvailable;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}
	
	public String getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}
}
