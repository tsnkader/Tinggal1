package com.queppelin.wudstay.vo.custom;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by hp on 9/29/2015.
 */
public class CorporateForm implements Serializable {
    private Long corpId;
    private String corpName;
    private String corpAddress;

    private String contactName;
    private String contactEmail;
    private String contactNo;

    private String tin;
    private String tan;
    private String cin;

    private String isFixedPriceSingleRoom = "1";
    private String isFixedPriceDoubleRoom = "1";
    private String isFixedPriceTripleRoom = "1";

    private String singleRoomFixedPrice = "";
    private String doubleRoomFixedPrice = "";
    private String tripleRoomFixedPrice = "";

    private String singleRoomPriceInRangeFrom = "";
    private String singleRoomPriceInRangeTo = "";

    private String doubleRoomPriceInRangeFrom = "";
    private String doubleRoomPriceInRangeTo = "";

    private String tripleRoomPriceInRangeFrom = "";
    private String tripleRoomPriceInRangeTo = "";


    List<CorporateLoginDto> corpLoginList = new ArrayList<CorporateLoginDto>();



    public Long getCorpId() {
        return corpId;
    }

    public void setCorpId(Long corpId) {
        this.corpId = corpId;
    }

    public String getCorpName() {
        return corpName;
    }

    public void setCorpName(String corpName) {
        this.corpName = corpName;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public String getContactNo() {
        return contactNo;
    }

    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }

    public String getCorpAddress() {
        return corpAddress;
    }

    public void setCorpAddress(String corpAddress) {
        this.corpAddress = corpAddress;
    }

    public String getTin() {
        return tin;
    }

    public void setTin(String tin) {
        this.tin = tin;
    }

    public String getTan() {
        return tan;
    }

    public void setTan(String tan) {
        this.tan = tan;
    }

    public String getCin() {
        return cin;
    }

    public void setCin(String cin) {
        this.cin = cin;
    }

    public List<CorporateLoginDto> getCorpLoginList() {
        return corpLoginList;
    }

    public void setCorpLoginList(List<CorporateLoginDto> corpLoginList) {
        this.corpLoginList = corpLoginList;
    }

    public void addCorporateLoginDto(CorporateLoginDto dto) {
        if (corpLoginList == null) {
            corpLoginList = new ArrayList<CorporateLoginDto>();
        }
        corpLoginList.add(dto);
    }

    public Integer intIsFixedPriceSingleRoom() {
        try {
            return Integer.parseInt(isFixedPriceSingleRoom.trim());
        } catch (Exception ex) {
            return 0;
        }
    }

    public String getIsFixedPriceSingleRoom() {
        return isFixedPriceSingleRoom;
    }

    public void setIsFixedPriceSingleRoom(String isFixedPriceSingleRoom) {
        this.isFixedPriceSingleRoom = isFixedPriceSingleRoom;
    }

    public Integer intIsFixedPriceDoubleRoom() {
        try {
            return Integer.parseInt(isFixedPriceDoubleRoom.trim());
        } catch (Exception ex ){
            return 0;
        }
    }

    public String getIsFixedPriceDoubleRoom() {
        return isFixedPriceDoubleRoom;
    }

    public void setIsFixedPriceDoubleRoom(String isFixedPriceDoubleRoom) {
        this.isFixedPriceDoubleRoom = isFixedPriceDoubleRoom;
    }

    public Integer intIsFixedPriceTripleRoom() {
        try {
            return Integer.parseInt(isFixedPriceTripleRoom.trim());
        } catch (Exception ex ){
            return 0;
        }
    }

    public String getIsFixedPriceTripleRoom() {
        return isFixedPriceTripleRoom;
    }

    public void setIsFixedPriceTripleRoom(String isFixedPriceTripleRoom) {
        this.isFixedPriceTripleRoom = isFixedPriceTripleRoom;
    }

    public Integer intSingleRoomFixedPrice() {
        try {
            return Integer.parseInt(singleRoomFixedPrice.trim());
        } catch (Exception ex ){
            return  null;
        }
    }
    public String getSingleRoomFixedPrice() {
        return singleRoomFixedPrice;
    }

    public void setSingleRoomFixedPrice(String singleRoomFixedPrice) {
        this.singleRoomFixedPrice = singleRoomFixedPrice;
    }

    public Integer intDoubleRoomFixedPrice() {
        try {
            return Integer.parseInt(doubleRoomFixedPrice.trim());
        } catch (Exception ex ){
            return  null;
        }
    }
    public String getDoubleRoomFixedPrice() {
        return doubleRoomFixedPrice;
    }

    public void setDoubleRoomFixedPrice(String doubleRoomFixedPrice) {
        this.doubleRoomFixedPrice = doubleRoomFixedPrice;
    }

    public Integer intTripleRoomFixedPrice() {
        try {
            return Integer.parseInt(tripleRoomFixedPrice.trim());
        } catch (Exception ex ){
            return  null;
        }
    }
    public String getTripleRoomFixedPrice() {
        return tripleRoomFixedPrice;
    }

    public void setTripleRoomFixedPrice(String tripleRoomFixedPrice) {
        this.tripleRoomFixedPrice = tripleRoomFixedPrice;
    }

    public Integer intSingleRoomPriceInRangeFrom() {
        try {
            return Integer.parseInt(singleRoomPriceInRangeFrom.trim());
        } catch (Exception ex ){
            return  null;
        }
    }
    public String getSingleRoomPriceInRangeFrom() {
        return singleRoomPriceInRangeFrom;
    }

    public void setSingleRoomPriceInRangeFrom(String singleRoomPriceInRangeFrom) {
        this.singleRoomPriceInRangeFrom = singleRoomPriceInRangeFrom;
    }

    public Integer intSingleRoomPriceInRangeTo() {
        try {
            return Integer.parseInt(singleRoomPriceInRangeTo.trim());
        } catch (Exception ex ){
            return  null;
        }
    }
    public String getSingleRoomPriceInRangeTo() {
        return singleRoomPriceInRangeTo;
    }

    public void setSingleRoomPriceInRangeTo(String singleRoomPriceInRangeTo) {
        this.singleRoomPriceInRangeTo = singleRoomPriceInRangeTo;
    }

    public Integer intDoubleRoomPriceInRangeFrom() {
        try {
            return Integer.parseInt(doubleRoomPriceInRangeFrom.trim());
        } catch (Exception ex ){
            return  null;
        }
    }
    public String getDoubleRoomPriceInRangeFrom() {
        return doubleRoomPriceInRangeFrom;
    }

    public void setDoubleRoomPriceInRangeFrom(String doubleRoomPriceInRangeFrom) {
        this.doubleRoomPriceInRangeFrom = doubleRoomPriceInRangeFrom;
    }

    public Integer intDoubleRoomPriceInRangeTo() {
        try {
            return Integer.parseInt(doubleRoomPriceInRangeTo.trim());
        } catch (Exception ex ){
            return  null;
        }
    }
    public String getDoubleRoomPriceInRangeTo() {
        return doubleRoomPriceInRangeTo;
    }

    public void setDoubleRoomPriceInRangeTo(String doubleRoomPriceInRangeTo) {
        this.doubleRoomPriceInRangeTo = doubleRoomPriceInRangeTo;
    }

    public Integer intTripleRoomPriceInRangeFrom() {
        try {
            return Integer.parseInt(tripleRoomPriceInRangeFrom.trim());
        } catch (Exception ex ){
            return  null;
        }
    }
    public String getTripleRoomPriceInRangeFrom() {
        return tripleRoomPriceInRangeFrom;
    }

    public void setTripleRoomPriceInRangeFrom(String tripleRoomPriceInRangeFrom) {
        this.tripleRoomPriceInRangeFrom = tripleRoomPriceInRangeFrom;
    }

    public Integer intTripleRoomPriceInRangeTo() {
        try {
            return Integer.parseInt(tripleRoomPriceInRangeTo.trim());
        } catch (Exception ex ){
            return  null;
        }
    }
    public String getTripleRoomPriceInRangeTo() {
        return tripleRoomPriceInRangeTo;
    }

    public void setTripleRoomPriceInRangeTo(String tripleRoomPriceInRangeTo) {
        this.tripleRoomPriceInRangeTo = tripleRoomPriceInRangeTo;
    }
}
