package com.queppelin.wudstay.vo.custom;

import java.io.Serializable;

/**
 * Created by hp on 10/14/2015.
 */
public class KeyValueBean implements Serializable {
    private Long key;
    private String value;

    public KeyValueBean(){}
    public  KeyValueBean(Long key, String value) {
        this.key = key;
        this.value = value;
    }

    public Long getKey() {
        return key;
    }

    public void setKey(Long key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
