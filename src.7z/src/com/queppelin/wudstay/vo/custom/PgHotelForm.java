package com.queppelin.wudstay.vo.custom;

import org.springframework.web.multipart.MultipartFile;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class PgHotelForm implements Serializable {
	private Long hotelId;
	private Long userId;
	//Hotel Info
	private Long cityId;
	private Long locationId;
	private Long pgTypeId;
	private String hotelName;
	private String hotelDisplayName;
	private String hotelAddress;
	private String hotelDisplayAddress;
	private String howToReach;
	private String mapLink;
	private Boolean isActiveHotel;
	private MultipartFile roomImage;

	private String cityName;
	private String locationName;
	private Double latitude;
	private Double longitude;
	//Room Info
	private Integer singleOccupancyPrice;
	private Integer doubleOccupancyPrice;
	private Integer tripleOccupancyPrice;

	private Integer singleOccupancyWudstayPrice;
	private Integer doubleOccupancyWudstayPrice;
	private Integer tripleOccupancyWudstayPrice;

	private Integer singleOccupancyBeds;
	private Integer doubleOccupancyBeds;
	private Integer tripleOccupancyBeds;

	private MultipartFile hotelImages[];

	private String amenities[];
	//admin details
	private String username;
	private String userFullName;
	private String email;
	private String mobileNumber;
	private String password;
	private Boolean isActiveUser;
	//contact Details
	private String contactPersonName1;
	private String contactPersonName2;
	private String contactPersonNumber1;
	private String contactPersonNumber2;
	private String contactPersonEmail1;
	private String contactPersonEmail2;

	private List<HotelDescriptionVO> hotelDescriptionVOList = new ArrayList<HotelDescriptionVO>();
	//private List<HotelRoomVO> hotelRoomVOList = new ArrayList<HotelRoomVO>();
	//private List<RoomTypeVO> roomTypeVOList = new ArrayList<RoomTypeVO>();


	public Long getHotelId() {
		return hotelId;
	}

	public void setHotelId(Long hotelId) {
		this.hotelId = hotelId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getCityId() {
		return cityId;
	}

	public void setCityId(Long cityId) {
		this.cityId = cityId;
	}

	public Long getLocationId() {
		return locationId;
	}

	public void setLocationId(Long locationId) {
		this.locationId = locationId;
	}

	public Long getPgTypeId() {
		return pgTypeId;
	}

	public void setPgTypeId(Long pgTypeId) {
		this.pgTypeId = pgTypeId;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public String getHotelDisplayName() {
		return hotelDisplayName;
	}

	public void setHotelDisplayName(String hotelDisplayName) {
		this.hotelDisplayName = hotelDisplayName;
	}

	public String getHotelAddress() {
		return hotelAddress;
	}

	public void setHotelAddress(String hotelAddress) {
		this.hotelAddress = hotelAddress;
	}

	public String getHotelDisplayAddress() {
		return hotelDisplayAddress;
	}

	public void setHotelDisplayAddress(String hotelDisplayAddress) {
		this.hotelDisplayAddress = hotelDisplayAddress;
	}

	public String getHowToReach() {
		return howToReach;
	}

	public void setHowToReach(String howToReach) {
		this.howToReach = howToReach;
	}

	public String getMapLink() {
		return mapLink;
	}

	public void setMapLink(String mapLink) {
		this.mapLink = mapLink;
	}

	public Boolean getIsActiveHotel() {
		return isActiveHotel;
	}

	public void setIsActiveHotel(Boolean isActiveHotel) {
		this.isActiveHotel = isActiveHotel;
	}

	public MultipartFile getRoomImage() {
		return roomImage;
	}

	public void setRoomImage(MultipartFile roomImage) {
		this.roomImage = roomImage;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public Integer getSingleOccupancyPrice() {
		return singleOccupancyPrice;
	}

	public void setSingleOccupancyPrice(Integer singleOccupancyPrice) {
		this.singleOccupancyPrice = singleOccupancyPrice;
	}

	public Integer getDoubleOccupancyPrice() {
		return doubleOccupancyPrice;
	}

	public void setDoubleOccupancyPrice(Integer doubleOccupancyPrice) {
		this.doubleOccupancyPrice = doubleOccupancyPrice;
	}

	public Integer getTripleOccupancyPrice() {
		return tripleOccupancyPrice;
	}

	public void setTripleOccupancyPrice(Integer tripleOccupancyPrice) {
		this.tripleOccupancyPrice = tripleOccupancyPrice;
	}

	public Integer getSingleOccupancyWudstayPrice() {
		return singleOccupancyWudstayPrice;
	}

	public void setSingleOccupancyWudstayPrice(Integer singleOccupancyWudstayPrice) {
		this.singleOccupancyWudstayPrice = singleOccupancyWudstayPrice;
	}

	public Integer getDoubleOccupancyWudstayPrice() {
		return doubleOccupancyWudstayPrice;
	}

	public void setDoubleOccupancyWudstayPrice(Integer doubleOccupancyWudstayPrice) {
		this.doubleOccupancyWudstayPrice = doubleOccupancyWudstayPrice;
	}

	public Integer getTripleOccupancyWudstayPrice() {
		return tripleOccupancyWudstayPrice;
	}

	public void setTripleOccupancyWudstayPrice(Integer tripleOccupancyWudstayPrice) {
		this.tripleOccupancyWudstayPrice = tripleOccupancyWudstayPrice;
	}

	public Integer getSingleOccupancyBeds() {
		return singleOccupancyBeds;
	}

	public void setSingleOccupancyBeds(Integer singleOccupancyBeds) {
		this.singleOccupancyBeds = singleOccupancyBeds;
	}

	public Integer getDoubleOccupancyBeds() {
		return doubleOccupancyBeds;
	}

	public void setDoubleOccupancyBeds(Integer doubleOccupancyBeds) {
		this.doubleOccupancyBeds = doubleOccupancyBeds;
	}

	public Integer getTripleOccupancyBeds() {
		return tripleOccupancyBeds;
	}

	public void setTripleOccupancyBeds(Integer tripleOccupancyBeds) {
		this.tripleOccupancyBeds = tripleOccupancyBeds;
	}

	public MultipartFile[] getHotelImages() {
		return hotelImages;
	}

	public void setHotelImages(MultipartFile[] hotelImages) {
		this.hotelImages = hotelImages;
	}

	public String[] getAmenities() {
		return amenities;
	}

	public void setAmenities(String[] amenities) {
		this.amenities = amenities;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Boolean getIsActiveUser() {
		return isActiveUser;
	}

	public void setIsActiveUser(Boolean isActiveUser) {
		this.isActiveUser = isActiveUser;
	}

	public String getContactPersonName1() {
		return contactPersonName1;
	}

	public void setContactPersonName1(String contactPersonName1) {
		this.contactPersonName1 = contactPersonName1;
	}

	public String getContactPersonName2() {
		return contactPersonName2;
	}

	public void setContactPersonName2(String contactPersonName2) {
		this.contactPersonName2 = contactPersonName2;
	}

	public String getContactPersonNumber1() {
		return contactPersonNumber1;
	}

	public void setContactPersonNumber1(String contactPersonNumber1) {
		this.contactPersonNumber1 = contactPersonNumber1;
	}

	public String getContactPersonNumber2() {
		return contactPersonNumber2;
	}

	public void setContactPersonNumber2(String contactPersonNumber2) {
		this.contactPersonNumber2 = contactPersonNumber2;
	}

	public String getContactPersonEmail1() {
		return contactPersonEmail1;
	}

	public void setContactPersonEmail1(String contactPersonEmail1) {
		this.contactPersonEmail1 = contactPersonEmail1;
	}

	public String getContactPersonEmail2() {
		return contactPersonEmail2;
	}

	public void setContactPersonEmail2(String contactPersonEmail2) {
		this.contactPersonEmail2 = contactPersonEmail2;
	}

	public List<HotelDescriptionVO> getHotelDescriptionVOList() {
		return hotelDescriptionVOList;
	}

	public void setHotelDescriptionVOList(List<HotelDescriptionVO> hotelDescriptionVOList) {
		this.hotelDescriptionVOList = hotelDescriptionVOList;
	}
}
