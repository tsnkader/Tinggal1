package com.queppelin.wudstay.vo.custom;


import java.io.Serializable;

/**
 * Created by hp on 9/29/2015.
 */
public class CorporateLoginDto implements Serializable{
    private Long corpLoginId;
    private Long corpId;
    private String contactName="";
    private String contactNumber="";
    private String contactEmail="";
    private String loginID="";
    private String loginPassword="";



    public Long getNoneNullCorpLoginId() {
        return corpLoginId==null? 0L : corpLoginId.longValue();
    }

    public void setNoneNullCorpLoginId(Long noneNullCorpLoginId) {
        corpLoginId = noneNullCorpLoginId;
    }

    public Long getCorpLoginId() {
        return corpLoginId;
    }

    public void setCorpLoginId(Long corpLoginId) {
        this.corpLoginId = corpLoginId;
    }

    public Long getCorpId() {
        return corpId;
    }

    public void setCorpId(Long corpId) {
        this.corpId = corpId;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public String getLoginID() {
        return loginID;
    }

    public void setLoginID(String loginID) {
        this.loginID = loginID;
    }

    public String getLoginPassword() {
        return loginPassword;
    }

    public void setLoginPassword(String loginPassword) {
        this.loginPassword = loginPassword;
    }
}
