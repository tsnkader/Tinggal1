package com.queppelin.wudstay.vo.custom;

import java.io.Serializable;

public class ExcelGuestBookingDetailsVO implements Serializable {
	public String  guestName;
	public String  guestEmail;
	public String  guestMobNo;

	public ExcelGuestBookingDetailsVO(){}

	public ExcelGuestBookingDetailsVO(String guestName, String guestEmail, String guestMobNo) {
		this.guestName = guestName;
		this.guestEmail = guestEmail;
		this.guestMobNo = guestMobNo;
	}

	public String getGuestName() {
		return guestName;
	}

	public void setGuestName(String guestName) {
		this.guestName = guestName;
	}

	public String getGuestEmail() {
		return guestEmail;
	}

	public void setGuestEmail(String guestEmail) {
		this.guestEmail = guestEmail;
	}

	public String getGuestMobNo() {
		return guestMobNo;
	}

	public void setGuestMobNo(String guestMobNo) {
		this.guestMobNo = guestMobNo;
	}

	
	public String toString() {
		return "ExcelGuestBookingDetailsVO{" +
				"guestName='" + guestName + '\'' +
				", guestEmail='" + guestEmail + '\'' +
				", guestMobNo='" + guestMobNo + '\'' +
				'}';
	}
}
