package com.queppelin.wudstay.vo.custom;

/**
 * Created by hp on 12/7/2015.
 */
public class PayuHashVO  implements java.io.Serializable{
    String key = "gtKFFx";
    String salt = "eCwWELxi";

    String paymentHash;
    String merchantCodesHash;
    String mobileSdk;
    String detailsForMobileSdk;
    String deleteHash;
    String getUserCardHash;
    String editUserCardHash;
    String saveUserCardHash;


    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getSalt() {
        return salt;
    }

    public void setSalt(String salt) {
        this.salt = salt;
    }

    public String getPaymentHash() {
        return paymentHash;
    }

    public void setPaymentHash(String paymentHash) {
        this.paymentHash = paymentHash;
    }

    public String getMerchantCodesHash() {
        return merchantCodesHash;
    }

    public void setMerchantCodesHash(String merchantCodesHash) {
        this.merchantCodesHash = merchantCodesHash;
    }

    public String getMobileSdk() {
        return mobileSdk;
    }

    public void setMobileSdk(String mobileSdk) {
        this.mobileSdk = mobileSdk;
    }

    public String getDetailsForMobileSdk() {
        return detailsForMobileSdk;
    }

    public void setDetailsForMobileSdk(String detailsForMobileSdk) {
        this.detailsForMobileSdk = detailsForMobileSdk;
    }

    public String getDeleteHash() {
        return deleteHash;
    }

    public void setDeleteHash(String deleteHash) {
        this.deleteHash = deleteHash;
    }

    public String getGetUserCardHash() {
        return getUserCardHash;
    }

    public void setGetUserCardHash(String getUserCardHash) {
        this.getUserCardHash = getUserCardHash;
    }

    public String getEditUserCardHash() {
        return editUserCardHash;
    }

    public void setEditUserCardHash(String editUserCardHash) {
        this.editUserCardHash = editUserCardHash;
    }

    public String getSaveUserCardHash() {
        return saveUserCardHash;
    }

    public void setSaveUserCardHash(String saveUserCardHash) {
        this.saveUserCardHash = saveUserCardHash;
    }
}
