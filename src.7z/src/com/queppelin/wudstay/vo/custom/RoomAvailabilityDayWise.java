package com.queppelin.wudstay.vo.custom;

/**
 * Created by hp on 10/26/2015.
 */
public class RoomAvailabilityDayWise implements java.io.Serializable  {
    private long day;
    private int totalRooms = 0;
    private int bookedRooms = 0;
    //private int availableRooms;

    public RoomAvailabilityDayWise(){}
    public RoomAvailabilityDayWise(long day, int totalRooms, int bookedRooms) {
        this.day = day;
        this.totalRooms = totalRooms;
        this.bookedRooms = bookedRooms;
    }

    public long getDay() {
        return day;
    }

    public void setDay(long day) {
        this.day = day;
    }

    public int getTotalRooms() {
        return totalRooms;
    }

    public void setTotalRooms(int totalRooms) {
        this.totalRooms = totalRooms;
    }

    public int getBookedRooms() {
        return bookedRooms;
    }

    public void setBookedRooms(int bookedRooms) {
        this.bookedRooms = bookedRooms;
    }

    public void addBookedRooms(int bookedRooms) {
        this.bookedRooms += bookedRooms;
    }

    public int getAvailableRooms() {
        return totalRooms - bookedRooms;
    }
/*
    
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof RoomAvailabilityDayWise)) return false;

        RoomAvailabilityDayWise that = (RoomAvailabilityDayWise) o;

        if (bookedRooms != that.bookedRooms) return false;
        if (day != that.day) return false;
        if (totalRooms != that.totalRooms) return false;

        return true;
    }

    
    public int hashCode() {
        int result = (int) (day ^ (day >>> 32));
        result = 31 * result + totalRooms;
        result = 31 * result + bookedRooms;
        return result;
    }
    */
}
