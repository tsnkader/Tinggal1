package com.queppelin.wudstay.vo.custom;

import java.io.Serializable;

public class RoomTypeMasterVO implements Serializable {
	
	private static final long serialVersionUID = -1923665074452927121L;

	private Long roomTypeId;
	private String description;
	public Long getRoomTypeId() {
		return roomTypeId;
	}
	public void setRoomTypeId(Long roomTypeId) {
		this.roomTypeId = roomTypeId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
}
