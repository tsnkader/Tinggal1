package com.queppelin.wudstay.vo.custom;

import java.io.Serializable;

import org.springframework.web.multipart.MultipartFile;

public class HotelRoomVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2168306222120509524L;
	
	private Long hotelRoomId;
	
	private String roomNo;
	
	private Boolean roomStatus;

	public String getRoomNo() {
		return roomNo;
	}

	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}

	public Boolean getRoomStatus() {
		return roomStatus;
	}

	public void setRoomStatus(Boolean roomStatus) {
		this.roomStatus = roomStatus;
	}

	public Long getHotelRoomId() {
		return hotelRoomId;
	}

	public void setHotelRoomId(Long hotelRoomId) {
		this.hotelRoomId = hotelRoomId;
	}
}
