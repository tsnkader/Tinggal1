package com.queppelin.wudstay.vo.custom;

import java.io.Serializable;
import java.util.Date;

public class CorporateVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5491800036628383462L;

	private Long corpId;
	private String corpName;
	private String corpAddress;
	private String corpContactPersonName;
	private String corpContactPersonEmail;
	private String corpContactNo;
	private String corpTAN;
	private String corpTIN;
	private String corpCIN;
	private Boolean isActive;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;
	
	private String corpLoginID;
	private String corpLoginPassword;

	public Long getCorpId() {
		return corpId;
	}

	public void setCorpId(Long corpId) {
		this.corpId = corpId;
	}

	public String getCorpName() {
		return corpName;
	}

	public void setCorpName(String corpName) {
		this.corpName = corpName;
	}

	public String getCorpAddress() {
		return corpAddress;
	}

	public void setCorpAddress(String corpAddress) {
		this.corpAddress = corpAddress;
	}

	public String getCorpContactPersonName() {
		return corpContactPersonName;
	}

	public void setCorpContactPersonName(String corpContactPersonName) {
		this.corpContactPersonName = corpContactPersonName;
	}

	public String getCorpContactPersonEmail() {
		return corpContactPersonEmail;
	}

	public void setCorpContactPersonEmail(String corpContactPersonEmail) {
		this.corpContactPersonEmail = corpContactPersonEmail;
	}

	public String getCorpContactNo() {
		return corpContactNo;
	}

	public void setCorpContactNo(String corpContactNo) {
		this.corpContactNo = corpContactNo;
	}

	public String getCorpTAN() {
		return corpTAN;
	}

	public void setCorpTAN(String corpTAN) {
		this.corpTAN = corpTAN;
	}

	public String getCorpTIN() {
		return corpTIN;
	}

	public void setCorpTIN(String corpTIN) {
		this.corpTIN = corpTIN;
	}

	public String getCorpCIN() {
		return corpCIN;
	}

	public void setCorpCIN(String corpCIN) {
		this.corpCIN = corpCIN;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getCorpLoginID() {
		return corpLoginID;
	}

	public void setCorpLoginID(String corpLoginID) {
		this.corpLoginID = corpLoginID;
	}

	public String getCorpLoginPassword() {
		return corpLoginPassword;
	}

	public void setCorpLoginPassword(String corpLoginPassword) {
		this.corpLoginPassword = corpLoginPassword;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
