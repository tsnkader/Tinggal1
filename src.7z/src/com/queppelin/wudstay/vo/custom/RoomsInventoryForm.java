package com.queppelin.wudstay.vo.custom;

import com.queppelin.wudstay.util.DateUtil;
import com.queppelin.wudstay.vo.RoomsInventoryVO;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class RoomsInventoryForm implements java.io.Serializable {
    private RoomsInventoryVO roomsInventory = null;
    private List<RoomsDayInventory> calendar = new ArrayList<RoomsDayInventory>();
    private String strDate="";
    private int month;
    private int year;
    private int bookedRooms;
    private String monthName="";
    //private Long hotelId = null;

    public RoomsInventoryForm() {
        this(new Date(), new RoomsInventoryVO());
    }
    public RoomsInventoryForm(Long hotelId, Date date) {
        this(date, new RoomsInventoryVO());
        setHotelId(hotelId);
    }
    /*public RoomsInventoryForm(String strDate) {
        this(DateUtil.toDisplayDate(strDate), new RoomsInventoryVO());
    }
    public RoomsInventoryForm(RoomsInventoryVO roomsInventory) {
        this(new Date(), roomsInventory);
    }
    public RoomsInventoryForm(String strDate, RoomsInventoryVO roomsInventory) {
        this(DateUtil.toDisplayDate(strDate), roomsInventory);
    }*/

    public RoomsInventoryForm(Date date, RoomsInventoryVO roomsInventory ) {
        DateUtil dateUtil = new DateUtil(date);
        this.strDate = DateUtil.toDisplayDate(date);
        month=dateUtil.getMonth();
        year=dateUtil.getYear();
        monthName=dateUtil.getMonthFullName();
        this.roomsInventory = roomsInventory;
        setNoOfRooms(0);
    }
    //------------------------------------------------------------------------------------------------------------------

    public RoomsInventoryVO fetchRoomsInventoryVO(){
        return roomsInventory;
    }

    public Long getId() {
        return roomsInventory.getId();
    }

    public void setLastUpdatedDate(Date lastUpdatedDate) {
        roomsInventory.setLastUpdatedDate(lastUpdatedDate);
    }

    public void setId(Long id) {
        roomsInventory.setId(id);
    }

    public void setNoOfRooms(Integer noOfRooms) {
        roomsInventory.setNoOfRooms(noOfRooms);
    }

    public Date getLastUpdatedDate() {
        return roomsInventory.getLastUpdatedDate();
    }

    public void setHotelId(Long hotelId) {
        roomsInventory.setHotelId(hotelId);
    }

    public void setInventoryDate(Date inventoryDate) {
        roomsInventory.setInventoryDate(inventoryDate);
    }

    public Long getHotelId() {
        return roomsInventory.getHotelId();
    }

    public void setInventoryLongDate(Long inventoryLongDate) {
        roomsInventory.setInventoryLongDate(inventoryLongDate);
    }

    public Integer getNoOfRooms() {
        if(roomsInventory.getNoOfRooms()==null)
            return 0;
        else
            return roomsInventory.getNoOfRooms();
    }

    public Long getInventoryLongDate() {
        return roomsInventory.getInventoryLongDate();
    }

    public Date getInventoryDate() {
        return roomsInventory.getInventoryDate();
    }

    public List<RoomsDayInventory> getCalendar() {
        return calendar;
    }

    public void setCalendar(List<RoomsDayInventory> calendar) {
        this.calendar = calendar;
    }

    public void addCalenderDay(RoomsDayInventory day){
        this.calendar.add(day);
    }
    public void addCalenderDay(int noOfRooms, int bookedRooms, String strDate){
        this.calendar.add(new RoomsDayInventory(noOfRooms, bookedRooms, strDate));
    }
    public int calenderSize(){
        return this.calendar.size();
    }

    public String getStrDate() {
        return strDate;
    }

    public void setStrDate(String strDate) {
        this.strDate = strDate;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getBookedRooms() {
        return bookedRooms;
    }

    public void setBookedRooms(int bookedRooms) {
        this.bookedRooms = bookedRooms;
    }

    public String getMonthName() {
        return monthName;
    }

    public void setMonthName(String monthName) {
        this.monthName = monthName;
    }
}
