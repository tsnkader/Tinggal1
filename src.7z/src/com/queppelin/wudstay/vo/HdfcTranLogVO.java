package com.queppelin.wudstay.vo;

import com.queppelin.wudstay.util.HdfcPaymentUtil;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.util.WudstayMappings;

import javax.persistence.*;
import java.util.Date;


import static javax.persistence.GenerationType.IDENTITY;

/*
drop table hdfc_tran_log;
CREATE TABLE hdfc_tran_log(
	log_id 				INT(11) PRIMARY KEY auto_increment,
	description			VARCHAR(255)  DEFAULT NULL,
	amount				VARCHAR(25)  DEFAULT NULL,
	name				VARCHAR(100)  DEFAULT NULL,
	phone				VARCHAR(25)  DEFAULT NULL,
	email				VARCHAR(100)  DEFAULT NULL,

	currency			VARCHAR(25)  DEFAULT NULL,
	algo       			VARCHAR(25)  DEFAULT NULL,
	channel				VARCHAR(25)  DEFAULT NULL,
	mode				VARCHAR(25)  DEFAULT NULL,
	reference_no		VARCHAR(25)  DEFAULT NULL,
	return_url			VARCHAR(100)  DEFAULT NULL,
	secure_hash			VARCHAR(50)  DEFAULT NULL,

	account_id 			VARCHAR(25)  DEFAULT NULL,
	address    			VARCHAR(255)  DEFAULT NULL,
	city				VARCHAR(25)  DEFAULT NULL,
	country				VARCHAR(25)  DEFAULT NULL,
	postal_code			VARCHAR(25)  DEFAULT NULL,
	ship_address		VARCHAR(25)  DEFAULT NULL,
	ship_city			VARCHAR(25)  DEFAULT NULL,
	ship_country		VARCHAR(25)  DEFAULT NULL,
	ship_name			VARCHAR(25)  DEFAULT NULL,
	ship_phone			VARCHAR(25)  DEFAULT NULL,
	ship_postal_code	VARCHAR(25)  DEFAULT NULL,
	ship_state			VARCHAR(25)  DEFAULT NULL,
	state				VARCHAR(25)  DEFAULT NULL,
	log_time			timestamp
);

CREATE TABLE hdfc_tran_log( log_id INT(11) NOT NULL AUTO_INCREMENT, description VARCHAR(255)  DEFAULT NULL, amount VARCHAR(25)  DEFAULT NULL, name VARCHAR(100)  DEFAULT NULL, phone VARCHAR(25)  DEFAULT NULL, email VARCHAR(100)  DEFAULT NULL, currency VARCHAR(25)  DEFAULT NULL, algo VARCHAR(25)  DEFAULT NULL, channel VARCHAR(25)  DEFAULT NULL, mode VARCHAR(25)  DEFAULT NULL, reference_no VARCHAR(25)  DEFAULT NULL, return_url VARCHAR(100)  DEFAULT NULL, secure_hash VARCHAR(50)  DEFAULT NULL, account_id VARCHAR(25)  DEFAULT NULL, address VARCHAR(255)  DEFAULT NULL, city VARCHAR(25)  DEFAULT NULL, country VARCHAR(25)  DEFAULT NULL, postal_code VARCHAR(25)  DEFAULT NULL, ship_address VARCHAR(25)  DEFAULT NULL, ship_city VARCHAR(25)  DEFAULT NULL, ship_country VARCHAR(25)  DEFAULT NULL, ship_name VARCHAR(25)  DEFAULT NULL, ship_phone VARCHAR(25)  DEFAULT NULL, ship_postal_code VARCHAR(25)  DEFAULT NULL, ship_state VARCHAR(25)  DEFAULT NULL, state VARCHAR(25)  DEFAULT NULL, log_time timestamp , PRIMARY KEY ( log_id ) ) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=latin1;

ALTER TABLE hdfc_tran_log MODIFY reference_no VARCHAR(50);

ALTER TABLE hdfc_tran_log ADD COLUMN booking_id INT(11)  DEFAULT NULL;

 */
@Entity
@Table(name = "hdfc_tran_log")
public class HdfcTranLogVO implements java.io.Serializable {
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "log_id", nullable = false)
	private Long logId;
	//---------------------------------------------------------
	@Column(name = "account_id" )
	private String accountId = HdfcPaymentUtil.account_id; //credentialsParamMap.get("account_id");
	@Column(name = "address" )
	private String address = "146 - 147, Centrum Plaza, DLF Golf Course, Sector 53";
	@Column(name = "algo" )
	private String algo = HdfcPaymentUtil.algo; //credentialsParamMap.get("algo");
	@Column(name = "amount" )
	private String amount = "0";
	@Column(name = "channel" )
	private String channel  = HdfcPaymentUtil.channel; //credentialsParamMap.get("channel");
	@Column(name = "city" )
	private String city = "Gurgaon";
	@Column(name = "country" )
	private String country = "IND";
	@Column(name = "currency" )
	private String currency  = HdfcPaymentUtil.currency; //credentialsParamMap.get("currency");
	@Column(name = "description" )
	private String description = "Payment Ref: -"; //"-";
	@Column(name = "email" )
	private String email = "support@tinggal.com"; //"-";
	@Column(name = "mode" )
	private String mode = HdfcPaymentUtil.mode; //credentialsParamMap.get("mode");
	@Column(name = "name" )
	private String name = "-";
	@Column(name = "phone" )
	private String phone = "+62822 8539 0099"; //"-";
	@Column(name = "postal_code" )
	private String postalCode = "122002";
	@Column(name = "reference_no" )
	private String referenceNo = "-";
	@Column(name = "return_url" )
	private String returnUrl = WudstayConstants.BASE_URL + WudstayMappings.HDFC_PAYMENT_RESPONSE; //HdfcPaymentUtil.credentialsParamMap.get("return_url");
	@Column(name = "ship_address" )
	private String shipAddress ;//"Demo Address of Ship";
	@Column(name = "ship_city" )
	private String shipCity ;// "Jaipur";
	@Column(name = "ship_country" )
	private String shipCountry;// "IND";
	@Column(name = "ship_name" )
	private String shipName;//"Demo Ship";
	@Column(name = "ship_phone" )
	private String shipPhone ;//"01412399148";
	@Column(name = "ship_postal_code" )
	private String shipPostalCode;//"302020";
	@Column(name = "ship_state" )
	private String shipState ;//"Rajasthan";
	@Column(name = "state" )
	private String state = "Haryana";
	@Column(name = "secure_hash" )
	private String secureHash ;
	//---------------------------------------------------------
	@Column(name = "log_time", columnDefinition="DATETIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Date logTime =  new Date();
	//---------------------------------------------------------
	@Column(name = "booking_id" )
	private Long bookingId;

	public HdfcTranLogVO() {
	}

	/*public HdfcTranLogVO(boolean defaultValues) {
		accountId = HdfcPaymentUtil.credentialsParamMap.get("account_id");
		channel = HdfcPaymentUtil.credentialsParamMap.get("channel");
		currency = HdfcPaymentUtil.credentialsParamMap.get("currency");
		returnUrl = HdfcPaymentUtil.credentialsParamMap.get("return_url");
		mode = HdfcPaymentUtil.credentialsParamMap.get("mode");
		algo = HdfcPaymentUtil.credentialsParamMap.get("algo");
		//-----------------------------------------------------------------

	}*/

	public Long getLogId() {
		return logId;
	}

	public void setLogId(Long logId) {
		this.logId = logId;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAlgo() {
		return algo;
	}

	public void setAlgo(String algo) {
		this.algo = algo;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getReferenceNo() {
		return referenceNo;
	}

	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}

	public String getReturnUrl() {
		return returnUrl;
	}

	public void setReturnUrl(String returnUrl) {
		this.returnUrl = returnUrl;
	}

	public String getShipAddress() {
		return shipAddress;
	}

	public void setShipAddress(String shipAddress) {
		this.shipAddress = shipAddress;
	}

	public String getShipCity() {
		return shipCity;
	}

	public void setShipCity(String shipCity) {
		this.shipCity = shipCity;
	}

	public String getShipCountry() {
		return shipCountry;
	}

	public void setShipCountry(String shipCountry) {
		this.shipCountry = shipCountry;
	}

	public String getShipName() {
		return shipName;
	}

	public void setShipName(String shipName) {
		this.shipName = shipName;
	}

	public String getShipPhone() {
		return shipPhone;
	}

	public void setShipPhone(String shipPhone) {
		this.shipPhone = shipPhone;
	}

	public String getShipPostalCode() {
		return shipPostalCode;
	}

	public void setShipPostalCode(String shipPostalCode) {
		this.shipPostalCode = shipPostalCode;
	}

	public String getShipState() {
		return shipState;
	}

	public void setShipState(String shipState) {
		this.shipState = shipState;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getSecureHash() {
		return secureHash;
	}

	public void setSecureHash(String secureHash) {
		this.secureHash = secureHash;
	}

	public Date getLogTime() {
		return logTime;
	}

	public void setLogTime(Date logTime) {
		this.logTime = logTime;
	}

	public Long getBookingId() {
		return bookingId;
	}

	public void setBookingId(Long bookingId) {
		this.bookingId = bookingId;
	}
}
