package com.queppelin.wudstay.vo;

import javax.persistence.*;
import java.util.Date;
import java.util.List;
import java.util.Set;

import static javax.persistence.GenerationType.IDENTITY;

/*
delete table corporate
CREATE TABLE corporate(
	corp_id INT(11) PRIMARY KEY auto_increment,
	corp_name VARCHAR(100) NOT NULL,
	corp_address VARCHAR(500),
	corp_contact_person_name VARCHAR(100) NOT NULL,
	corp_contact_number VARCHAR(50),
	corp_tan_number VARCHAR(100) NOT NULL,
	corp_tin_number VARCHAR(100) NOT NULL,
	corp_cin_number VARCHAR(100) NOT NULL,
	is_active Char(1) DEFAULT 'Y',
	last_updated_by VARCHAR(50),
	last_updated_date DATE,
	corp_login_id VARCHAR(100),
	corp_login_password VARCHAR(100)
);


ALTER TABLE corporate ADD COLUMN corp_email VARCHAR(50) DEFAULT null

ALTER TABLE corporate ADD COLUMN sRoomFixedPrice int(11) DEFAULT NULL;
ALTER TABLE corporate ADD COLUMN dRoomFixedPrice int(11) DEFAULT NULL;
ALTER TABLE corporate ADD COLUMN tRoomFixedPrice int(11) DEFAULT NULL;
ALTER TABLE corporate ADD COLUMN sRoomPriceFrom int(11) DEFAULT NULL;
ALTER TABLE corporate ADD COLUMN dRoomPriceFrom int(11) DEFAULT NULL;
ALTER TABLE corporate ADD COLUMN tRoomPriceFrom int(11) DEFAULT NULL;
ALTER TABLE corporate ADD COLUMN sRoomPriceTo int(11) DEFAULT NULL;
ALTER TABLE corporate ADD COLUMN dRoomPriceTo int(11) DEFAULT NULL;
ALTER TABLE corporate ADD COLUMN tRoomPriceTo int(11) DEFAULT NULL;

ALTER TABLE corporate ADD COLUMN sRoomPriceIsFixed int(1) DEFAULT NULL;
ALTER TABLE corporate ADD COLUMN dRoomPriceIsFixed int(1) DEFAULT NULL;
ALTER TABLE corporate ADD COLUMN tRoomPriceIsFixed int(1) DEFAULT NULL;








 */
@Entity
@Table(name = "corporate" )
public class Corporate implements java.io.Serializable {
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "corp_id", nullable = false)
	private Long corpId;
	@Column(name = "corp_name")
	private String corpName;
	@Column(name = "corp_address")
	private String corpAddress;
	@Column(name = "corp_contact_person_name")
	private String corpContactPersonName;
	@Column(name = "corp_email")
	private String corpContactPersonEmail;
	@Column(name = "corp_contact_number")
	private String corpContactNo;
	@Column(name = "corp_tan_number")
	private String corpTAN;
	@Column(name = "corp_tin_number")
	private String corpTIN;
	@Column(name = "corp_cin_number")
	private String corpCIN;
	@Column(name = "is_active")
	private Boolean isActive;

	@Column(name = "sRoomPriceIsFixed" )
	private Integer singleRoomPriceIsFixed=1;
	@Column(name = "dRoomPriceIsFixed" )
	private Integer doubleRoomPriceIsFixed=1;
	@Column(name = "tRoomPriceIsFixed" )
	private Integer tripleRoomPriceIsFixed=1;

	@Column(name = "sRoomFixedPrice" )
	private Integer singleRoomFixedPrice;
	@Column(name = "dRoomFixedPrice" )
	private Integer doubleRoomFixedPrice;
	@Column(name = "tRoomFixedPrice" )
	private Integer tripleRoomFixedPrice;

	@Column(name = "sRoomPriceFrom" )
	private Integer singleRoomPriceFrom;
	@Column(name = "dRoomPriceFrom" )
	private Integer doubleRoomPriceFrom;
	@Column(name = "tRoomPriceFrom" )
	private Integer tripleRoomPriceFrom;

	@Column(name = "sRoomPriceTo" )
	private Integer singleRoomPriceTo;
	@Column(name = "dRoomPriceTo" )
	private Integer doubleRoomPriceTo;
	@Column(name = "tRoomPriceTo" )
	private Integer tripleRoomPriceTo;

	@Column(name = "last_updated_by", length = 50)
	private String lastUpdatedBy;
	@Temporal(TemporalType.DATE)
	@Column(name = "last_updated_date", length = 10)
	private Date lastUpdatedDate;

	@OneToMany(fetch = FetchType.LAZY )
	@JoinColumn(name="corp_id")
	private Set<CorporateLoginVO> corporateLoginUsers;

	public Corporate() {
	}

	public Long getCorpId() {
		return corpId;
	}

	public void setCorpId(Long corpId) {
		this.corpId = corpId;
	}


	public String getCorpName() {
		return corpName;
	}

	public void setCorpName(String corpName) {
		this.corpName = corpName;
	}
	

	public String getCorpAddress() {
		return corpAddress;
	}

	public void setCorpAddress(String corpAddress) {
		this.corpAddress = corpAddress;
	}


	public String getCorpContactPersonName() {
		return corpContactPersonName;
	}

	public void setCorpContactPersonName(String corpContactPersonName) {
		this.corpContactPersonName = corpContactPersonName;
	}

	public String getCorpContactPersonEmail() {
		return corpContactPersonEmail;
	}

	public void setCorpContactPersonEmail(String corpContactPersonEmail) {
		this.corpContactPersonEmail = corpContactPersonEmail;
	}


	public String getCorpContactNo() {
		return corpContactNo;
	}

	public void setCorpContactNo(String corpContactNo) {
		this.corpContactNo = corpContactNo;
	}


	public String getCorpTAN() {
		return corpTAN;
	}

	public void setCorpTAN(String corpTAN) {
		this.corpTAN = corpTAN;
	}


	public String getCorpTIN() {
		return corpTIN;
	}

	public void setCorpTIN(String corpTIN) {
		this.corpTIN = corpTIN;
	}


	public String getCorpCIN() {
		return corpCIN;
	}

	public void setCorpCIN(String corpCIN) {
		this.corpCIN = corpCIN;
	}


	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}


	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}


	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}


	public Set<CorporateLoginVO> getCorporateLoginUsers() {
		return corporateLoginUsers;
	}

	public void setCorporateLoginUsers(Set<CorporateLoginVO> corporateLoginUsers) {
		this.corporateLoginUsers = corporateLoginUsers;
	}


	public Integer getSingleRoomPriceIsFixed() {
		return singleRoomPriceIsFixed;
	}

	public void setSingleRoomPriceIsFixed(Integer singleRoomPriceIsFixed) {
		this.singleRoomPriceIsFixed = singleRoomPriceIsFixed;
	}

	public Integer getDoubleRoomPriceIsFixed() {
		return doubleRoomPriceIsFixed;
	}

	public void setDoubleRoomPriceIsFixed(Integer doubleRoomPriceIsFixed) {
		this.doubleRoomPriceIsFixed = doubleRoomPriceIsFixed;
	}

	public Integer getTripleRoomPriceIsFixed() {
		return tripleRoomPriceIsFixed;
	}

	public void setTripleRoomPriceIsFixed(Integer tripleRoomPriceIsFixed) {
		this.tripleRoomPriceIsFixed = tripleRoomPriceIsFixed;
	}

	public Integer getSingleRoomFixedPrice() {
		return singleRoomFixedPrice;
	}

	public void setSingleRoomFixedPrice(Integer singleRoomFixedPrice) {
		this.singleRoomFixedPrice = singleRoomFixedPrice;
	}

	public Integer getDoubleRoomFixedPrice() {
		return doubleRoomFixedPrice;
	}

	public void setDoubleRoomFixedPrice(Integer doubleRoomFixedPrice) {
		this.doubleRoomFixedPrice = doubleRoomFixedPrice;
	}

	public Integer getTripleRoomFixedPrice() {
		return tripleRoomFixedPrice;
	}

	public void setTripleRoomFixedPrice(Integer tripleRoomFixedPrice) {
		this.tripleRoomFixedPrice = tripleRoomFixedPrice;
	}

	public Integer getSingleRoomPriceFrom() {
		return singleRoomPriceFrom;
	}

	public void setSingleRoomPriceFrom(Integer singleRoomPriceFrom) {
		this.singleRoomPriceFrom = singleRoomPriceFrom;
	}

	public Integer getDoubleRoomPriceFrom() {
		return doubleRoomPriceFrom;
	}

	public void setDoubleRoomPriceFrom(Integer doubleRoomPriceFrom) {
		this.doubleRoomPriceFrom = doubleRoomPriceFrom;
	}

	public Integer getTripleRoomPriceFrom() {
		return tripleRoomPriceFrom;
	}

	public void setTripleRoomPriceFrom(Integer tripleRoomPriceFrom) {
		this.tripleRoomPriceFrom = tripleRoomPriceFrom;
	}

	public Integer getSingleRoomPriceTo() {
		return singleRoomPriceTo;
	}

	public void setSingleRoomPriceTo(Integer singleRoomPriceTo) {
		this.singleRoomPriceTo = singleRoomPriceTo;
	}

	public Integer getDoubleRoomPriceTo() {
		return doubleRoomPriceTo;
	}

	public void setDoubleRoomPriceTo(Integer doubleRoomPriceTo) {
		this.doubleRoomPriceTo = doubleRoomPriceTo;
	}

	public Integer getTripleRoomPriceTo() {
		return tripleRoomPriceTo;
	}

	public void setTripleRoomPriceTo(Integer tripleRoomPriceTo) {
		this.tripleRoomPriceTo = tripleRoomPriceTo;
	}
}
