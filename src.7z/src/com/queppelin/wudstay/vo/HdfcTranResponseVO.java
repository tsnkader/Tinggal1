package com.queppelin.wudstay.vo;

import javax.persistence.*;

import java.util.Date;

import static javax.persistence.GenerationType.IDENTITY;

/*
drop table hdfc_tran_res
CREATE TABLE hdfc_tran_res(
	res_id              	INT(11) PRIMARY KEY auto_increment,
	res_description			VARCHAR(150) DEFAULT NULL,
	res_code				VARCHAR(25)  DEFAULT NULL,
	res_msg					VARCHAR(100) DEFAULT NULL,
	res_date				VARCHAR(25)  DEFAULT NULL,
	res_payment_id			VARCHAR(25) DEFAULT NULL,
	res_merchant_ref_no		VARCHAR(25) DEFAULT NULL,
	res_amount				VARCHAR(25) DEFAULT NULL,
	res_mode				VARCHAR(25) DEFAULT NULL,
	res_is_flagged			VARCHAR(25) DEFAULT NULL,
	res_transaction_id		VARCHAR(50) DEFAULT NULL,
	res_payment_method		VARCHAR(25) DEFAULT NULL,
	res_request_id			VARCHAR(25) DEFAULT NULL,
	res_secure_hash			VARCHAR(50) DEFAULT NULL,
	res_name				VARCHAR(100) DEFAULT NULL,
	res_phone				VARCHAR(25) DEFAULT NULL,
	res_email				VARCHAR(100) DEFAULT NULL,
	log_time 				timestamp,
	log_id 				    INT(11) DEFAULT NULL
);

CREATE TABLE hdfc_tran_res( res_id INT(11) NOT NULL AUTO_INCREMENT, res_description VARCHAR(150) DEFAULT NULL, res_code VARCHAR(25)  DEFAULT NULL, res_msg VARCHAR(100) DEFAULT NULL, res_date VARCHAR(25)  DEFAULT NULL, res_payment_id VARCHAR(25) DEFAULT NULL, res_merchant_ref_no VARCHAR(25) DEFAULT NULL, res_amount VARCHAR(25) DEFAULT NULL, res_mode VARCHAR(25) DEFAULT NULL, res_is_flagged VARCHAR(25) DEFAULT NULL, res_transaction_id VARCHAR(50) DEFAULT NULL, res_payment_method VARCHAR(25) DEFAULT NULL, res_request_id VARCHAR(25) DEFAULT NULL, res_secure_hash VARCHAR(50) DEFAULT NULL, res_name VARCHAR(100) DEFAULT NULL, res_phone VARCHAR(25) DEFAULT NULL, res_email VARCHAR(100) DEFAULT NULL, log_time timestamp, log_id INT(11) DEFAULT NULL , PRIMARY KEY ( res_id ) ) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=latin1;
 */
@Entity
@Table(name = "hdfc_tran_res")
public class HdfcTranResponseVO implements java.io.Serializable {
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "res_id", nullable = false)
	private Long resId;
	//---------------------------------------------------------
	@Column(name = "res_code" )
	private String responseCode;
	@Column(name = "res_msg" )
	private String responseMessage;
	@Column(name = "res_date" )
	private String dateCreated;
	@Column(name = "res_payment_id" )
	private String paymentID;
	@Column(name = "res_merchant_ref_no" )
	private String merchantRefNo;
	@Column(name = "res_amount" )
	private String amount;
	@Column(name = "res_mode" )
	private String Mode;
	@Column(name = "res_is_flagged" )
	private String IsFlagged;
	@Column(name = "res_transaction_id" )
	private String transactionId;
	@Column(name = "res_payment_method" )
	private String paymentMethod;
	@Column(name = "res_request_id" )
	private String requestId;
	@Column(name = "res_secure_hash" )
	private String secureHash;
	@Column(name = "res_description" )
	private String description;
	//---------------------------------------------------------
	@Column(name = "res_name" )
	private String billingName;
	@Column(name = "res_phone" )
	private String billingPhone;
	@Column(name = "res_email" )
	private String billingEmail;
	//---------------------------------------------------------
	@Column(name = "log_time", columnDefinition="DATETIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Date logTime =  new Date();
	//---------------------------------------------------------
	@Column(name = "log_id" )
	private Long logId;



	public Long getResId() {
		return resId;
	}

	public void setResId(Long resId) {
		this.resId = resId;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public String getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(String dateCreated) {
		this.dateCreated = dateCreated;
	}

	public String getPaymentID() {
		return paymentID;
	}

	public void setPaymentID(String paymentID) {
		this.paymentID = paymentID;
	}

	public String getMerchantRefNo() {
		return merchantRefNo;
	}

	public void setMerchantRefNo(String merchantRefNo) {
		this.merchantRefNo = merchantRefNo;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getMode() {
		return Mode;
	}

	public void setMode(String mode) {
		Mode = mode;
	}

	public String getIsFlagged() {
		return IsFlagged;
	}

	public void setIsFlagged(String isFlagged) {
		IsFlagged = isFlagged;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestID) {
		requestId = requestID;
	}

	public String getSecureHash() {
		return secureHash;
	}

	public void setSecureHash(String secureHash) {
		this.secureHash = secureHash;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getBillingName() {
		return billingName;
	}

	public void setBillingName(String billingName) {
		this.billingName = billingName;
	}

	public String getBillingPhone() {
		return billingPhone;
	}

	public void setBillingPhone(String billingPhone) {
		this.billingPhone = billingPhone;
	}

	public String getBillingEmail() {
		return billingEmail;
	}

	public void setBillingEmail(String billingEmail) {
		this.billingEmail = billingEmail;
	}

	public Date getLogTime() {
		return logTime;
	}

	public void setLogTime(Date logTime) {
		this.logTime = logTime;
	}

	public Long getLogId() {
		return logId;
	}

	public void setLogId(Long logId) {
		this.logId = logId;
	}
}
