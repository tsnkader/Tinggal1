package com.queppelin.wudstay.vo;

import javax.persistence.*;
import java.util.Date;

import static javax.persistence.GenerationType.IDENTITY;

/**
 * Created by hp on 10/1/2015.

DROP TABLE IF EXISTS tblCouponCodeUsed;

 CREATE TABLE tblCouponCodeUsed (
     ccode_Id 				    int(11) 	NOT NULL AUTO_INCREMENT,
     coupon_Id 				    int(11)     NOT NULL,
     ccode_UsedDate 			datetime 	NOT NULL,
     lastUpdatedBy              varchar(50) NOT NULL,
     last_updated_date          datetime 	DEFAULT NULL,
     PRIMARY KEY (ccode_Id),
     KEY corp_id (coupon_Id),
     CONSTRAINT coupon_Id_fk FOREIGN KEY (coupon_Id) REFERENCES tblCouponCode (coupon_Id)
 ) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

 SELECT * FROM tblCouponCode;

 -- ALTER TABLE tblCouponCodeUsed ADD COLUMN last_updated_by varchar(100) 	DEFAULT NULL;
 -- ALTER TABLE tblCouponCodeUsed ADD COLUMN last_updated_date datetime 	DEFAULT NULL;

 ALTER TABLE tblCouponCodeUsed ADD COLUMN coupon_bookingId int(11) 	DEFAULT NULL;
 ALTER TABLE tblCouponCodeUsed ADD COLUMN coupon_discount int(11) 	DEFAULT 0;

 ALTER TABLE tblCouponCodeUsed ADD COLUMN coupon_upperLimit int(11) 	DEFAULT 0;



 CREATE PROCEDURE  sp_used_coupon (  in  v_ccode_Id int(11), in  v_mobile_on VARCHAR(50))
 BEGIN
 SELECT ccode_Id, coupon_Id, ccode_UsedDate, coupon_bookingId, coupon_discount, coupon_discount, tblcouponcodeused.last_updated_date FROM tblcouponcodeused
 LEFT OUTER JOIN  hotel_booking  ON ( coupon_bookingId = booking_id)
 WHERE coupon_Id = v_ccode_Id AND contact_number = v_mobile_on ;
 END;

 CREATE PROCEDURE  sp_used_coupon (  in  v_ccode_Id int(11), in  v_mobile_no VARCHAR(50))
 BEGIN
 SELECT ccode_Id, coupon_Id, ccode_UsedDate, coupon_bookingId, coupon_discount, coupon_discount, tblcouponcodeused.last_updated_date FROM tblcouponcodeused
 LEFT OUTER JOIN  hotel_booking  ON ( coupon_bookingId = booking_id)
 WHERE coupon_Id = v_ccode_Id AND contact_number = v_mobile_no ;
 END;

 */



@NamedNativeQueries({
        @NamedNativeQuery(
                name = "callSpUsedCoupons",
                query = "CALL sp_used_coupon(:v_ccode_Id, :v_mobile_no)",
                resultClass = CouponCodeUsedVO.class
        )
})

@Entity
@Table(name = "tblcouponcodeused" )
public class CouponCodeUsedVO implements java.io.Serializable {
    private static final long serialVersionUID = -1239318992754476680L;
    @Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "ccode_Id", unique = true, nullable = false)
    private Long id;
    @Column(name = "coupon_Id")
    private Long    couponId;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "ccode_UsedDate", nullable = false, length = 19)
    private Date    couponUsedDate;

    @Column(name = "coupon_bookingId")
    private Long bookingId;
    @Column(name = "coupon_discount")
    private Integer    discountAmt;

    //@Column(name = "last_updated_by", length = 100)
    //private String lastUpdatedBy=null; //java.sql.SQLException: Field 'lastUpdatedBy' doesn't have a default value
    @Temporal(TemporalType.DATE)
    @Column(name = "last_updated_date", length = 10)
    private Date   lastUpdatedDate= new Date();




    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCouponId() {
        return couponId;
    }

    public void setCouponId(Long couponId) {
        this.couponId = couponId;
    }

    public Date getCouponUsedDate() {
        return couponUsedDate;
    }

    public void setCouponUsedDate(Date couponUsedDate) {
        this.couponUsedDate = couponUsedDate;
    }

    /*public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }*/

    public Date getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate(Date lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }

    public Long getBookingId() {
        return bookingId;
    }

    public void setBookingId(Long bookingId) {
        this.bookingId = bookingId;
    }

    public Integer getDiscountAmt() {
        return discountAmt;
    }

    public void setDiscountAmt(Integer discountAmt) {
        this.discountAmt = discountAmt;
    }


}
