package com.queppelin.wudstay.vo;


import com.queppelin.wudstay.util.WudstayUtil;
import com.queppelin.wudstay.vo.custom.Employee;
import javax.persistence.*;
import java.util.Date;
import static javax.persistence.GenerationType.IDENTITY;

/*
drop table corporate_employee;

CREATE TABLE corporate_employee(
	emp_id INT(11) PRIMARY KEY auto_increment,
  	corp_id  INT(11)  NULL,
  	corp_booking_id  INT(11)  NULL,
	employee_name VARCHAR(100) NOT NULL,
  	employee_email VARCHAR(50),
  	employee_contact_number VARCHAR(50),
  	last_updated_by   varchar(50) DEFAULT NULL,
    last_updated_date date DEFAULT NULL,
  	unique_ref_key VARCHAR(50) NOT NULL
);

ALTER TABLE corporate_employee ADD COLUMN corp_booking_id  INT(11);
ALTER TABLE corporate_employee ADD COLUMN corp_booking_hotel_id    INT(11);

CREATE TABLE corporate_employee(
	corp_emp_id INT(11) PRIMARY KEY auto_increment,
	corp_emp_name 		VARCHAR(100) NOT NULL,
  	corp_emp_email 		VARCHAR(50),
  	corp_emp_contact_no VARCHAR(50),

  	corp_id  INT(11)  		NOT NULL,
  	corp_booking_id  		INT(11)  DEFAULT NULL,
  	corp_booking_hotel_id 	INT(11)  DEFAULT NULL,

  	last_updated_by   varchar(50) DEFAULT NULL,
    last_updated_date datetime DEFAULT NULL,
);
ALTER TABLE corporate_employee ADD COLUMN is_approved    tinyint(1) 		DEFAULT '0';
is_approved 				tinyint(1) 		DEFAULT '0',

ALTER TABLE corporate_employee ADD COLUMN roommates varchar(100) DEFAULT null

 */

@Entity
@Table(name = "corporate_employee")
public class CorporateEmployeeVO implements java.io.Serializable {
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "corp_emp_id", unique = true, nullable = false)
	private Long empId;
	@Column(name = "corp_emp_name")
	private String empName;
	@Column(name = "corp_emp_email")
	private String empEmail;
	@Column(name = "corp_emp_contact_no")
	private String empContactNumber;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "corp_id")
	private Corporate corporate;
	@Column(name = "corp_booking_id")
	private Long bookingId;
	@Column(name = "corp_booking_hotel_id")
	private Long hotelId;
	@Column(name = "is_approved")
	private Integer isApproved=0;

	@Column(name = "last_updated_by", length = 100)
	private String lastUpdatedBy;
	@Temporal(TemporalType.DATE)
	@Column(name = "last_updated_date", length = 10)
	private Date lastUpdatedDate;

	@Column(name = "roommates", length = 100)
	private String roommates="";
	@Transient
	private String hotelName;


	
	public CorporateEmployeeVO(){
	}

	public CorporateEmployeeVO(Corporate corporate, Employee guestsList) {
		this.corporate = corporate;
		this.empName = guestsList.getEmpName();
		this.empEmail = guestsList.getEmpEmail();
		this.empContactNumber = guestsList.getEmpContactNumber();
	}

	public Long getEmpId() {
		return empId;
	}

	public void setEmpId(Long empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpEmail() {
		return empEmail;
	}

	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}

	public String getEmpContactNumber() {
		return empContactNumber;
	}

	public void setEmpContactNumber(String empContactNumber) {
		this.empContactNumber = empContactNumber;
	}

	public Corporate getCorporate() {
		return corporate;
	}

	public void setCorporate(Corporate corporate) {
		this.corporate = corporate;
	}

	public Long getBookingId() {
		return bookingId;
	}

	public void setBookingId(Long bookingId) {
		this.bookingId = bookingId;
	}

	public Long getHotelId() {
		return hotelId;
	}

	public void setHotelId(Long hotelId) {
		this.hotelId = hotelId;
	}

	public Integer getIsApproved() {
		return isApproved;
	}

	public void setIsApproved(Integer isApproved) {
		this.isApproved = isApproved;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getRoommates() {
		return roommates;
	}

	public void setRoommates(String roommates) {
		this.roommates = roommates;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
}
