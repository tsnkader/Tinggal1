package com.queppelin.wudstay.vo;

import static javax.persistence.GenerationType.IDENTITY;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "room_type_master" )
public class RoomTypeMaster implements java.io.Serializable {
	private static final long serialVersionUID = -6204926605414248165L;

	private Long roomTypeId;
	private String description;
	
	public RoomTypeMaster() {
	}

	public RoomTypeMaster(Long roomTypeId, String description) {
		this.roomTypeId = roomTypeId;
		this.description = description;
	}

	public RoomTypeMaster(String description) {
		this.description = description;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "room_type_id", unique = true, nullable = false)
	public Long getRoomTypeId() {
		return this.roomTypeId;
	}

	public void setRoomTypeId(Long roomTypeId) {
		this.roomTypeId = roomTypeId;
	}

	@Column(name = "description", nullable = false, length = 50)
	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
