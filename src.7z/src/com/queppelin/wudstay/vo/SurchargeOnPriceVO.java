package com.queppelin.wudstay.vo;



import org.hibernate.annotations.Formula;

import javax.persistence.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static javax.persistence.GenerationType.IDENTITY;

/*
 DROP TABLE IF EXISTS surcharge_on_price;

 CREATE TABLE surcharge_on_price (
     id          	int(11)     NOT NULL AUTO_INCREMENT,
     hotel_id    	int(11)     NOT NULL,
     so_surcharge 	int(11)     NOT NULL,
     do_surcharge 	int(11)     NOT NULL,
     to_surcharge 	int(11)     NOT NULL,

     inv_date    	date        NOT NULL,
     str_inv_date 	int(11)    NOT NULL,
     unique_log_key	int(11)    NOT NULL,

     last_modify   timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
     PRIMARY KEY (id)
 ) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;



ALTER TABLE surcharge_on_price ADD INDEX (hotel_id);


 */

@Entity
@Table(name = "surcharge_on_price")
public class SurchargeOnPriceVO implements java.io.Serializable {
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "id", unique = true, nullable = false)
	private Long id;
	@Column(name = "hotel_id")
	private Long hotelId;

	@Column(name = "so_surcharge")
	private Integer singleOccupancySurcharge=0;
	@Column(name = "do_surcharge")
	private Integer doubleOccupancySurcharge=0;
	@Column(name = "to_surcharge")
	private Integer tripleOccupancySurcharge=0;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "inv_date", nullable = false, length = 19)
	private Date inventoryDate;
	@Column(name = "str_inv_date")
	private Long strInventoryDate;
	@Column(name = "unique_log_key")
	private Long uniqueKey;

	@Column(name = "last_modify", columnDefinition="DATETIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastUpdatedDate = new Date();

	@Formula("(select min(str_inv_date) from surcharge_on_price c where c.unique_log_key = unique_log_key)")
	private Long strInventoryFromDate;
	@Formula("(select max(str_inv_date) from surcharge_on_price c where c.unique_log_key = unique_log_key)")
	private Long strInventoryToDate;

	public SurchargeOnPriceVO(){}
	public SurchargeOnPriceVO(Integer allOccupancySurcharge, Date inventoryDate, Long uniqueKey) {
		this(allOccupancySurcharge,allOccupancySurcharge,allOccupancySurcharge,inventoryDate, uniqueKey);
	}
	public SurchargeOnPriceVO(Integer singleOccupancySurcharge, Integer doubleOccupancySurcharge, Integer tripleOccupancySurcharge,
							  Date inventoryDate, Long uniqueKey) {
		this.singleOccupancySurcharge = singleOccupancySurcharge;
		this.doubleOccupancySurcharge = doubleOccupancySurcharge;
		this.tripleOccupancySurcharge = tripleOccupancySurcharge;
		this.inventoryDate = inventoryDate;
		this.lastUpdatedDate=new Date();

		try{
			DateFormat df = new SimpleDateFormat("yyyyMMdd");
			String dtDate = df.format(inventoryDate);
			strInventoryDate = Long.parseLong(dtDate);
			DateFormat df2 = new SimpleDateFormat("yyyyMMdd HH:mm");//MM/dd/yyyy HH:mm:ss
			Date dt = df2.parse(dtDate + " 00:01");
			this.inventoryDate =dt;
			lastUpdatedDate = new Date();
		}catch ( Exception e) {
			e.printStackTrace();
		}
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getHotelId() {
		return hotelId;
	}

	public void setHotelId(Long hotelId) {
		this.hotelId = hotelId;
	}

	public Integer getSingleOccupancySurcharge() {
		return singleOccupancySurcharge;
	}

	public void setSingleOccupancySurcharge(Integer singleOccupancySurcharge) {
		this.singleOccupancySurcharge = singleOccupancySurcharge;
	}

	public Integer getDoubleOccupancySurcharge() {
		return doubleOccupancySurcharge;
	}

	public void setDoubleOccupancySurcharge(Integer doubleOccupancySurcharge) {
		this.doubleOccupancySurcharge = doubleOccupancySurcharge;
	}

	public Integer getTripleOccupancySurcharge() {
		return tripleOccupancySurcharge;
	}

	public void setTripleOccupancySurcharge(Integer tripleOccupancySurcharge) {
		this.tripleOccupancySurcharge = tripleOccupancySurcharge;
	}

	public Date getInventoryDate() {
		return inventoryDate;
	}

	public void setInventoryDate(Date inventoryDate) {
		this.inventoryDate = inventoryDate;
	}

	public Long getStrInventoryDate() {
		return strInventoryDate;
	}

	public void setStrInventoryDate(Long strInventoryDate) {
		this.strInventoryDate = strInventoryDate;
	}

	public Long getUniqueKey() {
		return uniqueKey;
	}

	public void setUniqueKey(Long uniqueKey) {
		this.uniqueKey = uniqueKey;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public Long getStrInventoryFromDate() {
		return strInventoryFromDate;
	}

	public void setStrInventoryFromDate(Long strInventoryFromDate) {
		this.strInventoryFromDate = strInventoryFromDate;
	}

	public Long getStrInventoryToDate() {
		return strInventoryToDate;
	}

	public void setStrInventoryToDate(Long strInventoryToDate) {
		this.strInventoryToDate = strInventoryToDate;
	}
}
