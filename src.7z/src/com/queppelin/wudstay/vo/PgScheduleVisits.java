package com.queppelin.wudstay.vo;

import org.apache.commons.lang.RandomStringUtils;

import javax.persistence.*;
import java.util.*;

import static javax.persistence.GenerationType.IDENTITY;

/**
 * Created by hp on 11/21/2015.
 *
 DROP TABLE IF EXISTS  pg_schedule_visits ;

 CREATE TABLE  pg_schedule_visits  (
     schedule_id  	int(11)      NOT NULL AUTO_INCREMENT,
     guest_name  	varchar(100) DEFAULT NULL,
     guest_email  	varchar(100) DEFAULT NULL,
     guest_phone  	varchar(25)  DEFAULT NULL,
     pg_hotel_id    int(11)      DEFAULT NULL,
     transactionId  varchar(25)  DEFAULT NULL,
     meeting_time	timestamp,
     log_time		timestamp,

     PRIMARY KEY ( schedule_id ),
     KEY  pg_hotel_id  ( pg_hotel_id ),
     CONSTRAINT  pg_schedule_visits_ibfk_1  FOREIGN KEY ( pg_hotel_id ) REFERENCES  pg_hotel  ( pg_id )
 ) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=latin1;


 */
@Entity
@Table(name = "pg_schedule_visits")
public class PgScheduleVisits implements java.io.Serializable {
    @Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "schedule_id", unique = true, nullable = false)
    private Long    scheduleId;
    // @Transient
    //private Long hotelId;
    @Column(name = "guest_name")
    String guestName;
    @Column(name = "guest_email")
    String guestEmail;
    @Column(name = "guest_phone")
    String guestPhone;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pg_hotel_id", nullable = false)
    private PgHotel hotel;
    @Column(name = "meeting_time", columnDefinition="DATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date meetingTime =  new Date();

    @Column(name = "log_time", columnDefinition="DATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date logTime =  new Date();

    @Column(name = "transactionId")
    String transactionId = RandomStringUtils.randomAlphanumeric(15).toUpperCase();

    public Long getScheduleId() {
        return scheduleId;
    }

    public void setScheduleId(Long scheduleId) {
        this.scheduleId = scheduleId;
    }

    public String getGuestName() {
        return guestName;
    }

    public void setGuestName(String guestName) {
        this.guestName = guestName;
    }

    public String getGuestEmail() {
        return guestEmail;
    }

    public void setGuestEmail(String guestEmail) {
        this.guestEmail = guestEmail;
    }

    public String getGuestPhone() {
        return guestPhone;
    }

    public void setGuestPhone(String guestPhone) {
        this.guestPhone = guestPhone;
    }

    public PgHotel getHotel() {
        return hotel;
    }

    public void setHotel(PgHotel hotel) {
        this.hotel = hotel;
    }

    public Date getMeetingTime() {
        return meetingTime;
    }

    public void setMeetingTime(Date meetingTime) {
        this.meetingTime = meetingTime;
    }

    public Date getLogTime() {
        return logTime;
    }

    public void setLogTime(Date logTime) {
        this.logTime = logTime;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }
}
