package com.queppelin.wudstay.vo;

// Generated 25-Apr-2015 18:44:33 by Hibernate Tools 3.4.0.CR1

import javax.persistence.*;
import java.util.Date;

import static javax.persistence.GenerationType.IDENTITY;

/**

 DROP TABLE IF EXISTS  pg_hotel_amenity ;

 CREATE TABLE  pg_hotel_amenity  (
 id  				int(11) NOT NULL AUTO_INCREMENT,
 pg_hotel_id  		int(11) NOT NULL,
 pg_amenity_id  	int(11) NOT NULL,
 amenity_listing_order  int(11) DEFAULT '0',
 is_active  		tinyint(1) DEFAULT '1',
 last_updated_by  	varchar(50) DEFAULT NULL,
 last_updated_date  date DEFAULT NULL,
 PRIMARY KEY ( id ),
 KEY  pg_hotel_id  ( pg_hotel_id ),
 KEY  pg_amenity_id  ( pg_amenity_id ),
 CONSTRAINT  pg_hotel_amenity_ibfk_1  FOREIGN KEY ( pg_hotel_id ) REFERENCES  pg_hotel( pg_id ),
 CONSTRAINT  pg_hotel_amenity_ibfk_2  FOREIGN KEY ( pg_amenity_id ) REFERENCES  pg_amenity( amenity_id )
 ) ENGINE=InnoDB AUTO_INCREMENT=4182 DEFAULT CHARSET=latin1;

 select * from pg_hotel_amenity where pg_amenity_id = 4197

 */
@Entity
@Table(name = "pg_hotel_amenity")
public class PgHotelAmenity implements java.io.Serializable {
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "id", unique = true, nullable = false)
	private Long amenityId;
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "pg_amenity_id", referencedColumnName = "amenity_id", nullable = false)
	private PgAmenity amenity;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "pg_hotel_id", nullable = false)
	private PgHotel hotel;
	@Column(name = "amenity_listing_order")
	private Integer amenityListingOrder;
	@Column(name = "is_active")
	private Boolean isActive;
	@Column(name = "last_updated_by", length = 50)
	private String lastUpdatedBy;
	@Temporal(TemporalType.DATE)
	@Column(name = "last_updated_date", length = 10)
	private Date lastUpdatedDate;

	public PgHotelAmenity() {
	}

	public PgHotelAmenity(PgAmenity amenity, PgHotel hotel) {
		this.amenity = amenity;
		this.hotel = hotel;
	}

	public PgHotelAmenity(PgAmenity amenity, PgHotel hotel,
						  Integer amenityListingOrder, Boolean isActive,
						  String lastUpdatedBy, Date lastUpdatedDate) {
		this.amenity = amenity;
		this.hotel = hotel;
		this.amenityListingOrder = amenityListingOrder;
		this.isActive = isActive;
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdatedDate = lastUpdatedDate;
	}


	public Long getHotelAmenityId() {
		return this.amenityId;
	}

	public void setHotelAmenityId(Long hotelAmenityId) {
		this.amenityId = hotelAmenityId;
	}


	public PgAmenity getAmenity() {
		return this.amenity;
	}

	public void setAmenity(PgAmenity amenity) {
		this.amenity = amenity;
	}


	public PgHotel getHotel() {
		return this.hotel;
	}

	public void setHotel(PgHotel hotel) {
		this.hotel = hotel;
	}


	public Integer getAmenityListingOrder() {
		return this.amenityListingOrder;
	}

	public void setAmenityListingOrder(Integer amenityListingOrder) {
		this.amenityListingOrder = amenityListingOrder;
	}


	public Boolean getIsActive() {
		return this.isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}


	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}


	public Date getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

}
