package com.queppelin.wudstay.vo;

import javax.persistence.*;
import java.util.Date;

import static javax.persistence.GenerationType.IDENTITY;

/**
 * Created by hp on 10/1/2015.

 DROP TABLE IF EXISTS tblcouponcodecity;

 CREATE TABLE tblcouponcodecity (
 cccity_Id 				    int(11) 	NOT NULL AUTO_INCREMENT,
 coupon_Id 				    int(11)     NOT NULL,
 city_Id 				      int(11)     NOT NULL,
 PRIMARY KEY (cccity_Id),

 KEY coupon_Id (coupon_Id),
 CONSTRAINT cccoupon_Id_fk FOREIGN KEY (coupon_Id) REFERENCES tblCouponCode (coupon_Id),
 KEY city_Id (city_id),
 CONSTRAINT cccity_Id_fk FOREIGN KEY (city_Id) REFERENCES city (city_id)
 ) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;


 */
@Entity
@Table(name = "tblcouponcodecity" )
public class CouponCodeInCityVO implements java.io.Serializable {
    @Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "cccity_Id", unique = true, nullable = false)
    private Long id;
    @Column(name = "coupon_Id")
    private Long    couponId;
    @Column(name = "city_Id")
    private Long    cityId;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCouponId() {
        return couponId;
    }

    public void setCouponId(Long couponId) {
        this.couponId = couponId;
    }

    public Long getCityId() {
        return cityId;
    }

    public void setCityId(Long cityId) {
        this.cityId = cityId;
    }
}
