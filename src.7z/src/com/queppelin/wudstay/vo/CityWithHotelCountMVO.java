package com.queppelin.wudstay.vo;

import javax.persistence.*;

import static javax.persistence.GenerationType.IDENTITY;

/**
 * Created by hp on 12/22/2015.

 CREATE VIEW v_city_with_hotel_count AS
 SELECT city_id, city_name, 0 as totalHotels, 0 as totalPgs, 0 as hotelOrPgType FROM city;




 CREATE PROCEDURE `sp_city_with_hotel_count`()
 BEGIN
 SELECT citys.city_id, city_name, IFNULL(totalHotels, '0') as totalHotels, IFNULL(totalPgs, '0') as totalPgs ,
 (CASE
 WHEN ( IFNULL(totalHotels, '0') = '0' &&  IFNULL(totalPgs, '0') = '0') THEN 0
 WHEN ( IFNULL(totalHotels, '0') > 0 &&  IFNULL(totalPgs, '0') = '0') THEN 1
 WHEN ( IFNULL(totalHotels, '0') = '0' &&  IFNULL(totalPgs, '0') > 0) THEN 2
 ELSE 3
 END) AS hotelOrPgType
 FROM
 (SELECT city_id, city_name FROM city WHERE is_active=TRUE ) citys
 LEFT OUTER JOIN
 (SELECT COUNT(hotel_id) totalHotels, city_id  FROM  hotel H LEFT OUTER JOIN location L ON (H.location_id = L.location_id)
 WHERE H.is_active=TRUE GROUP BY city_id) hotels ON (hotels.city_id = citys.city_id)
 LEFT OUTER JOIN
 (SELECT COUNT(pg_id) totalPgs, city_id  FROM  pg_hotel H LEFT OUTER JOIN location L ON (H.location_id = L.location_id)
 WHERE H.is_active=TRUE GROUP BY city_id ) pgs ON (pgs.city_id = citys.city_id)
 ORDER BY city_name;
 END;




 CREATE PROCEDURE sp_city_byid_with_hotel_count(in  v_cityid int(11))
 BEGIN
 SELECT citys.city_id, city_name, IFNULL(totalHotels, '0') as totalHotels, IFNULL(totalPgs, '0') as totalPgs ,
 (CASE
 WHEN ( IFNULL(totalHotels, '0') = '0' &&  IFNULL(totalPgs, '0') = '0') THEN 0
 WHEN ( IFNULL(totalHotels, '0') > 0 &&  IFNULL(totalPgs, '0') = '0') THEN 1
 WHEN ( IFNULL(totalHotels, '0') = '0' &&  IFNULL(totalPgs, '0') > 0) THEN 2
 ELSE 3
 END) AS hotelOrPgType
 FROM
 (SELECT city_id, city_name FROM city WHERE is_active=TRUE AND city_id = v_cityid) citys
 LEFT OUTER JOIN
 (SELECT COUNT(hotel_id) totalHotels, city_id  FROM  hotel H LEFT OUTER JOIN location L ON (H.location_id = L.location_id)
 WHERE H.is_active=TRUE GROUP BY city_id) hotels ON (hotels.city_id = citys.city_id)
 LEFT OUTER JOIN
 (SELECT COUNT(pg_id) totalPgs, city_id  FROM  pg_hotel H LEFT OUTER JOIN location L ON (H.location_id = L.location_id)
 WHERE H.is_active=TRUE GROUP BY city_id ) pgs ON (pgs.city_id = citys.city_id)
 ORDER BY city_name;
 END;

 */
@NamedNativeQueries({
    @NamedNativeQuery(
            name = "callSpCityWithHotelCount",
            query = "CALL sp_city_with_hotel_count( )",
            resultClass = CityWithHotelCountMVO.class
    ),
    @NamedNativeQuery(
            name = "callSpCityByIdWithHotelCount",
            query = "CALL sp_city_byid_with_hotel_count(:v_cityid)",
            resultClass = CityWithHotelCountMVO.class
    )
})

@Entity
@Table(name = "v_city_with_hotel_count")
public class CityWithHotelCountMVO implements java.io.Serializable {
    private static final long serialVersionUID = 250570177715385526L;
    @Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "city_id", unique = true, nullable = false)
    private Long cityId;
    @Column(name = "city_name" )
    private String cityName;
    @Column(name = "hotelOrPgType" )
    private int hotelOrPgType=0;
    @Column(name = "totalHotels" )
    private int totalHotels=0;
    @Column(name = "totalPgs" )
    private int totalPgs=0;

    public CityWithHotelCountMVO(){}
    public CityWithHotelCountMVO(Long cityId, String cityName) {
        this.cityId=cityId;
        this.cityName = cityName;
    }

    public Long getCityId() {
        return cityId;
    }

    public void setCityId(Long cityId) {
        this.cityId = cityId;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public int getHotelOrPgType() {
        return hotelOrPgType;
    }

    public void setHotelOrPgType(int hotelOrPgType) {
        this.hotelOrPgType = hotelOrPgType;
    }

    public int getTotalHotels() {
        return totalHotels;
    }

    public void setTotalHotels(int totalHotels) {
        this.totalHotels = totalHotels;
    }

    public int getTotalPgs() {
        return totalPgs;
    }

    public void setTotalPgs(int totalPgs) {
        this.totalPgs = totalPgs;
    }
}
