package com.queppelin.wudstay.vo;

import javax.persistence.*;
import java.util.Date;

import static javax.persistence.GenerationType.IDENTITY;

/**
 * Created by hp on 11/24/2015.

 DROP TABLE IF EXISTS  blackoutdates_checkout ;

 CREATE TABLE  blackoutdates_checkout  (
     id  					int(11) NOT NULL AUTO_INCREMENT,
     blackout_from_date  	date DEFAULT NULL,
     blackout_to_date  	    date DEFAULT NULL,
     city_id  	            int(11) DEFAULT NULL,
     PRIMARY KEY ( id ),
     KEY  city_id  ( city_id ),
     CONSTRAINT  blackoutdates_checkout_ibfk_1  FOREIGN KEY ( city_id ) REFERENCES  city  ( city_id )
 ) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=latin1;

 insert into blackoutdates_checkout (blackout_from_date,  blackout_to_date, city_id) values ( '2015-12-30' , '2016-01-01', 8);
 insert into blackoutdates_checkout (blackout_from_date,  blackout_to_date, city_id) values ( '2015-12-30' , '2016-01-01', 2);


 */
@Entity
@Table(name = "blackoutdates_checkout")
public class BlackoutDateForCheckOut implements java.io.Serializable {
    @Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "id", unique = true, nullable = false)
    private Long id;
    @Temporal(TemporalType.DATE)
    @Column(name = "blackout_from_date", length = 10)
    private Date blackoutFromDate;
    @Temporal(TemporalType.DATE)
    @Column(name = "blackout_to_date", length = 10)
    private Date blackoutToDate;
    @Column(name = "city_id")
    private Long cityId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getBlackoutFromDate() {
        return blackoutFromDate;
    }

    public void setBlackoutFromDate(Date blackoutFromDate) {
        this.blackoutFromDate = blackoutFromDate;
    }

    public Date getBlackoutToDate() {
        return blackoutToDate;
    }

    public void setBlackoutToDate(Date blackoutToDate) {
        this.blackoutToDate = blackoutToDate;
    }

    public Long getCityId() {
        return cityId;
    }

    public void setCityId(Long cityId) {
        this.cityId = cityId;
    }
}
