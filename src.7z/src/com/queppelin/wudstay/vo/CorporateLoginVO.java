package com.queppelin.wudstay.vo;

import com.queppelin.wudstay.vo.custom.CorporateLoginDto;

import javax.persistence.*;
import java.util.Date;

import static javax.persistence.GenerationType.IDENTITY;

/*
drop table   corp_login;

CREATE TABLE corp_login(
	id INT(11) 			PRIMARY KEY auto_increment,
	corp_id 			INT(11) 	DEFAULT NULL,

	corp_loginUser_name       VARCHAR(50) DEFAULT NULL,
	corp_loginUser_email      VARCHAR(50) DEFAULT NULL,
	corp_loginUser_number     VARCHAR(50) DEFAULT NULL,

	corp_login_id       VARCHAR(50) DEFAULT NULL,
	corp_login_password VARCHAR(50) DEFAULT NULL,
	is_active 			tinyint(1) 		DEFAULT '0',
	last_updated_by 	VARCHAR(50),
	last_updated_date 	timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
);
ALTER TABLE corp_login ADD CONSTRAINT ux_corp_login_id  UNIQUE ( corp_login_id);


ALTER TABLE corp_login ADD CONSTRAINT ux_corp_login_id  UNIQUE (corp_id, corp_login_id);


ALTER TABLE corporate ADD COLUMN corp_email VARCHAR(50) DEFAULT null


 */

@Entity
@Table(name = "corp_login")
public class CorporateLoginVO implements java.io.Serializable {
	private static final long serialVersionUID = -4099817139352235793L;
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "id", nullable = false)
	private Long id;
	@Column(name = "corp_id" )
	private Long corpId;

	@Column(name = "corp_loginUser_name")
	private String corpContactPersonName;
	@Column(name = "corp_loginUser_email")
	private String corpContactPersonEmail;
	@Column(name = "corp_loginUser_number")
	private String corpContactNo;

	@Column(name = "corp_login_id", length = 50, unique = true)
	private String corpLoginID;
	@Column(name = "corp_login_password", length = 50)
	private String corpLoginPassword;
	@Column(name = "is_active" )
	private Integer isActive=1;
	@Column(name = "last_updated_by", length = 50)
	private String lastUpdatedBy;
	@Column(name = "last_updated_date", columnDefinition="DATETIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastUpdatedDate;

	public CorporateLoginVO(){
	}
	public CorporateLoginVO(Long corpId, CorporateLoginDto loginDto) {
		this.corpId=corpId;
		this.id = loginDto.getCorpLoginId();
		this.corpContactPersonName = loginDto.getContactName();
		this.corpContactPersonEmail = loginDto.getContactEmail();
		this.corpContactNo = loginDto.getContactNumber();

		this.corpLoginID = loginDto.getLoginID();
		this.corpLoginPassword = loginDto.getLoginPassword();
		this.isActive = 1;
		this.lastUpdatedDate = new Date();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getCorpId() {
		return corpId;
	}

	public void setCorpId(Long corpId) {
		this.corpId = corpId;
	}

	public String getCorpLoginID() {
		return corpLoginID;
	}

	public void setCorpLoginID(String corpLoginID) {
		this.corpLoginID = corpLoginID;
	}

	public String getCorpLoginPassword() {
		return corpLoginPassword;
	}

	public void setCorpLoginPassword(String corpLoginPassword) {
		this.corpLoginPassword = corpLoginPassword;
	}

	public Integer getIsActive() {
		return isActive;
	}

	public void setIsActive(Integer isActive) {
		this.isActive = isActive;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getCorpContactPersonName() {
		return corpContactPersonName;
	}

	public void setCorpContactPersonName(String corpContactPersonName) {
		this.corpContactPersonName = corpContactPersonName;
	}

	public String getCorpContactPersonEmail() {
		return corpContactPersonEmail;
	}

	public void setCorpContactPersonEmail(String corpContactPersonEmail) {
		this.corpContactPersonEmail = corpContactPersonEmail;
	}

	public String getCorpContactNo() {
		return corpContactNo;
	}

	public void setCorpContactNo(String corpContactNo) {
		this.corpContactNo = corpContactNo;
	}
}
