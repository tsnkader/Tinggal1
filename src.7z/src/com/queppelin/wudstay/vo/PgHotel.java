package com.queppelin.wudstay.vo;

import javax.persistence.*;

import java.util.*;

import static javax.persistence.GenerationType.IDENTITY;

/**
 * Created by hp on 11/21/2015.

 CREATE TABLE  pg_hotel  (
     pg_id  			    int(11) NOT NULL AUTO_INCREMENT,
     pg_name  		        varchar(100) NOT NULL,
     pg_display_name        varchar(255) DEFAULT NULL,
     pg_address  		    varchar(500) DEFAULT NULL,
     pg_display_address     varchar(500) DEFAULT NULL,
     location_id  	        int(11) NOT NULL,
     latitude  		        double DEFAULT NULL,
     longitude  		    double DEFAULT NULL,
     map_link  		        varchar(500) DEFAULT NULL,
     -- room_type_id  	    int(11) DEFAULT NULL,
     how_to_reach  	        varchar(1000) DEFAULT NULL,

     contact_owner_name  	varchar(50) DEFAULT NULL,
     contact_owner_number  	varchar(20) DEFAULT NULL,
     contact_owner_email  	varchar(100) DEFAULT NULL,

     contact_person1_name  	varchar(50) DEFAULT NULL,
     contact_person1_number varchar(20) DEFAULT NULL,
     contact_person1_email  varchar(100) DEFAULT NULL,

     contact_person2_name  	varchar(50) DEFAULT NULL,
     contact_person2_number varchar(20) DEFAULT NULL,
     contact_person2_email  varchar(100) DEFAULT NULL,

     single_occupancy_price  int(5) DEFAULT NULL,
     double_occupancy_price  int(5) DEFAULT NULL,
     triple_occupancy_price  int(5) DEFAULT NULL,

     single_occupancy_wprice  int(5) DEFAULT NULL,
     double_occupancy_wprice  int(5) DEFAULT NULL,
     triple_occupancy_wprice  int(5) DEFAULT NULL,

     single_occupancy_beds  int(5) DEFAULT '0',
     double_occupancy_beds  int(5) DEFAULT '0',
     triple_occupancy_beds  int(5) DEFAULT '0',

     is_active          tinyint(1) DEFAULT '1',
     last_updated_by    varchar(50) DEFAULT NULL,
     last_updated_date  date DEFAULT NULL,

     PRIMARY KEY ( pg_id ),
     KEY  location_id  ( location_id ),
     -- KEY  room_type_id  ( room_type_id ),
     CONSTRAINT  pg_hotel_ibfk_1  FOREIGN KEY ( location_id ) REFERENCES  location  ( location_id ),
     -- CONSTRAINT  pg_hotel_ibfk_2  FOREIGN KEY ( room_type_id ) REFERENCES  room_type  ( room_type_id )
 ) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=latin1;


 */
@Entity
@Table(name = "pg_hotel")
public class PgHotel implements java.io.Serializable {
    @Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "pg_id", unique = true, nullable = false)
    private Long    id;
    // @Transient
    //private Long hotelId;
    @Column(name = "pg_name")
    String name;
    @Column(name = "pg_display_name")
    String displayName;
    @Column(name = "pg_address")
    String address;
    @Column(name = "pg_display_address")
    String displayAddress;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "location_id", nullable = false)
    private Location location;
    /*@Column(name = "location_id")
    Long locationId;*/
    @Column(name = "latitude")
    private Double latitude;
    @Column(name = "longitude")
    private Double longitude;
    @Column(name = "map_link", length = 500)
    private String mapLink;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pg_type_id")
    private PgType pgType;

    @Column(name = "how_to_reach", length = 1000)
    private String howToReach;

    /*@Column(name = "contact_owner_name", length = 50)
    private String ownerName;
    @Column(name = "contact_owner_number", length = 20)
    private String ownerNumber;
    @Column(name = "contact_owner_email", length = 100)
    private String  ownerEmail;*/

    @Column(name = "contact_person1_name", length = 50)
    private String contactPersonName1;
    @Column(name = "contact_person1_number", length = 20)
    private String contactPersonNumber1;
    @Column(name = "contact_person1_email", length = 100)
    private String  contactPersonEmail1;

    @Column(name = "contact_person2_name", length = 50)
    private String contactPersonName2;
    @Column(name = "contact_person2_number", length = 20)
    private String contactPersonNumber2;
    @Column(name = "contact_person2_email", length = 100)
    private String  contactPersonEmail2;

    @Column(name = "single_occupancy_price")
    private Integer singleOccupancyPrice;
    @Column(name = "double_occupancy_price")
    private Integer doubleOccupancyPrice;
    @Column(name = "triple_occupancy_price")
    private Integer tripleOccupancyPrice;

    @Column(name = "single_occupancy_wprice")
    private Integer singleOccupancyWudstayPrice;
    @Column(name = "double_occupancy_wprice")
    private Integer doubleOccupancyWudstayPrice;
    @Column(name = "triple_occupancy_wprice")
    private Integer tripleOccupancyWudstayPrice;

    @Column(name = "single_occupancy_beds")
    private Integer singleOccupancyBeds;
    @Column(name = "double_occupancy_beds")
    private Integer doubleOccupancyBeds;
    @Column(name = "triple_occupancy_beds")
    private Integer tripleOccupancyBeds;

    @Column(name = "is_active")
    private Boolean isActive;
    @Column(name = "last_updated_by", length = 50)
    private String  lastUpdatedBy;
    @Temporal(TemporalType.DATE)
    @Column(name = "last_updated_date", length = 10)
    private Date lastUpdatedDate;


    @OneToMany(fetch = FetchType.LAZY, mappedBy = "hotel")
    private Set<PgHotelDescription> hotelDescriptions = new HashSet<PgHotelDescription>(0);
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "hotel")
    private List<PgHotelAmenity> hotelAmenities = new ArrayList<PgHotelAmenity>();

    @Transient
    private String hotelAmenity="";
    @Transient
    private Integer price;
    @Column(name = "star_rating")
    private Integer starRating;

   /* public Long getHotelId() {
        return id; //hotelId;
    }

    public void setHotelId(Long hotelId) {
        this.id = hotelId;
        this.hotelId = hotelId;
    }*/

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDisplayAddress() {
        return displayAddress;
    }

    public void setDisplayAddress(String displayAddress) {
        this.displayAddress = displayAddress;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public String getMapLink() {
        return mapLink;
    }

    public void setMapLink(String mapLink) {
        this.mapLink = mapLink;
    }

    public String getHowToReach() {
        return howToReach;
    }

    public void setHowToReach(String howToReach) {
        this.howToReach = howToReach;
    }

    /*public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getOwnerNumber() {
        return ownerNumber;
    }

    public void setOwnerNumber(String ownerNumber) {
        this.ownerNumber = ownerNumber;
    }

    public String getOwnerEmail() {
        return ownerEmail;
    }

    public void setOwnerEmail(String ownerEmail) {
        this.ownerEmail = ownerEmail;
    }*/

    public String getContactPersonName1() {
        return contactPersonName1;
    }

    public void setContactPersonName1(String contactPersonName1) {
        this.contactPersonName1 = contactPersonName1;
    }

    public String getContactPersonNumber1() {
        return contactPersonNumber1;
    }

    public void setContactPersonNumber1(String contactPersonNumber1) {
        this.contactPersonNumber1 = contactPersonNumber1;
    }

    public String getContactPersonEmail1() {
        return contactPersonEmail1;
    }

    public void setContactPersonEmail1(String contactPersonEmail1) {
        this.contactPersonEmail1 = contactPersonEmail1;
    }

    public String getContactPersonName2() {
        return contactPersonName2;
    }

    public void setContactPersonName2(String contactPersonName2) {
        this.contactPersonName2 = contactPersonName2;
    }

    public String getContactPersonNumber2() {
        return contactPersonNumber2;
    }

    public void setContactPersonNumber2(String contactPersonNumber2) {
        this.contactPersonNumber2 = contactPersonNumber2;
    }

    public String getContactPersonEmail2() {
        return contactPersonEmail2;
    }

    public void setContactPersonEmail2(String contactPersonEmail2) {
        this.contactPersonEmail2 = contactPersonEmail2;
    }

    public Integer getSingleOccupancyPrice() {
        return singleOccupancyPrice;
    }

    public void setSingleOccupancyPrice(Integer singleOccupancyPrice) {
        this.singleOccupancyPrice = singleOccupancyPrice;
    }

    public Integer getDoubleOccupancyPrice() {
        return doubleOccupancyPrice;
    }

    public void setDoubleOccupancyPrice(Integer doubleOccupancyPrice) {
        this.doubleOccupancyPrice = doubleOccupancyPrice;
    }

    public Integer getTripleOccupancyPrice() {
        return tripleOccupancyPrice;
    }

    public void setTripleOccupancyPrice(Integer tripleOccupancyPrice) {
        this.tripleOccupancyPrice = tripleOccupancyPrice;
    }

    public Integer getSingleOccupancyWudstayPrice() {
        return singleOccupancyWudstayPrice;
    }

    public void setSingleOccupancyWudstayPrice(Integer singleOccupancyWudstayPrice) {
        this.singleOccupancyWudstayPrice = singleOccupancyWudstayPrice;
    }

    public Integer getDoubleOccupancyWudstayPrice() {
        return doubleOccupancyWudstayPrice;
    }

    public void setDoubleOccupancyWudstayPrice(Integer doubleOccupancyWudstayPrice) {
        this.doubleOccupancyWudstayPrice = doubleOccupancyWudstayPrice;
    }

    public Integer getTripleOccupancyWudstayPrice() {
        return tripleOccupancyWudstayPrice;
    }

    public void setTripleOccupancyWudstayPrice(Integer tripleOccupancyWudstayPrice) {
        this.tripleOccupancyWudstayPrice = tripleOccupancyWudstayPrice;
    }

    public Integer getSingleOccupancyBeds() {
        return singleOccupancyBeds;
    }

    public void setSingleOccupancyBeds(Integer singleOccupancyBeds) {
        this.singleOccupancyBeds = singleOccupancyBeds;
    }

    public Integer getDoubleOccupancyBeds() {
        return doubleOccupancyBeds;
    }

    public void setDoubleOccupancyBeds(Integer doubleOccupancyBeds) {
        this.doubleOccupancyBeds = doubleOccupancyBeds;
    }

    public Integer getTripleOccupancyBeds() {
        return tripleOccupancyBeds;
    }

    public void setTripleOccupancyBeds(Integer tripleOccupancyBeds) {
        this.tripleOccupancyBeds = tripleOccupancyBeds;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public Date getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate(Date lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }

    public PgType getPgType() {
        return pgType;
    }

    public void setPgType(PgType pgType) {
        this.pgType = pgType;
    }

    public Set<PgHotelDescription> getHotelDescriptions() {
        return hotelDescriptions;
    }

    public void setHotelDescriptions(Set<PgHotelDescription> hotelDescriptions) {
        this.hotelDescriptions = hotelDescriptions;
    }

    public List<PgHotelAmenity> getHotelAmenities() {
        return hotelAmenities;
    }

    public void setHotelAmenities(List<PgHotelAmenity> hotelAmenities) {
        this.hotelAmenities = hotelAmenities;
    }

    public String getHotelAmenity() {
        return hotelAmenity;
    }

    public void setHotelAmenity(String hotelAmenity) {
        this.hotelAmenity = hotelAmenity;
    }

    public Integer getPrice() {
        return this.price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public Integer getStarRating() {
        return starRating;
    }

    public void setStarRating(Integer starRating) {
        this.starRating = starRating;
    }
}
