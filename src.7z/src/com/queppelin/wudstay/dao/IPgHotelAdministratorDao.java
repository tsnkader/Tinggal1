package com.queppelin.wudstay.dao;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.PgHotelAdministrator;

public interface IPgHotelAdministratorDao extends IBaseDao<PgHotelAdministrator> {

	PgHotelAdministrator getHotelAdminByHotelId(Long hotelId) throws WudstayException;

}
