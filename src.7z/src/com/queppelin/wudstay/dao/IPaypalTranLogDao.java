package com.queppelin.wudstay.dao;

import com.queppelin.wudstay.vo.PayPalTranLogVO;

public interface IPaypalTranLogDao extends IBaseDao<PayPalTranLogVO> {
    public PayPalTranLogVO getBySecureToken(String secureToken);

}
