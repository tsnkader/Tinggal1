package com.queppelin.wudstay.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.HotelBooking;
import com.queppelin.wudstay.vo.custom.RoomAvailabilityDayWise;

public interface IHotelBookingDao extends IBaseDao<HotelBooking> {

	List<HotelBooking> getBookingsByHotelId(Long hotelId) throws WudstayException;

	List<HotelBooking> getBookingsBetweenSelectedDates(Long hotelId, Date checkIn, Date checkOut) throws WudstayException;

	List<HotelBooking> getBookingsByContactNumber(String mobileNumber) throws WudstayException;

	List<HotelBooking> getBookingsByHotelId(Long hotelId, String contactNumber) throws WudstayException;
	
	List<HotelBooking> getBookingsForCustomerCare(Long bookingId, Long hotelId) throws WudstayException;

	public Map<Long, RoomAvailabilityDayWise> getRoomBookingsDayWise(Long hotelId, Date checkIn, Date checkOut);

	List<HotelBooking> getBookingsByTransactionId(String transactionId) throws WudstayException;
}
