package com.queppelin.wudstay.dao;

import java.util.List;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.Location;

public interface ILocationDao extends IBaseDao<Location> {

	List<Location> getLocationsByCityId(Long cityId) throws WudstayException;

}
