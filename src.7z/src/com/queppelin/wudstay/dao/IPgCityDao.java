package com.queppelin.wudstay.dao;


import com.queppelin.wudstay.vo.PgCity;


public interface IPgCityDao extends IBaseDao<PgCity> {
	
}
