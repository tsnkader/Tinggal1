package com.queppelin.wudstay.dao;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.HotelAdministrator;

public interface IHotelAdministratorDao extends IBaseDao<HotelAdministrator> {

	HotelAdministrator getHotelAdminByHotelId(Long hotelId) throws WudstayException;

}
