package com.queppelin.wudstay.dao;

import com.queppelin.wudstay.vo.RoomType;

public interface IRoomTypeDao extends IBaseDao<RoomType> {

}
