package com.queppelin.wudstay.dao;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.CorporateEmployeeVO;

import java.util.List;

public interface ICorporateEmployeeDao extends IBaseDao<CorporateEmployeeVO> {
	
	List<CorporateEmployeeVO> getCorporateBookingsForCorporateId(Long corpId) throws WudstayException;

	public List<CorporateEmployeeVO> getListByCorpBookingId(Long corpBookingId) throws WudstayException;
	

}
