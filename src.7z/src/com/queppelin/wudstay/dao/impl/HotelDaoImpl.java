package com.queppelin.wudstay.dao.impl;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.queppelin.wudstay.dao.IHotelDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.Hotel;
import com.queppelin.wudstay.vo.HotelRoom;

@Repository
public class HotelDaoImpl extends BaseDaoImpl<Hotel> implements IHotelDao {
	
	private static final Logger logger = LoggerFactory.getLogger(HotelDaoImpl.class);
	
	public HotelDaoImpl() {
		super(Hotel.class);
	}
	
	public List<Hotel> getHotelByCityId(Long cityId) throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(Hotel.class, "hotelAlias");
			criteria.createAlias("hotelAlias.location", "locationAlias");
			criteria.createAlias("locationAlias.city", "cityAlias");
			criteria.add(Restrictions.eq("cityAlias.cityId", cityId));
			criteria.add(Restrictions.eq("hotelAlias.isActive", Boolean.TRUE));
				criteria.addOrder(Order.asc("hotelAlias.singleOccupancyPrice"));
			return (List<Hotel>) criteria.list();
		} catch (Exception e) {
			throw new WudstayException(logger, "HotelRoomDaoImpl.getHotelRoomsByCityId()", WudstayConstants.FETCH_HOTEL_ROOM_ERROR, null, e);
		}
	}

	
	public List<Hotel> getHotelByCityId(Long cityId, int minPax) throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(Hotel.class, "hotelAlias");
			criteria.createAlias("hotelAlias.location", "locationAlias");
			criteria.createAlias("locationAlias.city", "cityAlias");
			criteria.add(Restrictions.eq("cityAlias.cityId", cityId));
			criteria.add(Restrictions.eq("hotelAlias.isActive", Boolean.TRUE));
			if(minPax == 3) {
				criteria.add(Restrictions.eq("hotelAlias.allowTripleOccupancy", 1));
			}
			if(minPax == 1) {
				criteria.addOrder(Order.asc("hotelAlias.singleOccupancyPrice"));
			} else if(minPax == 2) {
				criteria.addOrder(Order.asc("hotelAlias.doubleOccupancyPrice"));
			} else if(minPax == 3) {
				criteria.addOrder(Order.asc("hotelAlias.tripleOccupancyPrice"));
			}
			//criteria.setProjection(Projections.projectionList().add(Projections.groupProperty("hotelAlias.hotelId"), "hotelId"));
			//criteria.addOrder(Order.desc("hotelAlias.starRating"));
			return (List<Hotel>) criteria.list();
		} catch (Exception e) {
			throw new WudstayException(logger, "HotelRoomDaoImpl.getHotelRoomsByCityId()", WudstayConstants.FETCH_HOTEL_ROOM_ERROR, null, e);
		}
	}
	
	
	public List<Hotel> filterHotels(Long locationId, Long cityId, List<Long> roomTypeIdList,
			String sortBy, Integer priceSortType, Integer ratingSortType, int minPax) throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(Hotel.class, "hotelAlias");
			criteria.createAlias("hotelAlias.roomType", "roomTypeAlias");
			criteria.createAlias("hotelAlias.location", "locationAlias");
			criteria.createAlias("locationAlias.city", "cityAlias");

			ProjectionList projectionList = Projections.projectionList();
			projectionList.add(Projections.property("singleOccupancyPrice"), "singleOccupancyPrice");
			projectionList.add(Projections.property("doubleOccupancyPrice"), "doubleOccupancyPrice");
			projectionList.add(Projections.property("tripleOccupancyPrice"), "tripleOccupancyPrice");
			projectionList.add(Projections.property("hotelId"), "hotelId");
			projectionList.add(Projections.property("hotelName"), "hotelName");
			projectionList.add(Projections.property("hotelDisplayName"), "hotelDisplayName");
			projectionList.add(Projections.property("starRating"), "starRating");
			projectionList.add(Projections.property("hotelAddress"), "hotelAddress");
			projectionList.add(Projections.property("hotelDisplayAddress"), "hotelDisplayAddress");

			projectionList.add(Projections.property("noOfRooms"), "noOfRooms");
			projectionList.add(Projections.property("validFromDate"), "validFromDate");
			projectionList.add(Projections.property("validToDate"), "validToDate");

			criteria.setProjection(projectionList).setResultTransformer(Transformers.aliasToBean(Hotel.class));

			criteria.add(Restrictions.eq("cityAlias.cityId", cityId));
			criteria.add(Restrictions.eq("hotelAlias.isActive", Boolean.TRUE));
			if(minPax == 3) {
				criteria.add(Restrictions.eq("hotelAlias.allowTripleOccupancy", 1));
			}
			if(locationId != null) {
				criteria.add(Restrictions.eq("locationAlias.locationId", locationId));
			}
			if(roomTypeIdList != null && roomTypeIdList.size() > 0) {
				criteria.add(Restrictions.in("roomTypeAlias.roomTypeId", roomTypeIdList));
			}
			if(sortBy.equals(WudstayConstants.RATING)) {
				if(ratingSortType.equals(Integer.valueOf(1))) {
					criteria.addOrder(Order.desc("starRating"));
				} else {
					criteria.addOrder(Order.asc("starRating"));
				}
			} else {
				if(priceSortType.equals(Integer.valueOf(1))) {
					//criteria.addOrder(Order.desc("price"));
					if(minPax == 1) {
						criteria.addOrder(Order.desc("hotelAlias.singleOccupancyPrice"));
					} else if(minPax == 2) {
						criteria.addOrder(Order.desc("hotelAlias.doubleOccupancyPrice"));
					} else if(minPax == 3) {
						criteria.addOrder(Order.desc("hotelAlias.tripleOccupancyPrice"));
					}
				} else {
					//criteria.addOrder(Order.asc("price"));
					if(minPax == 1) {
						criteria.addOrder(Order.asc("hotelAlias.singleOccupancyPrice"));
					} else if(minPax == 2) {
						criteria.addOrder(Order.asc("hotelAlias.doubleOccupancyPrice"));
					} else if(minPax == 3) {
						criteria.addOrder(Order.asc("hotelAlias.tripleOccupancyPrice"));
					}
				}
			}
			return (List<Hotel>) criteria.list();
		} catch (Exception e) {
			throw new WudstayException(logger, "HotelRoomDaoImpl.filterHotelRooms()", WudstayConstants.FETCH_HOTEL_ROOM_ERROR, null, e);
		}
	}
	
	
	public List<Hotel> getSuggestedHotelList(Hotel hotel)
			throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(Hotel.class, "hotelAlias");
			criteria.createAlias("hotelAlias.location", "locationAlias");
			criteria.createAlias("locationAlias.city", "cityAlias");
			criteria.add(Restrictions.between("singleOccupancyPrice", hotel.getSingleOccupancyPrice() - 100000, hotel.getSingleOccupancyPrice() + 100000));
			criteria.add(Restrictions.eq("cityAlias.cityId", hotel.getLocation().getCity().getCityId()));
			criteria.add(Restrictions.ne("hotelId", hotel.getHotelId()));
			criteria.add(Restrictions.eq("hotelAlias.isActive", Boolean.TRUE));
			criteria.addOrder(Order.asc("hotelAlias.singleOccupancyPrice"));
			criteria.setMaxResults(3);
			//criteria.addOrder(Order.desc("hotelAlias.starRating"));
			return (List<Hotel>) criteria.list();
		} catch (Exception e) {
			throw new WudstayException(logger, "HotelRoomDaoImpl.getSuggestedHotelList()", WudstayConstants.FETCH_HOTEL_ROOM_ERROR, null, e);
		}
	}
}
