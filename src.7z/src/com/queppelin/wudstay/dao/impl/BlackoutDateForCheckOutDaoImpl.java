package com.queppelin.wudstay.dao.impl;

import com.queppelin.wudstay.dao.IBlackoutDateForCheckOutDao;
import com.queppelin.wudstay.vo.BlackoutDateForCheckOut;
import com.queppelin.wudstay.vo.BlackoutDateForPayAtHotel;
import org.hibernate.Criteria;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Repository
public class BlackoutDateForCheckOutDaoImpl extends BaseDaoImpl<BlackoutDateForCheckOut> implements IBlackoutDateForCheckOutDao {

	private static final Logger logger = LoggerFactory.getLogger(BlackoutDateForCheckOutDaoImpl.class);

	public BlackoutDateForCheckOutDaoImpl() {
		super(BlackoutDateForCheckOut.class);
	}


	private List<BlackoutDateForCheckOut> getSearchCriteria( Date checkOut, Long cityId) throws ParseException {
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		String strCheckOut = format1.format(checkOut);
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		Date fromCheckOutDate = df.parse(strCheckOut + " 00:00:00");
		Date toCheckOutDate = df.parse(strCheckOut + " 23:59:59");

		Criteria criteria = null;
		List<BlackoutDateForCheckOut> lst = new ArrayList<BlackoutDateForCheckOut>();
		try {
			criteria = getCurrentSession().createCriteria(BlackoutDateForCheckOut.class, "blackoutDates");
			LogicalExpression checkInOutBetween = Restrictions.or(Restrictions.between("blackoutFromDate", fromCheckOutDate, toCheckOutDate), Restrictions.between("blackoutToDate", fromCheckOutDate, toCheckOutDate));
			LogicalExpression checkInOut = Restrictions.and(Restrictions.lt("blackoutFromDate", fromCheckOutDate), Restrictions.gt("blackoutToDate", toCheckOutDate));

			criteria.add(Restrictions.or(checkInOutBetween, checkInOut));
			//criteria.add(Restrictions.le("checkOut", checkOut));

			if(cityId!=null && cityId.longValue()>0){
				criteria.add(Restrictions.eq("cityId", cityId));
			}

			criteria.addOrder(Order.asc("cityId"));

			lst = criteria.list();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return lst;
	}





	
	public List<BlackoutDateForCheckOut> getListOfBlackoutDate(Date checkOut) throws ParseException {
		return getSearchCriteria( checkOut, null);
	}

	
	public List<BlackoutDateForCheckOut> getListOfBlackoutDate(Date checkOut, long cityId) throws ParseException{
		if(cityId>0)
			return getSearchCriteria( checkOut, cityId);
		else
			return getSearchCriteria( checkOut, null);
	}

	
	public boolean isBlackoutOn(Date checkOut, long cityId)throws ParseException {
		List<BlackoutDateForCheckOut> lst = getSearchCriteria(checkOut, cityId);
		if (lst.size() > 0) {
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}

	
	public boolean isBlackoutOn(Date checkOut)throws ParseException {
		List<BlackoutDateForCheckOut> lst = getSearchCriteria( checkOut, null);
		if (lst.size() > 0) {
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}



	}