package com.queppelin.wudstay.dao.impl;


import com.queppelin.wudstay.dao.IPaypalTranLogDao;
import com.queppelin.wudstay.vo.PayPalTranLogVO;
import com.queppelin.wudstay.vo.User;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public class PaypalTranLogDaoImpl extends BaseDaoImpl<PayPalTranLogVO> implements IPaypalTranLogDao  {

	private static final Logger logger = LoggerFactory.getLogger(PaypalTranLogDaoImpl.class);

	public PaypalTranLogDaoImpl() {
		super(PayPalTranLogVO.class);
	}

	
	public PayPalTranLogVO getBySecureToken(String secureToken){
		try {
			Criteria criteria = getCurrentSession().createCriteria(User.class);
			criteria.add(Restrictions.eq("secureToken", secureToken));
			//PayPalTranLogVO log = (PayPalTranLogVO) criteria.uniqueResult();
			List<PayPalTranLogVO> lst = criteria.list();
			if (lst == null || lst.size()<=0) {
				return null;
			}else{
				return lst.get(0);
			}
		} catch (Exception e) {
			return null;
		}
	}

}
