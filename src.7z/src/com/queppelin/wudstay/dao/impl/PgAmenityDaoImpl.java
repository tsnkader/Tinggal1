package com.queppelin.wudstay.dao.impl;

import com.queppelin.wudstay.dao.IAmenityDao;
import com.queppelin.wudstay.dao.IPgAmenityDao;
import com.queppelin.wudstay.vo.Amenity;
import com.queppelin.wudstay.vo.PgAmenity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

@Repository
public class PgAmenityDaoImpl extends BaseDaoImpl<PgAmenity> implements IPgAmenityDao {

	private static final Logger logger = LoggerFactory.getLogger(PgAmenityDaoImpl.class);

	public PgAmenityDaoImpl() {
		super(PgAmenity.class);
	}
}
