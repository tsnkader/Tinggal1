package com.queppelin.wudstay.dao.impl;

import com.queppelin.wudstay.dao.IPgScheduleVisitsDao;
import com.queppelin.wudstay.vo.PgScheduleVisits;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

@Repository
public class PgScheduleVisitsDaoImpl extends BaseDaoImpl<PgScheduleVisits> implements IPgScheduleVisitsDao {

	private static final Logger logger = LoggerFactory.getLogger(PgScheduleVisitsDaoImpl.class);

	public PgScheduleVisitsDaoImpl() {
		super(PgScheduleVisits.class);
	}
}
