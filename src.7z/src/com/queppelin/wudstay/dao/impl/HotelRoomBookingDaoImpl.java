package com.queppelin.wudstay.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.queppelin.wudstay.dao.IHotelRoomBookingDao;
import com.queppelin.wudstay.vo.HotelRoomBooking;

@Repository
public class HotelRoomBookingDaoImpl extends BaseDaoImpl<HotelRoomBooking> implements IHotelRoomBookingDao {

	private static final Logger logger = LoggerFactory.getLogger(HotelRoomBookingDaoImpl.class);
	
	public HotelRoomBookingDaoImpl() {
		super(HotelRoomBooking.class);
	}
}
