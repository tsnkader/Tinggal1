package com.queppelin.wudstay.dao.impl;

import com.queppelin.wudstay.dao.IHdfcTranLogDao;
import com.queppelin.wudstay.dao.IHdfcTranResponseDao;
import com.queppelin.wudstay.vo.HdfcTranLogVO;
import com.queppelin.wudstay.vo.HdfcTranResponseVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;


@Repository
public class HdfcTranResponseDaoImpl extends BaseDaoImpl<HdfcTranResponseVO> implements IHdfcTranResponseDao {

	private static final Logger logger = LoggerFactory.getLogger(HdfcTranResponseDaoImpl.class);

	public HdfcTranResponseDaoImpl() {
		super(HdfcTranResponseVO.class);
	}



}
