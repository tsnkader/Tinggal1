package com.queppelin.wudstay.dao.impl;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.util.WudstayConstants;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.queppelin.wudstay.dao.IAmenityDao;
import com.queppelin.wudstay.vo.Amenity;

@Repository
public class AmenityDaoImpl extends BaseDaoImpl<Amenity> implements IAmenityDao {

	private static final Logger logger = LoggerFactory.getLogger(AmenityDaoImpl.class);
	
	public AmenityDaoImpl() {
		super(Amenity.class);
	}
	public Amenity getFreeBreakfastAmenity(){
		String freeBreakfastAmenityImage = "icon10";
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(Amenity.class);
			criteria.add(Restrictions.eq("amenityImage", freeBreakfastAmenityImage));
			return (Amenity) criteria.uniqueResult();
		} catch (Exception e) {
			return null;
		}
	}
}
