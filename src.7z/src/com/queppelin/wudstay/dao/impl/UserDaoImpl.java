package com.queppelin.wudstay.dao.impl;

import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.queppelin.wudstay.dao.IUserDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.User;

@Repository
public class UserDaoImpl extends BaseDaoImpl<User> implements IUserDao {
	
	private static final Logger logger = LoggerFactory.getLogger(UserDaoImpl.class);
	
	public UserDaoImpl() {
		super(User.class);
	}

	
	public User login(User user, String userType) throws WudstayException {
		try{
			Criteria criteria = getCurrentSession().createCriteria(User.class);
			criteria.add(Restrictions.eq("username", user.getUsername()));
			//criteria.add(Restrictions.eq("password", encryptPassword(user.getPassword())));
			criteria.add(Restrictions.eq("password", user.getPassword()));
			criteria.add(Restrictions.eq("userType", userType));
			user = (User) criteria.uniqueResult();
		}catch(Exception e){
			throw new WudstayException(logger, "UserDaoImpl.login()", WudstayConstants.LOGIN_ERROR, e);
		}
		return user;
	}

	
	public Boolean isUsernameExists(String username) throws WudstayException {
		try{
			Criteria criteria = getCurrentSession().createCriteria(User.class);
			criteria.add(Restrictions.eq("username", username));
			User user = (User) criteria.uniqueResult();
			if(user == null) {
				return Boolean.FALSE;
			}
		}catch(Exception e){
			throw new WudstayException(logger, "UserDaoImpl.isUsernameExists()", WudstayConstants.CHECKING_DUPlICATE_USERNAME_ERROR, e);
		}
		return Boolean.TRUE;
	}

	
	public String encryptPassword(String password)
			throws WudstayException {
		String encPass = null;
		try {
			String query = "select SHA('" + password + "')";
			SQLQuery sqlQuery = getCurrentSession().createSQLQuery(query);
			encPass = (String) sqlQuery.uniqueResult();
			return encPass;
		} catch(Exception e) {
			throw new WudstayException(logger, "UserDaoImpl.updatePassword()", WudstayConstants.ENCRYPT_PASSWORD_ERROR, e);
		}
	}

}
