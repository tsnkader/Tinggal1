package com.queppelin.wudstay.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.queppelin.wudstay.dao.ICityDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.City;

@Repository
public class CityDaoImpl extends BaseDaoImpl<City> implements ICityDao {

	private static final Logger logger = LoggerFactory.getLogger(CityDaoImpl.class);
	
	public CityDaoImpl() {
		super(City.class);
	}

	
	public List<City> getAllCities() throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(City.class);
			ProjectionList projectionList = Projections.projectionList();
			projectionList.add(Projections.property("cityId"), "cityId");
			projectionList.add(Projections.property("cityName"), "cityName");
			criteria.setProjection(projectionList).setResultTransformer(Transformers.aliasToBean(City.class));
			criteria.add(Restrictions.eq("isActive", Boolean.TRUE));
			criteria.addOrder(Order.asc("cityName"));
			return (List<City>) criteria.list();
		} catch (Exception e) {
			e.printStackTrace();
			throw new WudstayException(logger, "CityDaoImpl.fetchAllCities()", WudstayConstants.FETCH_CITY_ERROR, null, e);
		}
	}

	
	public City getByCityName(String cityName) throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(City.class);
			criteria.add(Restrictions.eq("cityName", cityName));
			return (City) criteria.uniqueResult();
		} catch (Exception e) {
			throw new WudstayException(logger, "CityDaoImpl.getByCityName()", WudstayConstants.FETCH_CITY_ERROR, null, e);
		}
	}
}
