package com.queppelin.wudstay.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.queppelin.wudstay.dao.ILocationDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.Location;

@Repository
public class LocationDaoImpl extends BaseDaoImpl<Location> implements ILocationDao {
	
	private static final Logger logger = LoggerFactory.getLogger(LocationDaoImpl.class);
	
	public LocationDaoImpl() {
		super(Location.class);
	}

	
	public List<Location> getLocationsByCityId(Long cityId)
			throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(Location.class, "locationAlias");
			criteria.createAlias("locationAlias.city", "cityAlias");
			ProjectionList projectionList = Projections.projectionList();
			projectionList.add(Projections.property("locationId"), "locationId");
			projectionList.add(Projections.property("locationName"), "locationName");
			projectionList.add(Projections.property("latitude"), "latitude");
			projectionList.add(Projections.property("longitude"), "longitude");
			criteria.setProjection(projectionList).setResultTransformer(Transformers.aliasToBean(Location.class));
			criteria.add(Restrictions.eq("cityAlias.cityId", cityId));
			criteria.addOrder(Order.asc("locationName"));
			return (List<Location>) criteria.list();
		} catch (Exception e) {
			throw new WudstayException(logger, "CityDaoImpl.fetchAllCities()", WudstayConstants.FETCH_LOCATION_ERROR, null, e);
		}
	}

}
