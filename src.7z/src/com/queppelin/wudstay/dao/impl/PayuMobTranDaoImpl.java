package com.queppelin.wudstay.dao.impl;

import com.queppelin.wudstay.dao.IPayuMobTranDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.PayuMobTran;
import com.queppelin.wudstay.vo.custom.PayUVO;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class PayuMobTranDaoImpl extends BaseDaoImpl<PayuMobTran> implements IPayuMobTranDao {

	private static final Logger logger = LoggerFactory.getLogger(PayuMobTranDaoImpl.class);

	public PayuMobTranDaoImpl() {
		super(PayuMobTran.class);
	}


}
