package com.queppelin.wudstay.dao.impl;

import com.queppelin.wudstay.dao.ICorporateBookingDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.CorporateBookingVO;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CorporateBookingDaoImpl extends BaseDaoImpl<CorporateBookingVO> implements ICorporateBookingDao {
	
	private static final Logger logger = LoggerFactory.getLogger(CityDaoImpl.class);

	
	public CorporateBookingDaoImpl() {
		super(CorporateBookingVO.class);
	}
	
	
	public List<CorporateBookingVO> getAllBookings(Long corpId, Long corpLoginUserId) throws WudstayException {
		// TODO Auto-generated method stub
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(CorporateBookingVO.class, "corporateBookingAlias");
			//criteria.add(Restrictions.eq("corporateBookingAlias.corpLoginUserId", corpLoginUserId));
			criteria.createAlias("corporateBookingAlias.corporate", "corporateAlias");
			//criteria.add(Restrictions.eq("corporateAlias.corpLoginID", corpId));
			criteria.add(Restrictions.eq("corporateAlias.corpId", corpId));

			criteria.createAlias("corporateBookingAlias.corporateUser", "corporateUserAlias");
			//criteria.add(Restrictions.eq("corporateUserAlias.corpLoginUserId", corpLoginUserId));
			criteria.add(Restrictions.eq("corporateUserAlias.id", corpLoginUserId));

			//criteria.add(Restrictions.eq("corporateBookingAlias.corpLoginUserId", corpLoginUserId));
			//criteria.add(Restrictions.eq("corporateBookingAlias.corpLoginUser_id", corpLoginUserId));

			//criteria = getCurrentSession().createCriteria(CorporateBookingVO.class);
			//criteria.add(Restrictions.eq("corpLoginUserId", corpLoginUserId));


			return (List<CorporateBookingVO>) criteria.list();
		} catch (Exception e) {
			e.printStackTrace();
			throw new WudstayException(logger, "CityDaoImpl.fetchAllCities()", WudstayConstants.FETCH_CITY_ERROR, null, e);
		}
	}

	
	public List<CorporateBookingVO> getCorporateBookingsByCorporateId(Long corpId) throws WudstayException {
		// TODO Auto-generated method stub
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(CorporateBookingVO.class, "corporateBookingAlias");
			criteria.createAlias("corporateBookingAlias.corporate", "corporateAlias");
			criteria.add(Restrictions.eq("corporateAlias.corpId", corpId));
			//criteria.addOrder(Order.desc("dateFrom"));
			return (List<CorporateBookingVO>) criteria.list();
		} catch (Exception e) {
			throw new WudstayException(logger, "HotelBookingDaoImpl.getBookingsByHotelId()", WudstayConstants.FETCH_HOTEL_BOOKINGS_ERROR, null, e);
		}
	}

	
	public List<CorporateBookingVO> getCorporateBookingList() throws WudstayException {
		// TODO Auto-generated method stub
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(CorporateBookingVO.class, "corporateBookingAlias");
			criteria.createAlias("corporateBookingAlias.corporate", "corporateAlias");
			criteria.add(Restrictions.eq("corporateBookingAlias.isApproved", 0));
			criteria.addOrder(Order.desc("corporateBookingAlias.corpBookingId"));
			return (List<CorporateBookingVO>) criteria.list();
		} catch (Exception e) {
			throw new WudstayException(logger, "HotelBookingDaoImpl.getBookingsByHotelId()", WudstayConstants.FETCH_HOTEL_BOOKINGS_ERROR, null, e);
		}
	}

	
}
