package com.queppelin.wudstay.dao.impl;

import com.queppelin.wudstay.dao.IPgHotelDescriptionDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.HotelDescription;
import com.queppelin.wudstay.vo.PgHotelDescription;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class PgHotelDescriptionDaoImpl extends BaseDaoImpl<PgHotelDescription> implements IPgHotelDescriptionDao {

	private static final Logger logger = LoggerFactory.getLogger(PgHotelDescriptionDaoImpl.class);

	public PgHotelDescriptionDaoImpl() {
		super(PgHotelDescription.class);
	}



	
	public List<PgHotelDescription> getHotelDescriptionsByHotelId(Long hotelId)
			throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(PgHotelDescription.class, "hotelDescriptionAlias");
			criteria.createAlias("hotelDescriptionAlias.hotel", "hotelAlias");
			criteria.add(Restrictions.eq("hotelAlias.id", hotelId));
			return (List<PgHotelDescription>) criteria.list();
		} catch (Exception e) {
			throw new WudstayException(logger, "HotelRoomDaoImpl.getHotelDescriptionsByHotelId()", WudstayConstants.FETCH_HOTEL_DESCRIPTION_ERROR, null, e);
		}
	}

	
	public void deleteHotelDescriptionsByHotelId(Long hotelId) throws WudstayException {
		try {
			Query query = getCurrentSession().createQuery("delete PgHotelDescription where hotel.id = :hotelId");
			query.setParameter("hotelId", hotelId);
			query.executeUpdate();
		} catch (Exception e) {
			throw new WudstayException(logger, "PgHotelDescriptionDaoImpl.deleteHotelDescriptionsByHotelId()", WudstayConstants.DELETE_HOTEL_DESCRIPTIONS_ERROR, null, e);
		}
	}
}
