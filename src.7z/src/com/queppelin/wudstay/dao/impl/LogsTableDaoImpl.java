package com.queppelin.wudstay.dao.impl;

import com.queppelin.wudstay.dao.ICityDao;
import com.queppelin.wudstay.dao.ILogsTableDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.City;
import com.queppelin.wudstay.vo.LogsTable;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class LogsTableDaoImpl extends BaseDaoImpl<LogsTable> implements ILogsTableDao {

	private static final Logger logger = LoggerFactory.getLogger(LogsTableDaoImpl.class);

	public LogsTableDaoImpl() {
		super(LogsTable.class);
	}

}
