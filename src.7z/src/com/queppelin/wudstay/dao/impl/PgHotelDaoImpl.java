package com.queppelin.wudstay.dao.impl;

import com.queppelin.wudstay.dao.IHotelDao;
import com.queppelin.wudstay.dao.IPgHotelDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.*;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public class PgHotelDaoImpl extends BaseDaoImpl<PgHotel> implements IPgHotelDao {

	private static final Logger logger = LoggerFactory.getLogger(PgHotelDaoImpl.class);

	public PgHotelDaoImpl() {
		super(PgHotel.class);
	}

	
	public List<PgHotel> getHotelByCityId(Long cityId, int minPax) throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(PgHotel.class, "hotelAlias");
			criteria.createAlias("hotelAlias.location", "locationAlias");
			criteria.createAlias("locationAlias.city", "cityAlias");
			criteria.add(Restrictions.eq("cityAlias.cityId", cityId));
			criteria.add(Restrictions.eq("hotelAlias.isActive", Boolean.TRUE));
			if(minPax == 1) {
				criteria.addOrder(Order.asc("hotelAlias.singleOccupancyPrice"));
			} else if(minPax == 2) {
				criteria.addOrder(Order.asc("hotelAlias.doubleOccupancyPrice"));
			} else if(minPax == 3) {
				criteria.addOrder(Order.asc("hotelAlias.tripleOccupancyPrice"));
			}
			//criteria.setProjection(Projections.projectionList().add(Projections.groupProperty("hotelAlias.hotelId"), "hotelId"));
			//criteria.addOrder(Order.desc("hotelAlias.starRating"));
			return (List<PgHotel>) criteria.list();
		} catch (Exception e) {
			e.printStackTrace();
			throw new WudstayException(logger, "PgHotelDaoImpl.getHotelRoomsByCityId()", WudstayConstants.FETCH_HOTEL_ROOM_ERROR, null, e);
		}
	}



	
	public List<PgHotel> getHotelByCityId(Long cityId) throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(PgHotel.class, "hotelAlias");
			criteria.createAlias("hotelAlias.location", "locationAlias");
			criteria.createAlias("locationAlias.city", "cityAlias");
			criteria.add(Restrictions.eq("cityAlias.cityId", cityId));
			criteria.add(Restrictions.eq("hotelAlias.isActive", Boolean.TRUE));
			criteria.addOrder(Order.asc("hotelAlias.singleOccupancyPrice"));
			return (List<PgHotel>) criteria.list();
		} catch (Exception e) {
			e.printStackTrace();
			throw new WudstayException(logger, "PgHotelDaoImpl.getHotelByCityId()", WudstayConstants.FETCH_HOTEL_ROOM_ERROR, null, e);
		}
	}
	public List<PgHotel> getHotelBylocationIds(List<Long> locationIdsList) throws WudstayException{
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(PgHotel.class, "hotelAlias");
			criteria.createAlias("hotelAlias.location", "locationAlias");
			criteria.add(Restrictions.in("locationAlias.locationId", locationIdsList));
			criteria.add(Restrictions.eq("hotelAlias.isActive", Boolean.TRUE));
			criteria.addOrder(Order.asc("hotelAlias.singleOccupancyPrice"));
			return (List<PgHotel>) criteria.list();
		} catch (Exception e) {
			e.printStackTrace();
			throw new WudstayException(logger, "PgHotelDaoImpl.getHotelRoomsByCityId()", WudstayConstants.FETCH_HOTEL_ROOM_ERROR, null, e);
		}
	}

	
	/*public List<PgHotel> filterHotels(Long locationId, Long cityId, List<Long> pgTypeIdList,
									String sortBy, Integer priceSortType, Integer ratingSortType, int minPax) throws WudstayException {*/
	public List<PgHotel> filterHotels(List<Long> locationIdList, Long cityId, List<Long> pgTypeIdList,
									  String sortBy, Integer priceSortType, Integer ratingSortType, int minPax) throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(PgHotel.class, "hotelAlias");
			criteria.createAlias("hotelAlias.pgType", "pgTypeAlias");
			criteria.createAlias("hotelAlias.location", "locationAlias");
			criteria.createAlias("locationAlias.city", "cityAlias");


			ProjectionList projectionList = Projections.projectionList();
			projectionList.add(Projections.property("singleOccupancyWudstayPrice"), "singleOccupancyWudstayPrice");
			projectionList.add(Projections.property("doubleOccupancyWudstayPrice"), "doubleOccupancyWudstayPrice");
			projectionList.add(Projections.property("tripleOccupancyWudstayPrice"), "tripleOccupancyWudstayPrice");
			projectionList.add(Projections.property("id"), "id"); //hotelId
			projectionList.add(Projections.property("name"), "name"); //"hotelName");
			projectionList.add(Projections.property("displayName"), "displayName"); //"hotelDisplayName");
			projectionList.add(Projections.property("starRating"), "starRating");
			projectionList.add(Projections.property("address"), "address");//"hotelAddress");
			projectionList.add(Projections.property("displayAddress"), "displayAddress"); //"hotelDisplayAddress");
			//projectionList.add(Projections.property("hotelAmenities"), "hotelAmenities");


			criteria.setProjection(projectionList).setResultTransformer(Transformers.aliasToBean(PgHotel.class));


			criteria.add(Restrictions.eq("cityAlias.cityId", cityId));
			criteria.add(Restrictions.eq("hotelAlias.isActive", Boolean.TRUE));
			/*if(locationId != null) {
				criteria.add(Restrictions.eq("locationAlias.locationId", locationId));
			}*/
			if(locationIdList != null && locationIdList.size() > 0) {
				criteria.add(Restrictions.in("locationAlias.locationId", locationIdList));
			}
			if(pgTypeIdList != null && pgTypeIdList.size() > 0) {
				criteria.add(Restrictions.in("pgTypeAlias.pgTypeId", pgTypeIdList));
			}
			if(sortBy.equals(WudstayConstants.RATING)) {
				if(ratingSortType.equals(Integer.valueOf(1))) {
					criteria.addOrder(Order.desc("starRating"));
				} else {
					criteria.addOrder(Order.asc("starRating"));
				}
			} else {
				/*if(priceSortType.equals(Integer.valueOf(1))) {*/
					if(minPax == 1) {
						criteria.addOrder(Order.desc("hotelAlias.singleOccupancyWudstayPrice"));
					} else if(minPax == 2) {
						criteria.addOrder(Order.desc("hotelAlias.doubleOccupancyWudstayPrice"));
					} else if(minPax == 3) {
						criteria.addOrder(Order.desc("hotelAlias.tripleOccupancyWudstayPrice"));
					}
				/*} else {
					if(minPax == 1) {
						criteria.addOrder(Order.asc("hotelAlias.singleOccupancyPrice"));
					} else if(minPax == 2) {
						criteria.addOrder(Order.asc("hotelAlias.doubleOccupancyPrice"));
					} else if(minPax == 3) {
						criteria.addOrder(Order.asc("hotelAlias.tripleOccupancyPrice"));
					}
				}*/
			}
			//return (List<PgHotel>) criteria.list();
			List<PgHotel> lst =  criteria.list();
			try {
				for (PgHotel pg : lst) {
					Long city_Id = pg.getLocation().getCity().getCityId();
					Long type_Id = pg.getPgType().getPgTypeId();
					for (PgHotelAmenity amen : pg.getHotelAmenities()) {
						PgAmenity amt = amen.getAmenity();
						Long amenity_Id = amt.getAmenityId();
					}
					Set<PgHotelDescription> hotelDescriptions = pg.getHotelDescriptions();
				}
			}catch (Exception ex){
				ex.printStackTrace();
			}

			return lst; //(List<PgHotel>) criteria.list();
		} catch (Exception e) {
			e.printStackTrace();
			throw new WudstayException(logger, "HotelRoomDaoImpl.filterHotelRooms()", WudstayConstants.FETCH_HOTEL_ROOM_ERROR, null, e);
		}
	}

	
	public List<PgHotel> getSuggestedHotelList(PgHotel hotel) throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(PgHotel.class, "hotelAlias");
			criteria.createAlias("hotelAlias.location", "locationAlias");
			criteria.createAlias("locationAlias.city", "cityAlias");
			criteria.add(Restrictions.between("singleOccupancyPrice", hotel.getSingleOccupancyPrice() - 1000, hotel.getSingleOccupancyPrice() + 1000));
			criteria.add(Restrictions.eq("cityAlias.cityId", hotel.getLocation().getCity().getCityId()));
			criteria.add(Restrictions.ne("id", hotel.getId()));
			criteria.add(Restrictions.eq("hotelAlias.isActive", Boolean.TRUE));
			criteria.addOrder(Order.asc("hotelAlias.singleOccupancyPrice"));
			criteria.setMaxResults(3);
			//criteria.addOrder(Order.desc("hotelAlias.starRating"));
			return (List<PgHotel>) criteria.list();
		} catch (Exception e) {
			throw new WudstayException(logger, "HotelRoomDaoImpl.getSuggestedHotelList()", WudstayConstants.FETCH_HOTEL_ROOM_ERROR, null, e);
		}
	}

}
