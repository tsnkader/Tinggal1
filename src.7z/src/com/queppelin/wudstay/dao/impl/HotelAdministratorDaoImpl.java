package com.queppelin.wudstay.dao.impl;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.queppelin.wudstay.dao.IHotelAdministratorDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.HotelAdministrator;

@Repository
public class HotelAdministratorDaoImpl extends BaseDaoImpl<HotelAdministrator> implements IHotelAdministratorDao {
	
	private static final Logger logger = LoggerFactory.getLogger(HotelAdministratorDaoImpl.class);
	
	public HotelAdministratorDaoImpl() {
		super(HotelAdministrator.class);
	}

	
	public HotelAdministrator getHotelAdminByHotelId(Long hotelId)
			throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(HotelAdministrator.class, "hotelAdministratorAlias");
			criteria.createAlias("hotelAdministratorAlias.hotel", "hotelAlias");
			criteria.add(Restrictions.eq("hotelAlias.hotelId", hotelId));
			return (HotelAdministrator) criteria.uniqueResult();
		} catch (Exception e) {
			throw new WudstayException(logger, "HotelRoomDaoImpl.getHotelRoomsByHotelId()", WudstayConstants.FETCH_HOTEL_ADMINISTRATOR_ERROR, null, e);
		}
	}
}
