package com.queppelin.wudstay.dao.impl;

import com.queppelin.wudstay.dao.ICorporateDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.Corporate;
import com.queppelin.wudstay.vo.CorporateLoginVO;
import com.queppelin.wudstay.vo.User;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CorporateDaoImpl extends BaseDaoImpl<Corporate> implements ICorporateDao {

	private static final Logger logger = LoggerFactory.getLogger(CityDaoImpl.class);

	public CorporateDaoImpl() {
		super(Corporate.class);
	}

	/*
	public CorporateLoginVO login(CorporateLoginVO corporate) throws WudstayException {
		// TODO Auto-generated method stub
		try {
			Criteria criteria = getCurrentSession().createCriteria(Corporate.class);
			criteria.add(Restrictions.eq("corpLoginID", corporate.getCorpLoginID()));
			criteria.add(Restrictions.eq("corpLoginPassword", corporate.getCorpLoginPassword()));
			corporate = (Corporate) criteria.uniqueResult();
		} catch (Exception e) {
			e.printStackTrace();
			throw new WudstayException(logger, "UserDaoImpl.login()", WudstayConstants.LOGIN_ERROR, e);
		}
		return corporate;
	}*/

	
	public Boolean isUsernameExists(String corpUserName) throws WudstayException {
		// TODO Auto-generated method stub
		try {
			Criteria criteria = getCurrentSession().createCriteria(User.class);
			criteria.add(Restrictions.eq("username", corpUserName));
			Corporate corporate = (Corporate) criteria.uniqueResult();
			if (corporate == null) {
				return Boolean.FALSE;
			}
		} catch (Exception e) {
			throw new WudstayException(logger, "UserDaoImpl.isUsernameExists()",
					WudstayConstants.CHECKING_DUPlICATE_USERNAME_ERROR, e);
		}
		return Boolean.TRUE;
	}

	
	public String encryptPassword(String password) throws WudstayException {
		// TODO Auto-generated method stub
		String encPass = null;
		try {
			String query = "select SHA('" + password + "')";
			SQLQuery sqlQuery = getCurrentSession().createSQLQuery(query);
			encPass = (String) sqlQuery.uniqueResult();
			return encPass;
		} catch (Exception e) {
			throw new WudstayException(logger, "UserDaoImpl.updatePassword()", WudstayConstants.ENCRYPT_PASSWORD_ERROR,
					e);
		}
	}

	
	public List<Corporate> getAllCorporates() throws WudstayException {
		// TODO Auto-generated method stub
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(Corporate.class);
			ProjectionList projectionList = Projections.projectionList();
			projectionList.add(Projections.property("corpId"), "corpId");
			projectionList.add(Projections.property("corpName"), "corpName");
			projectionList.add(Projections.property("corpAddress"), "corpAddress");
			projectionList.add(Projections.property("corpContactPerson"), "corpContactPerson");
			projectionList.add(Projections.property("corpContactNo"), "corpContactNo");
			projectionList.add(Projections.property("corpTAN"), "corpTAN");
			projectionList.add(Projections.property("corpTIN"), "corpTIN");
			projectionList.add(Projections.property("corpCIN"), "corpCIN");
			criteria.setProjection(projectionList).setResultTransformer(Transformers.aliasToBean(Corporate.class));
			criteria.addOrder(Order.asc("corpId"));
			return (List<Corporate>) criteria.list();
		} catch (Exception e) {

			throw new WudstayException(logger, "CityDaoImpl.fetchAllCities()", WudstayConstants.FETCH_CITY_ERROR, null,
					e);

		}
	}

	
	public Corporate getCorporateById(Long corpId) throws WudstayException {
		// TODO Auto-generated method stub
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(Corporate.class);
			criteria.add(Restrictions.eq("corpId", corpId));
			Corporate corporate = (Corporate) criteria.uniqueResult();
			return corporate;
		} catch (Exception e) {

			throw new WudstayException(logger, "CityDaoImpl.fetchAllCities()", WudstayConstants.FETCH_CITY_ERROR, null,
					e);

		}
	}


	
	public Boolean isCorpNameExists(Long id, String corpName) throws WudstayException {
		boolean checkForDuplicateCorpName=true;
		if(id != null && id.longValue() > 0){
			Corporate vo = getById(id);
			checkForDuplicateCorpName = !(vo.getCorpName().equals(corpName));
		}
		if(checkForDuplicateCorpName){
			return isCorpNameExists(corpName);
		}else{
			return Boolean.FALSE;
		}

	}

	
	public Boolean isCorpNameExists(String corpName) throws WudstayException {
		try {
			Criteria criteria = getCurrentSession().createCriteria(Corporate.class);
			criteria.add(Restrictions.eq("corpName", corpName));
			//Corporate corporate = (Corporate) criteria.uniqueResult();
			List<Corporate> corporateList = criteria.list();
			if (corporateList == null || corporateList.size()==0) {
				return Boolean.FALSE;
			}else{
				return Boolean.TRUE;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new WudstayException(logger, "UserDaoImpl.isUsernameExists()",
					WudstayConstants.CHECKING_DUPlICATE_USERNAME_ERROR, e);
		}
	}


}
