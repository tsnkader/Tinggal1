package com.queppelin.wudstay.dao.impl;

import com.queppelin.wudstay.dao.ICorporateEmployeeDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.City;
import com.queppelin.wudstay.vo.CorporateEmployeeVO;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CorporateEmployeeDao extends BaseDaoImpl<CorporateEmployeeVO> implements ICorporateEmployeeDao {

	private static final Logger logger = LoggerFactory.getLogger(CityDaoImpl.class);

	public CorporateEmployeeDao() {
		super(CorporateEmployeeVO.class);
	}
	
	public List<CorporateEmployeeVO> getCorporateBookingsForCorporateId(Long corpId) throws WudstayException {
		// TODO Auto-generated method stub
		return null;
	}

	public List<CorporateEmployeeVO> getListByCorpBookingId(Long corpBookingId) throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(CorporateEmployeeVO.class);
			criteria.add(Restrictions.eq("bookingId", corpBookingId));
			return criteria.list();
		} catch (Exception e) {
			throw new WudstayException(logger, "CityDaoImpl.getByCityName()", WudstayConstants.FETCH_CITY_ERROR, null, e);
		}
	}

}
