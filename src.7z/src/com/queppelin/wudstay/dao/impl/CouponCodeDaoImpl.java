package com.queppelin.wudstay.dao.impl;

import com.queppelin.wudstay.dao.ICityDao;
import com.queppelin.wudstay.dao.ICouponCodeDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.City;
import com.queppelin.wudstay.vo.CouponCodeVO;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CouponCodeDaoImpl extends BaseDaoImpl<CouponCodeVO> implements ICouponCodeDao {

	private static final Logger logger = LoggerFactory.getLogger(CouponCodeDaoImpl.class);

	public CouponCodeDaoImpl() {
		super(CouponCodeVO.class);
	}

	public CouponCodeVO getByCouponCode(String couponCode) throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(CouponCodeVO.class, "couponCodeAlias");
			//criteria.createAlias("couponCodeAlias.corporate", "corporateAlias");
			criteria.add(Restrictions.eq("couponCodeAlias.couponCode", couponCode.trim()));
			List<CouponCodeVO> lst = criteria.list();
			if(lst==null || lst.size()==0)
				return null;
			else
				return lst.get(0);
		} catch (Exception e) {
			e.printStackTrace();
			throw new WudstayException(logger, "CouponCodeDaoImpl.listByCouponCode()", WudstayConstants.FETCH_CITY_ERROR, null, e);
		}
	}



}
