package com.queppelin.wudstay.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.queppelin.wudstay.dao.IRoomTypeDao;
import com.queppelin.wudstay.vo.RoomType;

@Repository
public class RoomTypeDaoImpl extends BaseDaoImpl<RoomType> implements IRoomTypeDao {

	private static final Logger logger = LoggerFactory.getLogger(RoomTypeDaoImpl.class);
	
	public RoomTypeDaoImpl() {
		super(RoomType.class);
	}
}
