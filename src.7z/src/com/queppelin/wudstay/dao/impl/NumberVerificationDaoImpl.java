package com.queppelin.wudstay.dao.impl;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.queppelin.wudstay.dao.INumberVerificationDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.NumberVerification;

@Repository
public class NumberVerificationDaoImpl extends BaseDaoImpl<NumberVerification> implements INumberVerificationDao {

	private static final Logger logger = LoggerFactory.getLogger(NumberVerificationDaoImpl.class);
	
	public NumberVerificationDaoImpl() {
		super(NumberVerification.class);
	}

	
	public Boolean verifyMobileNumber(String verificationCode,
			String mobileNumber) throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(NumberVerification.class);
			criteria.add(Restrictions.eq("verificationCode", verificationCode));
			criteria.add(Restrictions.eq("mobileNumber", mobileNumber));
			criteria.add(Restrictions.eq("isActive", Boolean.TRUE));
			//criteria.addOrder(Order.desc("hotelAlias.starRating"));
			NumberVerification numberVerification = (NumberVerification) criteria.uniqueResult();
			if(numberVerification != null) {
				numberVerification.setIsActive(Boolean.FALSE);
				getCurrentSession().save(numberVerification);
				return Boolean.TRUE;
			}
			return Boolean.FALSE;	
		} catch (Exception e) {
			throw new WudstayException(logger, "NumberVerificationDaoImpl.verifyMobileNumber()", WudstayConstants.MOBILE_NUMBER_VERIFICATION_ERROR, null, e);
		}
	}

	
	public Boolean isRegisteredMobileNumber(String mobileNumber)
			throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(NumberVerification.class);
			criteria.add(Restrictions.eq("mobileNumber", mobileNumber));
			criteria.add(Restrictions.eq("isActive", Boolean.FALSE));
			NumberVerification numberVerification = (NumberVerification) criteria.uniqueResult();
			if(numberVerification != null) {
				return Boolean.TRUE;
			}
		} catch (Exception e) {
			throw new WudstayException(logger, "NumberVerificationDaoImpl.isRegisteredMobileNumber()", WudstayConstants.REGISTERED_MOBILE_NUMBER_CHEKING_ERROR, null, e);
		}
		
		return Boolean.FALSE;
	}
	
	
	public NumberVerification getCustomerInfoByMobileNumber(String mobileNumber) throws WudstayException {
	Criteria criteria = null;
	try {
		criteria = getCurrentSession().createCriteria(NumberVerification.class);
		criteria.add(Restrictions.eq("mobileNumber", mobileNumber));
		
		NumberVerification numberVerification = (NumberVerification) criteria.uniqueResult();
		if(numberVerification != null) {
			return numberVerification;
		}else {
			return null;
		}
	} 
	catch (Exception e) {
		throw new WudstayException(logger, "NumberVerificationDaoImpl.getCustomerInfoByMobileNumber()", WudstayConstants.FETCH_CUSTOMER_VERIFICATION_DETAILS_ERROR, null, e);
	}
	
	}
}
