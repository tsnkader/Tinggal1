package com.queppelin.wudstay.dao.impl;

import com.queppelin.wudstay.dao.IAppVersionDao;
import com.queppelin.wudstay.dao.ICityDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.AppVersion;
import com.queppelin.wudstay.vo.City;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class AppVersionDaoImpl extends BaseDaoImpl<AppVersion> implements IAppVersionDao {

	private static final Logger logger = LoggerFactory.getLogger(AppVersionDaoImpl.class);

	public AppVersionDaoImpl() {
		super(AppVersion.class);
	}

	
	public List<AppVersion> getAppVersionList(String appType) throws WudstayException {
		try{
			Query query = getCurrentSession().createQuery("FROM " + AppVersion.class.getName() + " ap WHERE ap.appType = '"+ appType.toUpperCase() + "' ORDER BY ap.id ");
			return query.list();
		} catch (Exception e) {
			throw new WudstayException(logger, "AppVersionDaoImpl.getAppVersionList()", WudstayConstants.FETCH_MOBILE_APP_VERSION_ERROR, null, e);
		}
	}


}
