package com.queppelin.wudstay.dao.impl;

import com.queppelin.wudstay.dao.IBlackoutDateForPayAtHotelDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.BlackoutDateForPayAtHotel;
import com.queppelin.wudstay.vo.HotelBooking;
import org.hibernate.Criteria;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Repository
public class BlackoutDateForPayAtHotelDaoImpl extends BaseDaoImpl<BlackoutDateForPayAtHotel> implements IBlackoutDateForPayAtHotelDao {

	private static final Logger logger = LoggerFactory.getLogger(BlackoutDateForPayAtHotelDaoImpl.class);

	public BlackoutDateForPayAtHotelDaoImpl() {
		super(BlackoutDateForPayAtHotel.class);
	}

	private List<BlackoutDateForPayAtHotel> getSearchCriteria(Date checkIn, Date checkOut, Long cityId){
		Criteria criteria = null;
		List<BlackoutDateForPayAtHotel> lst = new ArrayList<BlackoutDateForPayAtHotel>();
		try {
			criteria = getCurrentSession().createCriteria(BlackoutDateForPayAtHotel.class, "blackoutDates");
			//criteria.createAlias("blackoutDates hotelBookingAlias.hotel", "hotelAlias");
			LogicalExpression checkInOutBetween = Restrictions.or(Restrictions.between("blackoutFromDate", checkIn, checkOut), Restrictions.between("blackoutToDate", checkIn, checkOut));
			LogicalExpression checkInOut = Restrictions.and(Restrictions.lt("blackoutFromDate", checkIn), Restrictions.gt("blackoutToDate", checkOut));

			criteria.add(Restrictions.or(checkInOutBetween, checkInOut));
			//criteria.add(Restrictions.le("checkOut", checkOut));

			if(cityId!=null && cityId.longValue()>0){
				criteria.add(Restrictions.eq("cityId", cityId));
			}

			criteria.addOrder(Order.asc("cityId"));

			lst = criteria.list();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return lst;
	}





	
	public List<BlackoutDateForPayAtHotel> getListOfBlackoutDate(Date checkIn, Date checkOut) {
		return getSearchCriteria( checkIn, checkOut, null);
	}

	
	public List<BlackoutDateForPayAtHotel> getListOfBlackoutDate(Date checkIn, Date checkOut, long cityId) {
		if(cityId>0)
			return getSearchCriteria( checkIn, checkOut, cityId);
		else
			return getSearchCriteria( checkIn, checkOut, null);
	}

	
	public boolean isBlackoutOn(Date checkIn, Date checkOut, long cityId) {
		List<BlackoutDateForPayAtHotel> lst = getSearchCriteria(checkIn, checkOut, cityId);
		if (lst.size() > 0) {
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}

	
	public boolean isBlackoutOn(Date checkIn, Date checkOut) {
		List<BlackoutDateForPayAtHotel> lst = getSearchCriteria( checkIn, checkOut, null);
		if(lst.size()>0){
			return Boolean.TRUE;
		}
		return Boolean.FALSE;


		//return false;
		/*Criteria criteria = null;
		List<BlackoutDateForPayAtHotel> lst = null; //blackoutFromDate blackoutToDate
		try {
			criteria = getCurrentSession().createCriteria(BlackoutDateForPayAtHotel.class, "blackoutDates");
			//criteria.createAlias("blackoutDates hotelBookingAlias.hotel", "hotelAlias");
			LogicalExpression checkInOutBetween = Restrictions.or(Restrictions.between("blackoutFromDate", checkIn, checkOut), Restrictions.between("blackoutToDate", checkIn, checkOut));
			LogicalExpression checkInOut = Restrictions.and(Restrictions.lt("blackoutFromDate", checkIn), Restrictions.gt("blackoutToDate", checkOut));

			criteria.add(Restrictions.or(checkInOutBetween, checkInOut));
			//criteria.add(Restrictions.le("checkOut", checkOut));
			lst = criteria.list();
			if(lst.size()>0){
				return Boolean.TRUE;
			}
			return Boolean.FALSE;
		} catch (Exception e) {
			return Boolean.FALSE;
		}*/
	}
}