package com.queppelin.wudstay.dao.impl;

import java.util.List;

import com.queppelin.wudstay.vo.HotelAmenity;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.queppelin.wudstay.dao.IHotelDescriptionDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.HotelDescription;

@Repository
public class HotelDescriptionDaoImpl extends BaseDaoImpl<HotelDescription> implements IHotelDescriptionDao {
	
	private static final Logger logger = LoggerFactory.getLogger(HotelDescriptionDaoImpl.class);
	
	public HotelDescriptionDaoImpl() {
		super(HotelDescription.class);
	}

	
	public List<HotelDescription> getHotelDescriptionsByHotelId(Long hotelId)
			throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(HotelDescription.class, "hotelDescriptionAlias");
			criteria.createAlias("hotelDescriptionAlias.hotel", "hotelAlias");
			criteria.add(Restrictions.eq("hotelAlias.hotelId", hotelId));
			return (List<HotelDescription>) criteria.list();
		} catch (Exception e) {
			e.printStackTrace();
			throw new WudstayException(logger, "HotelRoomDaoImpl.getHotelDescriptionsByHotelId()", WudstayConstants.FETCH_HOTEL_DESCRIPTION_ERROR, null, e);
		}
	}

	
	public void deleteHotelDescriptionsByHotelId(Long hotelId) throws WudstayException {
		/*try {
			Query query = getCurrentSession().createQuery("delete HotelDescription where hotel.hotelId = :hotelId");
			query.setParameter("hotelId", hotelId);
			query.executeUpdate();
		} catch (Exception e) {
			throw new WudstayException(logger, "HotelDescriptionDaoImpl.deleteHotelDescriptionsByHotelId()", WudstayConstants.DELETE_HOTEL_DESCRIPTIONS_ERROR, null, e);
		}*/
		List<HotelDescription> lst = getHotelDescriptionsByHotelId( hotelId);
		for(HotelDescription vo : lst ){
			try {
				super.delete(vo);
			}catch (Exception ex){
				ex.printStackTrace();
			}
		}
	}
}
