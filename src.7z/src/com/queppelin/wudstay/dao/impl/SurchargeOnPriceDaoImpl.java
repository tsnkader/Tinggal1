package com.queppelin.wudstay.dao.impl;


import com.queppelin.wudstay.dao.ISurchargeOnPriceDao;
import com.queppelin.wudstay.vo.SurchargeOnPriceVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@Repository
public class SurchargeOnPriceDaoImpl extends BaseDaoImpl<SurchargeOnPriceVO> implements ISurchargeOnPriceDao {

	private static final Logger logger = LoggerFactory.getLogger(SurchargeOnPriceDaoImpl.class);

	public SurchargeOnPriceDaoImpl() {
		super(SurchargeOnPriceVO.class);
	}


	public List<SurchargeOnPriceVO> sortList(List<SurchargeOnPriceVO> lst){
		Collections.sort(lst,
				new Comparator<SurchargeOnPriceVO>() {
					public int compare(SurchargeOnPriceVO lhs, SurchargeOnPriceVO rhs) {
						int x = 0;
						try {
							x = lhs.getHotelId().compareTo(rhs.getHotelId());
						}catch (Exception ex){ ex.printStackTrace();}
						if(x==0){
							try {
								x = lhs.getUniqueKey().compareTo(rhs.getUniqueKey());
							}catch (Exception ex){ ex.printStackTrace();}
						}
						if(x==0){
							try {
								x = lhs.getStrInventoryDate().compareTo(rhs.getStrInventoryDate());
							}catch (Exception ex){ ex.printStackTrace();}
						}

						if(x==0){
							try {
								x = lhs.getId().compareTo(rhs.getId());
							}catch (Exception ex){ ex.printStackTrace();}
						}
						return x;
					}
				});
		return lst;
	}
/*
	
	public List<SurchargeOnPriceVO> getSurchargePriceListForHotel(Long hotelId) {
		List<SurchargeOnPriceVO> lst;
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(SurchargeOnPriceVO.class);
			criteria.add(Restrictions.eq("hotelId", hotelId));
			lst = criteria.list();
		} catch (Exception e) {
			lst=new ArrayList<SurchargeOnPriceVO>();
		}

		*//*if(lst!=null && lst.size()>0){
			lst = sortList(lst);
			SurchargeOnPriceVO first = lst.get(0);
			SurchargeOnPriceVO last = lst.get(lst.size()-1);
			Long uniqueKey = first.getUniqueKey();
			*//**//*for(SurchargeOnPriceVO vo: lst){
				first.get
			}*//**//*
		}*//*



		return lst;
	}
	
	public List<SurchargeOnPrice> getSurchargePriceListForHotel(Long hotelId) {
		//SurchargeOnPrice(SurchargeOnPriceVO surchargeOnPriceVO)
		List<SurchargeOnPriceVO> lst;
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(SurchargeOnPriceVO.class);
			criteria.add(Restrictions.eq("hotelId", hotelId));
			lst = criteria.list();
		} catch (Exception e) {
			lst=new ArrayList<SurchargeOnPriceVO>();
		}
		return lst;
	}*/
}
