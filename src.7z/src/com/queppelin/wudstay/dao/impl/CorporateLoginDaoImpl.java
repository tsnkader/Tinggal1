package com.queppelin.wudstay.dao.impl;

import com.queppelin.wudstay.dao.ICorporateDao;
import com.queppelin.wudstay.dao.ICorporateLoginDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.Corporate;
import com.queppelin.wudstay.vo.CorporateLoginVO;
import com.queppelin.wudstay.vo.User;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CorporateLoginDaoImpl extends BaseDaoImpl<CorporateLoginVO> implements ICorporateLoginDao {

	private static final Logger logger = LoggerFactory.getLogger(CorporateLoginDaoImpl.class);

	public CorporateLoginDaoImpl() {
		super(CorporateLoginVO.class);
	}

	
	public CorporateLoginVO login(CorporateLoginVO corporate) throws WudstayException {
		// TODO Auto-generated method stub
		try {
			Criteria criteria = getCurrentSession().createCriteria(CorporateLoginVO.class);
			criteria.add(Restrictions.eq("corpLoginID", corporate.getCorpLoginID()));
			criteria.add(Restrictions.eq("corpLoginPassword", corporate.getCorpLoginPassword()));
			corporate = (CorporateLoginVO) criteria.uniqueResult();
		} catch (Exception e) {
			e.printStackTrace();
			throw new WudstayException(logger, "UserDaoImpl.login()", WudstayConstants.LOGIN_ERROR, e);
		}
		return corporate;
	}

	
	public Boolean isCorpLoginIdExists(Long id, String corpLoginId) throws WudstayException {
		boolean checkForDuplicateLoginId=true;
		if(id != null && id.longValue() > 0){
			CorporateLoginVO vo = getById(id);
			checkForDuplicateLoginId = !(vo.getCorpLoginID().equals(corpLoginId));
		}
		if(checkForDuplicateLoginId){
			return isCorpLoginIdExists(corpLoginId);
		}else{
			return Boolean.FALSE;
		}
	}

	
	public Boolean isCorpLoginIdExists(String corpLoginId) throws WudstayException {
		try {
			Criteria criteria = getCurrentSession().createCriteria(CorporateLoginVO.class);
			criteria.add(Restrictions.eq("corpLoginID", corpLoginId));
			//Corporate corporate = (Corporate) criteria.uniqueResult();
			List<CorporateLoginVO> corporateList = criteria.list();
			if (corporateList == null || corporateList.size()==0) {
				return Boolean.FALSE;
			}else{
				return Boolean.TRUE;
			}
		} catch (Exception e) {
			throw new WudstayException(logger, "UserDaoImpl.isUsernameExists()",
					WudstayConstants.CHECKING_DUPlICATE_USERNAME_ERROR, e);
		}
	}

}
