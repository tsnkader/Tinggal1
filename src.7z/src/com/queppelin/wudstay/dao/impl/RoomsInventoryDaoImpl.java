package com.queppelin.wudstay.dao.impl;

import com.queppelin.wudstay.dao.ICouponCodeUsedDao;
import com.queppelin.wudstay.dao.IRoomsInventoryDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.CouponCodeUsedVO;
import com.queppelin.wudstay.vo.HotelBooking;
import com.queppelin.wudstay.vo.RoomsInventoryVO;
import org.hibernate.Criteria;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Repository
public class RoomsInventoryDaoImpl extends BaseDaoImpl<RoomsInventoryVO> implements IRoomsInventoryDao {
	private static final Logger logger = LoggerFactory.getLogger(RoomsInventoryDaoImpl.class);

	public RoomsInventoryDaoImpl() {
		super(RoomsInventoryVO.class);
	}

	
	public List<RoomsInventoryVO> getListByHotelId(Long hotelId) { //throws WudstayException {
		List<RoomsInventoryVO> lst = new ArrayList<RoomsInventoryVO>();
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(RoomsInventoryVO.class, "alias");
			criteria.add(Restrictions.eq("alias.hotelId", hotelId));
			lst = criteria.list();
			return lst;
		} catch (Exception e) {
			//throw new WudstayException(logger, "HotelBookingDaoImpl.getBookingsByHotelId()", WudstayConstants.FETCH_HOTEL_BOOKINGS_ERROR, null, e);
			return lst;
		}
	}

	
	public RoomsInventoryVO getListByDate(Long hotelId, Long inventoryLongDate) throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(RoomsInventoryVO.class, "alias");
			criteria.add(Restrictions.eq("alias.inventoryLongDate", inventoryLongDate));
			criteria.add(Restrictions.eq("alias.hotelId", hotelId));
			List<RoomsInventoryVO> lst = criteria.list();
			if(lst!=null && lst.size()>0)
				return lst.get(0);
			else
				return null;
		} catch (Exception e) {
			throw new WudstayException(logger, "HotelBookingDaoImpl.getBookingsByHotelId()", WudstayConstants.FETCH_HOTEL_BOOKINGS_ERROR, null, e);
		}
	}

	
	public List<RoomsInventoryVO> getListByDate(Long hotelId, Long fromLngDate, Long toLngDate) throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(RoomsInventoryVO.class, "alias");
			//criteria.add(Restrictions.between("alias.inventoryLongDate", fromLngDate, toLngDate));
			criteria.add(Restrictions.and(Restrictions.ge("alias.inventoryLongDate",fromLngDate),
										  Restrictions.lt("alias.inventoryLongDate", toLngDate)));
			//LogicalExpression checkInOutBetween = Restrictions.or(Restrictions.between("checkIn", checkIn, checkOut), Restrictions.between("checkOut", checkIn, checkOut));
			criteria.add(Restrictions.eq("alias.hotelId", hotelId));

			return criteria.list();
		} catch (Exception e) {
			throw new WudstayException(logger, "HotelBookingDaoImpl.getBookingsByHotelId()", WudstayConstants.FETCH_HOTEL_BOOKINGS_ERROR, null, e);
		}
	}

	
	public Integer getMinRoomAvailable(Long hotelId, Long fromLngDate, Long toLngDate) throws WudstayException{
		List<RoomsInventoryVO> lst = getListByDate(hotelId, fromLngDate, toLngDate);
		int minRoom = -1;
		for(RoomsInventoryVO vo: lst){
			if(minRoom < 0){
				minRoom = vo.getNoOfRooms().intValue();
			}else if(vo.getNoOfRooms().intValue() < minRoom){
				minRoom = vo.getNoOfRooms().intValue();
			}
		}
		return (minRoom<0? 0 : minRoom);
	}


}
