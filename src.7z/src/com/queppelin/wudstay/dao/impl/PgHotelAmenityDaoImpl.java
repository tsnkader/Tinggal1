package com.queppelin.wudstay.dao.impl;

import com.queppelin.wudstay.dao.IHotelAmenityDao;
import com.queppelin.wudstay.dao.IPgHotelAmenityDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.PgHotelAmenity;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class PgHotelAmenityDaoImpl extends BaseDaoImpl<PgHotelAmenity> implements IPgHotelAmenityDao {

	private static final Logger logger = LoggerFactory.getLogger(PgHotelAmenityDaoImpl.class);

	public PgHotelAmenityDaoImpl() {
		super(PgHotelAmenity.class);
	}

	
	public List<PgHotelAmenity> getPgHotelAmenitiesByHotelId(Long hotelId) throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(PgHotelAmenity.class, "hotelAmenityAlias");
			criteria.createAlias("hotelAmenityAlias.hotel", "hotelAlias");
			criteria.add(Restrictions.eq("hotelAlias.id", hotelId));
			criteria.addOrder(Order.asc("amenityListingOrder"));
			return (List<PgHotelAmenity>) criteria.list();
		} catch (Exception e) {
			throw new WudstayException(logger, "HotelAmenityDaoImpl.getHotelAmenitiesByHotelId()", WudstayConstants.FETCH_HOTEL_AMENITIES_ERROR, null, e);
		}
	}

	
	public void deletePgHotelAmenitiesByHotelId(Long hotelId)
			throws WudstayException {
		try {
			Query query = getCurrentSession().createQuery("delete PgHotelAmenity where hotel.id = :hotelId");
			query.setParameter("hotelId", hotelId);
			query.executeUpdate();
		} catch (Exception e) {
			throw new WudstayException(logger, "HotelAmenityDaoImpl.deleteHotelAmenitiesByHotelId()", WudstayConstants.DELETE_HOTEL_AMENITIES_ERROR, null, e);
		}
	}
}
