package com.queppelin.wudstay.dao.impl;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.queppelin.wudstay.dao.IBaseDao;

@Repository
public class BaseDaoImpl<T> implements IBaseDao<T> {

	@Autowired
	private SessionFactory sessionFactory;

	private Class<T> persistenceClass;

	public BaseDaoImpl() {
		super();
	}

	public BaseDaoImpl(Class<T> persistenceClass) {
		this.persistenceClass = persistenceClass;
	}

	protected Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}

	
	public void save(T obj) {
		getCurrentSession().save(obj);
	}

	@SuppressWarnings("unchecked")
	
	public T getById(Serializable id) {
		return (T)getCurrentSession().get(persistenceClass, id);
	}

	
	public void delete(T obj) {    	
		getCurrentSession().delete(obj);
		getCurrentSession().flush();
	}

	@SuppressWarnings("unchecked")
	
	public List<T> list(String propertyName, String orderType) {
		Query query = getCurrentSession().createQuery("from "+persistenceClass.getName() + " ORDER BY " + propertyName + " " + orderType);
		return query.list();
	}

	@SuppressWarnings("unchecked")
	public List<T> list() {
		Query query = getCurrentSession().createQuery("from "+persistenceClass.getName());
		return query.list();
	}

	
	public void saveOrUpdate(T obj) {
		getCurrentSession().saveOrUpdate(obj);
	}


	public Query getNamedQuery(String namedQuery)  {
		//Query query = getCurrentSession().getNamedQuery("callStockStoreProcedure").setParameter("stockCode", "7277");
		Query query = getCurrentSession().getNamedQuery(namedQuery);
		return query;
	}
	public Query getNamedQuery(String namedQuery, String[] paramNames, Object[] paramValues)  {
		//Query query = getCurrentSession().getNamedQuery("callStockStoreProcedure").setParameter("stockCode", "7277");
		Query query = getCurrentSession().getNamedQuery(namedQuery);
		for(int i=0;i<paramNames.length;i++) {
			query.setParameter(paramNames[i], paramValues[i]);
		}
		return query ;
	}

}
