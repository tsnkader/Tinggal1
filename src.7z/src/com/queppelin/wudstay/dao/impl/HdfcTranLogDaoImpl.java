package com.queppelin.wudstay.dao.impl;

import com.queppelin.wudstay.dao.IHdfcTranLogDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.City;
import com.queppelin.wudstay.vo.HdfcTranLogVO;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public class HdfcTranLogDaoImpl extends BaseDaoImpl<HdfcTranLogVO> implements IHdfcTranLogDao {

	private static final Logger logger = LoggerFactory.getLogger(HdfcTranLogDaoImpl.class);

	public HdfcTranLogDaoImpl() {
		super(HdfcTranLogVO.class);
	}

	public HdfcTranLogVO getSecureHash(String secureHash){
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(HdfcTranLogVO.class);
			criteria.add(Restrictions.eq("secureHash", secureHash));
			List<HdfcTranLogVO> lst = criteria.list();
			//return (HdfcTranLogVO) criteria.uniqueResult();
			if(lst!=null && lst.size()>0){
				return lst.get(0);
			}
			return null;
		} catch (Exception e) {
			return null;
		}
	}

}
