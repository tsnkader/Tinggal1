package com.queppelin.wudstay.dao.impl;

import com.queppelin.wudstay.dao.ICouponCodeDao;
import com.queppelin.wudstay.dao.ICouponCodeUsedDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.CouponCodeUsedVO;
import com.queppelin.wudstay.vo.CouponCodeVO;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class CouponCodeUsedDaoImpl extends BaseDaoImpl<CouponCodeUsedVO> implements ICouponCodeUsedDao {

	private static final Logger logger = LoggerFactory.getLogger(CouponCodeUsedDaoImpl.class);

	public CouponCodeUsedDaoImpl() {
		super(CouponCodeUsedVO.class);
	}

	
	public List<CouponCodeUsedVO> getByCouponCodeId(Long couponCodeId) throws WudstayException{
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(CouponCodeUsedVO.class, "CouponCodeUsedAlias");
			//criteria.createAlias("couponCodeAlias.corporate", "corporateAlias");
			criteria.add(Restrictions.eq("CouponCodeUsedAlias.couponId", couponCodeId));
			List<CouponCodeUsedVO> lst = criteria.list();
			if(lst==null || lst.size()==0)
				return null;
			else
				return lst;
		} catch (Exception e) {
			e.printStackTrace();
			throw new WudstayException(logger, "CouponCodeDaoImpl.listByCouponCode()", WudstayConstants.FETCH_CITY_ERROR, null, e);
		}
	}
	
	public List<CouponCodeUsedVO> getByCouponCodeIdAndMobile(Long couponCodeId, String mobileNo)  throws WudstayException {
		List<CouponCodeUsedVO> list = new ArrayList<CouponCodeUsedVO>();
		try {
			if(mobileNo==null || "".equals(mobileNo.trim())){
				list = getByCouponCodeId(couponCodeId);
			}else{
				list = (List<CouponCodeUsedVO> )(getNamedQuery("callSpUsedCoupons", new String[]{"v_ccode_Id", "v_mobile_no"}, new Object[]{couponCodeId, mobileNo}).list());
			}
			return list;
		}catch (Exception ex){
			ex.printStackTrace();
			throw new WudstayException(logger, "CouponCodeDaoImpl.getByCouponCodeIdAndMobile()", "Error to fetching data: " + ex.getMessage(), null, ex);
		}
	}

}
