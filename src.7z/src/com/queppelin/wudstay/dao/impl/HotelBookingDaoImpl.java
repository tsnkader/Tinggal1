package com.queppelin.wudstay.dao.impl;

import java.util.*;

import com.queppelin.wudstay.util.DateUtil;
import com.queppelin.wudstay.vo.custom.RoomAvailabilityDayWise;
import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.queppelin.wudstay.dao.IHotelBookingDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.HotelBooking;

@Repository
public class HotelBookingDaoImpl extends BaseDaoImpl<HotelBooking> implements IHotelBookingDao {

	private static final Logger logger = LoggerFactory.getLogger(HotelBookingDaoImpl.class);
	
	public HotelBookingDaoImpl() {
		super(HotelBooking.class);
	}

	
	public List<HotelBooking> getBookingsByHotelId(Long hotelId)
			throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(HotelBooking.class, "hotelBookingAlias");
			criteria.createAlias("hotelBookingAlias.hotel", "hotelAlias");
			criteria.add(Restrictions.eq("hotelAlias.hotelId", hotelId));
			//criteria.addOrder(Order.desc("dateFrom"));
			return (List<HotelBooking>) criteria.list();
		} catch (Exception e) {
			throw new WudstayException(logger, "HotelBookingDaoImpl.getBookingsByHotelId()", WudstayConstants.FETCH_HOTEL_BOOKINGS_ERROR, null, e);
		}
	}

	
	public List<HotelBooking> getBookingsBetweenSelectedDates(Long hotelId,
			Date checkIn, Date checkOut) throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(HotelBooking.class, "hotelBookingAlias");
			criteria.createAlias("hotelBookingAlias.hotel", "hotelAlias");
			LogicalExpression checkInOutBetween = Restrictions.or(Restrictions.between("checkIn", checkIn, checkOut), Restrictions.between("checkOut", checkIn, checkOut));
			
			
			LogicalExpression checkInOut = Restrictions.and(Restrictions.lt("checkIn", checkIn), Restrictions.gt("checkOut", checkOut));
			
			criteria.add(Restrictions.or(checkInOutBetween, checkInOut));
			//criteria.add(Restrictions.le("checkOut", checkOut));
			criteria.add(Restrictions.eq("hotelAlias.hotelId", hotelId));
			//criteria.addOrder(Order.desc("dateFrom"));
			return (List<HotelBooking>) criteria.list();
		} catch (Exception e) {
			throw new WudstayException(logger, "HotelBookingDaoImpl.getBookingsBetweenSelectedDates()", WudstayConstants.FETCH_HOTEL_BOOKINGS_ERROR, null, e);
		}
	}

	public Map<Long, RoomAvailabilityDayWise> getRoomBookingsDayWise(Long hotelId, Date checkIn, Date checkOut) {
		List<HotelBooking> bookingList = new ArrayList<HotelBooking>();
		try {
			bookingList = getBookingsBetweenSelectedDates(hotelId, checkIn, checkOut);
		} catch (WudstayException e) {
			e.printStackTrace();
		}
		Map<Long, RoomAvailabilityDayWise> map = new HashMap<Long, RoomAvailabilityDayWise>();
		DateUtil dateUtil = new DateUtil(checkIn);
		int days = (int) dateUtil.getDifferenceInDays(checkOut);
		RoomAvailabilityDayWise obj ;
		for(int i=0; i<= days ;i++) {
			Long key = DateUtil.toLongDate(dateUtil.toDate());

			if(map.containsKey(key)) {
				obj = map.get(key);
			}else {
				obj = new RoomAvailabilityDayWise();
			}

			for(HotelBooking booking : bookingList) {
				Long checkInDt = DateUtil.toLongDate(booking.getCheckIn());
				Long checkOutDt = DateUtil.toLongDate(booking.getCheckOut());
				if(key>=checkInDt && key<checkOutDt) {
					obj.addBookedRooms(booking.getNoOfRooms());
				}
			}

			map.put(key, obj );
			dateUtil.moveNexDay();
		}
		return map;
	}

	
	public List<HotelBooking> getBookingsByContactNumber(String mobileNumber)
			throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(HotelBooking.class);
			criteria.add(Restrictions.eq("contactNumber", mobileNumber));
			//criteria.addOrder(Order.desc("dateFrom"));
			return (List<HotelBooking>) criteria.list();
		} catch (Exception e) {
			throw new WudstayException(logger, "HotelBookingDaoImpl.getBookingsByContactNumber()", WudstayConstants.FETCH_HOTEL_BOOKINGS_ERROR, null, e);
		}
	}

	
	public List<HotelBooking> getBookingsByHotelId(Long hotelId,
			String contactNumber) throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(HotelBooking.class, "hotelBookingAlias");
			criteria.createAlias("hotelBookingAlias.hotel", "hotelAlias");
			criteria.add(Restrictions.eq("hotelAlias.hotelId", hotelId));
			criteria.add(Restrictions.eq("hotelBookingAlias.contactNumber", contactNumber));
			criteria.add(Restrictions.gt("hotelBookingAlias.checkIn", new Date()));
			//criteria.addOrder(Order.desc("dateFrom"));
			return (List<HotelBooking>) criteria.list();
		} catch (Exception e) {
			throw new WudstayException(logger, "HotelBookingDaoImpl.getBookingsByHotelId()", WudstayConstants.FETCH_HOTEL_BOOKINGS_ERROR, null, e);
		}
	}
	
	
	public List<HotelBooking> getBookingsForCustomerCare(Long bookingId, Long hotelId) throws WudstayException {

		Criteria criteria = null;
		try{
			criteria = getCurrentSession().createCriteria(HotelBooking.class, "hotelBookingAlias");
			criteria.createAlias("hotelBookingAlias.hotel", "hotelAlias");
			criteria.add(Restrictions.eq("hotelBookingAlias.bookingId", bookingId));
			criteria.add(Restrictions.eq("hotelAlias.hotelId", hotelId));
			return (List<HotelBooking>) criteria.list();
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			throw new WudstayException(logger, "HotelBookingDaoImpl.getBookingsForCustomerCare()", WudstayConstants.FETCH_HOTEL_BOOKINGS_ERROR, null, e);
		}
		
	}
	
	
	public List<HotelBooking> getBookingsByTransactionId(String transactionId)
			throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(HotelBooking.class);
			criteria.add(Restrictions.eq("transactionId", transactionId));
			//criteria.addOrder(Order.desc("dateFrom"));
			return (List<HotelBooking>) criteria.list();
		} catch (Exception e) {
			throw new WudstayException(logger, "HotelBookingDaoImpl.getBookingsByTransactionId()", WudstayConstants.FETCH_HOTEL_BOOKINGS_ERROR, null, e);
		}
	}
}
