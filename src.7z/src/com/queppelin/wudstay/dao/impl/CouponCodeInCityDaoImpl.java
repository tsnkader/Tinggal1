package com.queppelin.wudstay.dao.impl;

import com.queppelin.wudstay.dao.ICouponCodeDao;
import com.queppelin.wudstay.dao.ICouponCodeInCityDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.CouponCodeInCityVO;
import com.queppelin.wudstay.vo.CouponCodeVO;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CouponCodeInCityDaoImpl extends BaseDaoImpl<CouponCodeInCityVO> implements ICouponCodeInCityDao {

	private static final Logger logger = LoggerFactory.getLogger(CouponCodeInCityDaoImpl.class);

	public CouponCodeInCityDaoImpl() {
		super(CouponCodeInCityVO.class);
	}


	
	public List<CouponCodeInCityVO> getByCouponId(Long couponId) throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(CouponCodeInCityVO.class, "couponCodeCityAlias");
			//criteria.createAlias("couponCodeAlias.corporate", "corporateAlias");
			criteria.add(Restrictions.eq("couponCodeCityAlias.couponId", couponId));
			return  criteria.list();
		} catch (Exception e) {
			e.printStackTrace();
			throw new WudstayException(logger, "CouponCodeDaoImpl.listByCouponCode()", WudstayConstants.FETCH_CITY_ERROR, null, e);
		}
	}
	
	public CouponCodeInCityVO getByCouponAndcityId(Long couponId, Long cityId) throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(CouponCodeInCityVO.class, "couponCodeCityAlias");
			//criteria.createAlias("couponCodeAlias.corporate", "corporateAlias");
			criteria.add(Restrictions.eq("couponCodeCityAlias.couponId", couponId));
			criteria.add(Restrictions.eq("couponCodeCityAlias.cityId", cityId));
			List<CouponCodeInCityVO> lst =  criteria.list();
			if(lst!=null && lst.size()>0){
				return lst.get(0);
			}
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			throw new WudstayException(logger, "CouponCodeDaoImpl.listByCouponCode()", WudstayConstants.FETCH_CITY_ERROR, null, e);
		}
	}
}
