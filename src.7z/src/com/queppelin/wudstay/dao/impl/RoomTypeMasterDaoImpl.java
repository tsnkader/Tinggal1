package com.queppelin.wudstay.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.queppelin.wudstay.dao.IRoomTypeMasterDao;
import com.queppelin.wudstay.vo.RoomTypeMaster;

@Repository
public class RoomTypeMasterDaoImpl extends BaseDaoImpl<RoomTypeMaster> implements IRoomTypeMasterDao {

	private static final Logger logger = LoggerFactory.getLogger(RoomTypeMasterDaoImpl.class);
	
	public RoomTypeMasterDaoImpl() {
		super(RoomTypeMaster.class);
	}
}
