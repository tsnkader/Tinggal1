package com.queppelin.wudstay.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.queppelin.wudstay.dao.IHotelAmenityDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.HotelAmenity;

@Repository
public class HotelAmenityDaoImpl extends BaseDaoImpl<HotelAmenity> implements IHotelAmenityDao {

	private static final Logger logger = LoggerFactory.getLogger(HotelAmenityDaoImpl.class);
	
	public HotelAmenityDaoImpl() {
		super(HotelAmenity.class);
	}

	
	public List<HotelAmenity> getHotelAmenitiesByHotelId(Long hotelId) throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(HotelAmenity.class, "hotelAmenityAlias");
			criteria.createAlias("hotelAmenityAlias.hotel", "hotelAlias");
			criteria.add(Restrictions.eq("hotelAlias.hotelId", hotelId));
			criteria.addOrder(Order.asc("amenityListingOrder"));
			return (List<HotelAmenity>) criteria.list();
		} catch (Exception e) {
			throw new WudstayException(logger, "HotelAmenityDaoImpl.getHotelAmenitiesByHotelId()", WudstayConstants.FETCH_HOTEL_AMENITIES_ERROR, null, e);
		}
	}

	
	public void deleteHotelAmenitiesByHotelId(Long hotelId)
			throws WudstayException {
		/*try { // update hotel_amenity set hotel_id=null where hotel_id=?
			Query query = getCurrentSession().createQuery("delete HotelAmenity where hotel.hotelId = :hotelId");
			query.setParameter("hotelId", hotelId);
			query.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw new WudstayException(logger, "HotelAmenityDaoImpl.deleteHotelAmenitiesByHotelId()", WudstayConstants.DELETE_HOTEL_AMENITIES_ERROR, null, e);
		}*/

		List<HotelAmenity> lst = getHotelAmenitiesByHotelId(hotelId);
		for(HotelAmenity vo : lst ){
			try {
				super.delete(vo);
			}catch (Exception ex){
				ex.printStackTrace();
			}
		}

	}
}
