package com.queppelin.wudstay.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.queppelin.wudstay.dao.IHotelRoomDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.HotelRoom;

@Repository
public class HotelRoomDaoImpl extends BaseDaoImpl<HotelRoom> implements IHotelRoomDao {

	private static final Logger logger = LoggerFactory.getLogger(HotelRoomDaoImpl.class);

	public HotelRoomDaoImpl() {
		super(HotelRoom.class);
	}

	
	public List<HotelRoom> getHotelRoomsByHotelId(Long hotelId)
			throws WudstayException {
		Criteria criteria = null;
		try {
			criteria = getCurrentSession().createCriteria(HotelRoom.class, "hotelRoomAlias");
			criteria.createAlias("hotelRoomAlias.hotel", "hotelAlias");
			criteria.add(Restrictions.eq("hotelAlias.hotelId", hotelId));
			return (List<HotelRoom>) criteria.list();
		} catch (Exception e) {
			throw new WudstayException(logger, "HotelRoomDaoImpl.getHotelRoomsByHotelId()", WudstayConstants.FETCH_HOTEL_ROOM_ERROR, null, e);
		}
	}


}
