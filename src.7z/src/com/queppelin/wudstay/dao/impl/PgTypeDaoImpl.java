package com.queppelin.wudstay.dao.impl;

import com.queppelin.wudstay.dao.IPgTypeDao;
import com.queppelin.wudstay.vo.PgType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

@Repository
public class PgTypeDaoImpl extends BaseDaoImpl<PgType> implements IPgTypeDao {

	private static final Logger logger = LoggerFactory.getLogger(PgTypeDaoImpl.class);

	public PgTypeDaoImpl() {
		super(PgType.class);
	}
}
