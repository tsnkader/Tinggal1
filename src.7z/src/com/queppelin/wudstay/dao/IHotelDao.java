package com.queppelin.wudstay.dao;

import java.util.List;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.Hotel;


public interface IHotelDao extends IBaseDao<Hotel> {

	public List<Hotel> getHotelByCityId(Long cityId) throws WudstayException;

	List<Hotel> getHotelByCityId(Long cityId, int minPax) throws WudstayException;

	List<Hotel> filterHotels(Long locationId, Long cityId,
							 List<Long> roomTypeIdList, String sortBy, Integer priceSortType, Integer ratingSortType, int minPax) throws WudstayException;

	List<Hotel> getSuggestedHotelList(Hotel hotel) throws WudstayException;

}
