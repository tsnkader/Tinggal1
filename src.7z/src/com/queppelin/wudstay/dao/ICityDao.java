package com.queppelin.wudstay.dao;

import java.util.List;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.City;

public interface ICityDao extends IBaseDao<City> {

	List<City> getAllCities() throws WudstayException;

	City getByCityName(String cityName) throws WudstayException;
	
}
