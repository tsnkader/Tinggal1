package com.queppelin.wudstay.dao;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.CouponCodeUsedVO;
import com.queppelin.wudstay.vo.CouponCodeVO;

import java.util.List;

public interface ICouponCodeUsedDao extends IBaseDao<CouponCodeUsedVO> {
    public List<CouponCodeUsedVO> getByCouponCodeId(Long couponCodeId) throws WudstayException;
    public List<CouponCodeUsedVO> getByCouponCodeIdAndMobile(Long couponCodeId, String mobileNo)  throws WudstayException;
	
}
