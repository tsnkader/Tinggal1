package com.queppelin.wudstay.dao;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.CorporateBookingVO;

import java.util.List;

public interface ICorporateBookingDao extends IBaseDao<CorporateBookingVO> {
	
	List<CorporateBookingVO> getAllBookings(Long corpId, Long corpLoginUserId) throws WudstayException;

	List<CorporateBookingVO> getCorporateBookingsByCorporateId(Long corpId) throws WudstayException;
	
	List<CorporateBookingVO> getCorporateBookingList() throws WudstayException;
	
}
