package com.queppelin.wudstay.dao;

import com.queppelin.wudstay.vo.RoomTypeMaster;

public interface IRoomTypeMasterDao extends IBaseDao<RoomTypeMaster> {

}
