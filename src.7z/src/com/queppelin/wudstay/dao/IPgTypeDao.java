package com.queppelin.wudstay.dao;

import com.queppelin.wudstay.vo.PgType;

public interface IPgTypeDao extends IBaseDao<PgType> {

}
