package com.queppelin.wudstay.dao;


import com.queppelin.wudstay.vo.SurchargeOnPriceVO;

import java.util.List;

public interface ISurchargeOnPriceDao extends IBaseDao<SurchargeOnPriceVO> {
	//public List<SurchargeOnPriceVO> getSurchargePriceListForHotel(Long hotelId);

	
}
