package com.queppelin.wudstay.dao;

import java.util.List;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.HotelRoom;

public interface IHotelRoomDao extends IBaseDao<HotelRoom> {

	List<HotelRoom> getHotelRoomsByHotelId(Long hotelId) throws WudstayException;

}
