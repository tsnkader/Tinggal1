package com.queppelin.wudstay.dao;

import com.queppelin.wudstay.vo.PgAmenity;

public interface IPgAmenityDao extends IBaseDao<PgAmenity> {

}
