package com.queppelin.wudstay.dao;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.RoomsInventoryVO;
import java.util.List;

public interface IRoomsInventoryDao extends IBaseDao<RoomsInventoryVO> {
    public List<RoomsInventoryVO> getListByHotelId(Long hotelId);
    public RoomsInventoryVO getListByDate(Long hotelId, Long date) throws WudstayException;
    public List<RoomsInventoryVO> getListByDate(Long hotelId, Long fromDate, Long toDate) throws WudstayException;
    public Integer getMinRoomAvailable(Long hotelId, Long fromLngDate, Long toLngDate) throws WudstayException;
}
