package com.queppelin.wudstay.dao;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.HotelAmenity;
import com.queppelin.wudstay.vo.PgHotelAmenity;

import java.util.List;

public interface IPgHotelAmenityDao extends IBaseDao<PgHotelAmenity> {

	List<PgHotelAmenity> getPgHotelAmenitiesByHotelId(Long hotelId) throws WudstayException;

	void deletePgHotelAmenitiesByHotelId(Long hotelId) throws WudstayException;

}
