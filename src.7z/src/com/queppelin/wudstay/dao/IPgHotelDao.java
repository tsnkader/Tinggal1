package com.queppelin.wudstay.dao;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.City;
import com.queppelin.wudstay.vo.Hotel;
import com.queppelin.wudstay.vo.PgHotel;

import java.util.List;

public interface IPgHotelDao extends IBaseDao<PgHotel> {
    public List<PgHotel> getHotelByCityId(Long cityId) throws WudstayException;
    public List<PgHotel> getHotelBylocationIds(List<Long> locationIdsList) throws WudstayException;

    List<PgHotel> getHotelByCityId(Long cityId, int minPax) throws WudstayException;
    /*public List<PgHotel> filterHotels(Long locationId, Long cityId, List<Long> roomTypeIdList,
                                      String sortBy, Integer priceSortType, Integer ratingSortType, int minPax) throws WudstayException;*/
    public List<PgHotel> filterHotels(List<Long> locationIdList, Long cityId, List<Long> pgTypeIdList,
                                      String sortBy, Integer priceSortType, Integer ratingSortType, int minPax) throws WudstayException;
    public List<PgHotel> getSuggestedHotelList(PgHotel hotel) throws WudstayException;
}
