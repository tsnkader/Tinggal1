
package com.queppelin.wudstay.dao;

import org.hibernate.Query;

import java.io.Serializable;
import java.util.List;

public interface IBaseDao<T> {

	public void save(T obj);

	public void saveOrUpdate(T obj);

	public T getById(Serializable id);

	public void delete(T obj);

	List<T> list(String propertyName, String orderType);

	List<T> list();


	public Query getNamedQuery(String namedQuery);
	public Query getNamedQuery(String namedQuery, String[] paramNames, Object[] paramValues);

}
