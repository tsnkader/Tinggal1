package com.queppelin.wudstay.dao;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.Corporate;

import java.util.List;

public interface ICorporateDao extends IBaseDao<Corporate> {
	
	List<Corporate> getAllCorporates() throws WudstayException;
	
	//Corporate login_old(Corporate corporate) throws WudstayException;

	Boolean isUsernameExists(String corpUserName) throws WudstayException;

	String encryptPassword(String password) throws WudstayException;
	
	Corporate getCorporateById(Long corpId) throws WudstayException;

	public Boolean isCorpNameExists(String corpName) throws WudstayException;

	public Boolean isCorpNameExists(Long id, String corpName) throws WudstayException;



}
