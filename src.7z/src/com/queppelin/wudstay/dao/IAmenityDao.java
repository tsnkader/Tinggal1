package com.queppelin.wudstay.dao;

import com.queppelin.wudstay.vo.Amenity;

public interface IAmenityDao extends IBaseDao<Amenity> {
    public Amenity getFreeBreakfastAmenity();
}
