package com.queppelin.wudstay.dao;


import com.queppelin.wudstay.vo.HdfcTranLogVO;



public interface IHdfcTranLogDao extends IBaseDao<HdfcTranLogVO> {
    public HdfcTranLogVO getSecureHash(String secureHash);
}
