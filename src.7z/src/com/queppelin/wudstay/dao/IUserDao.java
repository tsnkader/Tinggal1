package com.queppelin.wudstay.dao;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.User;

public interface IUserDao extends IBaseDao<User> {

	User login(User user, String userType) throws WudstayException;

	Boolean isUsernameExists(String username) throws WudstayException;

	String encryptPassword(String password) throws WudstayException;

}
