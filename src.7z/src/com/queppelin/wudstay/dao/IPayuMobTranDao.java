package com.queppelin.wudstay.dao;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.PayuMobTran;
import com.queppelin.wudstay.vo.custom.PayUVO;

import java.util.List;

public interface IPayuMobTranDao extends IBaseDao<PayuMobTran> {

}
