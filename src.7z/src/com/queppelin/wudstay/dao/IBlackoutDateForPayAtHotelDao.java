package com.queppelin.wudstay.dao;

import com.queppelin.wudstay.vo.BlackoutDateForPayAtHotel;
import java.util.Date;
import java.util.List;

public interface IBlackoutDateForPayAtHotelDao extends IBaseDao<BlackoutDateForPayAtHotel> {
	public List<BlackoutDateForPayAtHotel> getListOfBlackoutDate(Date checkIn, Date checkOut);
	public List<BlackoutDateForPayAtHotel> getListOfBlackoutDate(Date checkIn, Date checkOut, long cityId);
	public boolean isBlackoutOn(Date checkIn, Date checkOut, long cityId);
	public boolean isBlackoutOn(Date checkIn, Date checkOut);
}
