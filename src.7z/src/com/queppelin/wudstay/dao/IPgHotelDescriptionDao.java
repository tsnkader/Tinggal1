package com.queppelin.wudstay.dao;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.HotelDescription;
import com.queppelin.wudstay.vo.PgHotelDescription;

import java.util.List;

public interface IPgHotelDescriptionDao extends IBaseDao<PgHotelDescription> {

	List<PgHotelDescription> getHotelDescriptionsByHotelId(Long hotelId) throws WudstayException;

	void deleteHotelDescriptionsByHotelId(Long hotelId) throws WudstayException;

}
