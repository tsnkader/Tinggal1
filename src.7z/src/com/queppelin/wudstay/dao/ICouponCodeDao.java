package com.queppelin.wudstay.dao;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.CouponCodeVO;

import java.util.List;

public interface ICouponCodeDao extends IBaseDao<CouponCodeVO> {
    public CouponCodeVO getByCouponCode(String couponCode) throws WudstayException;
}
