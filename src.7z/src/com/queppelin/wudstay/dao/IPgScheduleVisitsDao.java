package com.queppelin.wudstay.dao;

import com.queppelin.wudstay.vo.PgScheduleVisits;

public interface IPgScheduleVisitsDao extends IBaseDao<PgScheduleVisits> {

}
