package com.queppelin.wudstay.dao;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.CouponCodeInCityVO;
import com.queppelin.wudstay.vo.CouponCodeVO;

import java.util.List;

public interface ICouponCodeInCityDao extends IBaseDao<CouponCodeInCityVO> {
    public List<CouponCodeInCityVO> getByCouponId(Long couponId) throws WudstayException;

    public CouponCodeInCityVO getByCouponAndcityId(Long couponId, Long cityId) throws WudstayException;
}
