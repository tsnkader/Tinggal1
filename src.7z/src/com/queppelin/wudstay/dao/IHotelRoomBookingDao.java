package com.queppelin.wudstay.dao;

import com.queppelin.wudstay.vo.HotelRoomBooking;

public interface IHotelRoomBookingDao extends IBaseDao<HotelRoomBooking> {

}
