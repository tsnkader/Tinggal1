package com.queppelin.wudstay.dao;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.AppVersion;
import com.queppelin.wudstay.vo.City;

import java.util.List;

public interface IAppVersionDao extends IBaseDao<AppVersion> {

	List<AppVersion> getAppVersionList(String appType) throws WudstayException;
	
}
