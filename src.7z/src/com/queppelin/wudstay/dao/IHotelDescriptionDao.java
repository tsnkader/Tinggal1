package com.queppelin.wudstay.dao;

import java.util.List;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.HotelDescription;

public interface IHotelDescriptionDao extends IBaseDao<HotelDescription> {

	List<HotelDescription> getHotelDescriptionsByHotelId(Long hotelId) throws WudstayException;

	void deleteHotelDescriptionsByHotelId(Long hotelId) throws WudstayException;

}
