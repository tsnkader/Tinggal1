package com.queppelin.wudstay.dao;

import com.queppelin.wudstay.vo.BlackoutDateForCheckOut;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

public interface IBlackoutDateForCheckOutDao extends IBaseDao<BlackoutDateForCheckOut> {
	public List<BlackoutDateForCheckOut> getListOfBlackoutDate(Date checkOut) throws ParseException;
	public List<BlackoutDateForCheckOut> getListOfBlackoutDate(Date checkOut, long cityId) throws ParseException;
	public boolean isBlackoutOn(Date checkOut, long cityId) throws ParseException;
	public boolean isBlackoutOn(Date checkOut) throws ParseException;
}
