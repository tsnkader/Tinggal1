package com.queppelin.wudstay.dao;

import java.util.List;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.HotelAmenity;

public interface IHotelAmenityDao extends IBaseDao<HotelAmenity> {

	List<HotelAmenity> getHotelAmenitiesByHotelId(Long hotelId) throws WudstayException;

	void deleteHotelAmenitiesByHotelId(Long hotelId) throws WudstayException;

}
