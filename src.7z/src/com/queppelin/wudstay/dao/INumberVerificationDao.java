package com.queppelin.wudstay.dao;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.NumberVerification;

public interface INumberVerificationDao extends IBaseDao<NumberVerification> {

	Boolean verifyMobileNumber(String verificationCode, String mobileNumber) throws WudstayException;

	Boolean isRegisteredMobileNumber(String mobileNumber) throws WudstayException;
	
	NumberVerification getCustomerInfoByMobileNumber(String mobileNumber) throws WudstayException;
}
