package com.queppelin.wudstay.dao;


import com.queppelin.wudstay.vo.LogsTable;

public interface ILogsTableDao extends IBaseDao<LogsTable> {
	
}
