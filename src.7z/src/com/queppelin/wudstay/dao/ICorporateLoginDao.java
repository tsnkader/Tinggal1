package com.queppelin.wudstay.dao;


import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.Corporate;
import com.queppelin.wudstay.vo.CorporateLoginVO;
import com.queppelin.wudstay.vo.User;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;


public interface ICorporateLoginDao extends IBaseDao<CorporateLoginVO> {
    public CorporateLoginVO login(CorporateLoginVO corporate) throws WudstayException ;
    public Boolean isCorpLoginIdExists(Long id, String corpLoginId) throws WudstayException ;
    public Boolean isCorpLoginIdExists(String corpLoginId) throws WudstayException ;
}
