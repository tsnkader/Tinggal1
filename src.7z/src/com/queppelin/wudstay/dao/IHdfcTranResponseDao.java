package com.queppelin.wudstay.dao;


import com.queppelin.wudstay.vo.HdfcTranResponseVO;


public interface IHdfcTranResponseDao extends IBaseDao<HdfcTranResponseVO> {

}
