package com.queppelin.wudstay.web.controller;

import com.queppelin.wudstay.manager.IBaseManager;
import com.queppelin.wudstay.vo.Amenity;

public interface IAmenityManager extends IBaseManager<Amenity> {

}
