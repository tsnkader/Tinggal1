package com.queppelin.wudstay.web.controller;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.*;
import com.queppelin.wudstay.util.*;
import com.queppelin.wudstay.vo.*;
import com.queppelin.wudstay.vo.CorporateBookingVO;
import com.queppelin.wudstay.vo.custom.*;
//import com.sun.org.apache.xpath.internal.operations.Bool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.queppelin.wudstay.exception.CustomGenericException;

@Controller
@RequestMapping("/admin")
public class SuperAdminController {
    private static final Logger logger = LoggerFactory.getLogger(SuperAdminController.class);
    private static boolean firstOccurrence = Boolean.FALSE;

    @Autowired
    IUserManager userManager;

    @Autowired
    IHotelRoomBookingManager hotelRoomBookingManager;

    @Autowired
    IHotelBookingManager hotelBookingManager;

    @Autowired
    ICityManager cityManager;

    @Autowired
    IAmenityManager amenityManager;

    @Autowired
    IPgAmenityManager pgAmenityManager;

    @Autowired
    IRoomTypeManager roomTypeManager;
    
    @Autowired
    IRoomTypeMasterManager roomTypeMasterManager;

    @Autowired
    IPgTypeManager pgTypeManager;

    @Autowired
    ILocationManager locationManager;

    @Autowired
    IHotelManager hotelManager;

    @Autowired
    IPgHotelManager pgHotelManager;

    @Autowired
    IHotelRoomManager hotelRoomManager;

    @Autowired
    IHotelDescriptionManager hotelDescriptionManager;

    @Autowired
    IHotelAdministratorManager hotelAdministratorManager;

    @Autowired
    IHotelAmenityManager hotelAmenityManager;

    @Autowired
    ICorporateManager corporateManager;

    @Autowired
    ICorporateBookingManager corporateBookingManager;

    @Autowired
    ICorporateEmployeeManager corporateEmployeeManager;

    @Autowired
    ICouponCodeManager couponCodeManager;
    @Autowired
    IRoomsInventoryManager roomsInventoryManager;

    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.LOGIN)
    public ModelAndView getLoginPage(HttpServletRequest request, HttpSession session, RedirectAttributes redirectAttributes) {
        ModelAndView modelAndView = new ModelAndView(WudstayConstants.LOGIN_PAGE);
        Boolean isLoginSuccess = (Boolean) session.getAttribute("isLoginSuccess");
        if (isLoginSuccess != null && !isLoginSuccess) {
            modelAndView.addObject("isLoginSuccess", isLoginSuccess);
        }
        session.removeAttribute("isLoginSuccess");
        return modelAndView;
    }

    @RequestMapping(method = RequestMethod.POST, value = WudstayMappings.VERIFY_CREDENTIALS)
    public ModelAndView login(@ModelAttribute User user, HttpServletRequest request, HttpServletResponse response, HttpSession session, RedirectAttributes redirectAttributes) {
        try {
            user = userManager.login(user, WudstayConstants.SUPER_ADMIN);
            if (user != null) {
                session.setAttribute(WudstayConstants.USER, user);
                return new ModelAndView("redirect:" + WudstayMappings.GET_BOOKINGS);
            } else {
                session.setAttribute("isLoginSuccess", Boolean.FALSE);
                return new ModelAndView("redirect:" + WudstayMappings.LOGIN);
            }
        } catch (Exception e) {
            return null;
        }
    }

    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.GET_BOOKINGS)
    public ModelAndView getLandingPage(HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView(WudstayConstants.SHOW_HOTEL_BOOKINGS_PAGE);
        List<HotelBooking> hotelBookingList = hotelBookingManager.list();
        try {
            modelAndView.addObject("hotelBookingList", hotelBookingList);
        } catch (Exception e) {
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.ADD_HOTEL)
    public ModelAndView addHotel(HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView(WudstayConstants.ADD_HOTEL_PAGE);
        try {

            Boolean isSuccess = (Boolean) session.getAttribute("isSuccess");
            if (isSuccess != null) {
                modelAndView.addObject("isSuccess", isSuccess);
                session.removeAttribute("isSuccess");
            }

            List<City> cityList = cityManager.list();
            List<Amenity> amenitiyList = amenityManager.list();
            List<RoomType> roomTypeList = roomTypeManager.list();
            List<RoomTypeMaster> roomTypeMasterList = roomTypeMasterManager.list();
            modelAndView.addObject("cityList", cityList);
            modelAndView.addObject("amenityList", amenitiyList);
            modelAndView.addObject("roomTypeList", roomTypeList);
            modelAndView.addObject("roomTypeMasterList", roomTypeMasterList);
        } catch (Exception e) {
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    @RequestMapping(method = RequestMethod.POST, value = WudstayMappings.SAVE_HOTEL)
    public ModelAndView saveHotel(@ModelAttribute HotelVO hotelVO, HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("redirect:" + WudstayMappings.ADD_HOTEL);
        try {
            User user = (User) session.getAttribute(WudstayConstants.USER);
            if(request.getParameter("allowTripleOccupancy")==null){
                hotelVO.setAllowTripleOccupancy(0);
                hotelVO.setTripleOccupancyPrice(0);
            }
            
            Long hotelId = hotelManager.addHotel(hotelVO, user,request,session);
            try {
                Hotel hotel = hotelManager.getById(hotelId);
                roomsInventoryManager.updateInventory(hotel.getHotelId(), hotel.getNoOfRooms(), hotel.getValidFromDate(), hotel.getValidToDate());
            }catch (Exception ex ){
                ex.printStackTrace();
            }
            /*List<HotelRoomVO> hotelRoomVOList = hotelVO.getHotelRoomVOList();
            for (HotelRoomVO hotelRoomVO : hotelRoomVOList) {
				if(hotelRoomVO.getRoomPrice() != null) {
					MultipartFile file = hotelRoomVO.getRoomImage();
					if (!file.isEmpty()) {
						byte[] bytes = file.getBytes();

						String directoryPath = 
								context.getRealPath("hotel_images" + File.separator + hotelId + File.separator + "rooms");
								File directory = new File(directoryPath);

						if(!directory.exists()) {
							directory.mkdirs();
						}

						// Create the file on server
						File serverFile = new File(directory.getAbsolutePath()
								+ File.separator + "room.png");
						BufferedOutputStream stream = new BufferedOutputStream(
								new FileOutputStream(serverFile));
						stream.write(bytes);
						stream.close();
					}
				}
			}*/
            session.setAttribute("isSuccess", Boolean.TRUE);
        } catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("isSuccess", Boolean.FALSE);
        }
        return modelAndView;
    }

    @RequestMapping(method = RequestMethod.POST, value = WudstayMappings.UPDATE_HOTEL)
    public ModelAndView updateHotel(@ModelAttribute HotelVO hotelVO, HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("redirect:" + WudstayMappings.VIEW_HOTEL_DETAILS + "?hotelId=" + hotelVO.getHotelId());
        try {
            User user = (User) session.getAttribute(WudstayConstants.USER);
            if(request.getParameter("allowTripleOccupancy")==null){
                hotelVO.setAllowTripleOccupancy(0);
                hotelVO.setTripleOccupancyPrice(0);
            }
            Hotel hotel = hotelManager.updateHotel(hotelVO, user, request,session);
            //roomsInventoryManager.updateInventory(hotel.getHotelId(), hotel.getNoOfRooms(), hotel.getValidFromDate(), hotel.getValidToDate());
            session.setAttribute("isSuccess", Boolean.TRUE);
        } catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("isSuccess", Boolean.FALSE);
        }
        return modelAndView;
    }

    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.GET_All_LOCATIONS_BY_CITY_ID)
    public
    @ResponseBody
    List<Location> getAllLocationsByCityId(@RequestParam Long cityId, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        List<Location> locationList = new ArrayList<Location>();
        try {
            locationList = locationManager.getLocationsByCityId(cityId);
        } catch (Exception e) {
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return locationList;
    }

    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.VIEW_HOTELS)
    public ModelAndView viewHotels(@ModelAttribute HotelVO hotelVO, HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView(WudstayConstants.SHOW_HOTELS_PAGE);
        //--------------------------------------------------------------------------------------------------------------
       /* if(firstOccurrence == false) {
            try {
                List<Hotel> hotelList = hotelManager.list();
                for (Hotel hotel : hotelList) {
                    try {
                        List<RoomsInventoryVO> lst = roomsInventoryManager.getListByHotelId(hotel.getHotelId());
                        if (lst == null || lst.size() == 0)
                            roomsInventoryManager.updateInventory(hotel.getHotelId(), hotel.getNoOfRooms(), hotel.getValidFromDate(), hotel.getValidToDate());
                    }catch (Exception ex){
                        ex.printStackTrace();
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            firstOccurrence = Boolean.TRUE;
        }*/
        //--------------------------------------------------------------------------------------------------------------

        try {
            List<Hotel> hotelList = hotelManager.list();
            modelAndView.addObject("hotelList", hotelList);
        } catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.LOGOUT)
    public ModelAndView logout(HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("redirect:" + WudstayMappings.LOGIN);
        try {
            session.removeAttribute(WudstayConstants.USER);
        } catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.VIEW_HOTEL_DETAILS)
    public ModelAndView viewHotelDetails(@RequestParam Long hotelId, HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView(WudstayConstants.SHOW_HOTEL_DETAILS_PAGE);
        try {
            Boolean isSuccess = (Boolean) session.getAttribute("isSuccess");
            if (isSuccess != null) {
                modelAndView.addObject("isSuccess", isSuccess);
                session.removeAttribute("isSuccess");
            }

            Hotel hotel = hotelManager.getById(hotelId);
            //List<RoomTypeVO> roomTypeVOList = hotelRoomManager.getRoomTypeVOList(hotelId);
            //List<HotelRoom> hotelRoomList = hotelRoomManager.getHotelRoomsByHotelId(hotelId);
            List<HotelDescription> hotelDescriptionList = hotelDescriptionManager.getHotelDescriptionsByHotelId(hotelId);
            HotelAdministrator hotelAdministrator = hotelAdministratorManager.getHotelAdminByHotelId(hotelId);
            List<HotelAmenity> hotelAmenityList = hotelAmenityManager.getHotelAmenitiesByHotelId(hotelId);
            List<HotelRoom> hotelRoomList = hotelRoomManager.getHotelRoomsByHotelId(hotelId);
            List<String> hotelImageList = WudstayUtil.getHotelImages(hotel.getHotelId(),request);
            modelAndView.addObject("hotel", hotel);
            //modelAndView.addObject("hotelRoomList", hotelRoomList);
            //modelAndView.addObject("roomTypeVOList", roomTypeVOList);
            modelAndView.addObject("hotelDescriptionList", hotelDescriptionList);
            modelAndView.addObject("hotelAdministrator", hotelAdministrator);
            modelAndView.addObject("hotelAmenityList", hotelAmenityList);
            modelAndView.addObject("hotelRoomList", hotelRoomList);
            modelAndView.addObject("hotelImageList", hotelImageList);

            modelAndView.addObject("validFromDate", DateUtil.toDisplayDate(hotel.getValidFromDate()));
            modelAndView.addObject("validToDate", DateUtil.toDisplayDate(hotel.getValidToDate()));
        } catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.EDIT_HOTEL_DETAILS)
    public ModelAndView editHotelDetails(@RequestParam Long hotelId, HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView(WudstayConstants.EDIT_HOTEL_DETAILS_PAGE);
        try {
            Hotel hotel = hotelManager.getById(hotelId);
            List<Location> locationList = locationManager.getLocationsByCityId(hotel.getLocation().getCity().getCityId());
            //List<HotelRoom> hotelRoomList = hotelRoomManager.getHotelRoomsByHotelId(hotelId);
            List<City> cityList = cityManager.list();
            List<Amenity> amenitiyList = amenityManager.list();
            List<RoomType> roomTypeList = roomTypeManager.list();
            List<HotelRoom> hotelRoomList = hotelRoomManager.getHotelRoomsByHotelId(hotelId);
            List<String> hotelImageList = WudstayUtil.getHotelImages(hotel.getHotelId(),request);
            List<RoomTypeMaster> roomTypeMasterList = roomTypeMasterManager.list();
            //List<RoomTypeVO> roomTypeVOList = hotelRoomManager.getRoomTypeVOList(hotelId);

            List<HotelDescription> hotelDescriptionVOList = hotelDescriptionManager.getHotelDescriptionsByHotelId(hotelId);
            HotelAdministrator hotelAdministrator = hotelAdministratorManager.getHotelAdminByHotelId(hotelId);

            List<HotelAmenity> hotelAmenityList = hotelAmenityManager.getHotelAmenitiesByHotelId(hotelId);

            WudstayUtil.processAmenityList(amenitiyList, hotelAmenityList);
			/*List<RoomTypeVO> processedRoomTypeVOList = WudstayUtil.processRoomTypeVOList(roomTypeList, roomTypeVOList);*/
            modelAndView.addObject("hotel", hotel);
            //modelAndView.addObject("roomTypeVOList", processedRoomTypeVOList);
            modelAndView.addObject("roomTypeList", roomTypeList);
            modelAndView.addObject("hotelDescriptionVOList", hotelDescriptionVOList);
            modelAndView.addObject("hotelAdministrator", hotelAdministrator);
            modelAndView.addObject("hotelAmenityList", hotelAmenityList);
            modelAndView.addObject("cityList", cityList);
            modelAndView.addObject("locationList", locationList);
            modelAndView.addObject("amenityList", amenitiyList);
            modelAndView.addObject("hotelRoomList", hotelRoomList);
            modelAndView.addObject("hotelImageList", hotelImageList);

            modelAndView.addObject("roomTypeMasterList", roomTypeMasterList);
            modelAndView.addObject("validFromDate", DateUtil.toDisplayDate(hotel.getValidFromDate()));
            modelAndView.addObject("validToDate", DateUtil.toDisplayDate(hotel.getValidToDate()));

            DateUtil dateUtil = new DateUtil(new Date());
            RoomsInventoryForm inventory = roomsInventoryManager.getRoomAvailabilityCalendar( hotel, dateUtil.getMonth(), dateUtil.getYear() );
            modelAndView.addObject("inventory", inventory);
            modelAndView.addObject("NoOfRoomsOpen", hotel.getNoOfRooms());
            //modelAndView.addObject("validFromDate", hotel.getValidFromDate());
            //modelAndView.addObject("validToDate", inventory);
        } catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.IS_USERNAME_EXISTS)
    public
    @ResponseBody
    Boolean isUsernameExists(@RequestParam String username, HttpServletRequest request, HttpSession session) {
        try {
            return userManager.isUsernameExists(username);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Boolean.FALSE;
    }

    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.ADD_CITY)
    public ModelAndView addCity(HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView(WudstayConstants.ADD_CITY_PAGE);
        try {

        } catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.EDIT_CITY)
    public ModelAndView editCity(@RequestParam Long cityId, HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView(WudstayConstants.ADD_CITY_PAGE);
        try {
            City city = cityManager.getById(cityId);
            modelAndView.addObject("city", city);
        } catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.GET_ALL_CITIES)
    public ModelAndView getAllCities(HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView(WudstayConstants.SHOW_CITIES_PAGE);
        try {

            Boolean isSuccess = (Boolean) session.getAttribute("isSuccess");
            if (isSuccess != null) {
                modelAndView.addObject("isSuccess", isSuccess);
                session.removeAttribute("isSuccess");
            }

            Boolean isUpdateSuccess = (Boolean) session.getAttribute("isUpdateSuccess");
            if (isUpdateSuccess != null) {
                modelAndView.addObject("isUpdateSuccess", isUpdateSuccess);
                session.removeAttribute("isUpdateSuccess");
            }

            List<City> cityList = cityManager.list();
            modelAndView.addObject("cityList", cityList);
        } catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    @RequestMapping(method = RequestMethod.POST, value = WudstayMappings.SAVE_UPDATE_CITY)
    public ModelAndView addUpdateCity(@ModelAttribute City city, HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("redirect:" + WudstayMappings.GET_All_CITIES);
        Long cityId = city.getCityId();
        try {
            User user = (User) session.getAttribute(WudstayConstants.USER);
            if (city.getIsActive() == null) {
                city.setIsActive(Boolean.FALSE);
            }
            city.setLastUpdatedBy(user.getUsername());
            city.setLastUpdatedDate(new Date());
            cityManager.saveOrUpdate(city);
            if (cityId != null) {
                session.setAttribute("isUpdateSuccess", Boolean.TRUE);
            } else {
                session.setAttribute("isSuccess", Boolean.TRUE);
            }
        } catch (Exception e) {
            e.printStackTrace();
            if (cityId != null) {
                session.setAttribute("isUpdateSuccess", Boolean.FALSE);
            } else {
                session.setAttribute("isSuccess", Boolean.FALSE);
            }
        }
        return modelAndView;
    }

    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.ADD_LOCATION)
    public ModelAndView addLocation(HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView(WudstayConstants.ADD_LOCATION_PAGE);
        try {
            List<City> cityList = cityManager.list();
            modelAndView.addObject("cityList", cityList);
        } catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.EDIT_LOCATION)
    public ModelAndView editLocation(@RequestParam Long locationId, HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView(WudstayConstants.ADD_LOCATION_PAGE);
        try {
            Location location = locationManager.getById(locationId);
            List<City> cityList = cityManager.list();
            modelAndView.addObject("cityList", cityList);
            modelAndView.addObject("location", location);
        } catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.GET_ALL_LOCATIONS)
    public ModelAndView getAllLocations(HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView(WudstayConstants.SHOW_LOCATIONS_PAGE);
        try {

            Boolean isSuccess = (Boolean) session.getAttribute("isSuccess");
            if (isSuccess != null) {
                modelAndView.addObject("isSuccess", isSuccess);
                session.removeAttribute("isSuccess");
            }

            Boolean isUpdateSuccess = (Boolean) session.getAttribute("isUpdateSuccess");
            if (isUpdateSuccess != null) {
                modelAndView.addObject("isUpdateSuccess", isUpdateSuccess);
                session.removeAttribute("isUpdateSuccess");
            }

            List<Location> locationList = locationManager.list();
            modelAndView.addObject("locationList", locationList);
        } catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    @RequestMapping(method = RequestMethod.POST, value = WudstayMappings.SAVE_UPDATE_LOCATION)
    public ModelAndView addUpdateLocation(@ModelAttribute Location location, HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("redirect:" + WudstayMappings.GET_ALL_LOCATIONS);
        Long locationId = location.getLocationId();
        try {
            Long cityId = location.getCityId();
            location.setCity(cityManager.getById(cityId));
            User user = (User) session.getAttribute(WudstayConstants.USER);
            if (location.getIsActive() == null) {
                location.setIsActive(Boolean.FALSE);
            }
            location.setLastUpdatedBy(user.getUsername());
            location.setLastUpdatedDate(new Date());
            locationManager.saveOrUpdate(location);
            if (locationId != null) {
                session.setAttribute("isUpdateSuccess", Boolean.TRUE);
            } else {
                session.setAttribute("isSuccess", Boolean.TRUE);
            }
        } catch (Exception e) {
            e.printStackTrace();
            if (locationId != null) {
                session.setAttribute("isUpdateSuccess", Boolean.FALSE);
            } else {
                session.setAttribute("isSuccess", Boolean.FALSE);
            }
        }
        return modelAndView;
    }

    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.DELETE_HOTEL_IMAGE)
    public
    @ResponseBody
    Boolean deleteHotelImage(@RequestParam Long hotelId, @RequestParam String imageName, HttpServletRequest request, HttpSession session) {
        try {
           /// String directoryPath = WudstayUtil.getOtherImagesDirPath(hotelId);
    		String directoryPath =  request.getRealPath("/")+"hotel_images/"+hotelId+"/others/";
            File imageFile = new File(directoryPath + File.separator + imageName);
            return imageFile.delete();
        } catch (Exception e) {
            //ignore
        }
        return Boolean.FALSE;
    }

    //------------------------------------------------------------------------------------------------------------------
    //--------------------------------------------- Corporate Panel-----------------------------------------------------
    //------------------------------------------------------------------------------------------------------------------




    //------------------------------------------------------------------------------------------------------------------
    //------------------------------------------- Add/Edit/View Corporates ---------------------------------------------
    //------------------------------------------------------------------------------------------------------------------

    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.VIEW_CORP)// viewCorporates.jsp
    public ModelAndView viewCorporate(HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView(WudstayConstants.SHOW_CORP_PAGE);
        try {
            List<Corporate> lst = corporateManager.list();
            modelAndView.addObject("corporateList", lst);

            modelAndView.addObject("EDIT_MODE", Boolean.FALSE);
        } catch (Exception e) {
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }
    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.ADD_CORP)
    public ModelAndView addCorporate(HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView(WudstayConstants.SHOW_ADD_CORP_PAGE);
        try {
            CorporateForm form = new CorporateForm();
            form.addCorporateLoginDto(new CorporateLoginDto());
            modelAndView.addObject("corp", form);

            modelAndView.addObject("EDIT_MODE", Boolean.FALSE);
        } catch (Exception e) {
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }
    @RequestMapping(method = RequestMethod.POST, value = WudstayMappings.EDIT_CORP)
    public ModelAndView editCorporate(@RequestParam String corpId, HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView(WudstayConstants.SHOW_ADD_CORP_PAGE);
        CorporateForm form = new CorporateForm();
        try {
            Corporate corporate = corporateManager.getById(Long.parseLong(corpId.trim()));
            form.setCorpId(corporate.getCorpId());
            form.setCorpName(corporate.getCorpName());
            form.setCorpAddress(corporate.getCorpAddress());
            form.setContactName(corporate.getCorpContactPersonName());
            form.setContactEmail(corporate.getCorpContactPersonEmail());
            form.setContactNo(corporate.getCorpContactNo());
            form.setTan(corporate.getCorpTAN());
            form.setTin(corporate.getCorpTIN());
            form.setCin(corporate.getCorpCIN());

            form.setIsFixedPriceSingleRoom("" + corporate.getSingleRoomPriceIsFixed());
            form.setIsFixedPriceDoubleRoom("" + corporate.getDoubleRoomPriceIsFixed());
            form.setIsFixedPriceTripleRoom("" + corporate.getTripleRoomPriceIsFixed());

            form.setSingleRoomFixedPrice("" + corporate.getSingleRoomFixedPrice());
            form.setDoubleRoomFixedPrice("" + corporate.getDoubleRoomFixedPrice());
            form.setTripleRoomFixedPrice("" + corporate.getTripleRoomFixedPrice());

            form.setSingleRoomPriceInRangeFrom("" + corporate.getSingleRoomPriceFrom());
            form.setDoubleRoomPriceInRangeFrom("" + corporate.getDoubleRoomPriceFrom());
            form.setTripleRoomPriceInRangeFrom("" + corporate.getTripleRoomPriceFrom());


            form.setSingleRoomPriceInRangeTo("" + corporate.getSingleRoomPriceTo());
            form.setDoubleRoomPriceInRangeTo("" + corporate.getDoubleRoomPriceTo());
            form.setTripleRoomPriceInRangeTo("" + corporate.getTripleRoomPriceTo());

            Set<CorporateLoginVO> corporateLoginUsers = corporate.getCorporateLoginUsers();
            for (CorporateLoginVO loginVO : corporateLoginUsers) {
                CorporateLoginDto loginDto = new CorporateLoginDto();
                loginDto.setCorpLoginId(loginVO.getId());
                loginDto.setContactName(loginVO.getCorpContactPersonName());
                loginDto.setContactEmail(loginVO.getCorpContactPersonEmail());
                loginDto.setContactNumber(loginVO.getCorpContactNo());
                loginDto.setLoginID(loginVO.getCorpLoginID());
                loginDto.setLoginPassword(loginVO.getCorpLoginPassword());
                form.addCorporateLoginDto(loginDto);
            }
            modelAndView.addObject("corp", form);
            modelAndView.addObject("EDIT_MODE", Boolean.TRUE);
        } catch (Exception e) {
            form = new CorporateForm();
            form.addCorporateLoginDto(new CorporateLoginDto());
            modelAndView.addObject("corp", form);
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    @RequestMapping(method = RequestMethod.POST, value = WudstayMappings.SUBMIT_ADD_CORP)
    public ModelAndView addCorporateSubmit(HttpServletRequest request, HttpSession session) throws WudstayException {
        ModelAndView modelAndView = new ModelAndView(WudstayConstants.SHOW_ADD_CORP_PAGE);//SHOW_CORP_PAGE
        String errorMsg="";
        CorporateForm form = new CorporateForm();
        HttpRequestToBeanUtil.populateBean(form, request);
        int i=0;
        CorporateLoginDto dto = new CorporateLoginDto();
        while(HttpRequestToBeanUtil.populateCorporateUserBean(i++, dto, request)) {
            form.addCorporateLoginDto(dto);
            if(corporateManager.isCorpLoginIdExists(dto.getCorpLoginId(), dto.getLoginID()).booleanValue() == true) {
            	if ("".equals(errorMsg)) {
            		errorMsg =  "Corporate's user Login ID ( " + dto.getLoginID() + " ) already exist.";
            	}else{
            		errorMsg = errorMsg + "<br/>" + "Corporate's user Login ID ( " + dto.getLoginID() + " ) already exist.";
            	}
            }
            dto = new CorporateLoginDto();
        }
        String corpName = form.getCorpName();
        try {
            //return corporateManager.isCorpLoginIdExists(corpLoginId);
            if ("".equals(errorMsg) ){
                if (corpName != null && corporateManager.isCorpNameExists(form.getCorpId() , corpName.trim()).booleanValue() == false) {
                    Corporate corporate = new Corporate();
                    if(form.getCorpId()!=null && form.getCorpId().longValue()>0){
                        corporate = corporateManager.getCorporateById(form.getCorpId());
                    }
                    corporate.setCorpName(corpName.trim());
                    corporate.setCorpAddress(form.getCorpAddress());
                    corporate.setCorpContactPersonName(form.getContactName());
                    corporate.setCorpContactPersonEmail(form.getContactEmail());
                    corporate.setCorpContactNo(form.getContactNo());
                    corporate.setCorpTAN(form.getTan());
                    corporate.setCorpTIN(form.getTin());
                    corporate.setCorpCIN(form.getCin());

                    corporate.setSingleRoomPriceIsFixed(form.intIsFixedPriceSingleRoom());
                    corporate.setDoubleRoomPriceIsFixed(form.intIsFixedPriceDoubleRoom());
                    corporate.setTripleRoomPriceIsFixed(form.intIsFixedPriceTripleRoom());

                    corporate.setSingleRoomFixedPrice(form.intSingleRoomFixedPrice());
                    corporate.setDoubleRoomFixedPrice(form.intDoubleRoomFixedPrice());
                    corporate.setTripleRoomFixedPrice(form.intTripleRoomFixedPrice());

                    corporate.setSingleRoomPriceFrom(form.intSingleRoomPriceInRangeFrom());
                    corporate.setDoubleRoomPriceFrom(form.intDoubleRoomPriceInRangeFrom());
                    corporate.setTripleRoomPriceFrom(form.intTripleRoomPriceInRangeFrom());


                    corporate.setSingleRoomPriceTo(form.intSingleRoomPriceInRangeTo());
                    corporate.setDoubleRoomPriceTo(form.intDoubleRoomPriceInRangeTo());
                    corporate.setTripleRoomPriceTo(form.intTripleRoomPriceInRangeTo());


                    corporateManager.addCorporate(corporate);

                    Set<CorporateLoginVO> corporateLoginUsers = new LinkedHashSet<CorporateLoginVO>();
                    for (CorporateLoginDto loginDto : form.getCorpLoginList()) {
                        CorporateLoginVO vo = null;
                        if(loginDto.getCorpLoginId()!=null && loginDto.getCorpLoginId().longValue()>0) {
                            vo = corporateManager.getCorporateLoginById(loginDto.getCorpLoginId());

                            vo.setId(loginDto.getCorpLoginId());
                            vo.setCorpId(corporate.getCorpId());
                            vo.setCorpContactPersonName(loginDto.getContactName());
                            vo.setCorpContactPersonEmail(loginDto.getContactEmail());
                            vo.setCorpContactNo(loginDto.getContactNumber());

                            vo.setCorpLoginID(loginDto.getLoginID());
                            vo.setCorpLoginPassword(loginDto.getLoginPassword());
                            vo.setIsActive(1);
                            vo.setLastUpdatedDate(new Date());
                        }else{
                            vo = new CorporateLoginVO(corporate.getCorpId(), loginDto);
                        }
                        if(vo.getId() != null && vo.getId().equals(0L)){
                            vo.setId(null);
                        }
                        vo = corporateManager.saveCorporateLoginVO(vo);
                        corporateLoginUsers.add(vo);
                    }
                    corporate.setCorporateLoginUsers(corporateLoginUsers);
                    corporateManager.addCorporate(corporate);
                    //modelAndView = new ModelAndView(WudstayConstants.SHOW_CORP_PAGE);
                    modelAndView = new ModelAndView("redirect:" + WudstayMappings.VIEW_CORP) ;//WudstayConstants.SHOW_CORP_PAGE);
                } else {
                    modelAndView = new ModelAndView(WudstayConstants.SHOW_ADD_CORP_PAGE);
                    modelAndView.addObject("corp", form);
                    if ("".equals(errorMsg)) {
                        errorMsg = "Corporate name ( " + corpName + " ) already exist.";
                    } else {
                        errorMsg = errorMsg + "<br/>" + "Corporate name ( " + corpName + " ) already exist.";
                    }
                }
            }
            if(form.getCorpLoginList()!=null && form.getCorpLoginList().size()==0){
            	form.addCorporateLoginDto(new CorporateLoginDto());
            }
            modelAndView.addObject("corp", form);
            modelAndView.addObject("errorMsg", errorMsg);
            
        } catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }
    //------------------------------------------------------------------------------------------------------------------

    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.CORP_APPROVE_BOOKINGS)
    public ModelAndView approveBooking(HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView(WudstayConstants.SHOW_APPROVE_BOOKING_PAGE);
        List<CorporateBookingVO> corporateBookings;
        try {
            corporateBookings = corporateBookingManager.getCorporateBookingList();

            modelAndView.addObject("corporateBookings", corporateBookings);
            if(corporateBookings!=null && corporateBookings.size()>0) {
                modelAndView.addObject("EDIT_MODE", Boolean.TRUE);
            }else{
                modelAndView.addObject("EDIT_MODE", Boolean.FALSE);
            }
        } catch (Exception e) {
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }


    private String getRequestParam(HttpServletRequest request, String paramName, String defaultValue) {
        try {
            if (request.getParameter(paramName.trim()) != null) {
                return request.getParameter(paramName.trim());
            } else {
                return defaultValue;
            }
        } catch (Exception ex) {
            return defaultValue;
        }
    }

    private int divisionRoundUp(int a, int b) {
        int c = a / b;
        int d = a % b;
        if (d > 0) {
            c = c + 1;
        }
        return c;
    }

    @RequestMapping(method = {RequestMethod.GET, RequestMethod.POST}, value = WudstayMappings.SUBMIT_PROCEED_CORP_APPROVE_BOOKING)
    public ModelAndView submitProceedCorporateBooking(HttpServletRequest request, HttpSession session) {
        String errMessage="";

        System.out.println("proceedCorporateBooking");//@RequestParam("corporateBookingForm")  CorporateBookingForm corporateBookingForm,

        Long corpBookingId = Long.parseLong(getRequestParam(request, "corpBookingId", "0"));
        ModelAndView modelAndView = new ModelAndView("redirect:" + WudstayMappings.PROCEED_CORP_APPROVE_BOOKING + "?corpBooking=" + corpBookingId); //proceedApproveCorpBooking.do?corpBooking=6
        CorporateBookingVO corpBooking = corporateBookingManager.getById(corpBookingId);

        Long cityId = corpBooking.getLocation().getCity().getCityId();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String checkIn = dateFormat.format(corpBooking.getCheckIn());
        String checkOut = dateFormat.format(corpBooking.getCheckOut());

        String guestRequest = corpBooking.getGuestRequest();   //getRequestParam(request, "guest_request", "-").trim();
        Integer price = Integer.parseInt(getRequestParam(request, "price", "0").trim());
        Integer billPayAt = Integer.parseInt(getRequestParam(request, "billPayAt", "0").trim());

        if(price==0){
            errMessage = errMessage + "<br/> Zero price. ";
        }

        Map<Long, List<Long>> corpUserMap = new HashMap<Long, List<Long>>();
        int i = 0;
        while (request.getParameter("listOfEmployee[" + i + "].empId") != null) {
            Long empId = Long.parseLong(getRequestParam(request, "listOfEmployee[" + i + "].empId", "0"));
            Long hotelId = Long.parseLong(getRequestParam(request, "listOfEmployee[" + i + "].hotelId", "0"));
            i++;
            if (empId > 0 && hotelId > 0) {
                List<Long> lst = null;
                if (corpUserMap.containsKey(hotelId)) {
                    lst = corpUserMap.get(hotelId);
                } else {
                    lst = new ArrayList<Long>();
                }
                lst.add(empId);
                corpUserMap.put(hotelId, lst);
            }
        }
        //--------------------------------------------------------------------------------------------------------------
        //      Collection Guest hotel wise
        //--------------------------------------------------------------------------------------------------------------
        int roomType = 1;
        if (corpBooking.getRoomType().equalsIgnoreCase(WudstayConstants.ROOM_TYPE_TRIPLE)) {
            roomType = 3;
        } else if (corpBooking.getRoomType().equalsIgnoreCase(WudstayConstants.ROOM_TYPE_DOUBLE)) {
            roomType = 2;
        } else { // if (corpBooking.getRoomType().equalsIgnoreCase(WudstayConstants.ROOM_TYPE_SINGLE)) {
            roomType = 1;
        }

        //--------------------------------------------------------------------------------------------------------------
        //                  APPROVE_BOOKING
        //--------------------------------------------------------------------------------------------------------------
        City city = cityManager.getById(cityId);
        WudstayCorpBookingUtil booking = new WudstayCorpBookingUtil(price, corpBooking.getBookingDate(), corpBooking.getCorporate(), corpBooking.getCorporateUser(),hotelBookingManager, hotelAdministratorManager, city);
        for (Map.Entry<Long, List<Long>> entry : corpUserMap.entrySet()) {
            Long hotelId = entry.getKey();
            List<Long> empIdList = entry.getValue();
            Hotel hotel = hotelManager.getById(hotelId);
            booking.setHotel(hotel);
            //--------------------------------------------
            Integer paidAmount=0;
            Integer persons = empIdList.size();
            Integer rooms = divisionRoundUp(persons, roomType);
            HotelAvailabilityVO hotelAvailabilityVO = booking.checkAvailability(checkIn, checkOut, rooms);
            if (hotelAvailabilityVO.getIsAvailable() == false && hotelAvailabilityVO.getRooms() > 0) {
                rooms = hotelAvailabilityVO.getRooms();
                persons = roomType * rooms;
                hotelAvailabilityVO = booking.checkAvailability(checkIn, checkOut, rooms);
                errMessage = errMessage + "<br/> Only " + rooms + " room(s) are availabile in hotel(" + hotel.getHotelDisplayName() + ").";
            }
            if (hotelAvailabilityVO.getIsAvailable()) {
                String bookingId = booking.bookAndConfirmHotel(checkIn, checkOut, rooms, persons);
                //BookingDetailsVO bookingDetailsVO = booking.getBookingDetailsVO();

                List<CorporateEmployeeVO> guestList = new ArrayList<CorporateEmployeeVO>();
                List<String> guestNames = new ArrayList<String>();
                Map<String, Object> mapCommonEmailData = booking.commonBbookingConfirmationBodyDetails(bookingId, paidAmount, persons , guestRequest, billPayAt);
                for (i = 0; i < persons; i++) {
                    try {
                        CorporateEmployeeVO corpEmp = corporateEmployeeManager.getById(empIdList.get(i));
                        corpEmp.setHotelId(hotelId);
                        corpEmp.setIsApproved(1);
                        corporateEmployeeManager.saveOrUpdate(corpEmp);

                        guestList.add(corpEmp);
                        guestNames.add(corpEmp.getEmpName());
                        booking.sendConfirmationMailAndSmsToGuest(corpEmp, bookingId, mapCommonEmailData); // sendConfirmation Mail & SMS to guest
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
                String guestNameCSVlistToCsv = booking.listToCsv(guestNames);
                booking.sendConfirmationMailAndSmsToCorporatAdmin( bookingId, mapCommonEmailData, guestNameCSVlistToCsv);
                booking.sendConfirmationMailAndSmsToHotelAdmin(hotelAdministratorManager, hotelId, guestNameCSVlistToCsv, bookingId, mapCommonEmailData);
            }
        }
        modelAndView.addObject("errorMsg", errMessage);
        try {
            corpBooking = corporateBookingManager.getById(corpBookingId);
            boolean allEmpApproved = true;
            for (CorporateEmployeeVO emp : corpBooking.getListOfEmployee()) {
                if (emp.getIsApproved() == 0) {
                    allEmpApproved = false;
                    break;
                }
            }
            if (allEmpApproved == true) {
                corpBooking.setIsApproved(1);
                //corporateBookingManager.saveOrUpdate(corpBooking);
                modelAndView = new ModelAndView("redirect:" + WudstayMappings.GET_BOOKINGS);
            }

            corpBooking.setGuestRequest(guestRequest);
            corpBooking.setPrice(price);
            corpBooking.setBillPayAt(billPayAt);
            corporateBookingManager.saveOrUpdate(corpBooking);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return modelAndView;
    }

    private String getPrice(Integer val){
        try {
            if (val == null)
                return "";
            else {
                return "" + val.intValue();
            }
        }catch (Exception ex){
            return "";
        }

    }

    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.PROCEED_CORP_APPROVE_BOOKING)
    public ModelAndView proceedCorporateBooking(@RequestParam String corpBooking, HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView(WudstayConstants.SHOW_APPROVE_BOOKING_DETAILS_PAGE);
        try {
            String[] values = corpBooking.split(",");
            Long lngCorpBookingId = Long.parseLong(values[0]);

			/*String corpBookingId = values[0];
			String bookingName = values[1];
			String corpName = values[1];
			List<Hotel> hotelList = hotelManager.getHotelByCityId(cityId, persons/rooms);
			*/

            CorporateBookingVO corpBookingDetail = corporateBookingManager.getById(lngCorpBookingId);
            CorporateBookingForm form = new CorporateBookingForm(corpBookingDetail);
            form.setNoOfGuests(corpBookingDetail.getListOfEmployee().size());
            List<CorporateEmployeeVO> corpEmpWhichHotelAllottedList = new ArrayList<CorporateEmployeeVO>();
            List<CorporateEmployeeVO> corpEmpWhichHotelUnAllottedList = new ArrayList<CorporateEmployeeVO>();
            for (CorporateEmployeeVO vo : corpBookingDetail.getListOfEmployee()) {
                if (vo.getIsApproved() == 0) {
                    corpEmpWhichHotelUnAllottedList.add(vo);
                } else {
                    try {
                        Hotel hotel = hotelManager.getById(vo.getHotelId());
                        vo.setHotelName(hotel.getHotelDisplayName());
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                    corpEmpWhichHotelAllottedList.add(vo);
                }
            }
            try {
                Corporate corporate = corpBookingDetail.getCorporate();
                if (WudstayConstants.ROOM_TYPE_TRIPLE.equalsIgnoreCase(corpBookingDetail.getRoomType())) {
                    if (corporate.getTripleRoomPriceIsFixed() != null && corporate.getTripleRoomPriceIsFixed() > 0) {
                        modelAndView.addObject("Contracted_Rate", getPrice(corporate.getTripleRoomFixedPrice()) + ("  Fixed"));
                    } else {
                        modelAndView.addObject("Contracted_Rate", getPrice(corporate.getTripleRoomPriceFrom()) + " - " + getPrice(corporate.getTripleRoomPriceTo()));
                    }
                } else if (WudstayConstants.ROOM_TYPE_DOUBLE.equalsIgnoreCase(corpBookingDetail.getRoomType())) {
                    if (corporate.getDoubleRoomPriceIsFixed() != null && corporate.getDoubleRoomPriceIsFixed() > 0) {
                        modelAndView.addObject("Contracted_Rate", getPrice(corporate.getDoubleRoomFixedPrice()) + ("  Fixed"));
                    } else {
                        modelAndView.addObject("Contracted_Rate", getPrice(corporate.getDoubleRoomPriceFrom()) + " - " + getPrice(corporate.getDoubleRoomPriceTo()));
                    }
                } else {
                    if (corporate.getSingleRoomPriceIsFixed() != null && corporate.getSingleRoomPriceIsFixed() > 0) {
                        modelAndView.addObject("Contracted_Rate", getPrice(corporate.getSingleRoomFixedPrice()) + ("  Fixed"));
                    } else {
                        modelAndView.addObject("Contracted_Rate", getPrice(corporate.getSingleRoomPriceFrom()) + " - " + getPrice(corporate.getSingleRoomPriceTo()));
                    }
                }
            }catch (Exception ex){
                ex.printStackTrace();
            }


            form.setListOfEmployee(corpEmpWhichHotelUnAllottedList);
            form.setlListOfEmployeeAllottedhotel(corpEmpWhichHotelAllottedList);
            form.setNoOfGuestsAllottedhotel(corpEmpWhichHotelUnAllottedList.size());

            List<City> cityList = cityManager.getAllCities();
            modelAndView.addObject("cityList", cityList);
            Long cityId = corpBookingDetail.getLocation().getCity().getCityId();
            List<Location> locationList = locationManager.getLocationsByCityId(cityId);
            modelAndView.addObject("locationList", locationList);
            Long locationId = corpBookingDetail.getLocation().getLocationId();

            form.setCityName(corpBookingDetail.getLocation().getCity().getCityName());
            form.setLocationName(corpBookingDetail.getLocation().getLocationName());
            modelAndView.addObject("corporateBookingForm", form);


            int persons = 1;
            int rooms = 1;
            if (corpBookingDetail.getRoomType() != null && WudstayConstants.ROOM_TYPE_DOUBLE.equalsIgnoreCase(corpBookingDetail.getRoomType()))
                rooms = 2;
            else if (corpBookingDetail.getRoomType() != null && WudstayConstants.ROOM_TYPE_TRIPLE.equalsIgnoreCase(corpBookingDetail.getRoomType()))
                rooms = 3;
            List<Hotel> hotelList = hotelManager.getHotelByCityId(cityId, persons / rooms);

            Map<Long, String> hotels_in_city = new HashMap<Long, String>();
            Map<Long, String> hotels_in_locality = new HashMap<Long, String>();
            for (Hotel hotel : hotelList) {
                if (hotel.getLocation().getLocationId().equals(locationId)) {
                    hotels_in_locality.put(hotel.getHotelId(), hotel.getHotelDisplayName());
                }
                hotels_in_city.put(hotel.getHotelId(), hotel.getHotelDisplayName());
            }
            modelAndView.addObject("hotels_in_city", hotels_in_city);
            modelAndView.addObject("hotels_in_locality", hotels_in_locality);
        } catch (Exception e) {
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.GET_IF_ALREADY_EXIST_CORP_NAME)
    public
    @ResponseBody
    Boolean getAlreadyExistsCorpName(@RequestParam String corpName, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        List<Location> locationList = new ArrayList<Location>();
        try {
            return corporateManager.isCorpNameExists(corpName);
        } catch (Exception e) {
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
    }

    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.GET_IF_ALREADY_EXIST_CORP_LOGIN_ID)
    public
    @ResponseBody
    Boolean getAlreadyExistsCorpLoginId(@RequestParam String corpLoginId, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        List<Location> locationList = new ArrayList<Location>();
        try {
            return corporateManager.isCorpLoginIdExists(corpLoginId);
        } catch (Exception e) {
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
    }
    private void newCouponCode(Long couponId, ModelAndView modelAndView, HttpServletRequest request){
        CouponCodeForm from = new CouponCodeForm();
        if(couponId!=null && couponId.longValue()>0){
            try {
                from.setNewCouponCode(couponCodeManager.getById(couponId));
                modelAndView.addObject("checkIn", CouponCodeForm.strDate(from.getCouponValidFromDate()));
                modelAndView.addObject("checkOut", CouponCodeForm.strDate(from.getCouponValidTillDate()));
            }catch (Exception ex){
                ex.printStackTrace();
            }
        }else{
            modelAndView.addObject("checkIn", CouponCodeForm.strDate(new Date()));
            modelAndView.addObject("checkOut", CouponCodeForm.tomorrowDate(new Date()));
        }
        newCouponCode2(from, modelAndView, request);
    }

    private void newCouponCode2(CouponCodeForm from, ModelAndView modelAndView, HttpServletRequest request){
        try {

            List<City> cityList = cityManager.list();
            Collections.sort(cityList, new Comparator<City>(){
                public int compare(City s1, City s2) {
                    return s1.getCityName().compareToIgnoreCase(s2.getCityName());
                }
            });

            List<City> selectedCityList = new ArrayList<City>();
            CouponCodeVO vo = from.getNewCouponCode();
            for(CouponCodeInCityVO city: vo.getCities()){
                for(int i=0;i<cityList.size(); i++){
                    City c = cityList.get(i);
                    if(city.getCityId().equals(c.getCityId())){
                        cityList.remove(i);
                        selectedCityList.add(c);
                        break;
                    }
                }
            }
            Collections.sort(selectedCityList, new Comparator<City>(){
                public int compare(City s1, City s2) {
                    return s1.getCityName().compareToIgnoreCase(s2.getCityName());
                }
            });
            modelAndView.addObject("cityList", cityList);
            modelAndView.addObject("selectedCityList", selectedCityList);

            //---------------------------------------------------------------------
            try {
                List<CouponCodeVO> couponCodeList = couponCodeManager.list();
                if(couponCodeList!=null && couponCodeList.size()>0){
                    from.setCouponCodeList(couponCodeList);
                }
            }catch (Exception ex){
                ex.printStackTrace();
            }
            modelAndView.addObject("couponCodeForm", from);
        } catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
    }
    @RequestMapping(method = {RequestMethod.GET, RequestMethod.POST}, value = WudstayMappings.CREATE_COUPON_CODE)
    public ModelAndView createCouponCode(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView =  new ModelAndView("couponCode");
        Long couponId = null;
        if(request.getParameter("CouponId")!=null){
            try {
                couponId = Long.parseLong(request.getParameter("CouponId").trim());
            }catch (Exception ex){
                ex.printStackTrace();
                couponId = null;
            }
        }

        newCouponCode(couponId, modelAndView, request);
        return modelAndView;
    }
    @RequestMapping(method = RequestMethod.POST, value = WudstayMappings.SUBMIT_NEW_COUPON_CODE)
    public ModelAndView saveCouponCode(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        //ModelAndView modelAndView =  new ModelAndView("couponCode");
        CouponCodeVO vo = null;
        String errorMsg="";
        ModelAndView modelAndView = new ModelAndView("redirect:/admin/" + WudstayMappings.CREATE_COUPON_CODE);
        CouponCodeForm form = new CouponCodeForm();
        HttpRequestToBeanUtil.populateBean(form, request);

        String []cityIds = null;
        if(request.getParameter("cityIds")!=null){
            cityIds = request.getParameter("cityIds").split(",");
        }
        //-------------------------------------------
        try {
            vo = couponCodeManager.getByCouponCode(form.getCouponCode().trim());
            if(vo!=null){
                boolean checkDuplicateCode=false;
                if(form.getCouponId()==null || form.getCouponId().longValue()==0){
                    checkDuplicateCode=true;
                }else {//Edit Mode
                    if (!vo.getCouponId().equals(form.getCouponId())) {
                        checkDuplicateCode=true;
                    }else if(!vo.getCouponCode().equals(form.getCouponCode())) {
                        checkDuplicateCode=true;
                    }
                }
                if(checkDuplicateCode==true) {
                    modelAndView = new ModelAndView("couponCode");
                    errorMsg = "This Coupon Code already exist, Please enter other Coupon Code";
                    modelAndView.addObject("errorMsg", errorMsg);
                    newCouponCode2(form, modelAndView, request);
                    return modelAndView;
                }
            }
        } catch (WudstayException e) {
            e.printStackTrace();
        }
        //-------------------------------------------
        if(vo!=null){
            vo.setCouponCode(form.getCouponCode());
            vo.setCouponAmtValue(form.getCouponAmtValue());
            vo.setIsDiscountPercentageMode(form.getIsDiscountPercentageMode());
            vo.setCouponValidFromDate(form.getCouponValidFromDate());
            vo.setCouponValidTillDate(form.getCouponValidTillDate());
            vo.setCouponValidTillTimes(form.getCouponValidTillTimes());
            vo.setCouponIgnoreValidityDate(form.getCouponIgnoreValidityDate());
            vo.setCouponValidityDateApplyOnCheckout(form.getCouponValidityDateApplyOnCheckout());
            vo.setDiscountUpperLimit(form.getDiscountUpperLimit());
            //vo.setCouponValidForAllCities(form.getCouponValidForAllCities());
            vo.setLastUpdatedDate(new Date());
            vo.setValidForBookingsource(form.getValidForBookingsource());
            vo.setIsValidForUniqueUser(form.getIsValidForUniqueUser());
            vo.setIsValidForOnlinePaymentOnly(form.getIsValidForOnlinePaymentOnly());

        }else{
            vo = form.getNewCouponCode();
        }
        //CouponCodeVO vo = form.getNewCouponCode();
        if(vo.getCouponId() != null && vo.getCouponId().longValue() == 0)
            vo.setCouponId(null);
        if(cityIds==null)
            vo.setCouponValidForAllCities(1);
        else
            vo.setCouponValidForAllCities(0);
        try {
            couponCodeManager.saveOrUpdate(vo);
        }catch (Exception ex){
            ex.printStackTrace();
        }
        //-------------------------------------------
        Set<CouponCodeInCityVO> lst = new HashSet<CouponCodeInCityVO>();
        if(cityIds!=null){
            for(String city: cityIds){
                if(city!=null && !"".equals(city.trim())){
                    try {
                        Long cityId = Long.parseLong(city.trim());
                        CouponCodeInCityVO couponCity = couponCodeManager.getCouponCodeCityByCouponAndcityId(vo.getCouponId() , cityId);
                        if(couponCity==null)
                            couponCity = new CouponCodeInCityVO();
                        couponCity.setCouponId(vo.getCouponId());
                        couponCity.setCityId(cityId);
                        couponCodeManager.saveCouponCodeCity(couponCity);
                        lst.add(couponCity);
                    }catch (Exception ex){
                        ex.printStackTrace();
                    }
                }
            }
        }
        //-------------------------------------------
        vo.setCities(lst);
        try {
            couponCodeManager.saveOrUpdate(vo);
        }catch (Exception ex){
            ex.printStackTrace();
        }
        newCouponCode(null, modelAndView, request);
        return modelAndView;
    }

    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.GET_MONTHLY_INVENTORY)
    public
    @ResponseBody
    Map<String, Object> getMonthlyRoomsInventory(@RequestParam Long hotelId, @RequestParam String direction, @RequestParam Integer currMonth, @RequestParam Integer currYear,
                                            HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        DateUtil dateUtil = new DateUtil(1, currMonth, currYear);
        Hotel hotel = hotelManager.getById(hotelId);
        DateUtil dateUtilFromDate = new DateUtil(hotel.getValidFromDate());
        int minYear = dateUtilFromDate.getYear();
        DateUtil dateUtilToDate = new DateUtil(hotel.getValidToDate());
        int maxYear = dateUtilToDate.getYear();

        if(minYear<=currYear && maxYear>=currYear) {
            if ("P".equalsIgnoreCase(direction)) {
                if (minYear < currYear || (minYear == currYear && dateUtilFromDate.getMonth() < currMonth)) {
                    dateUtil.movePreviousMonth();
                }
            } else { //if("N".equalsIgnoreCase(direction)){
                if (maxYear > currYear || (maxYear == currYear && dateUtilToDate.getMonth() > currMonth)) {
                    dateUtil.moveNexMonth();
                }
            }
        }

        return fetchMonthlyRoomsInventory( hotelId,  dateUtil.getMonth(),  dateUtil.getYear());
    }
    private Map<String, Object> fetchMonthlyRoomsInventory(Long hotelId, Integer currMonth, Integer currYear){
        Hotel hotel = hotelManager.getById(hotelId);
        return fetchMonthlyRoomsInventory(hotel, currMonth, currYear);
    }
    private Map<String, Object> fetchMonthlyRoomsInventory(Hotel hotel, Integer currMonth, Integer currYear){
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("isSuccess", Boolean.FALSE);

        //Hotel hotel = hotelManager.getById(hotelId);
        RoomsInventoryForm inventory = roomsInventoryManager.getRoomAvailabilityCalendar( hotel, currMonth,  currYear);
        map.put("inventory", inventory);

        map.put("isSuccess", Boolean.TRUE);
        return map;
    }

    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.UPDATE_IN_RANGE_MONTHLY_INVENTORY)
    public
    @ResponseBody
    Map<String, Object> updateInRangeMonthlyRoomsInventory(@RequestParam Long hotelId, @RequestParam String inventoryDate, @RequestParam Integer noOfRooms,
                                                    HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        DateUtil dateUtil = new DateUtil(new Date());
        try {
            String[] dates = inventoryDate.split(" - ");
            String inventoryFDate = dates[0].trim();
            String inventoryTDate = dates[1].trim();

            dateUtil = new DateUtil(inventoryFDate);
            DateUtil toDateUtil = new DateUtil(inventoryTDate);
            int days = (int) dateUtil.getDifferenceInDays(toDateUtil.toDate());

            for (int i = 0; i <= days; i++) {
                roomsInventoryManager.updateInventory(hotelId, noOfRooms, dateUtil.toDate());
                dateUtil.moveNexDay();
            }
        }catch (Exception ex){
            ex.printStackTrace();
        }

        return fetchMonthlyRoomsInventory( hotelId,  dateUtil.getMonth(),  dateUtil.getYear());
    }
    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.UPDATE_MONTHLY_INVENTORY)
    public
    @ResponseBody
    Map<String, Object> updateMonthlyRoomsInventory(@RequestParam Long hotelId, @RequestParam String inventoryDate, @RequestParam Integer noOfRooms,
                                                    HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        DateUtil dateUtil = new DateUtil(inventoryDate);

        roomsInventoryManager.updateInventory(hotelId, noOfRooms, dateUtil.toDate());

        return fetchMonthlyRoomsInventory( hotelId,  dateUtil.getMonth(),  dateUtil.getYear());
    }

    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.RESET_MONTHLY_INVENTORY)
    public
    @ResponseBody
    Map<String, Object> updateMonthlyRoomsInventory(@RequestParam Long hotelId, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        Hotel hotel = hotelManager.getById(hotelId);
        Date dtFrom = hotel.getValidFromDate();
        Date dtTo = hotel.getValidToDate();
        if(dtFrom!=null && dtTo !=null){
            roomsInventoryManager.updateInventory(hotel.getHotelId(), hotel.getNoOfRooms(), dtFrom, dtTo);
        }
        DateUtil dateUtil = new DateUtil(new Date());
        return fetchMonthlyRoomsInventory( hotelId,  dateUtil.getMonth(),  dateUtil.getYear());
    }

    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.ADD_PG)
    public ModelAndView addPgHotel(HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView(WudstayConstants.ADD_PG_PAGE);
        try {

            Boolean isSuccess = (Boolean) session.getAttribute("isSuccess");
            if (isSuccess != null) {
                modelAndView.addObject("isSuccess", isSuccess);
                session.removeAttribute("isSuccess");
            }

            List<City> cityList = cityManager.list();
            List<PgAmenity> amenitiyList = pgAmenityManager.list();
            List<PgType> pgTypeList = pgTypeManager.list();
            modelAndView.addObject("cityList", cityList);
            modelAndView.addObject("amenityList", amenitiyList);
            modelAndView.addObject("pgTypeList", pgTypeList); //roomTypeList
        } catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }
    @RequestMapping(method = RequestMethod.POST, value = WudstayMappings.SAVE_PG) //SAVE_HOTEL
    public ModelAndView savePG(@ModelAttribute PgHotelForm hotelVO, HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("redirect:" + WudstayMappings.ADD_PG);
        try {
            User user = (User) session.getAttribute(WudstayConstants.USER);
            Long hotelId = pgHotelManager.addHotel(hotelVO, user);

            session.setAttribute("isSuccess", Boolean.TRUE);
        } catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("isSuccess", Boolean.FALSE);
        }
        return modelAndView;
    }

}
