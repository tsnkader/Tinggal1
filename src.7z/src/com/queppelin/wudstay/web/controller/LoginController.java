package com.queppelin.wudstay.web.controller;

import org.springframework.stereotype.Controller;

@Controller
public class LoginController {
	
	
}
