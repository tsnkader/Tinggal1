package com.queppelin.wudstay.web.controller;

import com.queppelin.wudstay.exception.CustomGenericException;
import com.queppelin.wudstay.manager.*;
import com.queppelin.wudstay.util.*;
import com.queppelin.wudstay.vo.*;
import com.queppelin.wudstay.vo.CorporateBookingVO;
import com.queppelin.wudstay.vo.custom.*;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Controller
@RequestMapping("/corporate")
public class CorporateController {


    @Autowired
    IUserManager userManager;

    @Autowired
    IHotelRoomBookingManager hotelRoomBookingManager;

    @Autowired
    IHotelBookingManager hotelBookingManager;

    @Autowired
    ICityManager cityManager;

    @Autowired
    IAmenityManager amenityManager;

    @Autowired
    IRoomTypeManager roomTypeManager;

    @Autowired
    ILocationManager locationManager;

    @Autowired
    IHotelManager hotelManager;

    @Autowired
    IHotelRoomManager hotelRoomManager;

    @Autowired
    IHotelDescriptionManager hotelDescriptionManager;

    @Autowired
    IHotelAdministratorManager hotelAdministratorManager;

    @Autowired
    IHotelAmenityManager hotelAmenityManager;

    @Autowired
    ICorporateManager corporateManager;

    @Autowired
    ICorporateBookingManager corporateBookingManager;

    @Autowired
    ICorporateEmployeeManager corporateEmployeeManager;


    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.LOGIN)
    public ModelAndView getLoginPage(HttpServletRequest request, HttpSession session, RedirectAttributes redirectAttributes) {
        ModelAndView modelAndView = new ModelAndView(WudstayConstants.LOGIN_PAGE);
        try {
            Boolean isLoginSuccess = (Boolean) session.getAttribute("isLoginSuccess");
            if (isLoginSuccess != null && !isLoginSuccess) {
                modelAndView.addObject("isLoginSuccess", isLoginSuccess);
            }
            session.removeAttribute("isLoginSuccess");
        } catch (Exception e) {
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }
    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.LOGOUT)
    public ModelAndView logout(HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("redirect:" + WudstayMappings.LOGIN);
        try {
            session.removeAttribute(WudstayConstants.CORP_CorporateLoginVO);
            session.removeAttribute(WudstayConstants.CORP_CorporateVO);
            session.invalidate();
        } catch (Exception e) {
            e.printStackTrace();
            //throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    @RequestMapping(method = RequestMethod.POST, value = WudstayMappings.VERIFY_CREDENTIALS)
    public ModelAndView login(@ModelAttribute User user, HttpServletRequest request, HttpServletResponse response, HttpSession session, RedirectAttributes redirectAttributes) {
        try {
            CorporateLoginVO corporate = new CorporateLoginVO();
            corporate.setCorpLoginID(user.getUsername());
            corporate.setCorpLoginPassword(user.getPassword());
            corporate = corporateManager.login(corporate);
            if (corporate != null) {
                session.setAttribute(WudstayConstants.CORP_CorporateLoginVO, corporate);
                session.setAttribute(WudstayConstants.CORP_CorporateVO , corporateManager.getById(corporate.getCorpId()));
                return new ModelAndView("redirect:" + WudstayMappings.GET_CORP_BOOKINGS);
            } else {
                session.setAttribute("isLoginSuccess", Boolean.FALSE);
                return new ModelAndView("redirect:" + WudstayMappings.LOGIN);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.GET_CORP_BOOKINGS)
    public ModelAndView getLandingPage(HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView(WudstayConstants.SHOW_CORP_BOOKINGS_PAGE);

        //Corporate corporate = (Corporate) session.getAttribute(WudstayConstants.CORP_CorporateVO);
        CorporateLoginVO corporateLogin = (CorporateLoginVO) session.getAttribute(WudstayConstants.CORP_CorporateLoginVO);
        List<CorporateBookingVO> corporateBookingList = null ;//= corporateBookingManager.list();
        try {
            corporateBookingList = corporateBookingManager.getAllBookings(corporateLogin.getCorpId(), corporateLogin.getId());
            for(CorporateBookingVO item : corporateBookingList){
                System.out.println(item.getLocation().getCity().getCityId());
                System.out.println(item.getListOfEmployee().size());
            }
            modelAndView.addObject("corporateBookingList", corporateBookingList);
        } catch (Exception e) {
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    // http://localhost:8080/wudstaycorporate/corporate/getCorpBookings.do
    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.ADD_BULK_BOOKING)
    public ModelAndView getBulkBooking(HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView(WudstayConstants.SHOW_BULK_BOOKINGS_PAGE);
        modelAndView.addObject("EDIT_MODE", Boolean.FALSE);
        try {
            CorporateEmployeeForm employeeForm = new CorporateEmployeeForm();

            List<City> cityList = cityManager.getAllCities();
            modelAndView.addObject("cityList", cityList);

            modelAndView.addObject("employeeForm", employeeForm);

            Date today = new Date();
            Calendar c = Calendar.getInstance();
            c.setTime(today);
            c.add(Calendar.DATE, 1);
            Date tomorrow = c.getTime();
            SimpleDateFormat simpleDateFormatter = new SimpleDateFormat("dd/MM/yyyy");

            modelAndView.addObject("checkIn", simpleDateFormatter.format(today));
            modelAndView.addObject("checkOut", simpleDateFormatter.format(tomorrow));

        } catch (Exception e) {
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }
    @RequestMapping(method = {RequestMethod.GET, RequestMethod.POST}, value = WudstayMappings.Edit_BULK_BOOKING)
    public ModelAndView editBulkBooking(@RequestParam Long corpBookingId, HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView(WudstayConstants.SHOW_BULK_BOOKINGS_PAGE);
        CorporateEmployeeForm employeeForm = new CorporateEmployeeForm();
        modelAndView.addObject("EDIT_MODE", Boolean.TRUE);
        try {
            CorporateBookingVO corpBooking =  corporateBookingManager.getById(corpBookingId);
            employeeForm.setBookingName(corpBooking.getBookingName());
            try{
                SimpleDateFormat simpleDateFormatter = new SimpleDateFormat("dd/MM/yyyy");
                modelAndView.addObject("checkIn", simpleDateFormatter.format(corpBooking.getCheckIn()));
                modelAndView.addObject("checkOut", simpleDateFormatter.format(corpBooking.getCheckOut()));
            }catch (Exception ex){
                ex.printStackTrace();
            }
            employeeForm.setLocation(corpBooking.getLocation().getLocationName());
            employeeForm.setCity(corpBooking.getLocation().getCity().getCityName());
            employeeForm.setRoomType(corpBooking.getRoomType());
            employeeForm.setGuestRequest(corpBooking.getGuestRequest());

            //modelAndView.addObject("city",employeeForm.getCity());
            //modelAndView.addObject("location",employeeForm.getLocation());

            List<CorporateEmployeeVO> lst = corporateEmployeeManager.getListByCorpBookingId(corpBooking.getCorpBookingId());
            for(CorporateEmployeeVO vo : lst){
                Employee guest = new Employee();
                guest.setEmpName(vo.getEmpName());
                guest.setEmpEmail(vo.getEmpEmail());
                guest.setEmpContactNumber(vo.getEmpContactNumber());
                employeeForm.addEmployee(guest);
            }
            modelAndView.addObject("employeeForm", employeeForm);


            try {
                List<City> cityList = cityManager.getAllCities();
                modelAndView.addObject("cityList", cityList);
                List<Location> locationList = new ArrayList<Location>();
                locationList = locationManager.getLocationsByCityId(corpBooking.getLocation().getCity().getCityId());
                modelAndView.addObject("locationList", locationList);
            } catch (Exception e) {
                throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
            }

        } catch (Exception e) {
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    private String getRequestParam(HttpServletRequest request, String paramName, String defaultValue){
        try {
            if (request.getParameter(paramName.trim()) != null) {
                return request.getParameter(paramName.trim());
            } else {
                return defaultValue;
            }
        }catch (Exception ex){
            return defaultValue;
        }
    }
    private CorporateEmployeeForm refreshRequestForm(CorporateEmployeeForm employeeForm, HttpServletRequest request){
        //CorporateEmployeeForm employeeForm = new CorporateEmployeeForm();
        employeeForm.setBookingName(getRequestParam(request, "bookingName", ""));
        employeeForm.setCity(getRequestParam(request, "city", "0"));
        employeeForm.setLocation(getRequestParam(request, "location", ""));
        employeeForm.setRoomType(getRequestParam(request, "roomType", "Single"));


        int i=0;
        while(request.getParameter("emp[" + i + "].empName") != null) {
            employeeForm.addEmployee(getRequestParam(request, "emp[" + i + "].empName", ""),
                    getRequestParam(request, "emp[" + i + "].empEmail", ""),
                    getRequestParam(request, "emp[" + i + "].empContactNumber", ""));
            i++;
        }

        //SimpleDateFormat simpleDateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        //employeeForm.setBookingDate(simpleDateFormatter.parse("2015-01-01 12:01:01"));
        SimpleDateFormat simpleDateFormatter = new SimpleDateFormat("dd/MM/yyyy"); //09/08/2015 11:07 AM

        //Attribute Name - txtDate, Value - 05/10/2015 - 07/10/2015
        String dateCheckIn = simpleDateFormatter.format(new Date());
        String dateCheckOut = simpleDateFormatter.format(new Date());
        try{
            String txtDate = request.getParameter("txtDate");
            String []strDates = txtDate.split(" - ");
            dateCheckIn =strDates[0].trim();
            dateCheckOut =strDates[1].trim();
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            //String strDate = getRequestParam(request,"dateCheckIn", simpleDateFormatter.format(new Date()));
            employeeForm.setCheckin(simpleDateFormatter.parse(dateCheckIn));
            //strDate = getRequestParam(request,"dateCheckOut", simpleDateFormatter.format(new Date()));
            employeeForm.setCheckout(simpleDateFormatter.parse(dateCheckOut));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return employeeForm;
    }

    @RequestMapping(method = RequestMethod.POST, value = WudstayMappings.BULK_BOOKING_SUBMIT)
    public ModelAndView submitBulkBooking(@ModelAttribute("employeeForm") CorporateEmployeeForm employeeForm, HttpServletRequest request, HttpSession session) {
        employeeForm = refreshRequestForm( employeeForm, request);
        ModelAndView modelAndView = new ModelAndView("redirect:" + WudstayMappings.GET_CORP_BOOKINGS);

        /*Enumeration params = request.getParameterNames();
        while(params.hasMoreElements()){
            String paramName = (String)params.nextElement();
            System.out.println("Attribute Name - "+paramName+", Value - "+request.getParameter(paramName));
        }*/


        Corporate corporate = (Corporate) session.getAttribute(WudstayConstants.CORP_CorporateVO);
        CorporateLoginVO corporateLogin = (CorporateLoginVO) session.getAttribute(WudstayConstants.CORP_CorporateLoginVO);


        User user = (User) session.getAttribute(WudstayConstants.USER);
        Date bookingDate = new Date();
        String uniqueRefKey =  WudstayUtil.getUniqueId();
        Location location = locationManager.getById(Long.parseLong(employeeForm.getLocation()));
        try {
            System.out.println("From Page - Start");

            CorporateBookingVO corpBooking = new CorporateBookingVO(corporate, corporateLogin, employeeForm.getBookingName(),
                    employeeForm.getCheckin(), employeeForm.getCheckout(), bookingDate, location, employeeForm.getRoomType() );

            corpBooking.setGuestRequest(employeeForm.getGuestRequest());
            if(user!=null)
                corpBooking.setLastUpdatedBy(user.getUsername());
            corpBooking.setLastUpdatedDate(bookingDate);
            corporateBookingManager.saveOrUpdate(corpBooking);

            for(Employee guest : employeeForm.getListEmployee()) {
                CorporateEmployeeVO corpEmp = new CorporateEmployeeVO(corporate, guest);
                if(user!=null)
                    corpEmp.setLastUpdatedBy(user.getUsername());
                corpEmp.setLastUpdatedDate(bookingDate);
                corpEmp.setBookingId(corpBooking.getCorpBookingId());
                corporateEmployeeManager.saveOrUpdate(corpEmp);
            }
            System.out.println("From Page - End");

        } catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }


    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.VIEW_CORP_HOTELS)
    public ModelAndView viewHotels(HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView(WudstayConstants.SHOW_CORP_HOTELS_PAGE);
        try {

        } catch (Exception e) {
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }


    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.GET_All_LOCATIONS_BY_CITY_ID)
    public
    @ResponseBody
    List<Location> getAllLocationsByCityId(@RequestParam Long cityId, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        List<Location> locationList = new ArrayList<Location>();
        try {
            locationList = locationManager.getLocationsByCityId(cityId);
        } catch (Exception e) {
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return locationList;
    }


    @RequestMapping(value = WudstayMappings.VIEW_UPLOAD_EXCEL_FOR_BOOKING, method = RequestMethod.POST)
    @ResponseBody
    public List<ExcelGuestBookingDetailsVO> uploadFile(@RequestParam("uploadfile") MultipartFile uploadfile) {
        List<ExcelGuestBookingDetailsVO> guestList = new ArrayList<ExcelGuestBookingDetailsVO>();
        try {
            String filename = uploadfile.getOriginalFilename();
            System.out.println("File Uploaded ...." + filename);

            Iterator<Row> rowIterator = null;
            DataFormatter formatter = new DataFormatter(); //creating formatter using the default locale

            try{//MS Office 2007+
                XSSFWorkbook my_xls_workbook = new XSSFWorkbook(uploadfile.getInputStream());
                XSSFSheet my_worksheet = my_xls_workbook.getSheetAt(0); //This will read the sheet for us into another object
                rowIterator = my_worksheet.iterator(); // Create iterator object
            }catch (org.apache.poi.POIXMLException ex){ //Older MS Office
                HSSFWorkbook my_xls_workbook = new HSSFWorkbook(uploadfile.getInputStream()); //Read the Excel Workbook in a instance object
                HSSFSheet my_worksheet = my_xls_workbook.getSheetAt(0); //This will read the sheet for us into another object
                rowIterator = my_worksheet.iterator(); // Create iterator object
            }
            //Iterator<Row> rowIterator = my_worksheet.iterator(); // Create iterator object

            while(rowIterator.hasNext()) {
                ExcelGuestBookingDetailsVO vo = new ExcelGuestBookingDetailsVO();
                int cilIndex=0;
                Row row = rowIterator.next(); //Read Rows from Excel document
                Iterator<Cell> cellIterator = row.cellIterator();//Read every column for every row that is READ
                boolean isFirstRow=false;
                while(cellIterator.hasNext()) {
                    Cell cell = cellIterator.next(); //Fetch CELL
                    //System.out.print(cell.getStringCellValue() + "\t\t"); //print string value
                    //Cell cell = cellIterator.getRow(i).getCell(0);
                    String txtCellValue = formatter.formatCellValue(cell); //Returns the formatted value of a cell as a String regardless of the cell type.
                    System.out.print(txtCellValue + "\t\t");
                    if((cilIndex==0 && "Name".equalsIgnoreCase(txtCellValue)) ||
                            (cilIndex==1 && "Email".equalsIgnoreCase(txtCellValue)) ||
                            (cilIndex==2 && (txtCellValue.toUpperCase().contains("PHONE")|| txtCellValue.toUpperCase().contains("MOBILE")) )){
                        isFirstRow=true;
                        break;
                    }
                    if(cilIndex==0){
                        vo.setGuestName(txtCellValue);
                    }else if(cilIndex==1){
                        vo.setGuestEmail(txtCellValue);
                    }else if(cilIndex==2){
                        vo.setGuestMobNo(txtCellValue);
                    }
                    cilIndex++;

                    /*switch(cell.getCellType()) { //Identify CELL type
                        case Cell.CELL_TYPE_NUMERIC:
                            System.out.print(cell.getNumericCellValue() + "\t\t"); //print numeric value
                            break;
                        case Cell.CELL_TYPE_STRING:
                            System.out.print(cell.getStringCellValue() + "\t\t"); //print string value
                            break;
                    }*/
                }
                if(isFirstRow==false) {
                    guestList.add(vo);
                }
                System.out.println(vo.toString());
                System.out.println(""); // To iterate over to the next row
            }


        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        return guestList;
    }

    public List<ExcelGuestBookingDetailsVO> uploadExcelFile_97(MultipartFile uploadfile) {
        List<ExcelGuestBookingDetailsVO> guestList = new ArrayList<ExcelGuestBookingDetailsVO>();
        try {
            String filename = uploadfile.getOriginalFilename();
            System.out.println("File Uploaded ...." + filename);

            DataFormatter formatter = new DataFormatter(); //creating formatter using the default locale
            HSSFWorkbook my_xls_workbook = new HSSFWorkbook(uploadfile.getInputStream()); //Read the Excel Workbook in a instance object
            //XSSFWorkbook my_xls_workbook = new XSSFWorkbook(uploadfile.getInputStream());
            HSSFSheet my_worksheet = my_xls_workbook.getSheetAt(0); //This will read the sheet for us into another object
            //XSSFSheet my_worksheet = my_xls_workbook.getSheetAt(0); //This will read the sheet for us into another object
            Iterator<Row> rowIterator = my_worksheet.iterator(); // Create iterator object
            while(rowIterator.hasNext()) {
                ExcelGuestBookingDetailsVO vo = new ExcelGuestBookingDetailsVO();
                int cilIndex=0;
                Row row = rowIterator.next(); //Read Rows from Excel document
                Iterator<Cell> cellIterator = row.cellIterator();//Read every column for every row that is READ
                while(cellIterator.hasNext()) {
                    Cell cell = cellIterator.next(); //Fetch CELL
                    //System.out.print(cell.getStringCellValue() + "\t\t"); //print string value
                    //Cell cell = cellIterator.getRow(i).getCell(0);
                    String txtCellValue = formatter.formatCellValue(cell); //Returns the formatted value of a cell as a String regardless of the cell type.
                    System.out.print(txtCellValue + "\t\t");
                    if(cilIndex==0){
                        vo.setGuestName(txtCellValue);
                    }else if(cilIndex==1){
                        vo.setGuestEmail(txtCellValue);
                    }else if(cilIndex==2){
                        vo.setGuestMobNo(txtCellValue);
                    }
                    cilIndex++;


                    /*switch(cell.getCellType()) { //Identify CELL type
                        case Cell.CELL_TYPE_NUMERIC:
                            System.out.print(cell.getNumericCellValue() + "\t\t"); //print numeric value
                            break;
                        case Cell.CELL_TYPE_STRING:
                            System.out.print(cell.getStringCellValue() + "\t\t"); //print string value
                            break;
                    }*/
                }
                guestList.add(vo);
                System.out.println(vo.toString());
                System.out.println(""); // To iterate over to the next row
            }


        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        return guestList;
    }
}
