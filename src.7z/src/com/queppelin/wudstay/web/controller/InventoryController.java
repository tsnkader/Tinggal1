package com.queppelin.wudstay.web.controller;

import com.queppelin.wudstay.exception.CustomGenericException;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.*;
import com.queppelin.wudstay.util.DateUtil;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.util.WudstayMappings;
import com.queppelin.wudstay.vo.*;

import com.queppelin.wudstay.vo.custom.RoomsInventoryForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Controller
@RequestMapping("/inventory")
public class InventoryController {

    @Autowired
    IHotelManager hotelManager;
    @Autowired
    IRoomsInventoryManager roomsInventoryManager;

    private String getRequestParam(HttpServletRequest request, String paramName, String defaultValue){
        try {
            if (request.getParameter(paramName.trim()) != null) {
                return request.getParameter(paramName.trim());
            } else {
                return defaultValue;
            }
        }catch (Exception ex){
            return defaultValue;
        }
    }
   /* @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.CALENDER_UN_AVAILABLE_ROOM)
    public
    @ResponseBody
    List<RoomsInventoryForm> roomAvailabilityCalendar(@RequestParam Long hotelId,  @RequestParam Integer month,  @RequestParam Integer year,
                                                         HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        return  roomsInventoryManager.getRoomAvailabilityCalendar(hotelId, month, year);
    }
    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.ADD_UN_AVAILABLE_ROOM)
    public
    @ResponseBody
    HotelRoomUnAvailableVO addUnAvailableRoom(@RequestParam Long hotelId,  @RequestParam Integer noOfRooms, @RequestParam String fromDate,
                                              HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        HotelRoomUnAvailableVO vo = null ;
        User user = null;
        try {
            user = (User) session.getAttribute(WudstayConstants.USER);
        }catch (Exception ex){}

        try {
            vo = roomsInventoryManager.saveOrUpdate(hotelId, noOfRooms, format.parse(fromDate.trim()), user);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return vo;
    }

    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.GET_LIST_UN_AVAILABLE_ROOMS)
    public
    @ResponseBody
    List<HotelRoomUnAvailableVO> getUnAvailableRoomsList(@RequestParam Long hotelId,@RequestParam String fromDate,@RequestParam String toDate,
                                                         HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        List<HotelRoomUnAvailableVO> unAvailableRoomsList = new ArrayList<HotelRoomUnAvailableVO>();
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");//("yyyy-MM-dd HH:mm:ss");
        try {
            //User user = (User) session.getAttribute(WudstayConstants.USER);
            //Hotel hotel = hotelManager.getById(hotelId);


            unAvailableRoomsList = roomsInventoryManager.listBetweenDates(hotelId, format.parse(fromDate), format.parse(toDate));
        } catch (Exception e) {
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return unAvailableRoomsList;
    }

    //  http://localhost:8080/wudstaycorporate/inventory/moveRoomInventory.do?hotelId=3
    //  http://localhost:8080/wudstaycorporate/inventory/moveRoomInventory.do?direction=3&currMonth=10&currYear=2015&hotelId=2&day=1
    @RequestMapping(method = {RequestMethod.GET, RequestMethod.POST}, value = WudstayMappings.MOVE_AND_UPDATE_ROOM_INVENTORY)
    public ModelAndView updateMoveRoomInventory(@RequestParam Long hotelId, @RequestParam Integer reserveRooms, @RequestParam String day,
                                          HttpServletRequest request, HttpServletResponse response, HttpSession session) {

        Date dt = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        try {
            dt = dateFormat.parse(day.trim());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        DateUtil date = new DateUtil(dt);

        try {
            User user=null;
            Hotel hotel = hotelManager.getById(hotelId);
            if(hotel.getNoOfRooms()<reserveRooms){
                reserveRooms=hotel.getNoOfRooms();
            }
            roomsInventoryManager.saveOrUpdate(hotelId, reserveRooms, date.toDate(), user);
        }catch (Exception ex){
            ex.printStackTrace();
        }

        ModelAndView modelAndView = new ModelAndView("redirect:/admin/" + WudstayMappings.EDIT_ROOM_INVENTORY);
        modelAndView.addObject("hotelId", hotelId);
        modelAndView.addObject("month", date.getMonth());
        modelAndView.addObject("year", date.getYear());
        return modelAndView;
    }

    @RequestMapping(method = {RequestMethod.GET, RequestMethod.POST}, value = WudstayMappings.MOVE_ROOM_INVENTORY)
    public ModelAndView editRoomInventory(@RequestParam String direction, @RequestParam Integer currMonth, @RequestParam Integer currYear,@RequestParam Long hotelId,
                                          HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        DateUtil date = new DateUtil(1, currMonth, currYear);
        if("P".equalsIgnoreCase(direction)){
            date.movePreviousMonth();
        }else { //if("N".equalsIgnoreCase(direction)){
            date.moveNexMonth();
        }

        ModelAndView modelAndView = new ModelAndView("redirect:/admin/" + WudstayMappings.EDIT_ROOM_INVENTORY);
        modelAndView.addObject("hotelId", hotelId);
        modelAndView.addObject("month", date.getMonth());
        modelAndView.addObject("year", date.getYear());
        return modelAndView;
    }

    // inventory/updateRoomInventory.do

    @RequestMapping(method = {RequestMethod.GET, RequestMethod.POST}, value = WudstayMappings.UPDATE_ROOM_INVENTORY)
    public ModelAndView saveRoomInventory(@RequestParam Long hotelId, @RequestParam Integer noOfRooms, @RequestParam Integer reserveRooms, @RequestParam String txtDate,
                                          HttpServletRequest request, HttpServletResponse response, HttpSession session) {

        Hotel hotel = hotelManager.getById(hotelId);
        User user=null;
        RoomsInventoryForm from = new RoomsInventoryForm(hotelId, noOfRooms, reserveRooms, txtDate);
        HotelRoomUnAvailableVO hotelRoomUnAvailableVO;
        DateUtil date = new DateUtil(from.getCheckInDate());
        int days = (int) date.getDifferenceInDays(from.getCheckOutDate());

        if(!hotel.getNoOfRooms().equals(noOfRooms)){
            hotel.setNoOfRooms(noOfRooms);
            hotelManager.saveOrUpdate(hotel);
            hotel = hotelManager.getById(hotelId);
        }

        if(hotel.getNoOfRooms()<reserveRooms){
            reserveRooms=hotel.getNoOfRooms();
        }
        for(int i=0; i<days; i++){
            roomsInventoryManager.saveOrUpdate(hotelId, reserveRooms, date.toDate(), user);
            date.moveNexDay();
        }
        ModelAndView modelAndView = new ModelAndView("redirect:/admin/" + WudstayMappings.VIEW_HOTEL_DETAILS);
        modelAndView.addObject("hotelId", hotelId);
        return modelAndView;
    }
*/
}
