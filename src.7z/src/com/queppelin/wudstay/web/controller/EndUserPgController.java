package com.queppelin.wudstay.web.controller;

import com.queppelin.wudstay.exception.CustomGenericException;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.*;
import com.queppelin.wudstay.util.*;
import com.queppelin.wudstay.vo.*;
import com.queppelin.wudstay.vo.custom.BookingDetailsVO;
import com.queppelin.wudstay.vo.custom.DiscountCouponInfo;
import com.queppelin.wudstay.vo.custom.HotelAvailabilityVO;
import com.queppelin.wudstay.vo.custom.PayUVO;
import org.apache.commons.lang.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.security.MessageDigest;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;


@Controller
@RequestMapping("/pg")
public class EndUserPgController {

	public static final Logger logger = LoggerFactory.getLogger(EndUserPgController.class);
	private static SimpleDateFormat dateFormat_ddMMyyyy = new SimpleDateFormat("dd/MM/yyyy");

	@Autowired
	IPgHotelManager pgHotelManager;

	@Autowired
	IPgScheduleVisitsManager pgScheduleVisitsManager;

	@Autowired
	ICityManager cityManager;

	@Autowired
	IHotelRoomManager hotelRoomManager;

	@Autowired
	ILocationManager locationManager;

	@Autowired
	IPgTypeManager pgTypeManager;

	@Autowired
	IHotelAmenityManager hotelAmenityManager;

	@Autowired
	IHotelDescriptionManager hotelDescriptionManager;

	@Autowired
	INumberVerificationManager numberVerificationManager;

	@Autowired
	IHotelBookingManager hotelBookingManager;

	@Autowired
	IHotelAdministratorManager hotelAdministratorManager;

	@Autowired
	IPgHotelAdministratorManager pgHotelAdministratorManager;

	@Autowired
	ICouponCodeManager couponCodeManager;


	/*@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST}, value = WudstayMappings.SCHEDULE_VISIT)
	public ModelAndView scheduleVisit(@RequestParam String mobileNumber, @RequestParam String name, @RequestParam String email, @RequestParam String meetingTime,
										   HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		ModelAndView modelAndView =  new ModelAndView(WudstayConstants.SCHEDULE_CONFIRM_PAGE);
		try {
			Date dtMeetingTime= new Date();
			PgScheduleVisits scheduleVisit = new PgScheduleVisits();
			scheduleVisit.setGuestName(name==null? "" : name.trim());
			scheduleVisit.setGuestEmail(email==null? "" : email.trim());
			scheduleVisit.setGuestPhone(mobileNumber==null? "" : mobileNumber.trim());
			scheduleVisit.setMeetingTime(dtMeetingTime);

			pgScheduleVisitsManager.saveOrUpdate(scheduleVisit);

			modelAndView.addObject("name", scheduleVisit.getGuestName());
			modelAndView.addObject("email", scheduleVisit.getGuestEmail());
			modelAndView.addObject("mobileNumber", scheduleVisit.getGuestPhone());
			modelAndView.addObject("TransactionId", scheduleVisit.getTransactionId());
			modelAndView.addObject("meetingTime", "26/11/2015 10:30PM");
			modelAndView.addObject("pgDisplayName", "pgDisplayName");
			modelAndView.addObject("pgAddress", "pgAddress");

		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return modelAndView;
	}*/
	@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST}, value = WudstayMappings.SCHEDULE_VISIT)
	public ModelAndView scheduleVisit(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView(WudstayConstants.SCHEDULE_CONFIRM_PAGE);
		try {
			String meetingTime = request.getParameter("meetingTime");
			String meetingDate = request.getParameter("meetingDate");
			String meetingDateTime = "";

			String name = request.getParameter("name");
			String email = request.getParameter("email");
			String mobileNumber = request.getParameter("mobileNumber");
			Date dtMeetingTime = new Date();
			PgScheduleVisits scheduleVisit = new PgScheduleVisits();
			scheduleVisit.setGuestName(name == null ? "" : name.trim());
			scheduleVisit.setGuestEmail(email == null ? "" : email.trim());
			scheduleVisit.setGuestPhone(mobileNumber == null ? "" : mobileNumber.trim());

			try {
				meetingDate = (meetingDate == null || "".equals(meetingDate.trim())) ? dateFormat_ddMMyyyy.format(new Date()) : meetingDate.trim();
				meetingTime = (meetingTime == null || "".equals(meetingTime.trim())) ? "09:00 PM" : meetingTime.trim();
				meetingDateTime = meetingDate.trim() + " " + meetingTime.trim();
				SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy HH:mm aa");// DD-MM-YYYY HH:mm a
				dtMeetingTime = format.parse(meetingDateTime);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			scheduleVisit.setMeetingTime(dtMeetingTime);

			modelAndView.addObject("pgDisplayName", " ");
			modelAndView.addObject("pgAddress", " ");
			try {
				String id = request.getParameter("pgHotelId");
				Long pgHotelId = Long.parseLong(id.trim());
				PgHotel pgHotel = pgHotelManager.getById(pgHotelId);

				scheduleVisit.setHotel(pgHotel);
				pgScheduleVisitsManager.saveOrUpdate(scheduleVisit);

				modelAndView.addObject("pgDisplayName", pgHotel.getDisplayName());
				modelAndView.addObject("pgAddress", pgHotel.getDisplayAddress());
				//------------------------------------------------------------------------------------------------------
				try {
					String msg = "Dear " + name + ", this is to confirm that you've scheduled a visit to the '" + pgHotel.getDisplayName() + "' house/PG via WudStay. Address: " + pgHotel.getDisplayAddress();
					msg = msg + " Time of visit : + " + meetingDateTime;
					msg = msg + ". For any assistance you can call us anytime at +62822 8539 0099.";

					WudstayUtil.sendConfirmationMessage(msg, mobileNumber);
					Map<String, Object> emailData = new HashMap<String, Object>();
					emailData.put("GUEST", name);
					emailData.put("GUEST_PHONE", mobileNumber);
					emailData.put("GUEST_EMAIL", email);

					emailData.put("BOOKING_ID", scheduleVisit.getTransactionId());

					emailData.put("PG_NAME", pgHotel.getDisplayName());
					emailData.put("PG_ADDRESS", pgHotel.getDisplayAddress());
					emailData.put("DATE_AND_TIME_OF_VISIT", meetingDateTime);
					//emailData.put("PG_PRICE", pgHotel.getPrice());
					emailData.put("PG_PRICE", pgHotel.getSingleOccupancyWudstayPrice());


					List<String> ccList = new ArrayList<String>();
					ccList.add("support@tinggal.com");
					String[] bccArray = new String[]{"prafulla@tinggal.com", "praveen.k@tinggal.com", "support@tinggal.com", "surender.r@wudstay.com"};
					EmailSender.getInstance().sendEmail(email, "Visit Confirmation", emailData, WudstayConstants.VISIT_CONFIRMATION_EMAIL_BODY, ccList, bccArray);

					/*
					EmailSender.getInstance().sendEmail(email, "Visit Confirmation", emailData, WudstayConstants.VISIT_CONFIRMATION_EMAIL_BODY, ccList);
					String hotelAdministratorEmail = "support@wudstay.com";
					PgHotelAdministrator hotelAdministrator = pgHotelAdministratorManager.getPgHotelAdminByHotelId(pgHotel.getId());
					if (hotelAdministrator.getUser().getEmail() != null && !hotelAdministrator.getUser().getEmail().trim().equals("")) {
						hotelAdministratorEmail = hotelAdministrator.getUser().getEmail();
					}
					if (pgHotel.getContactPersonEmail1() != null && !pgHotel.getContactPersonEmail1().trim().equals("")) {
						ccList.add(pgHotel.getContactPersonEmail1());
					}
					if (pgHotel.getContactPersonEmail2() != null && !pgHotel.getContactPersonEmail2().trim().equals("")) {
						ccList.add(pgHotel.getContactPersonEmail2());
					}
					EmailSender.getInstance().sendEmail(hotelAdministratorEmail, "Visit Confirmation", emailData, WudstayConstants.VISIT_CONFIRMATION_EMAIL_BODY, ccList);
					*/
				} catch (Exception ex) {
					ex.printStackTrace();
				}
				//------------------------------------------------------------------------------------------------------
			} catch (Exception ex) {
				ex.printStackTrace();
			}

			modelAndView.addObject("name", scheduleVisit.getGuestName());
			modelAndView.addObject("email", scheduleVisit.getGuestEmail());
			modelAndView.addObject("mobileNumber", scheduleVisit.getGuestPhone());
			modelAndView.addObject("TransactionId", scheduleVisit.getTransactionId());
			modelAndView.addObject("meetingTime", meetingDateTime);// SimpleDateFormat dd-MM-yyyy HH:mm);


		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return modelAndView;
	}

	//----------------------------------------

	@RequestMapping("/")
	public ModelAndView searchPgDefault(HttpServletRequest request, HttpServletResponse response, HttpSession session){
		return searchHotelsByCity("Gurgaon",  request,  response,  session);
	}
	/*if(pgCity == null || "".equals(pgCity.trim())){
				pgCity = "Gurgaon";
			}

			City city = cityManager.getByCityName(pgCity);
			Long cityId = city.getCityId();
			List<PgHotel> hotelList = new ArrayList<PgHotel>();

			if(pglocality==null || "".equals(pglocality.trim())){
				hotelList = pgHotelManager.getHotelByCityId(cityId);
			}else{
				List<Long> ids = new ArrayList<Long>();
				Set<Location> locSet = city.getLocations();
				for(Location loc: locSet){
					if(pglocality.trim().equalsIgnoreCase(loc.getLocationName().trim())){
						ids.add(loc.getLocationId());
					}
				}
				if(ids.size()>0) {
					hotelList = pgHotelManager.getHotelBylocationIds(ids);
				}
			}*/
	/*@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST }, value = WudstayMappings.SEARCH_PG)
	public ModelAndView searchPg_old(HttpServletRequest request, HttpServletResponse response, HttpSession session)   {
		ModelAndView modelAndView =  new ModelAndView("pgSearchResult");
		City city = null;
		try {
			Long cityId = null;
			String sortBy="";
			Long locationId = null;
			String roomTypeIds="1,2,3";//List<Long> roomTypeIdList = WudstayUtil.getRoomTypeIdList(roomTypeIds);
			Integer priceSortType=0;
			Integer ratingSortType=0;
			List<PgHotel> hotelList = new ArrayList<PgHotel>();
			try {
				String pgGender = request.getParameter("pgGender");
				String pgGenderId = request.getParameter("pgGenderId");
				if (pgGender != null && pgGenderId != null) {
					roomTypeIds = "" + Long.parseLong(pgGenderId.trim());
				}
			}catch (Exception ex){
				ex.printStackTrace();
			}

			try {
				String pglocality = request.getParameter("pglocality");
				String pglocalityId = request.getParameter("pglocalityId");
				if (pglocality != null && pglocalityId != null) {
					locationId =   Long.parseLong(pglocalityId.trim());
				}
			}catch (Exception ex){
				ex.printStackTrace();
			}

			try {
				String pgCity = request.getParameter("pgCity");
				if(pgCity == null)
					pgCity="Gurgaon";
				String pgCityId = request.getParameter("pgCityId");
				if ((pgCity != null  || pgCity == null) && pgCityId != null) {
					cityId = Long.parseLong(pgCityId.trim());
					city = cityManager.getById(cityId);
				}else if (pgCity != null){
					city = cityManager.getByCityName(pgCity.trim());
					cityId=  city.getCityId();
				}
			}catch (Exception ex){
				ex.printStackTrace();
			}
			try {
				List<Long> roomTypeIdList = WudstayUtil.getRoomTypeIdList(roomTypeIds);

				HashMap<String, Object> searchParamMap = (HashMap<String, Object>) session.getAttribute(WudstayConstants.SEARCH_PARAM_MAP);

				int rooms = (Integer) searchParamMap.get("rooms");
				int persons = (Integer) searchParamMap.get("persons");
				hotelList = pgHotelManager.filterHotels(locationId, cityId, roomTypeIdList, sortBy, priceSortType, ratingSortType, persons / rooms);
				hotelList = WudstayUtil.processPgHotelList(hotelList, rooms, persons);
				WudstayUtil.setAmenitiesForPgHotel(hotelList);

			}catch (Exception ex){

			}
			List<Location> locationList = locationManager.getLocationsByCityId(cityId);
			List<PgType> pgTypeList = pgTypeManager.list();

			modelAndView.addObject("NO_OF_FILTERED_HOTELS", hotelList.size());
			modelAndView.addObject("city", city.getCityName());
			modelAndView.addObject("cityId", cityId);
			modelAndView.addObject("isAllRoomTypeSelected", Boolean.FALSE);
			modelAndView.addObject("locationList", locationList);
			modelAndView.addObject("pgTypeList", pgTypeList); //modelAndView.addObject("roomTypeList", roomTypeList);
			modelAndView.addObject("hotelList", hotelList);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return modelAndView;
	}*/

	@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST }, value = WudstayMappings.SEARCH_PG)
	public ModelAndView searchPg_old(HttpServletRequest request, HttpServletResponse response, HttpSession session)   {
		ModelAndView modelAndView =  new ModelAndView("pgSearchResult");
		try {
			Long cityId = null;
			City city = null;

			Long  lngPgGenderId=null;
			Long  lngPglocalityId=null;

			try {
				String pgCity = request.getParameter("pgCity");
				if(pgCity == null)
					pgCity="Gurgaon";
				String pgCityId = request.getParameter("pgCityId");
				if ((pgCity != null  || pgCity == null) && pgCityId != null) {
					cityId = Long.parseLong(pgCityId.trim());
					city = cityManager.getById(cityId);
				}else if (pgCity != null){
					city = cityManager.getByCityName(pgCity.trim());
					cityId=  city.getCityId();
				}
			}catch (Exception ex){
				ex.printStackTrace();
			}



			HashMap<String, Object> searchParamMap = refreshSearchParamsHashMap(session, city );
			int rooms = (Integer) searchParamMap.get("rooms");
			int persons = (Integer) searchParamMap.get("persons");
			String checkIn = (String) searchParamMap.get("checkIn");
			String checkOut = (String) searchParamMap.get("checkOut");
			extractSearchParam(searchParamMap,  modelAndView);

			List<PgHotel> hotelList = pgHotelManager.getHotelByCityId(cityId, persons/rooms);

			try {
				String pgGender = request.getParameter("pgGender");
				String pgGenderId = request.getParameter("pgGenderId");
				if (pgGender != null && pgGenderId != null) {
					lngPgGenderId =   Long.parseLong(pgGenderId.trim());
				}
			}catch (Exception ex){
				ex.printStackTrace();
			}

			try {
				String pglocality = request.getParameter("pglocality");
				String pglocalityId = request.getParameter("pglocalityId");
				if (pglocality != null && pglocalityId != null) {
					lngPglocalityId =   Long.parseLong(pglocalityId.trim());
				}
			}catch (Exception ex){
				ex.printStackTrace();
			}

			if(lngPglocalityId!=null){
				for(Iterator<PgHotel> item = hotelList.iterator(); item.hasNext();) {
					PgHotel pg = item.next();
					try {
						if(!lngPglocalityId.equals(pg.getLocation().getLocationId())){
							item.remove();
						}
					}catch (Exception ex){
						ex.printStackTrace();
					}
				}
			}
			if(lngPgGenderId!=null){
				for(Iterator<PgHotel> item = hotelList.iterator(); item.hasNext();) {
					PgHotel pg = item.next();
					try {
						if(!lngPgGenderId.equals(pg.getPgType().getPgTypeId())){
							item.remove();
						}
					}catch (Exception ex){
						ex.printStackTrace();
					}
				}
			}

			hotelList = WudstayUtil.processPgHotelList(hotelList, rooms, persons);
			WudstayUtil.setAmenitiesForPgHotel(hotelList, pgHotelManager);

			List<Location> locationList = locationManager.getLocationsByCityId(cityId);
			locationList = filterPgLocations( cityId, locationList);
			List<PgType> pgTypeList = pgTypeManager.list();

			modelAndView.addObject("NO_OF_FILTERED_HOTELS", hotelList.size());
			modelAndView.addObject("city", city.getCityName());
			modelAndView.addObject("cityId", cityId);
			modelAndView.addObject("isAllRoomTypeSelected", Boolean.FALSE);
			modelAndView.addObject("locationList", locationList);
			modelAndView.addObject("pgTypeList", pgTypeList); //modelAndView.addObject("roomTypeList", roomTypeList);
			modelAndView.addObject("hotelList", hotelList);
		} catch (Exception e) {
			//e.printStackTrace();
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return modelAndView;
	}

	@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.SEARCH_HOTELS_BY_CITY)
	public ModelAndView searchHotelsByCity(@PathVariable String cityName, HttpServletRequest request, HttpServletResponse response, HttpSession session)   {
		ModelAndView modelAndView =  new ModelAndView("pgSearchResult");
		try {
			Long selectedLocation = new Long(0);
			Long selectedGender = new Long(0);
			List<City> cityList = cityManager.getAllCities();
			modelAndView.addObject("cityList", cityList);
			City city = cityManager.getByCityName(cityName);
			//------------  City not found
			if(city==null){
				String hotelNameOrId = new String(cityName);
				return fetchHotelDetails(hotelNameOrId, null, request, response, session);
			}
			//------------ ------------
			Long cityId = city.getCityId();

			HashMap<String, Object> searchParamMap = refreshSearchParamsHashMap(session, city );
			int rooms = (Integer) searchParamMap.get("rooms");
			int persons = (Integer) searchParamMap.get("persons");
			String checkIn = (String) searchParamMap.get("checkIn");
			String checkOut = (String) searchParamMap.get("checkOut");
			extractSearchParam(searchParamMap,  modelAndView);

			List<PgHotel> hotelList = pgHotelManager.getHotelByCityId(cityId, persons/rooms);

			if(request.getParameter("pglocalityId")!=null){
				String strPglocalityId = request.getParameter("pglocalityId");
				if("".equals(strPglocalityId)){
					// do nothing
				}else{
					Long lngPglocalityId = Long.parseLong(strPglocalityId.trim());
					Iterator<PgHotel> it = hotelList.iterator();
					while(it.hasNext()){
						PgHotel pg = it.next();
						Location location = pg.getLocation();
						if(lngPglocalityId.equals(location.getLocationId())){
							selectedLocation = location.getLocationId();
						}else{
							it.remove();
						}
					}
				}
			}
			if(request.getParameter("pgGenderId")!=null){
				String strPgGenderId = request.getParameter("pgGenderId");
				if("".equals(strPgGenderId)){
					// do nothing
				}else{
					Long lngPgGenderId = Long.parseLong(strPgGenderId.trim());
					Iterator<PgHotel> it = hotelList.iterator();
					while(it.hasNext()){
						PgHotel pg = it.next();
						PgType pgType = pg.getPgType();
						if(lngPgGenderId.equals(pgType.getPgTypeId())){
							selectedGender = pgType.getPgTypeId();  // do nothing
						}else{
							it.remove();
						}
					}
				}
			}


			hotelList = WudstayUtil.processPgHotelList(hotelList, rooms, persons);
			WudstayUtil.setAmenitiesForPgHotel(hotelList, pgHotelManager);

			List<Location> locationList = locationManager.getLocationsByCityId(cityId);
			locationList = filterPgLocations( cityId, locationList);
			List<PgType> pgTypeList = pgTypeManager.list();

			modelAndView.addObject("NO_OF_FILTERED_HOTELS", hotelList.size());
			modelAndView.addObject("city", city.getCityName());
			modelAndView.addObject("cityId", cityId);
			modelAndView.addObject("isAllRoomTypeSelected", Boolean.FALSE);
			modelAndView.addObject("locationList", locationList);
			modelAndView.addObject("pgTypeList", pgTypeList); //modelAndView.addObject("roomTypeList", roomTypeList);
			modelAndView.addObject("hotelList", hotelList);
			modelAndView.addObject("SelectedLocation", selectedLocation);
			modelAndView.addObject("SelectedGender", selectedGender);

		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return modelAndView;
	}
	@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.GET_HOTEL_DETAILS)
	public ModelAndView getHotelDetails(@RequestParam(required=false)  String sortBy, @RequestParam(required=false)  Long locationId, @RequestParam(required=false)  String roomTypeIds,
										@RequestParam Long hotelId, @RequestParam(required=false) Long cityId,
										HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		Long lngCityId = null;
		try {
			lngCityId = getOptionalRequestParam(cityId, null);
			if(lngCityId==null){
				PgHotel hotel = pgHotelManager.getById(hotelId);
				lngCityId = hotel.getLocation().getCity().getCityId();
			}
			refreshSearchParamsHashMap(session, lngCityId);
		}catch (Exception ex){
			ex.printStackTrace();
		}
		return fetchHotelDetails(getOptionalRequestParam(sortBy,""), getOptionalRequestParam(locationId,null), getOptionalRequestParam(roomTypeIds,""), hotelId, lngCityId, request, response, session);
	}

	@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST}, value = WudstayMappings.FILTER_HOTELS)
	public @ResponseBody List<PgHotel> filterHotels(@RequestParam Long cityId, @RequestParam String sortBy, @RequestParam String locationIds,
												  @RequestParam String roomTypeIds, Integer priceSortType, Integer ratingSortType, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		List<PgHotel> hotelList = new ArrayList<PgHotel>();
		try {
			List<Long> roomTypeIdList = WudstayUtil.getRoomTypeIdList(roomTypeIds);
			List<Long> locationIdList = WudstayUtil.getRoomTypeIdList(locationIds);

			HashMap<String, Object> searchParamMap = (HashMap<String, Object>) session.getAttribute(WudstayConstants.SEARCH_PARAM_MAP);
			int rooms = WudstayConstants.DEFAULT_PG_ROOMS;
			int persons = WudstayConstants.DEFAULT_PG_PERSONS;
			try {
				rooms = (Integer) searchParamMap.get("rooms");
				persons = (Integer) searchParamMap.get("persons");
			}catch (NullPointerException ex){
				ex.printStackTrace();
			}
			hotelList = pgHotelManager.filterHotels(locationIdList, cityId, roomTypeIdList, sortBy, priceSortType, ratingSortType, persons/rooms);

			hotelList =  WudstayUtil.processPgHotelList(hotelList, rooms, persons);
			WudstayUtil.setAmenitiesForPgHotel(hotelList, pgHotelManager);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return hotelList;
	}
	/*
	@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST}, value = WudstayMappings.FILTER_HOTELS)
	public @ResponseBody List<PgHotel> filterHotels(@RequestParam Long cityId, @RequestParam String sortBy, @RequestParam Long locationId,
												  @RequestParam String roomTypeIds, Integer priceSortType, Integer ratingSortType, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		List<PgHotel> hotelList = new ArrayList<PgHotel>();
		try {
			List<Long> roomTypeIdList = WudstayUtil.getRoomTypeIdList(roomTypeIds);

			HashMap<String, Object> searchParamMap = (HashMap<String, Object>) session.getAttribute(WudstayConstants.SEARCH_PARAM_MAP);
			int rooms = WudstayConstants.DEFAULT_PG_ROOMS;
			int persons = WudstayConstants.DEFAULT_PG_PERSONS;
			try {
				rooms = (Integer) searchParamMap.get("rooms");
				persons = (Integer) searchParamMap.get("persons");
			}catch (java.lang.NullPointerException ex){
				ex.printStackTrace();
			}
			hotelList = pgHotelManager.filterHotels(locationId, cityId, roomTypeIdList, sortBy, priceSortType, ratingSortType, persons/rooms);

			hotelList =  WudstayUtil.processPgHotelList(hotelList, rooms, persons);
			WudstayUtil.setAmenitiesForPgHotel(hotelList, pgHotelManager);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return hotelList;
	}
	 */













	//--------------------------------------------------------------------

	public ModelAndView fetchHotelDetails(String hotelNameOrId, String cityName, HttpServletRequest request, HttpServletResponse response, HttpSession session) throws WudstayException {
		PgHotel hotel = getHotelByNameOrId(hotelNameOrId, cityName);
		City city = hotel.getLocation().getCity();
		refreshSearchParamsHashMap(session, city);
		return fetchHotelDetails("",null,"", hotel.getId(), city.getCityId(), request, response, session);
	}

	public ModelAndView fetchHotelDetails(String sortBy, Long locationId, String roomTypeIds, Long hotelId, Long cityId,
										  HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		ModelAndView modelAndView =  new ModelAndView("pgViewDetails");
		try {
			HashMap<String, Object> searchParamMap = (HashMap<String, Object>) session.getAttribute(WudstayConstants.SEARCH_PARAM_MAP);
			DateUtil today = new DateUtil(new Date());
			modelAndView.addObject("meetingDate_START", today.toDisplayDate(today.toDate()));
			today.moveNexMonth();
			today.moveLastDay();
			modelAndView.addObject("meetingDate_END", today.toDisplayDate(today.toDate()));


			Integer rooms = (Integer) searchParamMap.get("rooms");
			Integer persons = (Integer) searchParamMap.get("persons");
			City city = cityManager.getById(cityId);
			PgHotel hotel = pgHotelManager.getById(hotelId);
			int minPax = persons/rooms;
			if(minPax == 1) {
				hotel.setPrice(hotel.getSingleOccupancyWudstayPrice());
			} else if(minPax == 2) {
				hotel.setPrice(hotel.getDoubleOccupancyWudstayPrice());
			} else if(minPax == 3) {
				hotel.setPrice(hotel.getTripleOccupancyWudstayPrice());
			}
			List<Long> roomTypeIdList = WudstayUtil.getRoomTypeIdList(roomTypeIds);
			List<Long> locationIdList = new ArrayList<Long>(); //WudstayUtil.getRoomTypeIdList(roomTypeIds);
			locationIdList.add(locationId);
			//List<HotelAmenity> hotelAmenityList = hotelAmenityManager.getHotelAmenitiesByHotelId(hotelId);
			List<PgHotelAmenity> hotelAmenityList = pgHotelManager.getPgHotelAmenitiesByHotelId(hotelId);

			List<PgHotel> hotelList = pgHotelManager.filterHotels(locationIdList, cityId, roomTypeIdList, sortBy, Integer.valueOf(0), Integer.valueOf(1), persons/rooms);
			List<PgHotel> suggestedHotelList = pgHotelManager.getSuggestedHotelList(hotel);
			for (PgHotel suggestedHotel : suggestedHotelList) {
				suggestedHotel.setPrice(suggestedHotel.getTripleOccupancyWudstayPrice());
			}
			//List<HotelDescription> hotelDescriptionList = hotelDescriptionManager.getHotelDescriptionsByHotelId(hotel.getId());
			List<PgHotelDescription> hotelDescriptionList = pgHotelManager.getPgHotelDescriptionsByHotelId(hotel.getId());
			List<String> hotelImageList = WudstayUtil.getPgHotelImages(hotel.getId()); //getHotelImages(hotel.getId());
			WudstayUtil.setAmenitiesForPgHotel(suggestedHotelList, pgHotelManager);
			setNextAndPreviousHotelRoomIdInModel(hotel, hotelList, modelAndView);

			String checkIn = (String) searchParamMap.get("checkIn");
			String checkOut = (String) searchParamMap.get("checkOut");
			DateFormat fromFormat = new SimpleDateFormat("yyyy-MM-dd");
			fromFormat.setLenient(false);
			DateFormat toFormat = new SimpleDateFormat("dd/MM/yyyy");
			toFormat.setLenient(false);
			Date date = fromFormat.parse(checkIn);
			modelAndView.addObject("checkIn", toFormat.format(date));
			date = fromFormat.parse(checkOut);
			modelAndView.addObject("checkOut", toFormat.format(date));
			modelAndView.addObject("city", city.getCityName());
			modelAndView.addObject("cityId", cityId);
			modelAndView.addObject("sortBy", sortBy);
			modelAndView.addObject("locationId", locationId);
			modelAndView.addObject("roomTypeIds", roomTypeIds);
			modelAndView.addObject("rooms", rooms);
			modelAndView.addObject("persons", persons);
			modelAndView.addObject("hotel", hotel);
			modelAndView.addObject("hotelAmenityList", hotelAmenityList);
			modelAndView.addObject("suggestedHotelList", suggestedHotelList);
			modelAndView.addObject("hotelDescriptionList", hotelDescriptionList);
			modelAndView.addObject("hotelImageList", hotelImageList);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return modelAndView;
	}


    //--------------------------------------------------------------------
	private PgHotel getHotelByNameOrId(String hotelNameOrId, String cityName){
		PgHotel hotel=null;
		try{
			Long hotelId = Long.parseLong(hotelNameOrId);
			hotel = pgHotelManager.getById(hotelId);
			return hotel;
		}catch (NumberFormatException ex){
			String hotelName = new String(hotelNameOrId.trim());
			try {
				List<PgHotel> hotelList;
				if(cityName!=null && !"".equals(cityName.trim())){
					City city = cityManager.getByCityName(cityName);
					hotelList = pgHotelManager.getHotelByCityId(city.getCityId());
				}else{
					hotelList = pgHotelManager.list();
				}
				for(PgHotel dbHotel: hotelList){
					if( hotelName.equalsIgnoreCase(dbHotel.getDisplayName().trim()) || hotelNameOrId.equalsIgnoreCase(dbHotel.getDisplayName().replace(" ", ""))){
						hotel = dbHotel;
						break;
					}
				}
				return hotel;
			} catch (WudstayException e) {
				e.printStackTrace();
				return hotel;
			}
		}
	}
	private void setNextAndPreviousHotelRoomIdInModel(PgHotel hotel, List<PgHotel> hotelList, ModelAndView modelAndView) {
		for(int i = 0; i < hotelList.size(); i++) {
			if(hotelList.get(i).getId().equals(hotel.getId())) {
				modelAndView.addObject("CURRENT_SRNO_IN_FILTERED_HOTELS",  new Integer(i+1));
				if(i - 1 < 0) {
					modelAndView.addObject("previousHotelId", new Integer(0));
				} else {
					modelAndView.addObject("previousHotelId", hotelList.get(i-1).getId());
				}

				if(i + 1 == hotelList.size()) {
					modelAndView.addObject("nextHotelId", new Integer(0));
				} else {
					modelAndView.addObject("nextHotelId", hotelList.get(i+1).getId());
				}
				break;
			}
		}
		modelAndView.addObject("NO_OF_FILTERED_HOTELS", hotelList.size());

	}
	private String getOptionalRequestParam(String requestParam, String defaultValue){
		if(requestParam == null  || "NULL".equals(requestParam)) {
			return defaultValue;
		}else{
			return requestParam;
		}
	}
	private Long getOptionalRequestParam(Long requestParam, Long defaultValue){
		if(requestParam == null  || "NULL".equals(requestParam)) {
			return defaultValue;
		}else{
			return requestParam;
		}
	}

	private ModelAndView extractSearchParam(HashMap<String, Object> searchParamMap, ModelAndView modelAndView) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

		try{
			int rooms = (Integer) searchParamMap.get("rooms");
			int persons = (Integer) searchParamMap.get("persons");

			String checkIn = (String) searchParamMap.get("checkIn");
			String checkOut = (String) searchParamMap.get("checkOut");
			modelAndView.addObject("checkIn", dateFormat.format(format.parse(checkIn)));
			modelAndView.addObject("checkOut",dateFormat.format(format.parse(checkOut)));

			modelAndView.addObject("rooms", rooms);
			modelAndView.addObject("persons", persons);
		}catch (Exception ex){
			ex.printStackTrace();
		}
		return modelAndView;
	}

	private HashMap<String, Object> refreshSearchParamsHashMap(HttpSession session, Long cityId ) throws WudstayException {
		City city = cityManager.getById(cityId);
		return refreshSearchParamsHashMap(session, city);
	}
	private HashMap<String, Object> refreshSearchParamsHashMap(HttpSession session, String cityName ) throws WudstayException {
		City city = cityManager.getByCityName(cityName);
		return refreshSearchParamsHashMap(session, city);
	}
	private HashMap<String, Object> refreshSearchParamsHashMap(HttpSession session, City city ) throws WudstayException {
		return refreshSearchParamsHashMap(session, city.getCityId(), city.getCityName());
	}
	private HashMap<String, Object> refreshSearchParamsHashMap(HttpSession session, Long cityId , String cityName ) throws WudstayException {
		HashMap<String, Object> searchParamsHashMap = new HashMap<String, Object>();
		searchParamsHashMap.put("cityId", cityId);
		searchParamsHashMap.put("city",     cityName);
		searchParamsHashMap.put("checkIn",  WudstayUtil.getDefaultCheckInDate());
		searchParamsHashMap.put("checkOut", WudstayUtil.getDefaultCheckOutDate());
		searchParamsHashMap.put("rooms",    WudstayConstants.DEFAULT_PG_ROOMS);
		searchParamsHashMap.put("persons",  WudstayConstants.DEFAULT_PG_PERSONS);
		/*String city, Long cityId, String checkIn, String checkOut, Integer rooms, Integer persons*/
		if(session == null || session.getAttribute(WudstayConstants.SEARCH_PARAM_MAP)==null){
			session.setAttribute(WudstayConstants.SEARCH_PARAM_MAP, searchParamsHashMap);
			return searchParamsHashMap;
		}else{
			searchParamsHashMap = (HashMap<String, Object>) session.getAttribute(WudstayConstants.SEARCH_PARAM_MAP);
			if(searchParamsHashMap.get("cityId")==null)
				searchParamsHashMap.put("cityId", cityId);
			if(searchParamsHashMap.get("city")==null)
				searchParamsHashMap.put("city",     cityName);
			if(searchParamsHashMap.get("checkIn")==null)
				searchParamsHashMap.put("checkIn",  WudstayUtil.getDefaultCheckInDate());
			if(searchParamsHashMap.get("checkOut")==null)
				searchParamsHashMap.put("checkOut", WudstayUtil.getDefaultCheckOutDate());
			if(searchParamsHashMap.get("rooms")==null)
				searchParamsHashMap.put("rooms",    WudstayConstants.DEFAULT_PG_ROOMS);
			if(searchParamsHashMap.get("persons")==null)
				searchParamsHashMap.put("persons",  WudstayConstants.DEFAULT_PG_PERSONS);

			return searchParamsHashMap;
		}
	}
	private List<Location> filterPgLocations(Long cityId, List<Location> locationList){
		try {
			List<PgHotel> hotelList = pgHotelManager.getHotelByCityId(cityId, 3 / 1);

			for(Iterator<Location> item = locationList.iterator(); item.hasNext();) {
				Location loc = item.next();
				try {
					Boolean found=Boolean.FALSE;
					for(PgHotel pg : hotelList){
						Long lngPglocalityId = pg.getLocation().getLocationId();
						if(loc.getLocationId().equals(lngPglocalityId)){
							found=Boolean.TRUE;
							break;
						}
					}
					if(found==Boolean.FALSE){
						item.remove();
					}
				}catch (Exception ex){
					ex.printStackTrace();
				}
			}
			return locationList;
		}catch (Exception ex){
			ex.printStackTrace();
			return locationList;
		}
	}

}
