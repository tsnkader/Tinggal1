package com.queppelin.wudstay.web.controller;

import com.queppelin.wudstay.exception.CustomGenericException;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.ICityManager;
import com.queppelin.wudstay.manager.ICouponCodeManager;
import com.queppelin.wudstay.manager.IHdfcTranLogManager;
import com.queppelin.wudstay.manager.IHotelAdministratorManager;
import com.queppelin.wudstay.manager.IHotelAmenityManager;
import com.queppelin.wudstay.manager.IHotelBookingManager;
import com.queppelin.wudstay.manager.IHotelDescriptionManager;
import com.queppelin.wudstay.manager.IHotelManager;
import com.queppelin.wudstay.manager.IHotelRoomManager;
import com.queppelin.wudstay.manager.ILocationManager;
import com.queppelin.wudstay.manager.INumberVerificationManager;
import com.queppelin.wudstay.manager.IPaypalTranLogManager;
import com.queppelin.wudstay.manager.IPayuMobTranManager;
import com.queppelin.wudstay.manager.IPgHotelManager;
import com.queppelin.wudstay.manager.IPgTypeManager;
import com.queppelin.wudstay.manager.IRoomTypeManager;
import com.queppelin.wudstay.util.DateUtil;
import com.queppelin.wudstay.util.EmailSender;
import com.queppelin.wudstay.util.HdfcPaymentUtil;
import com.queppelin.wudstay.util.PayflowproSecureTokenUtil;
import com.queppelin.wudstay.util.PayuPaymentUtil;
import com.queppelin.wudstay.util.SearchParamMapInSession;
import com.queppelin.wudstay.util.VeritransResponse;
import com.queppelin.wudstay.util.VeritransUtil;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.util.WudstayMappings;
import com.queppelin.wudstay.util.WudstayUtil;
import com.queppelin.wudstay.vo.City;
import com.queppelin.wudstay.vo.HdfcTranLogVO;
import com.queppelin.wudstay.vo.HdfcTranResponseVO;
import com.queppelin.wudstay.vo.Hotel;
import com.queppelin.wudstay.vo.HotelAdministrator;
import com.queppelin.wudstay.vo.HotelBooking;
import com.queppelin.wudstay.vo.Location;
import com.queppelin.wudstay.vo.LogsTable;
import com.queppelin.wudstay.vo.NumberVerification;
import com.queppelin.wudstay.vo.PayPalTranLogVO;
import com.queppelin.wudstay.vo.PayuMobTran;
import com.queppelin.wudstay.vo.PgHotel;
import com.queppelin.wudstay.vo.RoomTypeMaster;
import com.queppelin.wudstay.vo.User;
import com.queppelin.wudstay.vo.custom.BookingDetailsVO;
import com.queppelin.wudstay.vo.custom.DiscountCouponInfo;
import com.queppelin.wudstay.vo.custom.HotelAvailabilityVO;
import com.queppelin.wudstay.vo.custom.PayUVO;
import com.queppelin.wudstay.vo.custom.VeritransNotificationWrapper;
import com.queppelin.wudstay.web.filter.WudstayFilter;
import java.io.PrintStream;
import java.io.Serializable;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.commons.lang.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.support.RequestContextUtils;

@Controller
public class EndUserController {
    static long paymenTranId = 1000;
    public static final Logger logger = LoggerFactory.getLogger((Class)EndUserController.class);
    @Autowired
    IHotelManager hotelManager;
    @Autowired
    ICityManager cityManager;
    @Autowired
    IHotelRoomManager hotelRoomManager;
    @Autowired
    ILocationManager locationManager;
    @Autowired
    IRoomTypeManager roomTypeManager;
    @Autowired
    IHotelAmenityManager hotelAmenityManager;
    @Autowired
    IHotelDescriptionManager hotelDescriptionManager;
    @Autowired
    INumberVerificationManager numberVerificationManager;
    @Autowired
    IHotelBookingManager hotelBookingManager;
    @Autowired
    IHotelAdministratorManager hotelAdministratorManager;
    @Autowired
    ICouponCodeManager couponCodeManager;
    @Autowired
    IHdfcTranLogManager hdfcTranLogManager;
    @Autowired
    IPaypalTranLogManager paypalTranLogManager;
    @Autowired
    IPayuMobTranManager payuMobTranManager;
    @Autowired
    IPgTypeManager pgTypeManager;
    @Autowired
    IPgHotelManager pgHotelManager;

    private String getValue(String[] strArr, int index, String defaultValue) {
        String val = defaultValue;
        try {
            val = strArr[index];
        }
        catch (Exception ex) {
            val = defaultValue;
        }
        return val;
    }

    private Integer getValue(String[] strArr, int index, Integer defaultValue) {
        Integer val = defaultValue;
        try {
            val = Integer.parseInt(strArr[index].trim());
        }
        catch (Exception ex) {
            val = defaultValue;
        }
        return val;
    }

    private Long getValue(String[] strArr, int index, Long defaultValue) {
        Long val = defaultValue;
        try {
            val = Long.parseLong(strArr[index].trim());
        }
        catch (Exception ex) {
            val = defaultValue;
        }
        return val;
    }

    @RequestMapping(method={RequestMethod.GET}, value={"veritranslog"})
    public ModelAndView veritransLog(@RequestParam String orderId, HttpServletRequest request, HttpServletResponse response, HttpSession session) throws WudstayException {
        ModelAndView modelAndView = new ModelAndView("veritranslog");
        try {
            HdfcTranLogVO tranLogVO = this.hdfcTranLogManager.getBySecureHash(orderId.trim());
            String description = tranLogVO.getDescription();
            String[] descriptionParts = new String[]{"-"};
            modelAndView.addObject("orderId", (Object)tranLogVO.getSecureHash());
            modelAndView.addObject("Name", (Object)tranLogVO.getName());
            modelAndView.addObject("MobileNumber", (Object)tranLogVO.getPhone());
            modelAndView.addObject("Email", (Object)tranLogVO.getEmail());
            modelAndView.addObject("BookingId", (Object)tranLogVO.getReferenceNo());
            modelAndView.addObject("Amount", (Object)tranLogVO.getAmount());
            if (description != null) {
                descriptionParts = description.split("<#>");
            }
            modelAndView.addObject("description", (Object)description);
            Long logId = this.getValue(descriptionParts, 0, new Long(0));
            modelAndView.addObject("logId", (Object)(logId > 0 ? logId : "-"));
            String referenceNo = this.getValue(descriptionParts, 1, "-");
            modelAndView.addObject("referenceNo", (Object)referenceNo);
            String udf1 = this.getValue(descriptionParts, 2, "-");
            modelAndView.addObject("udf1", (Object)udf1);
            String[] udf1_parts = udf1.split("#");
            String checkInDate = this.getValue(udf1_parts, 0, "-");
            String checkOutDate = this.getValue(udf1_parts, 1, "-");
            Long hotelId = this.getValue(udf1_parts, 2, new Long(0));
            modelAndView.addObject("hotelId", (Object)hotelId);
            try {
                Hotel hotel = (Hotel)this.hotelManager.getById((Serializable)hotelId);
                modelAndView.addObject("HotelDisplayName", (Object)hotel.getHotelDisplayName());
                modelAndView.addObject("HotelDisplayAddress", (Object)hotel.getHotelDisplayAddress());
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
            Integer nights = this.getValue(udf1_parts, 3, new Integer(0));
            modelAndView.addObject("Nights", (Object)nights);
            Integer totalPrice = this.getValue(udf1_parts, 4, new Integer(0));
            modelAndView.addObject("TotalPrice", (Object)totalPrice);
            Integer totalPriceContractual = this.getValue(udf1_parts, 5, new Integer(0));
            modelAndView.addObject("TotalPriceContractual", (Object)totalPriceContractual);
            String roomTypeMaster = this.getValue(udf1_parts, 6, "-");
            modelAndView.addObject("RoomType", (Object)roomTypeMaster);
            String udf2 = this.getValue(descriptionParts, 3, "-");
            String[] udf2_parts = udf2.split("#");
            checkInDate = String.valueOf(checkInDate) + "   [ " + this.getValue(udf2_parts, 0, "-") + " ]";
            modelAndView.addObject("CheckInDate", (Object)checkInDate);
            checkOutDate = String.valueOf(checkOutDate) + "   [ " + this.getValue(udf2_parts, 1, "-") + " ]";
            modelAndView.addObject("CheckOutDate", (Object)checkOutDate);
            Integer rooms = this.getValue(udf2_parts, 2, new Integer(0));
            modelAndView.addObject("Rooms", (Object)rooms);
            Integer persons = this.getValue(udf2_parts, 3, new Integer(0));
            modelAndView.addObject("Persons", (Object)persons);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return modelAndView;
    }

    @RequestMapping(method={RequestMethod.GET, RequestMethod.POST}, value={"veritransPayNowByMobile.do"})
    @ResponseBody
    public VeritransResponse veritransPayNow1(@RequestParam String mobileNumber, @RequestParam String name, @RequestParam String email, @RequestParam(required=false) String countryCode, @RequestParam(required=false) Long hotelId, @RequestParam(required=false) String daterange, @RequestParam(required=false) Integer rooms, @RequestParam(required=false) Integer persons, @RequestParam(required=false) Long cityId, @RequestParam(required=false) String cityName, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        String[] checkInOutDates = SearchParamMapInSession.toCheckInOutDates((String)daterange);
        String checkIn = checkInOutDates[0];
        String checkOut = checkInOutDates[1];
        Integer sourceOfBooking = WudstayConstants.getSourceOfBooking((String)"MOBILE-WEB", (int)10);
        return this.veritransPayNow(mobileNumber, name, email, countryCode, hotelId, checkIn, checkOut, rooms, persons, cityId, cityName, request, response, session, sourceOfBooking);
    }

    @RequestMapping(method={RequestMethod.GET, RequestMethod.POST}, value={"veritransPayNow.do"})
    @ResponseBody
    public VeritransResponse veritransPayNow2(@RequestParam String mobileNumber, @RequestParam String name, @RequestParam String email, @RequestParam(required=false) String countryCode, @RequestParam(required=false) Long hotelId, @RequestParam(required=false) String checkIn, @RequestParam(required=false) String checkOut, @RequestParam(required=false) Integer rooms, @RequestParam(required=false) Integer persons, @RequestParam(required=false) Long cityId, @RequestParam(required=false) String cityName, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        Integer sourceOfBooking = WudstayConstants.getSourceOfBooking((String)"WEB", (int)2);
        return this.veritransPayNow(mobileNumber, name, email, countryCode, hotelId, checkIn, checkOut, rooms, persons, cityId, cityName, request, response, session, sourceOfBooking);
    }

    private VeritransResponse veritransPayNow(String mobileNumber, String name, String email, String countryCode, Long hotelId, String checkIn, String checkOut, Integer rooms, Integer persons, Long cityId, String cityName, HttpServletRequest request, HttpServletResponse response, HttpSession session, Integer sourceOfBooking) {
        if (countryCode == null || "".equals(countryCode.trim())) {
            countryCode = "62";
        }
        String guestMobileNumber = String.valueOf(countryCode) + "-" + mobileNumber;
        VeritransResponse res = new VeritransResponse();
        Integer amount = 0;
        String bookingId = RandomStringUtils.randomAlphanumeric((int)15).toUpperCase();
        HdfcTranLogVO tranLogVO = new HdfcTranLogVO();
        tranLogVO.setAccountId(null);
        tranLogVO.setAddress(null);
        tranLogVO.setAlgo(sourceOfBooking+"");
        tranLogVO.setChannel(null);
        tranLogVO.setCity(null);
        tranLogVO.setCountry("MY");
        tranLogVO.setCurrency("Rp");
        tranLogVO.setMode(null);
        tranLogVO.setPostalCode(null);
        tranLogVO.setReturnUrl(null);
        tranLogVO.setState(null);
        BookingDetailsVO bookingDetailsVO = null;
        HashMap<String, Object> searchParamMap = null;
        if (session.getAttribute("Booking Details") == null) {
            try {
                searchParamMap = (HashMap)this.getSearchParamHashMap(cityName, cityId, WudstayUtil.getFormattedCheckInDate((String)checkIn.trim()), WudstayUtil.getFormattedCheckOutDate((String)checkOut.trim()), rooms, persons);
                session.setAttribute("searchParamsHashMap", (Object)searchParamMap);
                Hotel hotel = (Hotel)this.hotelManager.getById((Serializable)hotelId);
                bookingDetailsVO = WudstayUtil.getBookingDetailsVO((String)cityName, (String)checkIn, (String)checkOut, (Integer)rooms, (Integer)persons, (Hotel)hotel);
                session.setAttribute("Booking Details", (Object)bookingDetailsVO);
                tranLogVO.setMode(hotel.getRoomTypeMaster().getDescription());
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        } else {
            bookingDetailsVO = (BookingDetailsVO)session.getAttribute("Booking Details");
            searchParamMap = (HashMap)session.getAttribute("searchParamsHashMap");
        }
        amount = bookingDetailsVO.getTotalPrice();
        try {
            tranLogVO.setChannel((String)((Object)bookingDetailsVO.getTotalPriceContractual()));
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        try {
            tranLogVO.setName(name);
            tranLogVO.setPhone(guestMobileNumber);
            tranLogVO.setEmail(email);
            tranLogVO.setReferenceNo(bookingId);
            tranLogVO.setAmount(amount + "");
            tranLogVO = this.hdfcTranLogManager.saveLog(tranLogVO);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        Long logId = tranLogVO.getLogId();
        String orderRefId = VeritransUtil.md5HashData((String)logId.toString());
        String hdfcTranDescription = HdfcPaymentUtil.getHdfcTransactionDescription((Long)logId, (String)tranLogVO.getReferenceNo(), (BookingDetailsVO)bookingDetailsVO, (HashMap)searchParamMap);
        tranLogVO.setDescription(hdfcTranDescription);
        tranLogVO.setSecureHash(orderRefId);
        tranLogVO = this.hdfcTranLogManager.saveLog(tranLogVO);
        try {
            res = VeritransUtil.getRedirectUrlForPayment((String)orderRefId, (Integer)amount, (String)bookingId, (String)name, (String)email, (String)guestMobileNumber);
            if ("201".equals(res.getStatus_code())) {
                tranLogVO.setReturnUrl(res.getRedirect_url());
            } else {
                tranLogVO.setReturnUrl(String.valueOf(res.getStatus_code()) + ":" + res.getStatus_message());
            }
        }
        catch (Exception ex) {
            // empty catch block
        }
        return res;
    }

    @RequestMapping(method={RequestMethod.GET, RequestMethod.POST}, value={"veritrans/{responseType}"})
    public ModelAndView veritransTransaction(@PathVariable String responseType, @RequestParam(required=false) String order_id, @RequestParam(required=false) String status_code, @RequestParam(required=false) String transaction_status, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        Map<String, Object> map = this.veritransResLog("VERITRANS_" + (responseType == null ? "NULL" : responseType).toUpperCase(), order_id, status_code, transaction_status, request);
        String resType = (String)map.get("ResponseType");
        List logsList = (List)map.get("logsList");
        Integer sourceOfBooking = 2;
        HdfcTranLogVO tranLogVO = (HdfcTranLogVO)map.get("HdfcTranLogVO");
        String bookingDetailsUDF = "";
        String searchParamUDF = "";
        String description = tranLogVO.getDescription();
        String[] arr = description.split("<#>");
        String referenceNo = arr[1];
        bookingDetailsUDF = arr[2];
        searchParamUDF = arr[3];
        HdfcTranResponseVO hdfcTranResponse = new HdfcTranResponseVO();
        hdfcTranResponse.setBillingName(tranLogVO.getName());
        hdfcTranResponse.setBillingEmail(tranLogVO.getEmail());
        hdfcTranResponse.setBillingPhone(tranLogVO.getPhone());
        hdfcTranResponse.setAmount(tranLogVO.getAmount());
        hdfcTranResponse.setMode(tranLogVO.getAlgo());
        try {
            sourceOfBooking = Integer.parseInt(tranLogVO.getAlgo());
        }
        catch (Exception ex) {
            sourceOfBooking = 2;
        }
        if (responseType != null && "finish".equalsIgnoreCase(responseType)) {
            Long bookingId = tranLogVO.getBookingId();
            String txnid = order_id;
            String mihpayid = "mihpayid";
            String status = "0";
            hdfcTranResponse.setTransactionId(txnid);
            hdfcTranResponse.setPaymentID(mihpayid);
            status = bookingId == null ? "0" : "420";
            hdfcTranResponse.setResponseCode(status);
            return this.hdfcPaymentSucces(bookingDetailsUDF, searchParamUDF, hdfcTranResponse, session, sourceOfBooking);
        }
        return this.hdfcPaymentFailure(bookingDetailsUDF, searchParamUDF, hdfcTranResponse, session, sourceOfBooking);
    }

    private void saveLogsTable(Long refLong, String refString, String description) {
        try {
            SimpleDateFormat dt = new SimpleDateFormat("yyyyy-mm-dd hh:mm:ss");
            String time = dt.format(new Date());
            LogsTable logsTable = new LogsTable();
            logsTable.setRefLong(refLong);
            logsTable.setRefString(refString);
            logsTable.setDescription(String.valueOf(time) + "     " + description);
            this.payuMobTranManager.saveLogsTable(logsTable);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @RequestMapping(method={RequestMethod.GET, RequestMethod.POST}, value={"notificationByveritrans.do"}, consumes={"application/json"}, produces={"application/json"})
    @ResponseBody
    public String greetingJson(@RequestBody String json, HttpServletRequest request) {
        String order_id = null;
        String status_code = null;
        String transaction_status = null;
        try {
            this.saveLogsTable(++paymenTranId, "Log Time", "Start.....");
            this.saveLogsTable(paymenTranId, "RequestBody_Param", json == null ? "NULL" : json);
            String jsomParam = "{";
            try {
                Enumeration parameterList = request.getParameterNames();
                while (parameterList.hasMoreElements()) {
                    String sName = parameterList.nextElement().toString();
                    String[] sMultiple = request.getParameterValues(sName);
                    String sValue = "";
                    if (1 >= sMultiple.length) {
                        sValue = request.getParameter(sName);
                    } else {
                        int i = 0;
                        while (i < sMultiple.length) {
                            sValue = "length: " + sMultiple.length + " ";
                            if (sMultiple[i] != null && !"".equals(sMultiple[i].trim())) {
                                sValue = String.valueOf(sValue) + "[" + i + "] = " + sMultiple[i] + " ";
                            }
                            ++i;
                        }
                    }
                    if (sValue != null && !"".equals(sValue.trim())) {
                        jsomParam = String.valueOf(jsomParam) + sName + ":" + sValue + ",";
                    }
                    if ("order_id".equalsIgnoreCase(sName.trim())) {
                        order_id = sValue;
                        continue;
                    }
                    if ("status_code".equalsIgnoreCase(sName.trim())) {
                        status_code = sValue;
                        continue;
                    }
                    if (!"transaction_status".equalsIgnoreCase(sName.trim())) continue;
                    transaction_status = sValue;
                }
            }
            catch (Exception ex) {
                ex.printStackTrace();
                jsomParam = String.valueOf(jsomParam) + "ERROR" + ":" + ex.getMessage() + ",";
            }
            jsomParam = String.valueOf(jsomParam) + "}";
            this.saveLogsTable(paymenTranId, "Json Of Request Params", jsomParam == null ? "NULL" : json);
            Map<String, Object> map = this.veritransResLog("NOTIFICATION_BY_VERITRANS", order_id, status_code, transaction_status, request);
            return "{\"response_code\": \"0\"}";
        }
        catch (Exception exOuter) {
            this.saveLogsTable(paymenTranId, "Error", WudstayUtil.exceptionPrintStackTrace((Throwable)exOuter));
            return "{\"response_code\": \"1\"}";
        }
    }

    @RequestMapping(method={RequestMethod.GET, RequestMethod.POST}, value={"notificationByveritrans1.do"}, consumes={"application/json"}, produces={"application/json"})
    @ResponseBody
    public String greetingJson(HttpEntity<String> httpEntity) {
        String json = (String)httpEntity.getBody();
        VeritransNotificationWrapper jsonWrapper = new VeritransNotificationWrapper(json);
        System.out.println((Object)jsonWrapper);
        return "DONE";
    }

    @RequestMapping(method={RequestMethod.GET, RequestMethod.POST}, value={"testNotificationByveritrans.do"})
    public ModelAndView testNotificationByveritrans(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("testNotificationByveritrans");
        return modelAndView;
    }

    private Map<String, Object> veritransResLog(String response_type, String order_id, String status_code, String transaction_status, HttpServletRequest request) {
        /*String responseType;
        String statusCode;
        String orderIdMd5;*/
        HashMap<String, Object> map = new HashMap<String, Object>();
        ArrayList<LogsTable> logsList = new ArrayList<LogsTable>();
        String responseType = response_type == null ? "<<NULL>>" : (responseType = String.valueOf("".equals(response_type.trim()) ? "<<EMPTY>>" : response_type) + "                         ");
        String orderIdMd5 = order_id == null ? "<<NULL>>" : (orderIdMd5 = "".equals(order_id.trim()) ? "<<EMPTY>>" : order_id);
        String statusCode = status_code == null ? "<<NULL>>" : (statusCode = "".equals(status_code.trim()) ? "<<EMPTY>>" : status_code);
        String transactionStatus = transaction_status == null ? "<<NULL>>" : ("".equals(transaction_status.trim()) ? "<<EMPTY>>" : transaction_status);
        String currentTimeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date());
        String trmJSON = "{type:'" + responseType.substring(0, 25) + "', time:'" + currentTimeStamp + "', id:'" + orderIdMd5 + "', scode:'" + statusCode + "', status:'" + transactionStatus + "', time:'" + currentTimeStamp + "' }";
        map.put("ResponseType", responseType);
        HdfcTranLogVO tranLogVO = this.hdfcTranLogManager.getBySecureHash(orderIdMd5);
        Long orderTranId = tranLogVO == null ? 0 : tranLogVO.getLogId();
        map.put("ORDER_Id_MD5", orderIdMd5);
        map.put("ORDER_TRAN_Id", orderTranId);
        map.put("HdfcTranLogVO", (Object)tranLogVO);
        LogsTable logsTable = new LogsTable();
        logsTable.setRefLong(orderTranId);
        logsTable.setRefString("RESPONSE_PARAM");
        logsTable.setDescription(trmJSON);
        this.payuMobTranManager.saveLogsTable(logsTable);
        logsList.add(logsTable);
        try {
            Long refTranId = logsTable.getId();
            map.put("refTranId", refTranId);
            Enumeration parameterList = request.getParameterNames();
            while (parameterList.hasMoreElements()) {
                String sName = parameterList.nextElement().toString();
                String[] sMultiple = request.getParameterValues(sName);
                String sValue = "";
                if (1 >= sMultiple.length) {
                    sValue = request.getParameter(sName);
                } else {
                    int i = 0;
                    while (i < sMultiple.length) {
                        sValue = "length: " + sMultiple.length + " ";
                        sValue = String.valueOf(sValue) + " " + i + "==>" + (sMultiple[i] == null ? "NULL" : sMultiple[i]);
                        ++i;
                    }
                }
                if (sValue == null || "".equals(sValue.trim())) continue;
                try {
                    logsTable = new LogsTable();
                    logsTable.setRefLong(orderTranId);
                    logsTable.setRefString(sName);
                    logsTable.setDescription(refTranId + " :{}: " + sValue);
                    this.payuMobTranManager.saveLogsTable(logsTable);
                    logsList.add(logsTable);
                    continue;
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        map.put("logsList", logsList);
        return map;
    }

    @RequestMapping(method={RequestMethod.GET, RequestMethod.POST}, value={"payuResponse/{responseType}/{payuMobTranID}"})
    public ModelAndView androidApp(@PathVariable String responseType, @PathVariable String payuMobTranID, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("payuMobResponse");
        modelAndView.addObject("IS_SUCCESS", (Object)Boolean.FALSE);
        modelAndView.addObject("IS_ANDROID", (Object)Boolean.FALSE);
        try {
            Long id = Long.parseLong(payuMobTranID.trim());
            PayuMobTran payuMobTran = (PayuMobTran)this.payuMobTranManager.getById((Serializable)id);
            payuMobTran.setPayuResponseTime(new Date());
            try {
                if ("ANDROID".equalsIgnoreCase(payuMobTran.getSource().trim())) {
                    modelAndView.addObject("IS_ANDROID", (Object)Boolean.TRUE);
                }
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
                this.doLogRequestParameters(request, id);
                payuMobTran.setPayuTransactionId(request.getParameter("mihpayid"));
                payuMobTran.setTransactionId(request.getParameter("txnid"));
                payuMobTran.setPayuAmount(request.getParameter("net_amount_debit"));
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
            if ("PAYU_PAYMENT_SUCCESS".equalsIgnoreCase(responseType.trim())) {
                payuMobTran.setPayuResponse("SUCCESS");
                modelAndView.addObject("responseType", (Object)"SUCCESS");
                modelAndView.addObject("IS_SUCCESS", (Object)Boolean.TRUE);
                try {
                    PayuPaymentUtil payuPaymentUtil = new PayuPaymentUtil(this.payuMobTranManager);
                    payuPaymentUtil.autoConfirmMobileBooking(payuMobTran, this.hotelManager, this.hotelBookingManager, this.hotelAdministratorManager);
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
            } else if ("PAYU_PAYMENT_CANCEL".equalsIgnoreCase(responseType.trim())) {
                payuMobTran.setPayuResponse("CANCEL");
                modelAndView.addObject("responseType", (Object)"CANCEL");
            } else if ("PAYU_PAYMENT_FAILURE".equalsIgnoreCase(responseType.trim())) {
                payuMobTran.setPayuResponse("FAILURE");
                modelAndView.addObject("responseType", (Object)"FAILURE");
            }
            this.payuMobTranManager.saveOrUpdate(payuMobTran);
            modelAndView.addObject("PayuMobTran", (Object)payuMobTran);
        }
        catch (Exception id) {
            // empty catch block
        }
        return modelAndView;
    }

    private void doLogRequestParameters(HttpServletRequest request, Long payuMobTranId) {
        ArrayList<String> nullParams = new ArrayList<String>();
        ArrayList<String> emptyParams = new ArrayList<String>();
        try {
            LogsTable logsTable;
            Enumeration parameterList = request.getParameterNames();
            while (parameterList.hasMoreElements()) {
                String sName = parameterList.nextElement().toString();
                String[] sMultiple = request.getParameterValues(sName);
                String sValue = "";
                if (1 >= sMultiple.length) {
                    sValue = request.getParameter(sName);
                } else {
                    int i = 0;
                    while (i < sMultiple.length) {
                        sValue = "length: " + sMultiple.length + " ";
                        if (sMultiple[i] == null) {
                            nullParams.add(String.valueOf(sName) + "[" + i + "] # ");
                        } else if ("".equals(sMultiple[i].trim())) {
                            emptyParams.add(String.valueOf(sName) + "[" + i + "] # ");
                        } else {
                            sValue = String.valueOf(sValue) + "[" + i + "] = " + sMultiple[i] + " ";
                        }
                        ++i;
                    }
                }
                if (sValue == null) {
                    nullParams.add(String.valueOf(sName) + "# ");
                    continue;
                }
                if ("".equals(sValue.trim())) {
                    emptyParams.add(String.valueOf(sName) + "# ");
                    continue;
                }
                try {
                    LogsTable logsTable2 = new LogsTable();
                    logsTable2.setRefLong(payuMobTranId);
                    logsTable2.setRefString(sName);
                    logsTable2.setDescription(sValue);
                    this.payuMobTranManager.saveLogsTable(logsTable2);
                    continue;
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
            if (nullParams.size() > 0) {
                logsTable = new LogsTable();
                logsTable.setRefLong(payuMobTranId);
                logsTable.setRefString("NULL_VALUES_OF_PARAMS");
                logsTable.setDescription(nullParams.toString());
                this.payuMobTranManager.saveLogsTable(logsTable);
            }
            if (emptyParams.size() > 0) {
                logsTable = new LogsTable();
                logsTable.setRefLong(payuMobTranId);
                logsTable.setRefString("EMPTY_VALUES_OF_PARAMS");
                logsTable.setDescription(emptyParams.toString());
                this.payuMobTranManager.saveLogsTable(logsTable);
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @RequestMapping(method={RequestMethod.GET, RequestMethod.POST}, value={"payuResponseForAndroid/{responseType}/{payuMobTranID}"})
    public ModelAndView payuResponseForMobSDK(@PathVariable String responseType, @PathVariable String payuMobTranID, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("payuMobResponseAndroid");
        modelAndView.addObject("IS_SUCCESS", (Object)Boolean.FALSE);
        modelAndView.addObject("IS_ANDROID", (Object)Boolean.FALSE);
        try {
            Long id = Long.parseLong(payuMobTranID.trim());
            PayuMobTran payuMobTran = (PayuMobTran)this.payuMobTranManager.getById((Serializable)id);
            payuMobTran.setPayuResponseTime(new Date());
            try {
                if ("ANDROID".equalsIgnoreCase(payuMobTran.getSource().trim())) {
                    modelAndView.addObject("IS_ANDROID", (Object)Boolean.TRUE);
                }
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
                this.doLogRequestParameters(request, id);
                payuMobTran.setPayuTransactionId(request.getParameter("mihpayid"));
                payuMobTran.setTransactionId(request.getParameter("txnid"));
                payuMobTran.setPayuAmount(request.getParameter("net_amount_debit"));
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
            if ("PAYU_PAYMENT_SUCCESS".equalsIgnoreCase(responseType.trim())) {
                payuMobTran.setPayuResponse("SUCCESS");
                modelAndView.addObject("responseType", (Object)"SUCCESS");
                modelAndView.addObject("IS_SUCCESS", (Object)Boolean.TRUE);
                try {
                    PayuPaymentUtil payuPaymentUtil = new PayuPaymentUtil(this.payuMobTranManager);
                    payuPaymentUtil.autoConfirmMobileBooking(payuMobTran, this.hotelManager, this.hotelBookingManager, this.hotelAdministratorManager);
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
            } else if ("PAYU_PAYMENT_CANCEL".equalsIgnoreCase(responseType.trim())) {
                payuMobTran.setPayuResponse("CANCEL");
                modelAndView.addObject("responseType", (Object)"CANCEL");
            } else if ("PAYU_PAYMENT_FAILURE".equalsIgnoreCase(responseType.trim())) {
                payuMobTran.setPayuResponse("FAILURE");
                modelAndView.addObject("responseType", (Object)"FAILURE");
            }
            this.payuMobTranManager.saveOrUpdate(payuMobTran);
            modelAndView.addObject("PayuMobTran", (Object)payuMobTran);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return modelAndView;
    }

    @RequestMapping(method={RequestMethod.GET, RequestMethod.POST}, value={"/androidApp"})
    public ModelAndView androidApp(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("androidAppIndex");
        return modelAndView;
    }

    @RequestMapping(method={RequestMethod.GET, RequestMethod.POST}, value={"/iosApp"})
    public ModelAndView iosApp(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("iosAppIndex");
        return modelAndView;
    }

    @RequestMapping(method={RequestMethod.GET, RequestMethod.POST}, value={"/windowsApp"})
    public ModelAndView windowsApp(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("windowsAppIndex");
        return modelAndView;
    }

    private HashMap<String, Object> refreshSearchParamsHashMap(HttpSession session, Long cityId) throws WudstayException {
        City city = (City)this.cityManager.getById((Serializable)cityId);
        return this.refreshSearchParamsHashMap(session, city);
    }

    private HashMap<String, Object> refreshSearchParamsHashMap(HttpSession session, String cityName) throws WudstayException {
        City city = this.cityManager.getByCityName(cityName);
        return this.refreshSearchParamsHashMap(session, city);
    }

    private HashMap<String, Object> refreshSearchParamsHashMap(HttpSession session, City city) throws WudstayException {
        return this.refreshSearchParamsHashMap(session, city.getCityId(), city.getCityName());
    }

    private HashMap<String, Object> refreshSearchParamsHashMap(HttpSession session, Long cityId, String cityName) throws WudstayException {
        HashMap<String, Object> searchParamsHashMap = new HashMap<String, Object>();
        searchParamsHashMap.put("cityId", cityId);
        searchParamsHashMap.put("city", cityName);
        searchParamsHashMap.put("checkIn", WudstayUtil.getDefaultCheckInDate());
        searchParamsHashMap.put("checkOut", WudstayUtil.getDefaultCheckOutDate());
        searchParamsHashMap.put("rooms", WudstayConstants.DEFAULT_ROOMS);
        searchParamsHashMap.put("persons", WudstayConstants.DEFAULT_PERSONS);
        if (session == null || session.getAttribute("searchParamsHashMap") == null) {
            session.setAttribute("searchParamsHashMap", searchParamsHashMap);
            return searchParamsHashMap;
        }
        return (HashMap)session.getAttribute("searchParamsHashMap");
    }

    private String getOptionalRequestParam(String requestParam, String defaultValue) {
        if (requestParam == null || "NULL".equals(requestParam)) {
            return defaultValue;
        }
        return requestParam;
    }

    private Long getOptionalRequestParam(Long requestParam, Long defaultValue) {
        if (requestParam == null || "NULL".equals(requestParam)) {
            return defaultValue;
        }
        return requestParam;
    }

    public ModelAndView fetchHotelDetails(String sortBy, Long locationId, String roomTypeIds, Long hotelId, Long cityId, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("back-list");
        try {
            HashMap searchParamMap = (HashMap)session.getAttribute("searchParamsHashMap");
            Integer rooms = (Integer)searchParamMap.get("rooms");
            Integer persons = (Integer)searchParamMap.get("persons");
            City city = (City)this.cityManager.getById((Serializable)cityId);
            Hotel hotel = (Hotel)this.hotelManager.getById((Serializable)hotelId);
            int minPax = persons / rooms;
            boolean ignoreTripleOccupancyAllowedFlag = true;
            if (minPax == 1) {
                hotel.setPrice(hotel.getSingleOccupancyPrice());
            } else if (minPax == 2) {
                hotel.setPrice(hotel.getDoubleOccupancyPrice());
            } else if (minPax == 3) {
                ignoreTripleOccupancyAllowedFlag = hotel.getAllowTripleOccupancy() == 1;
                hotel.setPrice(hotel.getTripleOccupancyPrice());
            }
            modelAndView.addObject("IgnoreTripleOccupancyAllowedFlag", (Object)ignoreTripleOccupancyAllowedFlag);
            List<Long> roomTypeIdList = WudstayUtil.getRoomTypeIdList((String)roomTypeIds);
            List hotelAmenityList = this.hotelAmenityManager.getHotelAmenitiesByHotelId(hotelId);
            List hotelList = this.hotelManager.filterHotels(locationId, cityId, roomTypeIdList, sortBy, Integer.valueOf(0), Integer.valueOf(1), persons / rooms);
            List<Hotel> suggestedHotelList = this.hotelManager.getSuggestedHotelList(hotel);
            for (Hotel suggestedHotel : suggestedHotelList) {
                suggestedHotel.setPrice(suggestedHotel.getSingleOccupancyPrice());
            }
            List hotelDescriptionList = this.hotelDescriptionManager.getHotelDescriptionsByHotelId(hotel.getHotelId());
            List hotelImageList = WudstayUtil.getHotelImages((Long)hotel.getHotelId(),(HttpServletRequest)request);
            WudstayUtil.setAmenitiesForHotel((List)suggestedHotelList);
            this.setNextAndPreviousHotelRoomIdInModel(hotel, hotelList, modelAndView);
            String checkIn = (String)searchParamMap.get("checkIn");
            String checkOut = (String)searchParamMap.get("checkOut");
            SimpleDateFormat fromFormat = new SimpleDateFormat("yyyy-MM-dd");
            fromFormat.setLenient(false);
            SimpleDateFormat toFormat = new SimpleDateFormat("dd/MM/yyyy");
            toFormat.setLenient(false);
            Date date = fromFormat.parse(checkIn);
            modelAndView.addObject("checkIn", (Object)toFormat.format(date));
            date = fromFormat.parse(checkOut);
            modelAndView.addObject("checkOut", (Object)toFormat.format(date));
            modelAndView.addObject("city", (Object)city.getCityName());
            modelAndView.addObject("cityId", (Object)cityId);
            modelAndView.addObject("sortBy", (Object)sortBy);
            modelAndView.addObject("locationId", (Object)locationId);
            modelAndView.addObject("roomTypeIds", (Object)roomTypeIds);
            modelAndView.addObject("rooms", (Object)rooms);
            modelAndView.addObject("persons", (Object)persons);
            modelAndView.addObject("hotel", (Object)hotel);
            modelAndView.addObject("hotelAmenityList", (Object)hotelAmenityList);
            modelAndView.addObject("suggestedHotelList", (Object)suggestedHotelList);
            modelAndView.addObject("hotelDescriptionList", (Object)hotelDescriptionList);
            modelAndView.addObject("hotelImageList", (Object)hotelImageList);
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    public ModelAndView fetchHotelDetails(String hotelNameOrId, String cityName, HttpServletRequest request, HttpServletResponse response, HttpSession session) throws WudstayException {
        Hotel hotel = this.getHotelByNameOrId(hotelNameOrId, cityName);
        City city = hotel.getLocation().getCity();
        this.refreshSearchParamsHashMap(session, city);
        return this.fetchHotelDetails("", null, "", hotel.getHotelId(), city.getCityId(), request, response, session);
    }

    private Hotel getHotelByNameOrId(String hotelNameOrId, String cityName) {
        Hotel hotel = null;
        try {
            Long hotelId = Long.parseLong(hotelNameOrId);
            hotel = (Hotel)this.hotelManager.getById((Serializable)hotelId);
            return hotel;
        }
        catch (NumberFormatException ex) {
            String hotelName = new String(hotelNameOrId.trim());
            try {
                List<Hotel> hotelList;
                if (cityName != null && !"".equals(cityName.trim())) {
                    City city = this.cityManager.getByCityName(cityName);
                    hotelList = this.hotelManager.getHotelByCityId(city.getCityId());
                } else {
                    hotelList = this.hotelManager.list();
                }
                for (Hotel dbHotel : hotelList) {
                    if (!hotelName.equalsIgnoreCase(dbHotel.getHotelDisplayName().trim()) && !hotelNameOrId.equalsIgnoreCase(dbHotel.getHotelDisplayName().replace(" ", ""))) continue;
                    hotel = dbHotel;
                    break;
                }
                return hotel;
            }
            catch (WudstayException e) {
                e.printStackTrace();
                return hotel;
            }
        }
    }

    @RequestMapping(value={"/pgs"})
    public ModelAndView getAllCitiesPgs(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("searchHotels_new");
        try {
            List cityList = this.cityManager.getAllCities();
            modelAndView.addObject("cityList", (Object)cityList);
            List pgCityList = this.cityManager.getAllPgCities();
            modelAndView.addObject("pgCityList", (Object)pgCityList);
            ArrayList<Location> pgLocationList = new ArrayList<Location>();
            Location location = new Location();
            location.setLocationId(Long.valueOf(0));
            location.setLocationName("Please select City");
            pgLocationList.add(location);
            modelAndView.addObject("pgLocationList", pgLocationList);
            List pgTypeList = this.pgTypeManager.list();
            modelAndView.addObject("pgTypeList", (Object)pgTypeList);
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    @RequestMapping(method={RequestMethod.GET, RequestMethod.POST}, value={"getHomepage.do"})
    public ModelAndView getHome(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        return new ModelAndView("redirect:/");
    }

    private void changeLocale(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        String language = "ba";
        try {
            if (request.getParameter("language") != null) {
                language = request.getParameter("language").trim();
                if ("ba".equalsIgnoreCase(language) || "bahasa".equalsIgnoreCase(language)) {
                    language = "ba";
                }
                LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver((HttpServletRequest)request);
                localeResolver.setLocale(request, response, StringUtils.parseLocaleString((String)language));
            } else {
                language = locale.getLanguage();
            }
            session.setAttribute("LANGUAGE", (Object)language);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @RequestMapping(value={"/"})
    public ModelAndView getAllCities(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("searchHotels");
        this.changeLocale(locale, request, response, session);
        try {
            List cityList = this.cityManager.getAllCities();
            modelAndView.addObject("cityList", (Object)cityList);
            List pgCityList = this.cityManager.getAllPgCities();
            modelAndView.addObject("pgCityList", (Object)pgCityList);
            ArrayList<Location> pgLocationList = new ArrayList<Location>();
            Location location = new Location();
            location.setLocationId(Long.valueOf(0));
            location.setLocationName("Please select City");
            pgLocationList.add(location);
            modelAndView.addObject("pgLocationList", pgLocationList);
            List pgTypeList = this.pgTypeManager.list();
            modelAndView.addObject("pgTypeList", (Object)pgTypeList);
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    @RequestMapping(value={"ramadhan"})
    public ModelAndView ramadhan(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("ramadhan");
        LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver((HttpServletRequest)request);
        localeResolver.setLocale(request, response, StringUtils.parseLocaleString((String)"ba"));
        return modelAndView;
    }

    @RequestMapping(value={"sgholiday"})
    public ModelAndView sgholiday(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("sgholiday");
        LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver((HttpServletRequest)request);
        localeResolver.setLocale(request, response, StringUtils.parseLocaleString((String)"en"));
        return modelAndView;
    }

    @RequestMapping(value={"citibank"})
    public ModelAndView citibank(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("citibank");
        LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver((HttpServletRequest)request);
        localeResolver.setLocale(request, response, StringUtils.parseLocaleString((String)"en"));
        return modelAndView;
    }

    @RequestMapping(value={"google"})
    public ModelAndView google(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("google");
        LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver((HttpServletRequest)request);
        localeResolver.setLocale(request, response, StringUtils.parseLocaleString((String)"en"));
        return modelAndView;
    }

    @RequestMapping(value={"JGOS2016"})
    public ModelAndView JGOS2016(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("JGOS2016");
        LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver((HttpServletRequest)request);
        localeResolver.setLocale(request, response, StringUtils.parseLocaleString((String)"en"));
        return modelAndView;
    }

    @RequestMapping(value={"jgos2016"})
    public ModelAndView jgos2016(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("JGOS2016");
        LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver((HttpServletRequest)request);
        localeResolver.setLocale(request, response, StringUtils.parseLocaleString((String)"en"));
        return modelAndView;
    }

    @RequestMapping(value={"LineJGOS"})
    public ModelAndView LineJGOS(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("LineJGOS");
        LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver((HttpServletRequest)request);
        localeResolver.setLocale(request, response, StringUtils.parseLocaleString((String)"en"));
        return modelAndView;
    }

    @RequestMapping(value={"LINEJGOS"})
    public ModelAndView LINEJGOS(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("LineJGOS");
        LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver((HttpServletRequest)request);
        localeResolver.setLocale(request, response, StringUtils.parseLocaleString((String)"en"));
        return modelAndView;
    }

    @RequestMapping(value={"linejgos"})
    public ModelAndView linejgos(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("LineJGOS");
        LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver((HttpServletRequest)request);
        localeResolver.setLocale(request, response, StringUtils.parseLocaleString((String)"en"));
        return modelAndView;
    }

    @RequestMapping(value={"TselJGOS"})
    public ModelAndView TselJGOS(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("TselJGOS");
        LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver((HttpServletRequest)request);
        localeResolver.setLocale(request, response, StringUtils.parseLocaleString((String)"en"));
        return modelAndView;
    }

    @RequestMapping(value={"TSELJGOS"})
    public ModelAndView TSELJGOS(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("TselJGOS");
        LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver((HttpServletRequest)request);
        localeResolver.setLocale(request, response, StringUtils.parseLocaleString((String)"en"));
        return modelAndView;
    }

    @RequestMapping(value={"tseljgos"})
    public ModelAndView tseljgos(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("TselJGOS");
        LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver((HttpServletRequest)request);
        localeResolver.setLocale(request, response, StringUtils.parseLocaleString((String)"en"));
        return modelAndView;
    }

    @RequestMapping(value={"permata"})
    public ModelAndView permata(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("permata");
        this.changeLocale(locale, request, response, session);
        try {
            Long cityId = 67L;
            City city = (City)this.cityManager.getById((Serializable)cityId);
            HashMap<String, Object> searchParamMap = this.refreshSearchParamsHashMap(session, city);
            int rooms = (Integer)searchParamMap.get("rooms");
            int persons = (Integer)searchParamMap.get("persons");
            String checkIn = (String)searchParamMap.get("checkIn");
            String checkOut = (String)searchParamMap.get("checkOut");
            this.extractSearchParam(searchParamMap, modelAndView);
            List hotelList = this.hotelManager.getHotelByCityId(cityId, persons / rooms);
            hotelList = WudstayUtil.processHotelList((List)hotelList, (Integer)rooms, (Integer)persons, (IHotelBookingManager)this.hotelBookingManager, (String)checkIn, (String)checkOut, (IHotelManager)this.hotelManager);
            modelAndView.addObject("NO_OF_FILTERED_HOTELS", (Object)hotelList.size());
            modelAndView.addObject("city", (Object)city.getCityName());
            modelAndView.addObject("cityId", (Object)cityId);
            modelAndView.addObject("isAllRoomTypeSelected", (Object)Boolean.FALSE);
            modelAndView.addObject("hotelList", (Object)hotelList);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return modelAndView;
    }
    @RequestMapping("permata25")
    public ModelAndView permata25(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("permata25");
        changeLocale(locale, request, response, session);
        //----------------------------------------------
        try {
            Long cityId = 67L; //City Name: 40 Percent Off Sale
            City city = cityManager.getById(cityId);
            HashMap<String, Object> searchParamMap = refreshSearchParamsHashMap(session, city);
            int rooms = (Integer) searchParamMap.get("rooms");
            int persons = (Integer) searchParamMap.get("persons");
            String checkIn = (String) searchParamMap.get("checkIn");
            String checkOut = (String) searchParamMap.get("checkOut");
            extractSearchParam(searchParamMap, modelAndView);
            List<Hotel> hotelList = hotelManager.getHotelByCityId(cityId, persons / rooms);
            hotelList = WudstayUtil.processHotelList(hotelList, rooms, persons, hotelBookingManager, checkIn, checkOut, hotelManager);
            //WudstayUtil.setAmenitiesForHotel(hotelList);
            modelAndView.addObject("NO_OF_FILTERED_HOTELS", hotelList.size());
            modelAndView.addObject("city", city.getCityName());
            modelAndView.addObject("cityId", cityId);
            modelAndView.addObject("isAllRoomTypeSelected", Boolean.FALSE);
            modelAndView.addObject("hotelList", hotelList);
        }catch (Exception ex){
            ex.printStackTrace();
        }
        //-------------------------------------------------
        return modelAndView;
    }
    @RequestMapping("PERMATA25")
    public ModelAndView PERMATA25(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("permata25");
        changeLocale(locale, request, response, session);
        //----------------------------------------------
        try {
            Long cityId = 67L; //City Name: 40 Percent Off Sale
            City city = cityManager.getById(cityId);
            HashMap<String, Object> searchParamMap = refreshSearchParamsHashMap(session, city);
            int rooms = (Integer) searchParamMap.get("rooms");
            int persons = (Integer) searchParamMap.get("persons");
            String checkIn = (String) searchParamMap.get("checkIn");
            String checkOut = (String) searchParamMap.get("checkOut");
            extractSearchParam(searchParamMap, modelAndView);
            List<Hotel> hotelList = hotelManager.getHotelByCityId(cityId, persons / rooms);
            hotelList = WudstayUtil.processHotelList(hotelList, rooms, persons, hotelBookingManager, checkIn, checkOut, hotelManager);
            //WudstayUtil.setAmenitiesForHotel(hotelList);
            modelAndView.addObject("NO_OF_FILTERED_HOTELS", hotelList.size());
            modelAndView.addObject("city", city.getCityName());
            modelAndView.addObject("cityId", cityId);
            modelAndView.addObject("isAllRoomTypeSelected", Boolean.FALSE);
            modelAndView.addObject("hotelList", hotelList);
        }catch (Exception ex){
            ex.printStackTrace();
        }
        //-------------------------------------------------
        return modelAndView;
    }
    @RequestMapping(method={RequestMethod.POST}, value={"getUpdatedHotelPrice.do"})
    @ResponseBody
    public Integer getUpdatedHotelPrice(@RequestParam Integer rooms, @RequestParam Integer persons, @RequestParam Long hotelId, HttpServletRequest request, HttpSession session) {
        try {
            Hotel hotel = (Hotel)this.hotelManager.getById((Serializable)hotelId);
            int minPax = persons / rooms;
            if (hotel.getAllowTripleOccupancy() != 1) {
                try {
                    int minPax1 = persons / rooms;
                    int minPaxPersons = minPax1 * rooms;
                    if (persons != minPaxPersons) {
                        ++minPax1;
                    }
                    if (minPax1 == 3) {
                        return -13;
                    }
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                    return -1;
                }
            }
            if (minPax == 1) {
                return hotel.getSingleOccupancyPrice();
            }
            if (minPax == 2) {
                return hotel.getDoubleOccupancyPrice();
            }
            if (minPax == 3) {
                return hotel.getTripleOccupancyPrice();
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return -1;
    }

    @RequestMapping(method={RequestMethod.GET}, value={"{cityName}/hotels"})
    public ModelAndView searchHotels(@PathVariable String cityName, @RequestParam String checkIn, @RequestParam String checkOut, @RequestParam Integer rooms, @RequestParam Integer persons, @RequestParam Long cityId, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("results2");
        try {
            List cityList = this.cityManager.getAllCities();
            modelAndView.addObject("cityList", (Object)cityList);
            modelAndView.addObject("checkIn", (Object)checkIn);
            modelAndView.addObject("checkOut", (Object)checkOut);
            modelAndView.addObject("rooms", (Object)rooms);
            modelAndView.addObject("persons", (Object)persons);
            City city = null;
            city = cityId != null && cityId > 0 ? (City)this.cityManager.getById((Serializable)cityId) : this.cityManager.getByCityName(cityName);
            if (city == null) {
                modelAndView.addObject("NO_OF_FILTERED_HOTELS", (Object)0);
                modelAndView.addObject("city", (Object)cityName);
                modelAndView.addObject("roomsAndPersons", (Object)WudstayUtil.getRoomsAndPersons((Integer)rooms, (Integer)persons));
                ArrayList locationList = new ArrayList();
                modelAndView.addObject("locationList", locationList);
                List roomTypeList = this.roomTypeManager.list();
                modelAndView.addObject("roomTypeList", (Object)roomTypeList);
                ArrayList hotelList = new ArrayList();
                modelAndView.addObject("hotelList", hotelList);
                if (checkIn == null || checkOut == null || "".equals(checkIn.trim()) || "".equals(checkOut.trim())) {
                    DateUtil dt = new DateUtil();
                    modelAndView.addObject("checkIn", (Object)DateUtil.toDisplayDate((Date)dt.toDate()));
                    dt.moveNexDay();
                    modelAndView.addObject("checkOut", (Object)DateUtil.toDisplayDate((Date)dt.toDate()));
                }
                if (rooms == null || rooms == 0) {
                    modelAndView.addObject("rooms", (Object)rooms);
                }
                if (persons == null || persons == 0) {
                    modelAndView.addObject("persons", (Object)persons);
                }
                return modelAndView;
            }
            cityId = city.getCityId();
            if (checkIn == null || checkIn.equals("") || checkOut == null || checkOut.equals("")) {
                session.setAttribute("searchParamsHashMap", this.getSearchParamHashMap(city.getCityName(), cityId, WudstayUtil.getDefaultCheckInDate(), WudstayUtil.getDefaultCheckOutDate(), rooms, persons));
            } else {
                session.setAttribute("searchParamsHashMap", this.getSearchParamHashMap(city.getCityName(), cityId, WudstayUtil.getFormattedCheckInDate((String)checkIn), WudstayUtil.getFormattedCheckOutDate((String)checkOut), rooms, persons));
            }
            List hotelList = this.hotelManager.getHotelByCityId(cityId, persons / rooms);
            HashMap searchParamMap = (HashMap)session.getAttribute("searchParamsHashMap");
            hotelList = WudstayUtil.processHotelList((List)hotelList, (Integer)rooms, (Integer)persons, (IHotelBookingManager)this.hotelBookingManager, (String)((String)searchParamMap.get("checkIn")), (String)((String)searchParamMap.get("checkOut")), (IHotelManager)this.hotelManager);
            WudstayUtil.setAmenitiesForHotel((List)hotelList);
            List locationList = this.locationManager.getLocationsByCityId(cityId);
            List roomTypeList = this.roomTypeManager.list();
            modelAndView.addObject("NO_OF_FILTERED_HOTELS", (Object)hotelList.size());
            modelAndView.addObject("city", (Object)city.getCityName());
            modelAndView.addObject("cityId", (Object)cityId);
            modelAndView.addObject("roomsAndPersons", (Object)WudstayUtil.getRoomsAndPersons((Integer)rooms, (Integer)persons));
            modelAndView.addObject("stayPeriod", (Object)WudstayUtil.getStayPeriod((String)((String)searchParamMap.get("checkIn")), (String)((String)searchParamMap.get("checkOut"))));
            modelAndView.addObject("locationList", (Object)locationList);
            modelAndView.addObject("roomTypeList", (Object)roomTypeList);
            modelAndView.addObject("hotelList", (Object)WudstayUtil.moveSoldOutHotelAtTheEndOfList((List)hotelList));
            this.extractSearchParam(searchParamMap, modelAndView);
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    @RequestMapping(method={RequestMethod.GET}, value={"{cityName}/{hotelNameOrId}"})
    public ModelAndView searchHotelsByCityAndHotel(@PathVariable String cityName, @PathVariable String hotelNameOrId, HttpServletRequest request, HttpServletResponse response, HttpSession session) throws WudstayException {
        return this.fetchHotelDetails(hotelNameOrId, cityName, request, response, session);
    }

    @RequestMapping(method={RequestMethod.GET}, value={"{cityName}/hotel"})
    public ModelAndView getHotelDetails(@RequestParam(required=false) String sortBy, @RequestParam(required=false) Long locationId, @RequestParam(required=false) String roomTypeIds, @RequestParam Long hotelId, @RequestParam(required=false) Long cityId, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        Long lngCityId = null;
        try {
            lngCityId = this.getOptionalRequestParam(cityId, null);
            if (lngCityId == null) {
                Hotel hotel = (Hotel)this.hotelManager.getById((Serializable)hotelId);
                lngCityId = hotel.getLocation().getCity().getCityId();
            }
            this.refreshSearchParamsHashMap(session, lngCityId);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return this.fetchHotelDetails(this.getOptionalRequestParam(sortBy, ""), this.getOptionalRequestParam(locationId, null), this.getOptionalRequestParam(roomTypeIds, ""), hotelId, lngCityId, request, response, session);
    }

    @RequestMapping(method={RequestMethod.GET, RequestMethod.POST}, value={"{cityName}"})
    public ModelAndView searchHotelsByCity(@PathVariable String cityName, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("results2");
        try {
            City city;
            List cityList = this.cityManager.getAllCities();
            modelAndView.addObject("cityList", (Object)cityList);
            if ("Bengaluru".equalsIgnoreCase(cityName) || "Bangalore".equalsIgnoreCase(cityName)) {
                cityName = "Bangalore";
            }
            if ((city = this.cityManager.getByCityName(cityName)) == null) {
                String hotelNameOrId = new String(cityName);
                return this.fetchHotelDetails(hotelNameOrId, null, request, response, session);
            }
            Long cityId = city.getCityId();
            HashMap<String, Object> searchParamMap = this.refreshSearchParamsHashMap(session, city);
            int rooms = (Integer)searchParamMap.get("rooms");
            int persons = (Integer)searchParamMap.get("persons");
            String checkIn = (String)searchParamMap.get("checkIn");
            String checkOut = (String)searchParamMap.get("checkOut");
            this.extractSearchParam(searchParamMap, modelAndView);
            List hotelList = this.hotelManager.getHotelByCityId(cityId, persons / rooms);
            hotelList = WudstayUtil.processHotelList((List)hotelList, (Integer)rooms, (Integer)persons, (IHotelBookingManager)this.hotelBookingManager, (String)checkIn, (String)checkOut, (IHotelManager)this.hotelManager);
            WudstayUtil.setAmenitiesForHotel((List)hotelList);
            List locationList = this.locationManager.getLocationsByCityId(cityId);
            List roomTypeList = this.roomTypeManager.list();
            modelAndView.addObject("NO_OF_FILTERED_HOTELS", (Object)hotelList.size());
            modelAndView.addObject("city", (Object)city.getCityName());
            modelAndView.addObject("cityId", (Object)cityId);
            modelAndView.addObject("isAllRoomTypeSelected", (Object)Boolean.FALSE);
            modelAndView.addObject("locationList", (Object)locationList);
            modelAndView.addObject("roomTypeList", (Object)roomTypeList);
            modelAndView.addObject("hotelList", (Object)hotelList);
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    private Object getSearchParamHashMap(String city, Long cityId, String checkIn, String checkOut, Integer rooms, Integer persons) {
        HashMap<String, Object> searchParamsHashMap = new HashMap<String, Object>();
        searchParamsHashMap.put("city", city);
        searchParamsHashMap.put("cityId", cityId);
        searchParamsHashMap.put("checkIn", checkIn);
        searchParamsHashMap.put("checkOut", checkOut);
        searchParamsHashMap.put("rooms", rooms);
        searchParamsHashMap.put("persons", persons);
        return searchParamsHashMap;
    }

    private ModelAndView extractSearchParam(HashMap<String, Object> searchParamMap, ModelAndView modelAndView) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        try {
            int rooms = (Integer)searchParamMap.get("rooms");
            int persons = (Integer)searchParamMap.get("persons");
            String checkIn = (String)searchParamMap.get("checkIn");
            String checkOut = (String)searchParamMap.get("checkOut");
            modelAndView.addObject("checkIn", (Object)dateFormat.format(format.parse(checkIn)));
            modelAndView.addObject("checkOut", (Object)dateFormat.format(format.parse(checkOut)));
            modelAndView.addObject("rooms", (Object)rooms);
            modelAndView.addObject("persons", (Object)persons);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return modelAndView;
    }

    @RequestMapping(method = RequestMethod.GET, value = WudstayMappings.FILTER_HOTELS)
    public
    @ResponseBody
    List<Hotel> filterHotels(@RequestParam Long cityId, @RequestParam String sortBy, @RequestParam Long locationId,
                             @RequestParam String roomTypeIds, Integer priceSortType, Integer ratingSortType, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        List<Hotel> hotelList = new ArrayList<Hotel>();
        try {
            List<Long> roomTypeIdList = WudstayUtil.getRoomTypeIdList(roomTypeIds);

            HashMap<String, Object> searchParamMap = (HashMap<String, Object>) session.getAttribute(WudstayConstants.SEARCH_PARAM_MAP);

            int rooms = (Integer) searchParamMap.get("rooms");
            int persons = (Integer) searchParamMap.get("persons");
            hotelList = hotelManager.filterHotels(locationId, cityId, roomTypeIdList, sortBy, priceSortType, ratingSortType, persons / rooms);

            hotelList = WudstayUtil.processHotelList(hotelList, (Integer) searchParamMap.get("rooms"), (Integer) searchParamMap.get("persons"), hotelBookingManager, (String) searchParamMap.get("checkIn"), (String) searchParamMap.get("checkOut"), hotelManager);
            WudstayUtil.setAmenitiesForHotel(hotelList, hotelManager);
        } catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return hotelList;
    }

    private void setNextAndPreviousHotelRoomIdInModel(Hotel hotel, List<Hotel> hotelList, ModelAndView modelAndView) {
        int i = 0;
        while (i < hotelList.size()) {
            if (hotelList.get(i).getHotelId().equals(hotel.getHotelId())) {
                modelAndView.addObject("CURRENT_SRNO_IN_FILTERED_HOTELS", (Object)new Integer(i + 1));
                if (i - 1 < 0) {
                    modelAndView.addObject("previousHotelId", (Object)new Integer(0));
                } else {
                    modelAndView.addObject("previousHotelId", (Object)hotelList.get(i - 1).getHotelId());
                }
                if (i + 1 == hotelList.size()) {
                    modelAndView.addObject("nextHotelId", (Object)new Integer(0));
                    break;
                }
                modelAndView.addObject("nextHotelId", (Object)hotelList.get(i + 1).getHotelId());
                break;
            }
            ++i;
        }
        modelAndView.addObject("NO_OF_FILTERED_HOTELS", (Object)hotelList.size());
    }

    @RequestMapping(method={RequestMethod.POST}, value={"checkAvailability.do"})
    @ResponseBody
    public HotelAvailabilityVO checkAvailability(@RequestParam String checkIn, @RequestParam String checkOut, @RequestParam Integer rooms, @RequestParam(required=false) Integer persons, @RequestParam Long hotelId, HttpServletRequest request, HttpSession session) {
        HotelAvailabilityVO hotelAvailabilityVO = new HotelAvailabilityVO();
        try {
            Hotel hotel = (Hotel)this.hotelManager.getById((Serializable)hotelId);
            String checkInDate = WudstayUtil.getFormattedCheckInDate((String)checkIn.trim());
            String checkOutDate = WudstayUtil.getFormattedCheckOutDate((String)checkOut.trim());
            if (hotel.getAllowTripleOccupancy() != 1) {
                try {
                    int minPax = persons / rooms;
                    int minPaxPersons = minPax * rooms;
                    if (persons != minPaxPersons) {
                        ++minPax;
                    }
                    if (minPax == 3) {
                        hotelAvailabilityVO.setStatus(Boolean.FALSE);
                        hotelAvailabilityVO.setErrMsg("Triple Occupancy not allowed.");
                        return hotelAvailabilityVO;
                    }
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                    hotelAvailabilityVO.setStatus(Boolean.FALSE);
                    return hotelAvailabilityVO;
                }
            }
            return WudstayUtil.isAvailable((Hotel)hotel, (Integer)rooms, (String)checkInDate, (String)checkOutDate, (IHotelBookingManager)this.hotelBookingManager);
        }
        catch (Exception e) {
            e.printStackTrace();
            hotelAvailabilityVO.setStatus(Boolean.FALSE);
            return hotelAvailabilityVO;
        }
    }

    @RequestMapping(method={RequestMethod.GET}, value={"book-hotel"})
    public ModelAndView bookHotel(@RequestParam String checkIn, @RequestParam String checkOut, @RequestParam Integer rooms, @RequestParam Integer persons, @RequestParam Long cityId, @RequestParam Long hotelId, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("booking");
        try {
            City city = (City)this.cityManager.getById((Serializable)cityId);
            Boolean isPaymentSuccess = (Boolean)session.getAttribute("isPaymentSuccess");
            if (isPaymentSuccess != null && !isPaymentSuccess.booleanValue()) {
                String name = (String)session.getAttribute("name");
                String email = (String)session.getAttribute("email");
                String mobileNumber = (String)session.getAttribute("mobileNumber");
                session.removeAttribute("name");
                session.removeAttribute("email");
                session.removeAttribute("mobileNumber");
                session.removeAttribute("isPaymentSuccess");
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                checkIn = dateFormat.format(format.parse(checkIn));
                checkOut = dateFormat.format(format.parse(checkOut));
                modelAndView.addObject("name", (Object)name);
                modelAndView.addObject("email", (Object)email);
                modelAndView.addObject("mobileNumber", (Object)mobileNumber);
                modelAndView.addObject("paymentStatus", (Object)"failed");
            }
            modelAndView.addObject("data_checkIn", (Object)checkIn.trim());
            modelAndView.addObject("data_checkOut", (Object)checkOut.trim());
            modelAndView.addObject("data_rooms", (Object)rooms);
            modelAndView.addObject("data_persons", (Object)persons);
            modelAndView.addObject("data_cityId", (Object)cityId);
            modelAndView.addObject("data_cityName", (Object)city.getCityName());
            modelAndView.addObject("data_hotelId", (Object)hotelId);
            session.setAttribute("searchParamsHashMap", this.getSearchParamHashMap(city.getCityName(), cityId, WudstayUtil.getFormattedCheckInDate((String)checkIn.trim()), WudstayUtil.getFormattedCheckOutDate((String)checkOut.trim()), rooms, persons));
            Hotel hotel = (Hotel)this.hotelManager.getById((Serializable)hotelId);
            BookingDetailsVO bookingDetailsVO = WudstayUtil.getBookingDetailsVO((String)city.getCityName(), (String)checkIn, (String)checkOut, (Integer)rooms, (Integer)persons, (Hotel)hotel);
            session.setAttribute("Booking Details", (Object)bookingDetailsVO);
            try {
                City cityHotel = hotel.getLocation().getCity();
                Long cityHotelId = city.getCityId();
                Date checkOutDate = WudstayUtil.getFormattedCheckOutDateObject((String)checkOut.trim());
                DateUtil dt = new DateUtil(checkOutDate);
                modelAndView.addObject("IsBlackoutDateForPayAtHotel", (Object)this.hotelManager.isBlackoutDateForPayAtHotel(WudstayUtil.getFormattedCheckInDateObject((String)checkIn.trim()), WudstayUtil.getFormattedCheckOutDateObject((String)checkOut.trim()), cityHotelId.longValue()));
            }
            catch (Exception ex) {
                modelAndView.addObject("IsBlackoutDateForPayAtHotel", (Object)Boolean.FALSE);
            }
            modelAndView.addObject("bookingDetailsVO", (Object)bookingDetailsVO);
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    private DiscountCouponInfo doCalculateCouponCodeDiscount(BookingDetailsVO bookingDetailsVO, String mobileNumber, String couponCode, Integer sourceOfBooking) {
        DiscountCouponInfo discountCouponInfo = new DiscountCouponInfo();
        City city = null;
        Integer totalAmount = bookingDetailsVO.getTotalPrice();
        Date checkOut = null;
        try {
            city = this.cityManager.getByCityName(bookingDetailsVO.getCity());
            String strCheckOut = bookingDetailsVO.getCheckOutDate();
            SimpleDateFormat dateFormat = new SimpleDateFormat("EEEE, dd MMMMM yyyy");
            dateFormat.setLenient(false);
            checkOut = dateFormat.parse(strCheckOut);
            discountCouponInfo = this.couponCodeManager.calculateCouponCodeDiscount(city, couponCode, totalAmount, checkOut, bookingDetailsVO.getNights().intValue(), mobileNumber, sourceOfBooking.intValue());
            return discountCouponInfo;
        }
        catch (Exception e) {
            e.printStackTrace();
            return discountCouponInfo;
        }
    }

    @RequestMapping(method={RequestMethod.GET, RequestMethod.POST}, value={"calculateCouponCodeDiscount.do"})
    @ResponseBody
    public Map calculateCouponCodeDiscount(@RequestParam String mobileNumber, @RequestParam String couponCode, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        HashMap<String, Object> map = new HashMap<String, Object>();
        BookingDetailsVO bookingDetailsVO = null;
        Integer totalAmount = null;
        Date checkOut = null;
        DiscountCouponInfo discountCouponInfo = new DiscountCouponInfo();
        map.put("success", Boolean.FALSE);
        try {
            if (session.getAttribute("Booking Details") != null) {
                bookingDetailsVO = (BookingDetailsVO)session.getAttribute("Booking Details");
                if (bookingDetailsVO.getTotalPrice() != null && !bookingDetailsVO.getTotalPrice().equals(bookingDetailsVO.getTotalPriceBeforeDiscount())) {
                    bookingDetailsVO.setTotalPrice(bookingDetailsVO.getTotalPriceBeforeDiscount());
                }
                String strCheckOut = bookingDetailsVO.getCheckOutDate();
                SimpleDateFormat dateFormat = new SimpleDateFormat("EEEE, dd MMMMM yyyy");
                dateFormat.setLenient(false);
                checkOut = dateFormat.parse(strCheckOut);
                totalAmount = bookingDetailsVO.getTotalPrice();
                City city = this.cityManager.getByCityName(bookingDetailsVO.getCity());
                Integer sourceOfBooking = WudstayConstants.getSourceOfBooking((String)"WEB", (int)10);
                if (WudstayFilter.isRequestComingFromAMobileDevice((HttpServletRequest)request)) {
                    sourceOfBooking = WudstayConstants.getSourceOfBooking((String)"MOBILE-WEB", (int)10);
                }
                discountCouponInfo = this.couponCodeManager.calculateCouponCodeDiscount(city, couponCode, totalAmount, checkOut, bookingDetailsVO.getNights().intValue(), mobileNumber, sourceOfBooking.intValue());
                bookingDetailsVO.setDiscountCoupon(discountCouponInfo);
                session.setAttribute("Booking Details", (Object)bookingDetailsVO);
            }
            map.put("success", Boolean.TRUE);
            map.put("BookingDetails", (Object)bookingDetailsVO);
            return map;
        }
        catch (Exception e) {
            e.printStackTrace();
            map.put("success", Boolean.FALSE);
            map.put("ERROR", e.getMessage());
            return map;
        }
    }

    @RequestMapping(method={RequestMethod.GET}, value={"sendMobileNumberVerificationCode.do"})
    @ResponseBody
    public String sendVerificationCode(@RequestParam(required=false) String countryCode, @RequestParam String mobileNumber, @RequestParam String name, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        try {
            int verificationCode = 0;
            while (String.valueOf(verificationCode).length() < 6) {
                verificationCode = (int)(Math.random() * 1000000.0);
            }
            NumberVerification numberVerification = new NumberVerification();
            numberVerification.setCustomerName(name);
            numberVerification.setMobileNumber(mobileNumber);
            numberVerification.setVerificationCode(String.valueOf(verificationCode));
            numberVerification.setIsActive(Boolean.TRUE);
            this.numberVerificationManager.save(numberVerification);
            WudstayUtil.sendVerificationCode((NumberVerification)numberVerification);
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return "success";
    }

    @RequestMapping(method={RequestMethod.GET}, value={"verifyMobileNumber.do"})
    @ResponseBody
    public Boolean verifyMobileNumber(@RequestParam String verificationCode, String mobileNumber, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        Boolean isVerified = Boolean.FALSE;
        try {
            isVerified = this.numberVerificationManager.verifyMobileNumber(verificationCode, mobileNumber);
            return isVerified;
        }
        catch (Exception e) {
            e.printStackTrace();
            return isVerified;
        }
    }

    @RequestMapping(method={RequestMethod.GET}, value={"confirmBooking.do"})
    public ModelAndView confirmBooking(@RequestParam String mobileNumber, @RequestParam String name, @RequestParam String email, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("redirect:booking-confirmation?name=" + name + "&email=" + email + "&mobileNumber=" + mobileNumber);
        try {
            ArrayList<String> ccList = new ArrayList<String>();
            HashMap searchParamMap = (HashMap)session.getAttribute("searchParamsHashMap");
            BookingDetailsVO bookingDetailsVO = (BookingDetailsVO)session.getAttribute("Booking Details");
            Integer discount = 0;
            Integer sourceOfBooking = WudstayConstants.getSourceOfBooking((String)"WEB", (int)2);
            try {
                if (bookingDetailsVO != null && bookingDetailsVO.getDiscountCoupon() != null && bookingDetailsVO.getTotalPrice() != bookingDetailsVO.getTotalPriceBeforeDiscount()) {
                    DiscountCouponInfo coupon = this.doCalculateCouponCodeDiscount(bookingDetailsVO, mobileNumber, bookingDetailsVO.getDiscountCoupon().getCouponCode(), sourceOfBooking);
                    if (coupon.getOnlyForOnlinePayment()) {
                        bookingDetailsVO.setTotalPrice(bookingDetailsVO.getTotalPriceBeforeDiscount());
                        bookingDetailsVO.setDiscountCoupon(null);
                    } else {
                        DiscountCouponInfo orgCoupon = bookingDetailsVO.getDiscountCoupon();
                        if (!orgCoupon.getDiscount().equals(coupon.getDiscount())) {
                            bookingDetailsVO.setDiscountCoupon(coupon);
                        }
                    }
                }
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
            int persons = Integer.valueOf(searchParamMap.get("persons").toString());
            bookingDetailsVO.setPersons(Integer.valueOf(persons));
            String bookingId = this.hotelBookingManager.makeBooking(bookingDetailsVO, name, mobileNumber, searchParamMap.get("checkIn").toString(), searchParamMap.get("checkOut").toString(), Integer.valueOf(searchParamMap.get("rooms").toString()), Integer.valueOf(persons), email, Boolean.FALSE, null, null, discount, sourceOfBooking, Integer.valueOf(0));
            session.setAttribute("totalAmountPaid", (Object)0);
            Hotel hotel = (Hotel)this.hotelManager.getById((Serializable)bookingDetailsVO.getHotelId());
            bookingDetailsVO.setBreakfastIncludedInPrice(Boolean.valueOf(hotel.getIsBreakfastIncludedInPrice()));
            WudstayUtil.sendConfirmationMessage((String)("Dear " + name + ", your Tinggal booking has been confirmed from " + bookingDetailsVO.getCheckInDate() + " to " + bookingDetailsVO.getCheckOutDate() + " at " + bookingDetailsVO.getHotelName() + ". The address is " + bookingDetailsVO.getAddress() + " and your booking id is " + bookingId + ". You can locate the stay at Google Maps on " + "the link " + bookingDetailsVO.getMapLink() + ". For any assistance you can call us anytime at +62822 8539 0099. Please carry a valid govt. address and ID proof when you checkin."), (String)mobileNumber);
            this.sendConfirmationMail(name, email, bookingDetailsVO, ccList, bookingId, new Integer(0));
            String hotelAdministratorEmail = null;
            HotelAdministrator hotelAdministrator = this.hotelAdministratorManager.getHotelAdminByHotelId(bookingDetailsVO.getHotelId());
            if (hotelAdministrator.getUser().getEmail() != null && !hotelAdministrator.getUser().getEmail().trim().equals("")) {
                hotelAdministratorEmail = hotelAdministrator.getUser().getEmail();
            }
            if (hotel.getContactPersonEmail1() != null && !hotel.getContactPersonEmail1().trim().equals("")) {
                ccList.add(hotel.getContactPersonEmail1());
            }
            if (hotel.getContactPersonEmail2() != null && !hotel.getContactPersonEmail2().trim().equals("")) {
                ccList.add(hotel.getContactPersonEmail2());
            }
            this.sendConfirmationMailToHotelAdmin(name, hotelAdministratorEmail, bookingDetailsVO, ccList, bookingId, new Integer(0));
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    private void sendConfirmationMail(String name, String email, BookingDetailsVO bookingDetailsVO, List<String> ccList, String bookingId, Integer paidAmount) throws MessagingException {
        this.sendConfirmationMail(name, email, bookingDetailsVO, ccList, bookingId, paidAmount, false);
    }

    private void sendConfirmationMail(String name, String email, BookingDetailsVO bookingDetailsVO, List<String> ccList, String bookingId, Integer paidAmount, boolean isOnlinePaid) throws MessagingException {
        HashMap<String, Object> bookingConfirmationBodyDetails = new HashMap<String, Object>();
        bookingConfirmationBodyDetails.put("GUEST", name);
        bookingConfirmationBodyDetails.put("CHECK_IN", bookingDetailsVO.getCheckInDate().split(",")[1].trim());
        bookingConfirmationBodyDetails.put("CHECK_OUT", bookingDetailsVO.getCheckOutDate().split(",")[1].trim());
        bookingConfirmationBodyDetails.put("HOTEL_DISPLAY_NAME", bookingDetailsVO.getHotelDisplayName());
        bookingConfirmationBodyDetails.put("BOOKING_ID", bookingId);
        bookingConfirmationBodyDetails.put("ROOM_COUNT", bookingDetailsVO.getRoomDetailsVOList().size());
        bookingConfirmationBodyDetails.put("NIGHT_COUNT", bookingDetailsVO.getNights());
        bookingConfirmationBodyDetails.put("TOTAL_PRICE", WudstayUtil.rupiahCurrencyFormat((Integer)bookingDetailsVO.getTotalPrice()));
        bookingConfirmationBodyDetails.put("TOTAL_PRICE_CONTRACTUAL", "");
        bookingConfirmationBodyDetails.put("PAID", paidAmount);
        bookingConfirmationBodyDetails.put("ROOM_TYPE", bookingDetailsVO.getRoomTypeMaster());
        bookingConfirmationBodyDetails.put("MAP_LINK", bookingDetailsVO.getMapLink());
        bookingConfirmationBodyDetails.put("HOTEL_ACTUAL_NAME", bookingDetailsVO.getHotelName());
        bookingConfirmationBodyDetails.put("HOTEL_ACTUAL_ADD", bookingDetailsVO.getAddress());
        bookingConfirmationBodyDetails.put("GUEST_COUNT", bookingDetailsVO.getPersons());
        bookingConfirmationBodyDetails.put("INCLUDE_BREAKFAST", bookingDetailsVO.getBreakfastIncludedInPrice());
        if (isOnlinePaid) {
            EmailSender.getInstance().sendEmail(email, "Booking Confirmation", bookingConfirmationBodyDetails, "bookingConfirmationPrepaidEmailBody.vm", ccList);
        } else {
            EmailSender.getInstance().sendEmail(email, "Booking Confirmation", bookingConfirmationBodyDetails, "bookingConfirmationEmailBody.vm", ccList);
        }
    }

    private void sendConfirmationMailToHotelAdmin(String name, String email, BookingDetailsVO bookingDetailsVO, List<String> ccList, String bookingId, Integer paidAmount) throws MessagingException {
        boolean isOnlinePaid = false;
        this.sendConfirmationMailToHotelAdmin(name, email, bookingDetailsVO, ccList, bookingId, paidAmount, isOnlinePaid);
    }

    private void sendConfirmationMailToHotelAdmin(String name, String email, BookingDetailsVO bookingDetailsVO, List<String> ccList, String bookingId, Integer paidAmount, boolean isOnlinePaid) throws MessagingException {
        HashMap<String, Object> bookingConfirmationBodyDetails = new HashMap<String, Object>();
        bookingConfirmationBodyDetails.put("GUEST", name);
        bookingConfirmationBodyDetails.put("CHECK_IN", bookingDetailsVO.getCheckInDate().split(",")[1].trim());
        bookingConfirmationBodyDetails.put("CHECK_OUT", bookingDetailsVO.getCheckOutDate().split(",")[1].trim());
        bookingConfirmationBodyDetails.put("HOTEL_DISPLAY_NAME", bookingDetailsVO.getHotelDisplayName());
        bookingConfirmationBodyDetails.put("BOOKING_ID", bookingId);
        bookingConfirmationBodyDetails.put("ROOM_COUNT", bookingDetailsVO.getRoomDetailsVOList().size());
        bookingConfirmationBodyDetails.put("NIGHT_COUNT", bookingDetailsVO.getNights());
        bookingConfirmationBodyDetails.put("TOTAL_PRICE", WudstayUtil.rupiahCurrencyFormat((Integer)bookingDetailsVO.getTotalPrice()));
        bookingConfirmationBodyDetails.put("TOTAL_PRICE_CONTRACTUAL", WudstayUtil.rupiahCurrencyFormat((Integer)bookingDetailsVO.getTotalPriceContractual()));
        bookingConfirmationBodyDetails.put("PAID", paidAmount);
        bookingConfirmationBodyDetails.put("ROOM_TYPE", bookingDetailsVO.getRoomTypeMaster());
        bookingConfirmationBodyDetails.put("MAP_LINK", bookingDetailsVO.getMapLink());
        bookingConfirmationBodyDetails.put("HOTEL_ACTUAL_NAME", bookingDetailsVO.getHotelName());
        bookingConfirmationBodyDetails.put("HOTEL_ACTUAL_ADD", bookingDetailsVO.getAddress());
        bookingConfirmationBodyDetails.put("GUEST_COUNT", bookingDetailsVO.getPersons());
        bookingConfirmationBodyDetails.put("INCLUDE_BREAKFAST", bookingDetailsVO.getBreakfastIncludedInPrice());
        if (isOnlinePaid) {
            EmailSender.getInstance().sendEmail(email, "Booking Confirmation", bookingConfirmationBodyDetails, "bookingConfirmationPrepaidEmailBody.vm", ccList);
        } else {
            EmailSender.getInstance().sendEmail(email, "Booking Confirmation", bookingConfirmationBodyDetails, "bookingConfirmationEmailBody.vm", ccList);
        }
    }

    @RequestMapping(method={RequestMethod.GET}, value={"booking-confirmation"})
    public ModelAndView showBookingDetails(@RequestParam String mobileNumber, @RequestParam String name, @RequestParam String email, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("bookingConfirm");
        try {
            HashMap searchParamMap = (HashMap)session.getAttribute("searchParamsHashMap");
            BookingDetailsVO bookingDetailsVO = (BookingDetailsVO)session.getAttribute("Booking Details");
            modelAndView.addObject("bookingDetailsVO", (Object)bookingDetailsVO);
            modelAndView.addObject("mobileNumber", (Object)mobileNumber);
            modelAndView.addObject("rooms", (Object)searchParamMap.get("rooms").toString());
            modelAndView.addObject("persons", (Object)searchParamMap.get("persons").toString());
            modelAndView.addObject("name", (Object)name);
            modelAndView.addObject("email", (Object)email);
            Integer totalAmountPaid = (Integer)session.getAttribute("totalAmountPaid");
            modelAndView.addObject("totalAmountPaid", (Object)totalAmountPaid);
            session.removeAttribute("totalAmountPaid");
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    @RequestMapping(method={RequestMethod.GET}, value={"processPayNow.do"})
    @ResponseBody
    public PayUVO processPayNow(@RequestParam String mobileNumber, @RequestParam String name, @RequestParam String email, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        PayUVO payUVO = new PayUVO();
        try {
            BookingDetailsVO bookingDetailsVO = (BookingDetailsVO)session.getAttribute("Booking Details");
            HashMap searchParamMap = (HashMap)session.getAttribute("searchParamsHashMap");
            payUVO.setFirstName(name);
            payUVO.setEmail(email);
            payUVO.setAmount(bookingDetailsVO.getTotalPrice());
            payUVO.setMerchantKey("44fZt5");
            payUVO.setProductInfo("Hotel Booking");
            payUVO.setSalt("t5vIbSb7");
            String transactionId = RandomStringUtils.randomAlphanumeric((int)15).toUpperCase();
            payUVO.setTransactionId(transactionId);
            payUVO.setPhone(mobileNumber);
            payUVO.setCurl("http://www.wudstay.com/paymentCancel.do");
            payUVO.setSurl("http://www.wudstay.com/paymentSuccess.do");
            payUVO.setFurl("http://www.wudstay.com/paymentFailure.do");
            StringBuffer buffer = new StringBuffer();
            buffer.append(payUVO.getMerchantKey());
            buffer.append("|");
            buffer.append(payUVO.getTransactionId());
            buffer.append("|");
            buffer.append(payUVO.getAmount());
            buffer.append("|");
            buffer.append(payUVO.getProductInfo());
            buffer.append("|");
            buffer.append(payUVO.getFirstName());
            buffer.append("|");
            buffer.append(payUVO.getEmail());
            buffer.append("|");
            payUVO.setUdf1(WudstayUtil.getUDFBookingDetails((BookingDetailsVO)bookingDetailsVO));
            buffer.append(payUVO.getUdf1());
            buffer.append("|");
            payUVO.setUdf2(WudstayUtil.getUDFSearchParam((HashMap)searchParamMap));
            buffer.append(payUVO.getUdf2());
            buffer.append("|||||||||");
            buffer.append(payUVO.getSalt());
            MessageDigest md = MessageDigest.getInstance("SHA-512");
            md.update(buffer.toString().getBytes());
            byte[] byteData = md.digest();
            StringBuffer sb = new StringBuffer();
            int i = 0;
            while (i < byteData.length) {
                sb.append(Integer.toString((byteData[i] & 255) + 256, 16).substring(1));
                ++i;
            }
            payUVO.setHash(sb.toString());
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return payUVO;
    }

    @RequestMapping(method={RequestMethod.GET, RequestMethod.POST}, value={"veritransurl.do"})
    @ResponseBody
    public VeritransResponse veritransurl(@RequestParam String mobileNumber, @RequestParam String name, @RequestParam String email, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        VeritransResponse res = new VeritransResponse();
        try {
            res = VeritransUtil.getRedirectUrlForPayment((String)WudstayUtil.getUniqueId(), (Integer)199000, (String)"bookingId-123", (String)name, (String)email, (String)mobileNumber);
            "201".equals(res.getStatus_code());
        }
        catch (Exception var8_8) {
            // empty catch block
        }
        return res;
    }

    @RequestMapping(method={RequestMethod.POST}, value={"paymentSuccess.do"})
    public ModelAndView paymentSucces(HttpServletResponse response, HttpSession session, HttpServletRequest request) {
        ModelAndView modelAndView = null;
        Double dAmount = Double.valueOf(request.getParameter("amount"));
        Integer amount = dAmount.intValue();
        String txnid = request.getParameter("txnid");
        String name = request.getParameter("firstname");
        String email = request.getParameter("email");
        String mobileNumber = request.getParameter("phone");
        String mihpayid = request.getParameter("mihpayid");
        String status = request.getParameter("status");
        String bookingDetailsUDF = request.getParameter("udf1");
        String searchParamUDF = request.getParameter("udf2");
        String[] searchParamSplit = searchParamUDF.split("#");
        String checkInDate = searchParamSplit[0];
        String checkOutDate = searchParamSplit[1];
        Integer rooms = Integer.valueOf(searchParamSplit[2]);
        Integer persons = Integer.valueOf(searchParamSplit[3]);
        BookingDetailsVO bookingDetailsVO = WudstayUtil.getBookingDetailsVOPayU((String)bookingDetailsUDF, (IHotelManager)this.hotelManager, (Integer)rooms, (Integer)persons);
        session.setAttribute("Booking Details", (Object)bookingDetailsVO);
        Hotel hotel = (Hotel)this.hotelManager.getById((Serializable)bookingDetailsVO.getHotelId());
        session.setAttribute("searchParamsHashMap", this.getSearchParamHashMap(hotel.getLocation().getCity().getCityName(), hotel.getLocation().getCity().getCityId(), checkInDate, checkOutDate, rooms, persons));
        if (!status.equals("success")) {
            modelAndView = new ModelAndView("redirect:book-hotel?checkIn=" + checkInDate + "&checkOut=" + checkOutDate + "&rooms=" + rooms + "&persons=" + persons + "&cityId=" + hotel.getLocation().getCity().getCityId() + "&hotelId=" + bookingDetailsVO.getHotelId());
            session.setAttribute("isPaymentSuccess", (Object)Boolean.FALSE);
            session.setAttribute("name", (Object)name);
            session.setAttribute("email", (Object)email);
            session.setAttribute("mobileNumber", (Object)mobileNumber);
            return modelAndView;
        }
        modelAndView = new ModelAndView("redirect:booking-confirmation?name=" + name + "&email=" + email + "&mobileNumber=" + mobileNumber);
        try {
            Integer discount = 0; String bookingId="";
            bookingDetailsVO.setBreakfastIncludedInPrice(Boolean.valueOf(hotel.getIsBreakfastIncludedInPrice()));
            Integer sourceOfBooking = WudstayConstants.getSourceOfBooking((String)"WEB", (int)2);
            if(txnid!=null){
            	
              List<HotelBooking> hotelTxnList = hotelBookingManager.getBookingsByTransactionId(txnid);
                 if(hotelTxnList.size()==0){
                      bookingId = this.hotelBookingManager.makeBooking(bookingDetailsVO, name, mobileNumber, checkInDate, checkOutDate, rooms, persons, email, Boolean.TRUE, txnid, mihpayid, discount, sourceOfBooking);
                  }
            }
            session.setAttribute("totalAmountPaid", (Object)amount);
            HotelAdministrator hotelAdministrator = this.hotelAdministratorManager.getHotelAdminByHotelId(bookingDetailsVO.getHotelId());
            WudstayUtil.sendConfirmationMessage((String)("Dear " + name + ", your Tinggal booking has been confirmed from " + bookingDetailsVO.getCheckInDate() + " to " + bookingDetailsVO.getCheckOutDate() + " at " + bookingDetailsVO.getHotelName() + ". The address is " + bookingDetailsVO.getAddress() + " and your booking id is " + bookingId + ". You can locate the stay at Google Maps on " + "the link " + bookingDetailsVO.getMapLink() + ". For any assistance you can call us anytime at +62822 8539 0099. Please carry a valid govt. address and ID proof when you checkin."), (String)mobileNumber);
            ArrayList<String> ccList = new ArrayList<String>();
            if (hotel.getContactPersonEmail1() != null && !hotel.getContactPersonEmail1().trim().equals("")) {
                ccList.add(hotel.getContactPersonEmail1());
            }
            if (hotel.getContactPersonEmail2() != null && !hotel.getContactPersonEmail2().trim().equals("")) {
                ccList.add(hotel.getContactPersonEmail2());
            }
            if (hotelAdministrator.getUser().getEmail() != null && !hotelAdministrator.getUser().getEmail().trim().equals("")) {
                ccList.add(hotelAdministrator.getUser().getEmail());
            }
            this.sendConfirmationMail(name, email, bookingDetailsVO, ccList, bookingId, amount);
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    @RequestMapping(method={RequestMethod.POST}, value={"paymentFailure.do"})
    public ModelAndView paymentFailure(HttpServletResponse response, HttpSession session, HttpServletRequest request) {
        ModelAndView modelAndView = null;
        String name = request.getParameter("firstname");
        String email = request.getParameter("email");
        String mobileNumber = request.getParameter("phone");
        String bookingDetailsUDF = request.getParameter("udf1");
        String searchParamUDF = request.getParameter("udf2");
        String[] searchParamSplit = searchParamUDF.split("#");
        String checkInDate = searchParamSplit[0];
        String checkOutDate = searchParamSplit[1];
        Integer rooms = Integer.valueOf(searchParamSplit[2]);
        Integer persons = Integer.valueOf(searchParamSplit[3]);
        BookingDetailsVO bookingDetailsVO = WudstayUtil.getBookingDetailsVOPayU((String)bookingDetailsUDF, (IHotelManager)this.hotelManager, (Integer)rooms, (Integer)persons);
        session.setAttribute("Booking Details", (Object)bookingDetailsVO);
        Hotel hotel = (Hotel)this.hotelManager.getById((Serializable)bookingDetailsVO.getHotelId());
        session.setAttribute("searchParamsHashMap", this.getSearchParamHashMap(hotel.getLocation().getCity().getCityName(), hotel.getLocation().getCity().getCityId(), checkInDate, checkOutDate, rooms, persons));
        modelAndView = new ModelAndView("redirect:book-hotel?checkIn=" + checkInDate + "&checkOut=" + checkOutDate + "&rooms=" + rooms + "&persons=" + persons + "&cityId=" + hotel.getLocation().getCity().getCityId() + "&hotelId=" + bookingDetailsVO.getHotelId());
        session.setAttribute("isPaymentSuccess", (Object)Boolean.FALSE);
        session.setAttribute("name", (Object)name);
        session.setAttribute("email", (Object)email);
        session.setAttribute("mobileNumber", (Object)mobileNumber);
        return modelAndView;
    }

    @RequestMapping(method={RequestMethod.POST}, value={"paymentCancel.do"})
    public ModelAndView paymentCancel(HttpServletResponse response, HttpSession session, HttpServletRequest request) {
        ModelAndView modelAndView = null;
        String name = request.getParameter("firstname");
        String email = request.getParameter("email");
        String mobileNumber = request.getParameter("phone");
        String bookingDetailsUDF = request.getParameter("udf1");
        String searchParamUDF = request.getParameter("udf2");
        String[] searchParamSplit = searchParamUDF.split("#");
        String checkInDate = searchParamSplit[0];
        String checkOutDate = searchParamSplit[1];
        Integer rooms = Integer.valueOf(searchParamSplit[2]);
        Integer persons = Integer.valueOf(searchParamSplit[3]);
        BookingDetailsVO bookingDetailsVO = WudstayUtil.getBookingDetailsVOPayU((String)bookingDetailsUDF, (IHotelManager)this.hotelManager, (Integer)rooms, (Integer)persons);
        session.setAttribute("Booking Details", (Object)bookingDetailsVO);
        Hotel hotel = (Hotel)this.hotelManager.getById((Serializable)bookingDetailsVO.getHotelId());
        session.setAttribute("searchParamsHashMap", this.getSearchParamHashMap(hotel.getLocation().getCity().getCityName(), hotel.getLocation().getCity().getCityId(), checkInDate, checkOutDate, rooms, persons));
        modelAndView = new ModelAndView("redirect:book-hotel?checkIn=" + checkInDate + "&checkOut=" + checkOutDate + "&rooms=" + rooms + "&persons=" + persons + "&cityId=" + hotel.getLocation().getCity().getCityId() + "&hotelId=" + bookingDetailsVO.getHotelId());
        session.setAttribute("isPaymentSuccess", (Object)Boolean.FALSE);
        session.setAttribute("name", (Object)name);
        session.setAttribute("email", (Object)email);
        session.setAttribute("mobileNumber", (Object)mobileNumber);
        return modelAndView;
    }

    @RequestMapping(method={RequestMethod.GET}, value={"isMaximumNightsReached.do"})
    @ResponseBody
    public Boolean isMaxNightsReached(Long hotelId, String mobileNumber, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        Boolean isMaxNightsReached = Boolean.TRUE;
        try {
            BookingDetailsVO bookingDetailsVO = (BookingDetailsVO)session.getAttribute("Booking Details");
            Hotel hotel = (Hotel)this.hotelManager.getById((Serializable)hotelId);
            List<HotelBooking> hotelBookingList = this.hotelBookingManager.getBookingsByHotelId(hotelId, mobileNumber);
            int totalNights = bookingDetailsVO.getNights();
            for (HotelBooking hotelBooking : hotelBookingList) {
                totalNights += hotelBooking.getNights().intValue();
            }
            if (hotel.getMaxBookingPerMobNum() > 0 && totalNights <= hotel.getMaxBookingPerMobNum()) {
                isMaxNightsReached = Boolean.FALSE;
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return isMaxNightsReached;
    }

    @RequestMapping(method={RequestMethod.GET, RequestMethod.POST}, value={"processHdfcPayNow.do"})
    @ResponseBody
    public HdfcTranLogVO hdfcProcessPayNow(@RequestParam String mobileNumber, @RequestParam String name, @RequestParam String email, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        HdfcTranLogVO tranLogVO = new HdfcTranLogVO();
        tranLogVO.setName(name);
        tranLogVO.setPhone(mobileNumber);
        tranLogVO.setEmail(email);
        tranLogVO.setReferenceNo(RandomStringUtils.randomAlphanumeric((int)15).toUpperCase());
        BookingDetailsVO bookingDetailsVO = (BookingDetailsVO)session.getAttribute("Booking Details");
        HashMap searchParamMap = (HashMap)session.getAttribute("searchParamsHashMap");
        tranLogVO.setAmount((String)((Object)bookingDetailsVO.getTotalPrice()));
        try {
            tranLogVO = this.hdfcTranLogManager.saveLog(tranLogVO);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        Long logId = tranLogVO.getLogId();
        String hdfcTranDescription = HdfcPaymentUtil.getHdfcTransactionDescription((Long)logId, (String)tranLogVO.getReferenceNo(), (BookingDetailsVO)bookingDetailsVO, (HashMap)searchParamMap);
        tranLogVO.setDescription(hdfcTranDescription);
        tranLogVO = HdfcPaymentUtil.setMd5Hashedvalue((HdfcTranLogVO)tranLogVO);
        tranLogVO = this.hdfcTranLogManager.saveLog(tranLogVO);
        return tranLogVO;
    }

    @RequestMapping(method={RequestMethod.GET, RequestMethod.POST}, value={"paymentResponse.do"})
    public ModelAndView paymentHdfcResponse(HttpServletResponse response, HttpSession session, HttpServletRequest request) {
        ModelAndView modelAndView = new ModelAndView("response");
        HdfcTranResponseVO hdfcTranResponse = new HdfcTranResponseVO();
        String description = "";
        HashMap<String, String> map = new HashMap<String, String>();
        Enumeration paramNames = request.getParameterNames();
        while (paramNames.hasMoreElements()) {
            String paramName = (String)paramNames.nextElement();
            String paramValue = request.getParameter(paramName);
            paramName = paramName.trim();
            paramValue.trim();
            map.put(paramName, paramValue);
            if (paramName.equalsIgnoreCase("ResponseCode")) {
                hdfcTranResponse.setResponseCode(paramValue);
                continue;
            }
            if (paramName.equalsIgnoreCase("ResponseMessage")) {
                hdfcTranResponse.setResponseMessage(paramValue);
                continue;
            }
            if (paramName.equalsIgnoreCase("DateCreated")) {
                hdfcTranResponse.setDateCreated(paramValue);
                continue;
            }
            if (paramName.equalsIgnoreCase("PaymentID")) {
                hdfcTranResponse.setPaymentID(paramValue);
                continue;
            }
            if (paramName.equalsIgnoreCase("MerchantRefNo")) {
                hdfcTranResponse.setMerchantRefNo(paramValue);
                continue;
            }
            if (paramName.equalsIgnoreCase("Amount")) {
                hdfcTranResponse.setAmount(paramValue);
                continue;
            }
            if (paramName.equalsIgnoreCase("Mode")) {
                hdfcTranResponse.setMode(paramValue);
                continue;
            }
            if (paramName.equalsIgnoreCase("IsFlagged")) {
                hdfcTranResponse.setIsFlagged(paramValue);
                continue;
            }
            if (paramName.equalsIgnoreCase("TransactionID")) {
                hdfcTranResponse.setTransactionId(paramValue);
                continue;
            }
            if (paramName.equalsIgnoreCase("PaymentMethod")) {
                hdfcTranResponse.setPaymentMethod(paramValue);
                continue;
            }
            if (paramName.equalsIgnoreCase("RequestID")) {
                hdfcTranResponse.setRequestId(paramValue);
                continue;
            }
            if (paramName.equalsIgnoreCase("SecureHash")) {
                hdfcTranResponse.setSecureHash(paramValue);
                continue;
            }
            if (paramName.equalsIgnoreCase("Description")) {
                hdfcTranResponse.setDescription(paramValue);
                description = new String(hdfcTranResponse.getDescription());
                continue;
            }
            if (paramName.equalsIgnoreCase("BillingName")) {
                hdfcTranResponse.setBillingName(paramValue);
                continue;
            }
            if (paramName.equalsIgnoreCase("BillingPhone")) {
                hdfcTranResponse.setBillingPhone(paramValue);
                continue;
            }
            if (!paramName.equalsIgnoreCase("BillingEmail")) continue;
            hdfcTranResponse.setBillingEmail(paramValue);
        }
        String bookingDetailsUDF = "";
        String searchParamUDF = "";
        try {
            String[] arr = description.split("<#>");
            hdfcTranResponse.setLogId(Long.valueOf(Long.parseLong(arr[0])));
            String referenceNo = arr[1];
            bookingDetailsUDF = arr[2];
            searchParamUDF = arr[3];
            modelAndView.addObject("LogId", (Object)arr[0]);
            modelAndView.addObject("referenceNo", (Object)arr[1]);
            modelAndView.addObject("bookingDetailsUDF", (Object)arr[2]);
            modelAndView.addObject("searchParamUDF", (Object)arr[3]);
            hdfcTranResponse = this.hdfcTranLogManager.saveResponse(hdfcTranResponse);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        modelAndView.addObject("paramsMap", map);
        if ("0".equals(hdfcTranResponse.getResponseCode())) {
            return this.hdfcPaymentSucces(bookingDetailsUDF, searchParamUDF, hdfcTranResponse, session);
        }
        return this.hdfcPaymentFailure(bookingDetailsUDF, searchParamUDF, hdfcTranResponse, session);
    }

    public ModelAndView hdfcPaymentSucces(String bookingDetailsUDF, String searchParamUDF, HdfcTranResponseVO hdfcTranResponse, HttpSession session) {
        Integer sourceOfBooking = WudstayConstants.getSourceOfBooking((String)"WEB", (int)2);
        return this.hdfcPaymentSucces(bookingDetailsUDF, searchParamUDF, hdfcTranResponse, session, sourceOfBooking);
    }

    public ModelAndView hdfcPaymentSucces(String bookingDetailsUDF, String searchParamUDF, HdfcTranResponseVO hdfcTranResponse, HttpSession session, Integer sourceOfBooking) {
        ModelAndView modelAndView = null;
        Double dAmount = Double.valueOf(hdfcTranResponse.getAmount());
        Integer amount = dAmount.intValue();
        String txnid = hdfcTranResponse.getTransactionId();
        String mihpayid = hdfcTranResponse.getPaymentID();
        String status = hdfcTranResponse.getResponseCode();
        String name = hdfcTranResponse.getBillingName();
        String email = hdfcTranResponse.getBillingEmail();
        String mobileNumber = hdfcTranResponse.getBillingPhone();
        String[] searchParamSplit = searchParamUDF.split("#");
        String checkInDate = searchParamSplit[0];
        String checkOutDate = searchParamSplit[1];
        Integer rooms = Integer.valueOf(searchParamSplit[2]);
        Integer persons = Integer.valueOf(searchParamSplit[3]);
        BookingDetailsVO bookingDetailsVO = WudstayUtil.getBookingDetailsVOPayU((String)bookingDetailsUDF, (IHotelManager)this.hotelManager, (Integer)rooms, (Integer)persons);
        session.setAttribute("Booking Details", (Object)bookingDetailsVO);
        Hotel hotel = (Hotel)this.hotelManager.getById((Serializable)bookingDetailsVO.getHotelId());
        session.setAttribute("searchParamsHashMap", this.getSearchParamHashMap(hotel.getLocation().getCity().getCityName(), hotel.getLocation().getCity().getCityId(), checkInDate, checkOutDate, rooms, persons));
        if (!"0".equalsIgnoreCase(status.trim())) {
            modelAndView = sourceOfBooking != 14 ? new ModelAndView("redirect:/book-hotel?checkIn=" + checkInDate + "&checkOut=" + checkOutDate + "&rooms=" + rooms + "&persons=" + persons + "&cityId=" + hotel.getLocation().getCity().getCityId() + "&hotelId=" + bookingDetailsVO.getHotelId()) : new ModelAndView("redirect:/m/hotelDetail?hotelId=" + bookingDetailsVO.getHotelId() + "&searchHotelType=hotel");
            session.setAttribute("isPaymentSuccess", (Object)Boolean.FALSE);
            session.setAttribute("name", (Object)name);
            session.setAttribute("email", (Object)email);
            session.setAttribute("mobileNumber", (Object)mobileNumber);
            return modelAndView;
        }
        String mobileUrlPrefix = sourceOfBooking == 14 ? "m/" : "";
        modelAndView = new ModelAndView("redirect:/" + mobileUrlPrefix + "booking-confirmation" + "?name=" + name + "&email=" + email + "&mobileNumber=" + mobileNumber);
        try {
            Integer discount = 0;
           // String bookingId = this.hotelBookingManager.makeBooking(bookingDetailsVO, name, mobileNumber, checkInDate, checkOutDate, rooms, persons, email, Boolean.TRUE, txnid, mihpayid, discount, sourceOfBooking);
            String bookingId ="";
            if(txnid!=null){
            	
                List<HotelBooking> hotelTxnList = hotelBookingManager.getBookingsByTransactionId(txnid);
                   if(hotelTxnList.size()==0){
                        bookingId = this.hotelBookingManager.makeBooking(bookingDetailsVO, name, mobileNumber, checkInDate, checkOutDate, rooms, persons, email, Boolean.TRUE, txnid, mihpayid, discount, sourceOfBooking);
                    }
              }
            session.setAttribute("totalAmountPaid", (Object)amount);
            bookingDetailsVO.setBreakfastIncludedInPrice(Boolean.valueOf(hotel.getIsBreakfastIncludedInPrice()));
            WudstayUtil.sendConfirmationMessage((String)("Dear " + name + ", your Tinggal booking has been confirmed from " + bookingDetailsVO.getCheckInDate() + " to " + bookingDetailsVO.getCheckOutDate() + " at " + bookingDetailsVO.getHotelName() + ". The address is " + bookingDetailsVO.getAddress() + " and your booking id is " + bookingId + ". You can locate the stay at Google Maps on " + "the link " + bookingDetailsVO.getMapLink() + ". For any assistance you can call us anytime at +62822 8539 0099. Please carry a valid govt. address and ID proof when you checkin."), (String)mobileNumber);
            ArrayList<String> ccList = new ArrayList<String>();
            this.sendConfirmationMail(name, email, bookingDetailsVO, ccList, bookingId, amount, true);
            String hotelAdministratorEmail = null;
            HotelAdministrator hotelAdministrator = this.hotelAdministratorManager.getHotelAdminByHotelId(bookingDetailsVO.getHotelId());
            if (hotelAdministrator.getUser().getEmail() != null && !hotelAdministrator.getUser().getEmail().trim().equals("")) {
                hotelAdministratorEmail = hotelAdministrator.getUser().getEmail();
            }
            if (hotel.getContactPersonEmail1() != null && !hotel.getContactPersonEmail1().trim().equals("")) {
                ccList.add(hotel.getContactPersonEmail1());
            }
            if (hotel.getContactPersonEmail2() != null && !hotel.getContactPersonEmail2().trim().equals("")) {
                ccList.add(hotel.getContactPersonEmail2());
            }
            this.sendConfirmationMailToHotelAdmin(name, hotelAdministratorEmail, bookingDetailsVO, ccList, bookingId, amount, true);
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    public ModelAndView hdfcPaymentFailure(String bookingDetailsUDF, String searchParamUDF, HdfcTranResponseVO hdfcTranResponse, HttpSession session) {
        Integer sourceOfBooking = WudstayConstants.getSourceOfBooking((String)"WEB", (int)10);
        return this.hdfcPaymentFailure(bookingDetailsUDF, searchParamUDF, hdfcTranResponse, session, sourceOfBooking);
    }

    public ModelAndView hdfcPaymentFailure(String bookingDetailsUDF, String searchParamUDF, HdfcTranResponseVO hdfcTranResponse, HttpSession session, Integer sourceOfBooking) {
        ModelAndView modelAndView = null;
        String name = hdfcTranResponse.getBillingName();
        String email = hdfcTranResponse.getBillingEmail();
        String mobileNumber = hdfcTranResponse.getBillingPhone();
        String[] searchParamSplit = searchParamUDF.split("#");
        String checkInDate = searchParamSplit[0];
        String checkOutDate = searchParamSplit[1];
        Integer rooms = Integer.valueOf(searchParamSplit[2]);
        Integer persons = Integer.valueOf(searchParamSplit[3]);
        BookingDetailsVO bookingDetailsVO = WudstayUtil.getBookingDetailsVOPayU((String)bookingDetailsUDF, (IHotelManager)this.hotelManager, (Integer)rooms, (Integer)persons);
        session.setAttribute("Booking Details", (Object)bookingDetailsVO);
        Hotel hotel = (Hotel)this.hotelManager.getById((Serializable)bookingDetailsVO.getHotelId());
        session.setAttribute("searchParamsHashMap", this.getSearchParamHashMap(hotel.getLocation().getCity().getCityName(), hotel.getLocation().getCity().getCityId(), checkInDate, checkOutDate, rooms, persons));
        modelAndView = sourceOfBooking != 14 ? new ModelAndView("redirect:/book-hotel?checkIn=" + checkInDate + "&checkOut=" + checkOutDate + "&rooms=" + rooms + "&persons=" + persons + "&cityId=" + hotel.getLocation().getCity().getCityId() + "&hotelId=" + bookingDetailsVO.getHotelId()) : new ModelAndView("redirect:/m/hotelDetail?hotelId=" + bookingDetailsVO.getHotelId() + "&searchHotelType=hotel");
        session.setAttribute("isPaymentSuccess", (Object)Boolean.FALSE);
        session.setAttribute("name", (Object)name);
        session.setAttribute("email", (Object)email);
        session.setAttribute("mobileNumber", (Object)mobileNumber);
        return modelAndView;
    }

    @RequestMapping(method={RequestMethod.GET}, value={"getLocationsOfCity.do"})
    @ResponseBody
    public List<Location> getAllLocationsByCityId(@RequestParam Long cityId, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
    	List<Location> locationList = new ArrayList<Location>();
        try {
            locationList = this.locationManager.getLocationsByCityId(cityId);
        }
        catch (Exception e) {
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return locationList;
    }

    @RequestMapping(method={RequestMethod.GET}, value={"getPgLocationsOfCity.do"})
    public
    @ResponseBody
    List<Location> getAllPgLocationsByCityId(@RequestParam Long cityId, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
    	List<Location> locationList = new ArrayList<Location>();
        try {
            locationList = locationManager.getLocationsByCityId(cityId);
            locationList = filterPgLocations(cityId, locationList);
        }
        catch (Exception e) {
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return locationList;
    }

    private List<Location> filterPgLocations(Long cityId, List<Location> locationList) {
        try {
            List<PgHotel> hotelList = this.pgHotelManager.getHotelByCityId(cityId, 3);
            Iterator<Location> item = locationList.iterator();
            while (item.hasNext()) {
                Location loc = item.next();
                try {
                    Boolean found = Boolean.FALSE;
                    for (PgHotel pg : hotelList) {
                        Long lngPglocalityId = pg.getLocation().getLocationId();
                        if (!loc.getLocationId().equals(lngPglocalityId)) continue;
                        found = Boolean.TRUE;
                        break;
                    }
                    if (found != Boolean.FALSE) continue;
                    item.remove();
                    continue;
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
            return locationList;
        }
        catch (Exception ex) {
            ex.printStackTrace();
            return locationList;
        }
    }

    @RequestMapping(method={RequestMethod.GET}, value={"paypalPayNow.do"})
    @ResponseBody
    public PayPalTranLogVO processPayNow_paypal(@RequestParam String mobileNumber, @RequestParam String name, @RequestParam String email, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        PayPalTranLogVO tranLogVO = new PayPalTranLogVO();
        tranLogVO.setName(name);
        tranLogVO.setPhone(mobileNumber);
        tranLogVO.setEmail(email);
        BookingDetailsVO bookingDetailsVO = (BookingDetailsVO)session.getAttribute("Booking Details");
        HashMap searchParamMap = (HashMap)session.getAttribute("searchParamsHashMap");
        tranLogVO.setAmount((String)((Object)bookingDetailsVO.getTotalPrice()));
        try {
            tranLogVO = this.paypalTranLogManager.saveLog(tranLogVO);
            PayflowproSecureTokenUtil payflowpro = PayflowproSecureTokenUtil.execute((PayPalTranLogVO)tranLogVO);
            tranLogVO.setSecureTokenId(payflowpro.getSecureTokenId());
            tranLogVO.setLocalToken(payflowpro.getToken());
            tranLogVO.setSecureCallRespMsg(payflowpro.getRespMsg());
            tranLogVO.setSecureToken(payflowpro.getSecureToken());
            tranLogVO = this.paypalTranLogManager.saveLog(tranLogVO);
            String referenceNo = RandomStringUtils.randomAlphanumeric((int)15).toUpperCase();
            String hdfcTranDescription = HdfcPaymentUtil.getHdfcTransactionDescription((Long)tranLogVO.getLogId(), (String)referenceNo, (BookingDetailsVO)bookingDetailsVO, (HashMap)searchParamMap);
            tranLogVO.setDescription(hdfcTranDescription);
            tranLogVO = this.paypalTranLogManager.saveLog(tranLogVO);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return tranLogVO;
    }

    @RequestMapping(method={RequestMethod.GET, RequestMethod.POST}, value={"paypalPaymentSuccess.do"})
    public ModelAndView paypalPaymentSuccess(HttpServletResponse response, HttpSession session, HttpServletRequest request) {
        ModelAndView modelAndView = new ModelAndView("paypal_response");
        modelAndView.addObject("PAGE_INFO", (Object)"PAYPAL_PAYMENT_SUCCESS");
        modelAndView.addObject("paramsMap", this.getRequestParamsMap(request));
        PayPalTranLogVO tranLog = this.savePaypalResponse(request);
        return modelAndView;
    }

    @RequestMapping(method={RequestMethod.GET, RequestMethod.POST}, value={"paypalPaymentCancel.do"})
    public ModelAndView paypalPaymentCancel(HttpServletResponse response, HttpSession session, HttpServletRequest request) {
        ModelAndView modelAndView = new ModelAndView("paypal_response");
        modelAndView.addObject("PAGE_INFO", (Object)"PAYPAL_PAYMENT_CANCEL");
        modelAndView.addObject("paramsMap", this.getRequestParamsMap(request));
        PayPalTranLogVO tranLog = this.savePaypalResponse(request);
        return modelAndView;
    }

    private Map<String, String> getRequestParamsMap(HttpServletRequest request) {
        HashMap<String, String> map = new HashMap<String, String>();
        Enumeration paramNames = request.getParameterNames();
        while (paramNames.hasMoreElements()) {
            String paramName = (String)paramNames.nextElement();
            String paramValue = request.getParameter(paramName);
            paramName = paramName.trim();
            paramValue = paramValue.trim();
            map.put(paramName, paramValue);
        }
        PayPalTranLogVO tranLog = this.savePaypalResponse(request);
        return map;
    }

    @RequestMapping(method={RequestMethod.GET, RequestMethod.POST}, value={"paypalPaymentFailure.do"})
    public ModelAndView paypalPaymentFailure(HttpServletResponse response, HttpSession session, HttpServletRequest request) {
        ModelAndView modelAndView = new ModelAndView("paypal_response");
        modelAndView.addObject("PAGE_INFO", (Object)"PAYPAL_PAYMENT_FAILURE");
        modelAndView.addObject("paramsMap", this.getRequestParamsMap(request));
        PayPalTranLogVO tranLog = this.savePaypalResponse(request);
        return modelAndView;
    }

    public PayPalTranLogVO savePaypalResponse(HttpServletRequest request) {
        Enumeration paramNames = request.getParameterNames();
        PayPalTranLogVO tranLog = new PayPalTranLogVO();
        String otherParamJson = "{";
        while (paramNames.hasMoreElements()) {
            String paramName = (String)paramNames.nextElement();
            String paramValue = request.getParameter(paramName);
            paramName = paramName.trim();
            paramValue = paramValue.trim();
            if ("TAX".equalsIgnoreCase(paramName)) {
                tranLog.setTax(paramValue);
                continue;
            }
            if ("SECURETOKEN".equalsIgnoreCase(paramName)) {
                tranLog.setSecureToken(paramValue);
                tranLog = this.paypalTranLogManager.getBySecureToken(tranLog);
                continue;
            }
            if ("COUNTRYTOSHIP".equalsIgnoreCase(paramName)) {
                tranLog.setCountryToShip(paramValue);
                continue;
            }
            if ("AVSDATA".equalsIgnoreCase(paramName)) {
                tranLog.setAvsData(paramValue);
                continue;
            }
            if ("AMT".equalsIgnoreCase(paramName)) {
                tranLog.setAmt(paramValue);
                continue;
            }
            if ("COUNTRY".equalsIgnoreCase(paramName)) {
                tranLog.setCountry(paramValue);
                continue;
            }
            if ("ACCT".equalsIgnoreCase(paramName)) {
                tranLog.setAcct(paramValue);
                continue;
            }
            if ("PNREF".equalsIgnoreCase(paramName)) {
                tranLog.setPnref(paramValue);
                continue;
            }
            if ("TENDER".equalsIgnoreCase(paramName)) {
                tranLog.setTender(paramValue);
                continue;
            }
            if ("TRXTYPE".equalsIgnoreCase(paramName)) {
                tranLog.setTrxType(paramValue);
                continue;
            }
            if ("RESULT".equalsIgnoreCase(paramName)) {
                tranLog.setResult(paramValue);
                continue;
            }
            if ("SECURETOKENID".equalsIgnoreCase(paramName)) {
                tranLog.setSecureTokenId(paramValue);
                continue;
            }
            if ("SHIPTOCOUNTRY".equalsIgnoreCase(paramName)) {
                tranLog.setShipToCountry(paramValue);
                continue;
            }
            if ("BILLTOCOUNTRY".equalsIgnoreCase(paramName)) {
                tranLog.setBillTocountry(paramValue);
                continue;
            }
            if ("EXPDATE".equalsIgnoreCase(paramName)) {
                tranLog.setExpDate(paramValue);
                continue;
            }
            if ("FPS_PREXMLDATA".equalsIgnoreCase(paramName)) {
                tranLog.setFpsPrexmlData(paramValue);
                continue;
            }
            if ("METHOD".equalsIgnoreCase(paramName)) {
                tranLog.setMethod(paramValue);
                continue;
            }
            if ("TRANSTIME".equalsIgnoreCase(paramName)) {
                tranLog.setTransTime(paramValue);
                continue;
            }
            if ("CARDTYPE".equalsIgnoreCase(paramName)) {
                tranLog.setCardType(paramValue);
                continue;
            }
            if ("TYPE".equalsIgnoreCase(paramName)) {
                tranLog.setType(paramValue);
                continue;
            }
            if ("PREFPSMSG".equalsIgnoreCase(paramName)) {
                tranLog.setPreFpsMsg(paramValue);
                continue;
            }
            if (!"{".equals(otherParamJson)) {
                otherParamJson = String.valueOf(otherParamJson) + ",  ";
            }
            otherParamJson = String.valueOf(otherParamJson) + "\"" + paramName + "\"";
            otherParamJson = String.valueOf(otherParamJson) + ": \"" + paramValue + "\"";
        }
        otherParamJson = String.valueOf(otherParamJson) + "}";
        tranLog.setOthers(otherParamJson);
        tranLog = this.paypalTranLogManager.saveLog(tranLog);
        return tranLog;
    }

    @RequestMapping(method={RequestMethod.GET}, value={"test-book-hotel"})
    public ModelAndView bookHotel2(@RequestParam String checkIn, @RequestParam String checkOut, @RequestParam Integer rooms, @RequestParam Integer persons, @RequestParam Long cityId, @RequestParam Long hotelId, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("booking2");
        try {
            City city = (City)this.cityManager.getById((Serializable)cityId);
            Boolean isPaymentSuccess = (Boolean)session.getAttribute("isPaymentSuccess");
            if (isPaymentSuccess != null && !isPaymentSuccess.booleanValue()) {
                String name = (String)session.getAttribute("name");
                String email = (String)session.getAttribute("email");
                String mobileNumber = (String)session.getAttribute("mobileNumber");
                session.removeAttribute("name");
                session.removeAttribute("email");
                session.removeAttribute("mobileNumber");
                session.removeAttribute("isPaymentSuccess");
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                checkIn = dateFormat.format(format.parse(checkIn));
                checkOut = dateFormat.format(format.parse(checkOut));
                modelAndView.addObject("name", (Object)name);
                modelAndView.addObject("email", (Object)email);
                modelAndView.addObject("mobileNumber", (Object)mobileNumber);
                modelAndView.addObject("paymentStatus", (Object)"failed");
            }
            modelAndView.addObject("data_checkIn", (Object)checkIn.trim());
            modelAndView.addObject("data_checkOut", (Object)checkOut.trim());
            modelAndView.addObject("data_rooms", (Object)rooms);
            modelAndView.addObject("data_persons", (Object)persons);
            modelAndView.addObject("data_cityId", (Object)cityId);
            modelAndView.addObject("data_cityName", (Object)city.getCityName());
            modelAndView.addObject("data_hotelId", (Object)hotelId);
            session.setAttribute("searchParamsHashMap", this.getSearchParamHashMap(city.getCityName(), cityId, WudstayUtil.getFormattedCheckInDate((String)checkIn.trim()), WudstayUtil.getFormattedCheckOutDate((String)checkOut.trim()), rooms, persons));
            Hotel hotel = (Hotel)this.hotelManager.getById((Serializable)hotelId);
            BookingDetailsVO bookingDetailsVO = WudstayUtil.getBookingDetailsVO((String)city.getCityName(), (String)checkIn, (String)checkOut, (Integer)rooms, (Integer)persons, (Hotel)hotel);
            session.setAttribute("Booking Details", (Object)bookingDetailsVO);
            try {
                City cityHotel = hotel.getLocation().getCity();
                Long cityHotelId = city.getCityId();
                Date checkOutDate = WudstayUtil.getFormattedCheckOutDateObject((String)checkOut.trim());
                DateUtil dt = new DateUtil(checkOutDate);
                modelAndView.addObject("IsBlackoutDateForPayAtHotel", (Object)this.hotelManager.isBlackoutDateForPayAtHotel(WudstayUtil.getFormattedCheckInDateObject((String)checkIn.trim()), WudstayUtil.getFormattedCheckOutDateObject((String)checkOut.trim()), cityHotelId.longValue()));
            }
            catch (Exception ex) {
                modelAndView.addObject("IsBlackoutDateForPayAtHotel", (Object)Boolean.FALSE);
            }
            modelAndView.addObject("bookingDetailsVO", (Object)bookingDetailsVO);
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }
}