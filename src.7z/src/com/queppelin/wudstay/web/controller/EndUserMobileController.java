package com.queppelin.wudstay.web.controller;

import com.queppelin.wudstay.exception.CustomGenericException;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.ICityManager;
import com.queppelin.wudstay.manager.ICouponCodeManager;
import com.queppelin.wudstay.manager.IHdfcTranLogManager;
import com.queppelin.wudstay.manager.IHotelAdministratorManager;
import com.queppelin.wudstay.manager.IHotelAmenityManager;
import com.queppelin.wudstay.manager.IHotelBookingManager;
import com.queppelin.wudstay.manager.IHotelDescriptionManager;
import com.queppelin.wudstay.manager.IHotelManager;
import com.queppelin.wudstay.manager.IHotelRoomManager;
import com.queppelin.wudstay.manager.ILocationManager;
import com.queppelin.wudstay.manager.INumberVerificationManager;
import com.queppelin.wudstay.manager.IPayuMobTranManager;
import com.queppelin.wudstay.manager.IPgHotelManager;
import com.queppelin.wudstay.manager.IPgScheduleVisitsManager;
import com.queppelin.wudstay.manager.IPgTypeManager;
import com.queppelin.wudstay.manager.IRoomTypeManager;
import com.queppelin.wudstay.util.EmailSender;
import com.queppelin.wudstay.util.SearchParamMapInSession;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.util.WudstayUtil;
import com.queppelin.wudstay.vo.City;
import com.queppelin.wudstay.vo.CityWithHotelCountMVO;
import com.queppelin.wudstay.vo.Hotel;
import com.queppelin.wudstay.vo.HotelAdministrator;
import com.queppelin.wudstay.vo.HotelBooking;
import com.queppelin.wudstay.vo.Location;
import com.queppelin.wudstay.vo.PgHotel;
import com.queppelin.wudstay.vo.PgScheduleVisits;
import com.queppelin.wudstay.vo.PgType;
import com.queppelin.wudstay.vo.RoomType;
import com.queppelin.wudstay.vo.User;
import com.queppelin.wudstay.vo.custom.BookingDetailsVO;
import com.queppelin.wudstay.vo.custom.DiscountCouponInfo;
import com.queppelin.wudstay.vo.custom.HotelAvailabilityVO;
import com.queppelin.wudstay.vo.custom.HotelDetailDto;
import com.queppelin.wudstay.vo.custom.PayUVO;
import com.queppelin.wudstay.web.controller.EndUserMobileController;
import java.io.PrintStream;
import java.io.Serializable;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.commons.lang.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value={"/m"})
public class EndUserMobileController {
    public static final Logger logger = LoggerFactory.getLogger((Class)EndUserMobileController.class);
    private static SimpleDateFormat dateFormat_ddMMyyyy = new SimpleDateFormat("dd/MM/yyyy");
    @Autowired
    IHotelManager hotelManager;
    @Autowired
    ICityManager cityManager;
    @Autowired
    IHotelRoomManager hotelRoomManager;
    @Autowired
    ILocationManager locationManager;
    @Autowired
    IRoomTypeManager roomTypeManager;
    @Autowired
    IHotelAmenityManager hotelAmenityManager;
    @Autowired
    IHotelDescriptionManager hotelDescriptionManager;
    @Autowired
    INumberVerificationManager numberVerificationManager;
    @Autowired
    IHotelBookingManager hotelBookingManager;
    @Autowired
    IHotelAdministratorManager hotelAdministratorManager;
    @Autowired
    ICouponCodeManager couponCodeManager;
    @Autowired
    IHdfcTranLogManager hdfcTranLogManager;
    @Autowired
    IPayuMobTranManager payuMobTranManager;
    @Autowired
    IPgTypeManager pgTypeManager;
    @Autowired
    IPgHotelManager pgHotelManager;
    @Autowired
    IPgScheduleVisitsManager pgScheduleVisitsManager;

    @RequestMapping(value={"citibank"})
    public ModelAndView citibank(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("m_citibank");
        return modelAndView;
    }

    @RequestMapping(value={"google"})
    public ModelAndView google(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("m_google");
        return modelAndView;
    }

    @RequestMapping(value={"JGOS2016"})
    public ModelAndView JGOS2016(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("m_JGOS2016");
        return modelAndView;
    }

    @RequestMapping(value={"jgos2016"})
    public ModelAndView jgos2016(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("m_JGOS2016");
        return modelAndView;
    }

    @RequestMapping(value={"LineJGOS"})
    public ModelAndView LineJGOS(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("m_LineJGOS");
        return modelAndView;
    }

    @RequestMapping(value={"linejgos"})
    public ModelAndView linejgos(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("m_LineJGOS");
        return modelAndView;
    }

    @RequestMapping(value={"LINEJGOS"})
    public ModelAndView LINEJGOS(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("m_LineJGOS");
        return modelAndView;
    }

    @RequestMapping(value={"TselJGOS"})
    public ModelAndView TselJGOS(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("m_TselJGOS");
        return modelAndView;
    }

    @RequestMapping(value={"TSELJGOS"})
    public ModelAndView TSELJGOS(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("m_TselJGOS");
        return modelAndView;
    }

    @RequestMapping(value={"tseljgos"})
    public ModelAndView tseljgos(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("m_TselJGOS");
        return modelAndView;
    }
    @RequestMapping(value={"permata"})
    public ModelAndView permata(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("m_permata");
        try {
            Long cityId = 67L;
            City city = (City)this.cityManager.getById((Serializable)cityId);
            HashMap searchParamMap = (HashMap)session.getAttribute("searchParamsHashMap");
            int rooms = (Integer)searchParamMap.get("rooms");
            int persons = (Integer)searchParamMap.get("persons");
            String checkIn = (String)searchParamMap.get("checkIn");
            String checkOut = (String)searchParamMap.get("checkOut");
            this.extractSearchParam(searchParamMap, modelAndView);
            List hotelList = this.hotelManager.getHotelByCityId(cityId, persons / rooms);
            hotelList = WudstayUtil.processHotelList((List)hotelList, (Integer)rooms, (Integer)persons, (IHotelBookingManager)this.hotelBookingManager, (String)checkIn, (String)checkOut, (IHotelManager)this.hotelManager);
            modelAndView.addObject("NO_OF_FILTERED_HOTELS", (Object)hotelList.size());
            modelAndView.addObject("city", (Object)city.getCityName());
            modelAndView.addObject("cityId", (Object)cityId);
            modelAndView.addObject("isAllRoomTypeSelected", (Object)Boolean.FALSE);
            modelAndView.addObject("hotelList", (Object)hotelList);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return modelAndView;
    }
	@RequestMapping("permata25")
	public ModelAndView permata25(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView("mob_permata25");
		//changeLocale(locale, request, response, session);
		//----------------------------------------------
		try {
			Long cityId = 67L; //City Name: 40 Percent Off Sale
			City city = cityManager.getById(cityId);
			HashMap<String, Object> searchParamMap = (HashMap<String, Object>) session.getAttribute(WudstayConstants.SEARCH_PARAM_MAP);
			int rooms = (Integer) searchParamMap.get("rooms");
			int persons = (Integer) searchParamMap.get("persons");
			String checkIn = (String) searchParamMap.get("checkIn");
			String checkOut = (String) searchParamMap.get("checkOut");
			extractSearchParam(searchParamMap, modelAndView);
			List<Hotel> hotelList = hotelManager.getHotelByCityId(cityId, persons / rooms);
			hotelList = WudstayUtil.processHotelList(hotelList, rooms, persons, hotelBookingManager, checkIn, checkOut, hotelManager);
			//WudstayUtil.setAmenitiesForHotel(hotelList);
			modelAndView.addObject("NO_OF_FILTERED_HOTELS", hotelList.size());
			modelAndView.addObject("city", city.getCityName());
			modelAndView.addObject("cityId", cityId);
			modelAndView.addObject("isAllRoomTypeSelected", Boolean.FALSE);
			modelAndView.addObject("hotelList", hotelList);
		}catch (Exception ex){
			ex.printStackTrace();
		}
		//-------------------------------------------------
		return modelAndView;
	}
	@RequestMapping("PERMATA25")
	public ModelAndView PERMATA25(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView("mob_permata25");
		//changeLocale(locale, request, response, session);
		//----------------------------------------------
		try {
			Long cityId = 67L; //City Name: 40 Percent Off Sale
			City city = cityManager.getById(cityId);
			HashMap<String, Object> searchParamMap = (HashMap<String, Object>) session.getAttribute(WudstayConstants.SEARCH_PARAM_MAP);
			int rooms = (Integer) searchParamMap.get("rooms");
			int persons = (Integer) searchParamMap.get("persons");
			String checkIn = (String) searchParamMap.get("checkIn");
			String checkOut = (String) searchParamMap.get("checkOut");
			extractSearchParam(searchParamMap, modelAndView);
			List<Hotel> hotelList = hotelManager.getHotelByCityId(cityId, persons / rooms);
			hotelList = WudstayUtil.processHotelList(hotelList, rooms, persons, hotelBookingManager, checkIn, checkOut, hotelManager);
			//WudstayUtil.setAmenitiesForHotel(hotelList);
			modelAndView.addObject("NO_OF_FILTERED_HOTELS", hotelList.size());
			modelAndView.addObject("city", city.getCityName());
			modelAndView.addObject("cityId", cityId);
			modelAndView.addObject("isAllRoomTypeSelected", Boolean.FALSE);
			modelAndView.addObject("hotelList", hotelList);
		}catch (Exception ex){
			ex.printStackTrace();
		}
		//-------------------------------------------------
		return modelAndView;
	}
    @RequestMapping(value={"ramadhan"})
    public ModelAndView ramadhan(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("m_ramadhan");
        return modelAndView;
    }

    @RequestMapping(value={"sgholiday"})
    public ModelAndView sgholiday(Locale locale, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("m_sgholiday");
        return modelAndView;
    }


    private ModelAndView extractSearchParam(HashMap<String, Object> searchParamMap, ModelAndView modelAndView) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        try {
            int rooms = (Integer)searchParamMap.get("rooms");
            int persons = (Integer)searchParamMap.get("persons");
            String checkIn = (String)searchParamMap.get("checkIn");
            String checkOut = (String)searchParamMap.get("checkOut");
            modelAndView.addObject("checkIn", (Object)dateFormat.format(format.parse(checkIn)));
            modelAndView.addObject("checkOut", (Object)dateFormat.format(format.parse(checkOut)));
            modelAndView.addObject("rooms", (Object)rooms);
            modelAndView.addObject("persons", (Object)persons);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return modelAndView;
    }

    @RequestMapping
    public ModelAndView getAllCities_1(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("m_home");
        try {
            List lst = this.cityManager.getAllCitiesWithHotelCount();
            modelAndView.addObject("cityList", (Object)lst);
            try {
                modelAndView.addObject("SELECTED_CITY", (Object)SearchParamMapInSession.refreshSearchParamMap((HttpSession)session, (CityWithHotelCountMVO)this.cityManager.getCityByIdWithHotelCount(Long.valueOf(2))).getSelectedCity());
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    @RequestMapping(value={"/"})
    public ModelAndView getAllCities(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("m_home");
        try {
            List lst = this.cityManager.getAllCitiesWithHotelCount();
            modelAndView.addObject("cityList", (Object)lst);
            modelAndView.addObject("SELECTED_CITY", (Object)SearchParamMapInSession.refreshSearchParamMap((HttpSession)session, (CityWithHotelCountMVO)this.cityManager.getCityByIdWithHotelCount(Long.valueOf(2))).getSelectedCity());
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    @RequestMapping(method={RequestMethod.GET, RequestMethod.POST}, value={"hotelDetail"})
    public ModelAndView hotelDetail(HttpServletRequest request, HttpSession session) {
        Long selectedHotelIdId = Long.parseLong(this.getRequestParameter(request, "hotelId", "0"));
        String searchHotelType = this.getRequestParameter(request, "searchHotelType", "hotel").toUpperCase();
        return this.hotelDetail_0(selectedHotelIdId, searchHotelType, request, session);
    }

    @RequestMapping(method={RequestMethod.GET}, value={"{cityName}/hotel"})
    public ModelAndView getHotelDetails(@RequestParam Long hotelId, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        String searchHotelType = "HOTEL";
        return this.hotelDetail_0(hotelId, searchHotelType, request, session);
    }

    public ModelAndView hotelDetail_0(Long selectedHotelIdId, String searchHotelType, HttpServletRequest request, HttpSession session) {
        ModelAndView modelAndView;
        block10 : {
            modelAndView = new ModelAndView("m_hotelDetail");
            try {
                HotelDetailDto hotel = this.hotelManager.getHotelDetailWithAmenity(selectedHotelIdId.longValue(), searchHotelType,request);
                if (searchHotelType != null && "PG".equalsIgnoreCase(searchHotelType.trim())) {
                    modelAndView = new ModelAndView("m_pgDetail");
                }
                if (hotel == null) break block10;
                modelAndView.addObject("hotelDetail", (Object)hotel);
                modelAndView.addObject("selectedCityId", (Object)hotel.getCityId());
                modelAndView.addObject("searchHotelType", (Object)searchHotelType);
                try {
                    SearchParamMapInSession sessonData = SearchParamMapInSession.refreshSearchParamMap((HttpSession)session);
                    if (!"PG".equalsIgnoreCase(searchHotelType)) {
                        try {
                            String cityName = "-";
                            Long hotelId = hotel.getHotelId();
                            Long cityId = hotel.getCityId();
                            HotelAvailabilityVO hotelAvailabilityVO = WudstayUtil.isAvailable((Long)cityId, (String)cityName, (Long)hotelId, (Integer)sessonData.getRooms(), (String)sessonData.getCheckIn(), (String)sessonData.getCheckOut(), (IHotelBookingManager)this.hotelBookingManager);
                            hotel.setAvailable(hotelAvailabilityVO.getIsAvailable().booleanValue());
                            modelAndView.addObject("hotelDetail", (Object)hotel);
                            try {
                                modelAndView.addObject("SELECTED_HOTEL_ID", (Object)hotelId);
                                modelAndView.addObject("SELECTED_CITY_ID", (Object)cityId);
                                City city = (City)this.cityManager.getById((Serializable)cityId);
                                modelAndView.addObject("SELECTED_CITY_NAME", (Object)city.getCityName());
                            }
                            catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        catch (Exception ex) {
                            ex.getMessage();
                        }
                    }
                    modelAndView.addObject("SELECTED_CHECKED_IN", (Object)sessonData.getSeletedCheckIn());
                    modelAndView.addObject("SELECTED_CHECKED_OUT", (Object)sessonData.getSeletedCheckOut());
                    modelAndView.addObject("SELECTED_ROOMS", (Object)sessonData.getRooms());
                    modelAndView.addObject("SELECTED_PERSONS", (Object)sessonData.getPersons());
                    Hotel hotelObj = (Hotel)this.hotelManager.getById((Serializable)hotel.getHotelId());
                    Map<String, Object> map = this.updateSessionPreBooking(session, hotelObj, sessonData);
                    HotelAvailabilityVO hotelAvailabilityVO = (HotelAvailabilityVO)map.get("hotelAvailability");
                    BookingDetailsVO bookingDetailsVO = (BookingDetailsVO)map.get("bookingDetailsVO");
                    modelAndView.addObject("hotelAvailability", (Object)hotelAvailabilityVO);
                    modelAndView.addObject("IsBlackoutDateForPayAtHotel", map.get("IsBlackoutDateForPayAtHotel"));
                    Integer gtotal = bookingDetailsVO.getTotalPrice();
                    Integer btotal = bookingDetailsVO.getTotalPriceBeforeDiscount();
                    modelAndView.addObject("price", (Object)btotal);
                    modelAndView.addObject("discount", (Object)(btotal - gtotal));
                    modelAndView.addObject("total_price", (Object)gtotal);
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
                List hotelDescriptionList = this.hotelDescriptionManager.getHotelDescriptionsByHotelId(hotel.getHotelId());
                modelAndView.addObject("hotelDescriptionList", (Object)hotelDescriptionList);
                System.out.println(" listing ");
            }
            catch (Exception e) {
                e.printStackTrace();
                throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
            }
        }
        return modelAndView;
    }

    @RequestMapping(method={RequestMethod.POST}, value={"listing"})
    public ModelAndView searchHotelsOrPg(HttpServletRequest request, HttpSession session) {
        Long selectedCityId = Long.parseLong(this.getRequestParameter(request, "selectedCityId", "0"));
        String searchHotelType = this.getRequestParameter(request, "searchHotelType", "hotel").toUpperCase();
        return this.searchHotelsOrPgByCity(request, session, selectedCityId, searchHotelType);
    }

    @RequestMapping(method={RequestMethod.GET}, value={"{cityName}"})
    public ModelAndView searchHotels_1(@PathVariable String cityName, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        String searchHotelType = "HOTEL";
        return this.searchHotels_0(request, session, cityName, searchHotelType);
    }

    @RequestMapping(method={RequestMethod.GET}, value={"pg/{cityName}"})
    public ModelAndView searchHotels_2(@PathVariable String cityName, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        String searchHotelType = "PG";
        return this.searchHotels_0(request, session, cityName, searchHotelType);
    }

    public ModelAndView searchHotels_0(HttpServletRequest request, HttpSession session, String cityName, String searchHotelType) {
        Long selectedCityId = 2L;
        if ("Bengaluru".equalsIgnoreCase(cityName) || "Bangalore".equalsIgnoreCase(cityName)) {
            cityName = "Bangalore";
        }
        try {
            City city = this.cityManager.getByCityName(cityName);
            selectedCityId = city.getCityId();
        }
        catch (WudstayException e) {
            selectedCityId = 2L;
            e.printStackTrace();
        }
        return this.searchHotelsOrPgByCity(request, session, selectedCityId, searchHotelType);
    }

    @SuppressWarnings("unchecked")
	public ModelAndView searchHotelsOrPgByCity(HttpServletRequest request, HttpSession session, Long selectedCityId, String searchHotelType) {
        ModelAndView modelAndView = new ModelAndView("m_listing");
        int sortOn = 1;
        try {
            List<HotelDetailDto> hotelList;
            SearchParamMapInSession sessonData;
            CityWithHotelCountMVO selectedCity;
            sessonData = SearchParamMapInSession.cleanSearchParamMap((HttpSession)session);
            if ("HOTEL".equalsIgnoreCase(searchHotelType)) {
                modelAndView.addObject("SELECTED_HOTEL_PG_TYPE", (Object)"Hotel");
                modelAndView.addObject("SELECTED_CHECKED_IN", (Object)sessonData.getSeletedCheckIn());
                modelAndView.addObject("SELECTED_CHECKED_OUT", (Object)sessonData.getSeletedCheckOut());
                modelAndView.addObject("SELECTED_ROOMS", (Object)sessonData.getRooms());
                modelAndView.addObject("SELECTED_PERSONS", (Object)sessonData.getPersons());
            } else {
                modelAndView = new ModelAndView("m_pg_listing");
                modelAndView.addObject("SELECTED_HOTEL_PG_TYPE", (Object)"Pg");
            }
            hotelList = this.hotelManager.getHotelsDetailWithAmenity(selectedCityId.longValue(), sortOn, searchHotelType,request);
            selectedCity = null;
            try {
                List<CityWithHotelCountMVO> lst = this.cityManager.getAllCitiesWithHotelCount();
                modelAndView.addObject("cityList", (Object)lst);
                for (CityWithHotelCountMVO city : lst) {
                    if (!selectedCityId.equals(city.getCityId())) continue;
                    selectedCity = city;
                    modelAndView.addObject("SELECTED_CITY", (Object)city);
                    modelAndView.addObject("SELECTED_CITY_HOTEL_COUNT", (Object)city.getTotalHotels());
                    modelAndView.addObject("SELECTED_CITY_PG_COUNT", (Object)city.getTotalPgs());
                    break;
                }
            }
            catch (Exception e) {
                e.printStackTrace();
                throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
            }
            SearchParamMapInSession.refreshSearchParamMap((HttpSession)session, (CityWithHotelCountMVO)selectedCity, (String)searchHotelType);
            hotelList = this.updateHotelAvailability(hotelList, sessonData.getRooms(), sessonData.getCheckIn(), sessonData.getCheckOut(), sessonData.getSeletedHotelOrPg());
            modelAndView.addObject("hotelList", hotelList);
            modelAndView.addObject("locationList", (Object)this.locationManager.getLocationsByCityId(selectedCityId));
            List lstRoomType = new ArrayList();
            if (searchHotelType != null && !"".equals(searchHotelType.trim()) && !"HOTEL".equalsIgnoreCase(searchHotelType.trim())) {
                List<PgType> lstPgType = this.pgTypeManager.list();
                for (PgType pgType : lstPgType) {
                    lstRoomType.add(new RoomType(pgType.getPgTypeId(), pgType.getPgType(), pgType.getPgTypeId()));
                }
            } else {
                lstRoomType = this.roomTypeManager.list();
            }
			Collections.sort(lstRoomType, new Comparator<RoomType>() {
				public int compare(RoomType o1, RoomType o2) {
					return o1.getListingOrder().compareTo(o2.getListingOrder());
				}
			});
			modelAndView.addObject("roomTypeList", lstRoomType);
            modelAndView.addObject("selectedCityId", (Object)selectedCityId);
            modelAndView.addObject("searchHotelType", (Object)searchHotelType);
            System.out.println(" listing ");
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    @RequestMapping(method={RequestMethod.GET, RequestMethod.POST}, value={"resortList"})
    @ResponseBody
    public List<HotelDetailDto> reSortList(@RequestParam Long selectedCityId, @RequestParam String searchHotelType, @RequestParam Integer sortBy, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        List<HotelDetailDto> hotelList = new ArrayList();
        try {
            hotelList = this.hotelManager.getHotelsDetailWithAmenity(selectedCityId.longValue(), sortBy.intValue(), searchHotelType,request);
            SearchParamMapInSession sessonData = SearchParamMapInSession.getSearchParamMap((HttpSession)session);
            hotelList = this.updateHotelAvailability(hotelList, sessonData.getRooms(), sessonData.getCheckIn(), sessonData.getCheckOut(), sessonData.getSeletedHotelOrPg());
            return hotelList;
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
    }

    @RequestMapping(method={RequestMethod.GET, RequestMethod.POST}, value={"filterList"})
    @ResponseBody
    public List<HotelDetailDto> filterList(@RequestParam Long selectedCityId, @RequestParam String searchHotelType, @RequestParam Integer sortBy, @RequestParam Integer price, @RequestParam String roomTypeIds, @RequestParam String locationIds, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        List hotelList = new ArrayList();
        try {
            String id = "";
            hotelList = this.hotelManager.getHotelsDetailWithAmenity(selectedCityId.longValue(), sortBy.intValue(), searchHotelType,request);
            Iterator iterator = hotelList.iterator();
            while (iterator.hasNext()) {
                HotelDetailDto hotel = (HotelDetailDto)iterator.next();
                if (hotel.getSingleOccupancyPrice() > price) {
                    iterator.remove();
                    continue;
                }
                id = hotel.getRoomTypeId()+"";
                if (roomTypeIds != null && !"".equals(roomTypeIds)) {
                    if (roomTypeIds.contains(id)) continue;
                    iterator.remove();
                    continue;
                }
                id = hotel.getRoomTypeId()+"";
                if (locationIds == null || "".equals(locationIds) || locationIds.contains(id)) continue;
                iterator.remove();
            }
            SearchParamMapInSession sessonData = SearchParamMapInSession.getSearchParamMap((HttpSession)session);
            hotelList = this.updateHotelAvailability(hotelList, sessonData.getRooms(), sessonData.getCheckIn(), sessonData.getCheckOut(), sessonData.getSeletedHotelOrPg());
            return hotelList;
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
    }

    private List<HotelDetailDto> updateHotelAvailability(List<HotelDetailDto> hotelList, Integer rooms, String checkIn, String checkOut, String searchHotelType) {
        String cityName = "-";
        for (HotelDetailDto hotel : hotelList) {
            Long hotelId = hotel.getHotelId();
            Long cityId = hotel.getCityId();
            if ("PG".equalsIgnoreCase(searchHotelType)) continue;
            HotelAvailabilityVO hotelAvailabilityVO = WudstayUtil.isAvailable((Long)cityId, (String)cityName, (Long)hotelId, (Integer)rooms, (String)checkIn, (String)checkOut, (IHotelBookingManager)this.hotelBookingManager);
            hotel.setAvailable(hotelAvailabilityVO.getIsAvailable().booleanValue());
        }
        return hotelList;
    }

    @RequestMapping(method={RequestMethod.GET, RequestMethod.POST}, value={"filterHotelList"})
    @ResponseBody
    public List<HotelDetailDto> filterList2(@RequestParam Long selectedCityId, @RequestParam String searchHotelType, @RequestParam Integer sortBy, @RequestParam String daterange, @RequestParam String wudstayGuestsAndRooms, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        HashMap map = new HashMap();
        List<HotelDetailDto> hotelList = new ArrayList();
        try {
            SearchParamMapInSession paramMapInSession = SearchParamMapInSession.refreshSearchParamMap((HttpSession)session, (String)daterange, (String)wudstayGuestsAndRooms);
            hotelList = this.hotelManager.getHotelsDetailWithAmenity(selectedCityId.longValue(), sortBy.intValue(), searchHotelType,request);
            return this.updateHotelAvailability(hotelList, paramMapInSession.getRooms(), paramMapInSession.getCheckIn(), paramMapInSession.getCheckOut(), paramMapInSession.getSeletedHotelOrPg());
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
    }

    @RequestMapping(method={RequestMethod.GET, RequestMethod.POST}, value={"filterPgList"})
    @ResponseBody
    public List<HotelDetailDto> filterList3(@RequestParam Long selectedCityId, @RequestParam Integer sortBy, @RequestParam String roomTypeIds, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        String searchHotelType = "PG";
        ArrayList<HotelDetailDto> hotelList = new ArrayList<HotelDetailDto>();
        try {
            SearchParamMapInSession paramMapInSession = SearchParamMapInSession.cleanSearchParamMap((HttpSession)session);
            List<HotelDetailDto> hotelList2 = this.hotelManager.getHotelsDetailWithAmenity(selectedCityId.longValue(), sortBy.intValue(), searchHotelType,request);
            for (HotelDetailDto hotel : hotelList2) {
                String id = hotel.getRoomTypeId()+"";
                if (roomTypeIds == null || !"".equals(roomTypeIds) && !roomTypeIds.contains(id)) continue;
                hotelList.add(hotel);
            }
            return hotelList;
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
    }

    private Map<String, Object> updateSessionPreBooking(HttpSession session, Hotel hotel, SearchParamMapInSession sessonData) {
        HashMap<String, Object> map = new HashMap<String, Object>();
        try {
            HotelAvailabilityVO hotelAvailabilityVO = sessonData.checkHotelAvailability(hotel, this.hotelBookingManager);
            if (hotel.getAllowTripleOccupancy() != 1) {
                try {
                    int persons = sessonData.getPersons();
                    int rooms = sessonData.getRooms();
                    int minPax = persons / rooms;
                    int minPaxPersons = minPax * rooms;
                    if (persons != minPaxPersons) {
                        ++minPax;
                    }
                    if (minPax == 3) {
                        hotelAvailabilityVO.setStatus(Boolean.FALSE);
                        hotelAvailabilityVO.setErrMsg("Triple Occupancy not allowed.");
                    }
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                    hotelAvailabilityVO.setStatus(Boolean.FALSE);
                }
            }
            map.put("hotelAvailability", (Object)hotelAvailabilityVO);
            sessonData.putSearchParamMapInSession(session, hotel);
            BookingDetailsVO bookingDetailsVO = sessonData.getBookingDetailsVO(hotel);
            try {
                if (session.getAttribute("Booking Details") != null) {
                    BookingDetailsVO bookingDetailsFromSession = (BookingDetailsVO)session.getAttribute("Booking Details");
                    DiscountCouponInfo discountCouponInfo = bookingDetailsFromSession.getDiscountCoupon();
                    bookingDetailsVO.setDiscountCoupon(discountCouponInfo);
                }
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
            session.setAttribute("Booking Details", (Object)bookingDetailsVO);
            map.put("IsBlackoutDateForPayAtHotel", sessonData.isBlackoutDateForPayAtHotel(hotel, this.hotelManager));
            map.put("bookingDetailsVO", (Object)bookingDetailsVO);
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return map;
    }

    @RequestMapping(method={RequestMethod.GET, RequestMethod.POST}, value={"book-hotel"})
    public ModelAndView bookHotel(@RequestParam(required=false) String daterange, @RequestParam(required=false) String checkIn, @RequestParam(required=false) String checkOut, @RequestParam(required=false) Integer rooms, @RequestParam(required=false) Integer persons, @RequestParam(required=false) Long cityId, @RequestParam Long hotelId, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView;
        block16 : {
            modelAndView = new ModelAndView("m_hotelBookingDetail");
            String searchHotelType = "HOTEL";
            try {
                HotelDetailDto hotel;
                if (daterange != null && !"".equals(daterange.trim())) {
                    String[] dates = SearchParamMapInSession.toCheckInOutDates((String)daterange);
                    checkIn = dates[0];
                    checkOut = dates[1];
                }
                SearchParamMapInSession sessonData = SearchParamMapInSession.refreshSearchParamMap((HttpSession)session);
                if (checkIn != null && !"".equals(checkIn.trim())) {
                    sessonData.setCheckIn(checkIn);
                }
                if (checkOut != null && !"".equals(checkOut.trim())) {
                    sessonData.setCheckOut(checkOut);
                }
                if (rooms != null) {
                    sessonData.setRooms(rooms);
                }
                if (persons != null) {
                    sessonData.setPersons(persons);
                }
                if ((hotel = this.hotelManager.getHotelDetailWithAmenity(hotelId.longValue(), searchHotelType,request)) == null) break block16;
                sessonData.setSelectedHotelId(hotel.getHotelId());
                City city = null;
                try {
                    cityId = hotel.getCityId();
                    sessonData.setCityId(cityId);
                    city = (City)this.cityManager.getById((Serializable)cityId);
                    sessonData.setCityName(city.getCityName());
                    sessonData = SearchParamMapInSession.refreshSearchParamMap((HttpSession)session, (SearchParamMapInSession)sessonData);
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
                modelAndView.addObject("hotelDetail", (Object)hotel);
                modelAndView.addObject("selectedCityId", (Object)cityId);
                modelAndView.addObject("searchHotelType", (Object)searchHotelType);
                try {
                    if (!"PG".equalsIgnoreCase(searchHotelType)) {
                        try {
                            String cityName = "-";
                            HotelAvailabilityVO hotelAvailabilityVO = WudstayUtil.isAvailable((Long)cityId, (String)cityName, (Long)hotelId, (Integer)sessonData.getRooms(), (String)sessonData.getCheckIn(), (String)sessonData.getCheckOut(), (IHotelBookingManager)this.hotelBookingManager);
                            hotel.setAvailable(hotelAvailabilityVO.getIsAvailable().booleanValue());
                            modelAndView.addObject("hotelDetail", (Object)hotel);
                            try {
                                modelAndView.addObject("SELECTED_HOTEL_ID", (Object)hotelId);
                                modelAndView.addObject("SELECTED_CITY_ID", (Object)cityId);
                                modelAndView.addObject("SELECTED_CITY_NAME", (Object)city.getCityName());
                            }
                            catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        catch (Exception ex) {
                            ex.getMessage();
                        }
                    }
                    modelAndView.addObject("SELECTED_CHECKED_IN", (Object)sessonData.getSeletedCheckIn());
                    modelAndView.addObject("SELECTED_CHECKED_OUT", (Object)sessonData.getSeletedCheckOut());
                    modelAndView.addObject("SELECTED_ROOMS", (Object)sessonData.getRooms());
                    modelAndView.addObject("SELECTED_PERSONS", (Object)sessonData.getPersons());
                    Hotel hotelObj = (Hotel)this.hotelManager.getById((Serializable)hotel.getHotelId());
                    Map<String, Object> map = this.updateSessionPreBooking(session, hotelObj, sessonData);
                    HotelAvailabilityVO hotelAvailabilityVO = (HotelAvailabilityVO)map.get("hotelAvailability");
                    BookingDetailsVO bookingDetailsVO = (BookingDetailsVO)map.get("bookingDetailsVO");
                    modelAndView.addObject("hotelAvailability", (Object)hotelAvailabilityVO);
                    modelAndView.addObject("IsBlackoutDateForPayAtHotel", map.get("IsBlackoutDateForPayAtHotel"));
                    Integer gtotal = bookingDetailsVO.getTotalPrice();
                    Integer btotal = bookingDetailsVO.getTotalPriceBeforeDiscount();
                    modelAndView.addObject("price", (Object)btotal);
                    modelAndView.addObject("discount", (Object)(btotal - gtotal));
                    modelAndView.addObject("total_price", (Object)gtotal);
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
                List hotelDescriptionList = this.hotelDescriptionManager.getHotelDescriptionsByHotelId(hotel.getHotelId());
                modelAndView.addObject("hotelDescriptionList", (Object)hotelDescriptionList);
                System.out.println(" listing ");
            }
            catch (Exception e) {
                e.printStackTrace();
                throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
            }
        }
        return modelAndView;
    }

	@RequestMapping(method = {RequestMethod.GET,RequestMethod.POST}, value = "bookHotel.do")
	public @ResponseBody Map<String, Object> bookHotel(@RequestParam Long hotelId, @RequestParam String daterange, @RequestParam Integer persons, @RequestParam Integer rooms,
														HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		Map<String, Object> map = new HashMap<String, Object>();
		try {
			Hotel hotel = hotelManager.getById(hotelId);
			SearchParamMapInSession sessonData = SearchParamMapInSession.getAndRefreshSearchParamMap(session, daterange, persons, rooms);
			map = updateSessionPreBooking( session,  hotel,sessonData);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return map;
	}

    @RequestMapping(method={RequestMethod.GET, RequestMethod.POST}, value={"scheduleVisit.do"})
    public ModelAndView scheduleVisit(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("m_visit_confirmation");
        try {
            String meetingTime = request.getParameter("meetingTime");
            String meetingDate = request.getParameter("daterange");
            String meetingDateTime = "";
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String mobileNumber = request.getParameter("mobileNumber");
            Date dtMeetingTime = new Date();
            PgScheduleVisits scheduleVisit = new PgScheduleVisits();
            scheduleVisit.setGuestName(name == null ? "" : name.trim());
            scheduleVisit.setGuestEmail(email == null ? "" : email.trim());
            scheduleVisit.setGuestPhone(mobileNumber == null ? "" : mobileNumber.trim());
            try {
                meetingDate = meetingDate == null || "".equals(meetingDate.trim()) ? dateFormat_ddMMyyyy.format(new Date()) : meetingDate.trim();
                meetingTime = meetingTime == null || "".equals(meetingTime.trim()) ? "09:00 PM" : meetingTime.trim();
                meetingDateTime = String.valueOf(meetingDate.trim()) + " " + meetingTime.trim();
                SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy HH:mm aa");
                dtMeetingTime = format.parse(meetingDateTime);
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
            scheduleVisit.setMeetingTime(dtMeetingTime);
            modelAndView.addObject("pgDisplayName", (Object)" ");
            modelAndView.addObject("pgAddress", (Object)" ");
            try {
                String id = request.getParameter("selectedHotelId");
                Long pgHotelId = Long.parseLong(id.trim());
                PgHotel pgHotel = (PgHotel)this.pgHotelManager.getById((Serializable)pgHotelId);
                scheduleVisit.setHotel(pgHotel);
                this.pgScheduleVisitsManager.saveOrUpdate(scheduleVisit);
                modelAndView.addObject("selectedHotel_Id", (Object)pgHotelId);
                modelAndView.addObject("pgDisplayName", (Object)pgHotel.getDisplayName());
                modelAndView.addObject("pgAddress", (Object)pgHotel.getDisplayAddress());
                try {
                    String msg = "Dear " + name + ", this is to confirm that you've scheduled a visit to the '" + pgHotel.getDisplayName() + "' house/PG via WudStay. Address: " + pgHotel.getDisplayAddress();
                    msg = String.valueOf(msg) + " Time of visit : + " + meetingDateTime;
                    msg = String.valueOf(msg) + ". For any assistance you can call us anytime at +62822 8539 0099.";
                    WudstayUtil.sendConfirmationMessage((String)msg, (String)mobileNumber);
                    HashMap<String, Object> emailData = new HashMap<String, Object>();
                    emailData.put("GUEST", name);
                    emailData.put("GUEST_PHONE", mobileNumber);
                    emailData.put("GUEST_EMAIL", email);
                    emailData.put("BOOKING_ID", scheduleVisit.getTransactionId());
                    emailData.put("PG_NAME", pgHotel.getDisplayName());
                    emailData.put("PG_ADDRESS", pgHotel.getDisplayAddress());
                    emailData.put("DATE_AND_TIME_OF_VISIT", meetingDateTime);
                    emailData.put("PG_PRICE", pgHotel.getSingleOccupancyWudstayPrice());
                    ArrayList<String> ccList = new ArrayList<String>();
                    ccList.add("support@tinggal.com");
                    String[] bccArray = new String[]{"prafulla@tinggal.com", "praveen.k@tinggal.com", "support@tinggal.com", "surender.r@wudstay.com"};
                    EmailSender.getInstance().sendEmail(email, "Visit Confirmation", emailData, "pgVisitSchedulingEmailBody.vm", ccList, bccArray);
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
            modelAndView.addObject("name", (Object)scheduleVisit.getGuestName());
            modelAndView.addObject("email", (Object)scheduleVisit.getGuestEmail());
            modelAndView.addObject("mobileNumber", (Object)scheduleVisit.getGuestPhone());
            modelAndView.addObject("TransactionId", (Object)scheduleVisit.getTransactionId());
            modelAndView.addObject("meetingTime", (Object)meetingDateTime);
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    @RequestMapping(method={RequestMethod.GET}, value={"booking-confirmation"})
    public ModelAndView showBookingDetails(@RequestParam String mobileNumber, @RequestParam String name, @RequestParam String email, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("m_booking_confirmation");
        try {
            HashMap searchParamMap = (HashMap)session.getAttribute("searchParamsHashMap");
            BookingDetailsVO bookingDetailsVO = (BookingDetailsVO)session.getAttribute("Booking Details");
            Integer totalAmountPaid = (Integer)session.getAttribute("totalAmountPaid");
            modelAndView.addObject("guest_name", (Object)name);
            modelAndView.addObject("selectedHotel_hotelDisplayName", (Object)bookingDetailsVO.getHotelDisplayName());
            modelAndView.addObject("selectedHotel_hotelDisplayAddress", (Object)bookingDetailsVO.getDisplayAddress());
            modelAndView.addObject("guest_CheckIn", (Object)bookingDetailsVO.getCheckInDate());
            modelAndView.addObject("guest_CheckOut", (Object)bookingDetailsVO.getCheckOutDate());
            modelAndView.addObject("guest_rooms", (Object)searchParamMap.get("rooms").toString());
            modelAndView.addObject("guest_persons", (Object)searchParamMap.get("persons").toString());
            modelAndView.addObject("totalPrice", (Object)totalAmountPaid);
            session.removeAttribute("totalAmountPaid");
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    @RequestMapping(method={RequestMethod.GET, RequestMethod.POST}, value={"confirmBooking.do"})
    public ModelAndView confirmBooking(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        ModelAndView modelAndView = new ModelAndView("m_booking_confirmation");
        Long hotelId = Long.parseLong(this.getRequestParameter(request, "selectedHotelId", "0"));
        SearchParamMapInSession sessonData = SearchParamMapInSession.getSearchParamMap((HttpSession)session);
        String countryCode = this.getRequestParameter(request, "countryCode", "62");
        String mobileNumber = String.valueOf(countryCode) + "-" + this.getRequestParameter(request, "mobileNumber", "");
        String name = this.getRequestParameter(request, "name", "");
        String email = this.getRequestParameter(request, "email", "");
        modelAndView.addObject("PG_POSTFIX", (Object)"");
        modelAndView.addObject("guest_name", (Object)name);
        modelAndView.addObject("guest_mobileNumber", (Object)mobileNumber);
        modelAndView.addObject("guest_email", (Object)email);
        modelAndView.addObject("selectedHotel_Id", (Object)hotelId);
        modelAndView.addObject("guest_CheckIn", (Object)sessonData.getSeletedCheckIn());
        modelAndView.addObject("guest_CheckOut", (Object)sessonData.getSeletedCheckOut());
        modelAndView.addObject("guest_persons", (Object)sessonData.getPersons());
        modelAndView.addObject("guest_rooms", (Object)sessonData.getRooms());
        int persons = Integer.valueOf(sessonData.getPersons().toString());
        try {
            ArrayList<String> ccList = new ArrayList<String>();
            HashMap searchParamMap = (HashMap)session.getAttribute("searchParamsHashMap");
            BookingDetailsVO bookingDetailsVO = (BookingDetailsVO)session.getAttribute("Booking Details");
            bookingDetailsVO.setPersons(Integer.valueOf(persons));
            Integer discount = 0;
            Integer sourceOfBooking = WudstayConstants.getSourceOfBooking((String)"MOBILE-WEB", (int)14);
            String bookingId = this.hotelBookingManager.makeBooking(bookingDetailsVO, name, mobileNumber, searchParamMap.get("checkIn").toString(), searchParamMap.get("checkOut").toString(), Integer.valueOf(searchParamMap.get("rooms").toString()), Integer.valueOf(searchParamMap.get("persons").toString()), email, Boolean.FALSE, null, null, discount, sourceOfBooking, Integer.valueOf(0));
            modelAndView.addObject("guest_bookingId", (Object)bookingId);
            modelAndView.addObject("totalPrice", (Object)bookingDetailsVO.getTotalPrice());
            session.setAttribute("totalAmountPaid", (Object)0);
            Hotel hotel = (Hotel)this.hotelManager.getById((Serializable)bookingDetailsVO.getHotelId());
            bookingDetailsVO.setBreakfastIncludedInPrice(Boolean.valueOf(hotel.getIsBreakfastIncludedInPrice()));
            WudstayUtil.sendConfirmationMessage((String)("Dear " + name + ", your Tinggal booking has been confirmed from " + bookingDetailsVO.getCheckInDate() + " to " + bookingDetailsVO.getCheckOutDate() + " at " + bookingDetailsVO.getHotelName() + ". The address is " + bookingDetailsVO.getAddress() + " and your booking id is " + bookingId + ". You can locate the stay at Google Maps on " + "the link " + bookingDetailsVO.getMapLink() + ". For any assistance you can call us anytime at +62822 8539 0099. Please carry a valid govt. address and ID proof when you checkin."), (String)mobileNumber);
            this.sendConfirmationMail(name, email, bookingDetailsVO, ccList, bookingId, new Integer(0));
            String hotelAdministratorEmail = null;
            HotelAdministrator hotelAdministrator = this.hotelAdministratorManager.getHotelAdminByHotelId(bookingDetailsVO.getHotelId());
            if (hotelAdministrator.getUser().getEmail() != null && !hotelAdministrator.getUser().getEmail().trim().equals("")) {
                hotelAdministratorEmail = hotelAdministrator.getUser().getEmail();
            }
            modelAndView.addObject("selectedHotel_hotelDisplayName", (Object)hotel.getHotelDisplayName());
            modelAndView.addObject("selectedHotel_hotelDisplayAddress", (Object)hotel.getHotelDisplayAddress());
            if (hotel.getContactPersonEmail1() != null && !hotel.getContactPersonEmail1().trim().equals("")) {
                ccList.add(hotel.getContactPersonEmail1());
            }
            if (hotel.getContactPersonEmail2() != null && !hotel.getContactPersonEmail2().trim().equals("")) {
                ccList.add(hotel.getContactPersonEmail2());
            }
            this.sendConfirmationMailToHotelAdmin(name, hotelAdministratorEmail, bookingDetailsVO, ccList, bookingId, new Integer(0));
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    @RequestMapping(method={RequestMethod.GET}, value={"processPayNow.do"})
    @ResponseBody
    public PayUVO processPayNow(@RequestParam String mobileNumber, @RequestParam String name, @RequestParam String email, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        PayUVO payUVO = new PayUVO();
        try {
            BookingDetailsVO bookingDetailsVO = (BookingDetailsVO)session.getAttribute("Booking Details");
            HashMap searchParamMap = (HashMap)session.getAttribute("searchParamsHashMap");
            payUVO.setFirstName(name);
            payUVO.setEmail(email);
            payUVO.setAmount(bookingDetailsVO.getTotalPrice());
            payUVO.setMerchantKey("44fZt5");
            payUVO.setProductInfo("Hotel Booking From Mobile");
            payUVO.setSalt("t5vIbSb7");
            String transactionId = RandomStringUtils.randomAlphanumeric((int)15).toUpperCase();
            payUVO.setTransactionId(transactionId);
            payUVO.setPhone(mobileNumber);
            payUVO.setCurl("http://www.wudstay.com/paymentCancel.do");
            payUVO.setFurl("http://www.wudstay.com/paymentFailure.do");
            payUVO.setSurl("http://www.wudstay.com/m/paymentSuccess.do");
            StringBuffer buffer = new StringBuffer();
            buffer.append(payUVO.getMerchantKey());
            buffer.append("|");
            buffer.append(payUVO.getTransactionId());
            buffer.append("|");
            buffer.append(payUVO.getAmount());
            buffer.append("|");
            buffer.append(payUVO.getProductInfo());
            buffer.append("|");
            buffer.append(payUVO.getFirstName());
            buffer.append("|");
            buffer.append(payUVO.getEmail());
            buffer.append("|");
            payUVO.setUdf1(WudstayUtil.getUDFBookingDetails((BookingDetailsVO)bookingDetailsVO));
            buffer.append(payUVO.getUdf1());
            buffer.append("|");
            payUVO.setUdf2(WudstayUtil.getUDFSearchParam((HashMap)searchParamMap));
            buffer.append(payUVO.getUdf2());
            buffer.append("|||||||||");
            buffer.append(payUVO.getSalt());
            MessageDigest md = MessageDigest.getInstance("SHA-512");
            md.update(buffer.toString().getBytes());
            byte[] byteData = md.digest();
            StringBuffer sb = new StringBuffer();
            int i = 0;
            while (i < byteData.length) {
                sb.append(Integer.toString((byteData[i] & 255) + 256, 16).substring(1));
                ++i;
            }
            payUVO.setHash(sb.toString());
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return payUVO;
    }

    @RequestMapping(method={RequestMethod.POST}, value={"paymentCancel.do"})
    public ModelAndView paymentCancel(HttpServletResponse response, HttpSession session, HttpServletRequest request) {
        ModelAndView modelAndView = null;
        String name = request.getParameter("firstname");
        String email = request.getParameter("email");
        String mobileNumber = request.getParameter("phone");
        String bookingDetailsUDF = request.getParameter("udf1");
        String searchParamUDF = request.getParameter("udf2");
        String[] searchParamSplit = searchParamUDF.split("#");
        String checkInDate = searchParamSplit[0];
        String checkOutDate = searchParamSplit[1];
        Integer rooms = Integer.valueOf(searchParamSplit[2]);
        Integer persons = Integer.valueOf(searchParamSplit[3]);
        BookingDetailsVO bookingDetailsVO = WudstayUtil.getBookingDetailsVOPayU((String)bookingDetailsUDF, (IHotelManager)this.hotelManager, (Integer)rooms, (Integer)persons);
        session.setAttribute("Booking Details", (Object)bookingDetailsVO);
        Hotel hotel = (Hotel)this.hotelManager.getById((Serializable)bookingDetailsVO.getHotelId());
        session.setAttribute("searchParamsHashMap", SearchParamMapInSession.getSearchParamHashMap((String)hotel.getLocation().getCity().getCityName(), (Long)hotel.getLocation().getCity().getCityId(), (String)checkInDate, (String)checkOutDate, (Integer)rooms, (Integer)persons));
        modelAndView = new ModelAndView("redirect:book-hotel?checkIn=" + checkInDate + "&checkOut=" + checkOutDate + "&rooms=" + rooms + "&persons=" + persons + "&cityId=" + hotel.getLocation().getCity().getCityId() + "&hotelId=" + bookingDetailsVO.getHotelId());
        session.setAttribute("isPaymentSuccess", (Object)Boolean.FALSE);
        session.setAttribute("name", (Object)name);
        session.setAttribute("email", (Object)email);
        session.setAttribute("mobileNumber", (Object)mobileNumber);
        return modelAndView;
    }

    @RequestMapping(method={RequestMethod.POST}, value={"paymentFailure.do"})
    public ModelAndView paymentFailure(HttpServletResponse response, HttpSession session, HttpServletRequest request) {
        ModelAndView modelAndView = null;
        String name = request.getParameter("firstname");
        String email = request.getParameter("email");
        String mobileNumber = request.getParameter("phone");
        String bookingDetailsUDF = request.getParameter("udf1");
        String searchParamUDF = request.getParameter("udf2");
        String[] searchParamSplit = searchParamUDF.split("#");
        String checkInDate = searchParamSplit[0];
        String checkOutDate = searchParamSplit[1];
        Integer rooms = Integer.valueOf(searchParamSplit[2]);
        Integer persons = Integer.valueOf(searchParamSplit[3]);
        BookingDetailsVO bookingDetailsVO = WudstayUtil.getBookingDetailsVOPayU((String)bookingDetailsUDF, (IHotelManager)this.hotelManager, (Integer)rooms, (Integer)persons);
        session.setAttribute("Booking Details", (Object)bookingDetailsVO);
        Hotel hotel = (Hotel)this.hotelManager.getById((Serializable)bookingDetailsVO.getHotelId());
        session.setAttribute("searchParamsHashMap", SearchParamMapInSession.getSearchParamHashMap((String)hotel.getLocation().getCity().getCityName(), (Long)hotel.getLocation().getCity().getCityId(), (String)checkInDate, (String)checkOutDate, (Integer)rooms, (Integer)persons));
        modelAndView = new ModelAndView("redirect:book-hotel?checkIn=" + checkInDate + "&checkOut=" + checkOutDate + "&rooms=" + rooms + "&persons=" + persons + "&cityId=" + hotel.getLocation().getCity().getCityId() + "&hotelId=" + bookingDetailsVO.getHotelId());
        session.setAttribute("isPaymentSuccess", (Object)Boolean.FALSE);
        session.setAttribute("name", (Object)name);
        session.setAttribute("email", (Object)email);
        session.setAttribute("mobileNumber", (Object)mobileNumber);
        return modelAndView;
    }

    @RequestMapping(method={RequestMethod.POST}, value={"paymentSuccess.do"})
    public ModelAndView paymentSucces(HttpServletResponse response, HttpSession session, HttpServletRequest request) {
        ModelAndView modelAndView = null;
        Double dAmount = Double.valueOf(request.getParameter("amount"));
        Integer amount = dAmount.intValue();
        String txnid = request.getParameter("txnid");
        String name = request.getParameter("firstname");
        String email = request.getParameter("email");
        String mobileNumber = request.getParameter("phone");
        String mihpayid = request.getParameter("mihpayid");
        String status = request.getParameter("status");
        String bookingDetailsUDF = request.getParameter("udf1");
        String searchParamUDF = request.getParameter("udf2");
        String[] searchParamSplit = searchParamUDF.split("#");
        String checkInDate = searchParamSplit[0];
        String checkOutDate = searchParamSplit[1];
        Integer rooms = Integer.valueOf(searchParamSplit[2]);
        Integer persons = Integer.valueOf(searchParamSplit[3]);
        BookingDetailsVO bookingDetailsVO = WudstayUtil.getBookingDetailsVOPayU((String)bookingDetailsUDF, (IHotelManager)this.hotelManager, (Integer)rooms, (Integer)persons);
        session.setAttribute("Booking Details", (Object)bookingDetailsVO);
        Hotel hotel = (Hotel)this.hotelManager.getById((Serializable)bookingDetailsVO.getHotelId());
        session.setAttribute("searchParamsHashMap", SearchParamMapInSession.getSearchParamHashMap((String)hotel.getLocation().getCity().getCityName(), (Long)hotel.getLocation().getCity().getCityId(), (String)checkInDate, (String)checkOutDate, (Integer)rooms, (Integer)persons));
        if (!status.equals("success")) {
            modelAndView = new ModelAndView("redirect:book-hotel?checkIn=" + checkInDate + "&checkOut=" + checkOutDate + "&rooms=" + rooms + "&persons=" + persons + "&cityId=" + hotel.getLocation().getCity().getCityId() + "&hotelId=" + bookingDetailsVO.getHotelId());
            session.setAttribute("isPaymentSuccess", (Object)Boolean.FALSE);
            session.setAttribute("name", (Object)name);
            session.setAttribute("email", (Object)email);
            session.setAttribute("mobileNumber", (Object)mobileNumber);
            return modelAndView;
        }
        modelAndView = new ModelAndView("m_booking_confirmation");
        modelAndView.addObject("PG_POSTFIX", (Object)"");
        modelAndView.addObject("guest_name", (Object)name);
        modelAndView.addObject("guest_mobileNumber", (Object)mobileNumber);
        modelAndView.addObject("guest_email", (Object)email);
        modelAndView.addObject("selectedHotel_Id", (Object)hotel.getHotelId());
        modelAndView.addObject("guest_CheckIn", (Object)checkInDate);
        modelAndView.addObject("guest_CheckOut", (Object)checkOutDate);
        modelAndView.addObject("guest_persons", (Object)persons);
        modelAndView.addObject("guest_rooms", (Object)rooms);
        modelAndView.addObject("selectedHotel_hotelDisplayName", (Object)hotel.getHotelDisplayName());
        modelAndView.addObject("selectedHotel_hotelDisplayAddress", (Object)hotel.getHotelDisplayAddress());
        try {
            Integer discount = 0;
            Integer sourceOfBooking = WudstayConstants.getSourceOfBooking((String)"MOBILE-WEB", (int)14);
            ///String bookingId = this.hotelBookingManager.makeBooking(bookingDetailsVO, name, mobileNumber, checkInDate, checkOutDate, rooms, persons, email, Boolean.TRUE, txnid, mihpayid, discount, sourceOfBooking);
            String bookingId ="";
            if(txnid!=null){
            	
                List<HotelBooking> hotelTxnList = hotelBookingManager.getBookingsByTransactionId(txnid);
                   if(hotelTxnList.size()==0){
                	   bookingId = this.hotelBookingManager.makeBooking(bookingDetailsVO, name, mobileNumber, checkInDate, checkOutDate, rooms, persons, email, Boolean.TRUE, txnid, mihpayid, discount, sourceOfBooking);
                    }
              }
            session.setAttribute("totalAmountPaid", (Object)amount);
            modelAndView.addObject("guest_bookingId", (Object)bookingId);
            modelAndView.addObject("totalPrice", (Object)bookingDetailsVO.getTotalPrice());
            HotelAdministrator hotelAdministrator = this.hotelAdministratorManager.getHotelAdminByHotelId(bookingDetailsVO.getHotelId());
            WudstayUtil.sendConfirmationMessage((String)("Dear " + name + ", your Tinggal booking has been confirmed from " + bookingDetailsVO.getCheckInDate() + " to " + bookingDetailsVO.getCheckOutDate() + " at " + bookingDetailsVO.getHotelName() + ". The address is " + bookingDetailsVO.getAddress() + " and your booking id is " + bookingId + ". You can locate the stay at Google Maps on " + "the link " + bookingDetailsVO.getMapLink() + ". For any assistance you can call us anytime at +62822 8539 0099. Please carry a valid govt. address and ID proof when you checkin."), (String)mobileNumber);
            ArrayList<String> ccList = new ArrayList<String>();
            if (hotel.getContactPersonEmail1() != null && !hotel.getContactPersonEmail1().trim().equals("")) {
                ccList.add(hotel.getContactPersonEmail1());
            }
            if (hotel.getContactPersonEmail2() != null && !hotel.getContactPersonEmail2().trim().equals("")) {
                ccList.add(hotel.getContactPersonEmail2());
            }
            if (hotelAdministrator.getUser().getEmail() != null && !hotelAdministrator.getUser().getEmail().trim().equals("")) {
                ccList.add(hotelAdministrator.getUser().getEmail());
            }
            this.sendConfirmationMail(name, email, bookingDetailsVO, ccList, bookingId, amount);
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return modelAndView;
    }

    private void sendConfirmationMail(String name, String email, BookingDetailsVO bookingDetailsVO, List<String> ccList, String bookingId, Integer paidAmount) throws MessagingException {
        HashMap<String, Object> bookingConfirmationBodyDetails = new HashMap<String, Object>();
        bookingConfirmationBodyDetails.put("GUEST", name);
        bookingConfirmationBodyDetails.put("CHECK_IN", bookingDetailsVO.getCheckInDate().split(",")[1].trim());
        bookingConfirmationBodyDetails.put("CHECK_OUT", bookingDetailsVO.getCheckOutDate().split(",")[1].trim());
        bookingConfirmationBodyDetails.put("HOTEL_DISPLAY_NAME", bookingDetailsVO.getHotelDisplayName());
        bookingConfirmationBodyDetails.put("BOOKING_ID", bookingId);
        bookingConfirmationBodyDetails.put("ROOM_COUNT", bookingDetailsVO.getRoomDetailsVOList().size());
        bookingConfirmationBodyDetails.put("NIGHT_COUNT", bookingDetailsVO.getNights());
        bookingConfirmationBodyDetails.put("TOTAL_PRICE", WudstayUtil.rupiahCurrencyFormat((Integer)bookingDetailsVO.getTotalPrice()));
        bookingConfirmationBodyDetails.put("TOTAL_PRICE_CONTRACTUAL", "");
        bookingConfirmationBodyDetails.put("PAID", paidAmount);
        bookingConfirmationBodyDetails.put("ROOM_TYPE", bookingDetailsVO.getRoomTypeMaster());
        bookingConfirmationBodyDetails.put("MAP_LINK", bookingDetailsVO.getMapLink());
        bookingConfirmationBodyDetails.put("HOTEL_ACTUAL_NAME", bookingDetailsVO.getHotelName());
        bookingConfirmationBodyDetails.put("HOTEL_ACTUAL_ADD", bookingDetailsVO.getAddress());
        bookingConfirmationBodyDetails.put("GUEST_COUNT", bookingDetailsVO.getPersons());
        bookingConfirmationBodyDetails.put("INCLUDE_BREAKFAST", bookingDetailsVO.getBreakfastIncludedInPrice());
        EmailSender.getInstance().sendEmail(email, "Booking Confirmation", bookingConfirmationBodyDetails, "bookingConfirmationEmailBody.vm", ccList);
    }

    private void sendConfirmationMailToHotelAdmin(String name, String email, BookingDetailsVO bookingDetailsVO, List<String> ccList, String bookingId, Integer paidAmount) throws MessagingException {
        HashMap<String, Object> bookingConfirmationBodyDetails = new HashMap<String, Object>();
        bookingConfirmationBodyDetails.put("GUEST", name);
        bookingConfirmationBodyDetails.put("CHECK_IN", bookingDetailsVO.getCheckInDate().split(",")[1].trim());
        bookingConfirmationBodyDetails.put("CHECK_OUT", bookingDetailsVO.getCheckOutDate().split(",")[1].trim());
        bookingConfirmationBodyDetails.put("HOTEL_DISPLAY_NAME", bookingDetailsVO.getHotelDisplayName());
        bookingConfirmationBodyDetails.put("BOOKING_ID", bookingId);
        bookingConfirmationBodyDetails.put("ROOM_COUNT", bookingDetailsVO.getRoomDetailsVOList().size());
        bookingConfirmationBodyDetails.put("NIGHT_COUNT", bookingDetailsVO.getNights());
        bookingConfirmationBodyDetails.put("TOTAL_PRICE", WudstayUtil.rupiahCurrencyFormat((Integer)bookingDetailsVO.getTotalPrice()));
        bookingConfirmationBodyDetails.put("TOTAL_PRICE_CONTRACTUAL", "");
        bookingConfirmationBodyDetails.put("PAID", paidAmount);
        bookingConfirmationBodyDetails.put("ROOM_TYPE", bookingDetailsVO.getRoomTypeMaster());
        bookingConfirmationBodyDetails.put("MAP_LINK", bookingDetailsVO.getMapLink());
        bookingConfirmationBodyDetails.put("HOTEL_ACTUAL_NAME", bookingDetailsVO.getHotelName());
        bookingConfirmationBodyDetails.put("HOTEL_ACTUAL_ADD", bookingDetailsVO.getAddress());
        bookingConfirmationBodyDetails.put("GUEST_COUNT", bookingDetailsVO.getPersons());
        bookingConfirmationBodyDetails.put("INCLUDE_BREAKFAST", bookingDetailsVO.getBreakfastIncludedInPrice());
        EmailSender.getInstance().sendEmail(email, "Booking Confirmation", bookingConfirmationBodyDetails, "bookingConfirmationEmailBody.vm", ccList);
    }

    private String getRequestParameter(HttpServletRequest request, String paramName, String defaultValue) {
        return this.getRequestParameter(request, paramName, defaultValue, false);
    }

    private String getRequestParameter(HttpServletRequest request, String paramName, String defaultValue, boolean allowEmpty) {
        if (request.getParameter(paramName) == null) {
            return defaultValue;
        }
        String paramValue = request.getParameter(paramName);
        paramValue = paramValue.trim();
        if (!allowEmpty && "".equals(paramValue)) {
            return defaultValue;
        }
        return paramValue;
    }
}
