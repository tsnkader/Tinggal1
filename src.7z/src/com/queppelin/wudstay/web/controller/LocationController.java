package com.queppelin.wudstay.web.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.queppelin.wudstay.exception.CustomGenericException;
import com.queppelin.wudstay.manager.ILocationManager;
import com.queppelin.wudstay.util.WudstayMappings;
import com.queppelin.wudstay.vo.Location;

@Controller
public class LocationController {
	
	public static final Logger logger = LoggerFactory.getLogger(EndUserController.class);

	@Autowired
	ILocationManager locationManager;
	
	@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.GET_All_LOCATIONS_BY_CITY_ID)
    public @ResponseBody List<Location> getAllLocationsByCityId(@RequestParam Long cityId, HttpServletRequest request, HttpServletResponse response,HttpSession session) {
		List<Location> locationList = new ArrayList<Location>();
		try {
			locationList = locationManager.getLocationsByCityId(cityId);
		} catch (Exception e) {
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return locationList;
    }
}
