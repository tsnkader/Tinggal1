package com.queppelin.wudstay.web.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.queppelin.wudstay.exception.CustomGenericException;
import com.queppelin.wudstay.manager.IHotelAdministratorManager;
import com.queppelin.wudstay.manager.IHotelAmenityManager;
import com.queppelin.wudstay.manager.IHotelBookingManager;
import com.queppelin.wudstay.manager.IHotelDescriptionManager;
import com.queppelin.wudstay.manager.IHotelManager;
import com.queppelin.wudstay.manager.IHotelRoomBookingManager;
import com.queppelin.wudstay.manager.IHotelRoomManager;
import com.queppelin.wudstay.manager.IUserManager;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.util.WudstayMappings;
import com.queppelin.wudstay.vo.Hotel;
import com.queppelin.wudstay.vo.HotelAdministrator;
import com.queppelin.wudstay.vo.HotelAmenity;
import com.queppelin.wudstay.vo.HotelBooking;
import com.queppelin.wudstay.vo.HotelDescription;
import com.queppelin.wudstay.vo.HotelRoom;
import com.queppelin.wudstay.vo.User;
import com.queppelin.wudstay.vo.custom.RoomTypeVO;

@Controller
@RequestMapping("/hotel")
public class HotelAdminController {

	@Autowired
	IUserManager userManager;

	@Autowired
	IHotelRoomBookingManager hotelRoomBookingManager;

	@Autowired
	IHotelBookingManager hotelBookingManager;
	
	@Autowired
	IHotelManager hotelManager;
	
	@Autowired
	IHotelRoomManager hotelRoomManager;
	
	@Autowired
	IHotelDescriptionManager hotelDescriptionManager;
	
	@Autowired
	IHotelAdministratorManager hotelAdministratorManager;
	
	@Autowired
	IHotelAmenityManager hotelAmenityManager;

	@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.LOGIN)
	public ModelAndView getLoginPage(HttpServletRequest request, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView(WudstayConstants.LOGIN_PAGE);
		Boolean isLoginSuccess = (Boolean) session.getAttribute("isLoginSuccess");
		if(isLoginSuccess != null && !isLoginSuccess) {
			modelAndView.addObject("isLoginSuccess", isLoginSuccess);
		}
		session.removeAttribute("isLoginSuccess");
		return modelAndView;
	}

	@RequestMapping(method = RequestMethod.POST, value = WudstayMappings.VERIFY_CREDENTIALS)
	public ModelAndView login(@ModelAttribute User user, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			user = userManager.login(user, WudstayConstants.HOTEL_ADMIN);
			if (user != null) {
				session.setAttribute(WudstayConstants.USER, user);
				return new ModelAndView("redirect:" + WudstayMappings.GET_BOOKINGS);
			} else {
				session.setAttribute("isLoginSuccess", Boolean.FALSE);
				return new ModelAndView("redirect:" + WudstayMappings.LOGIN);
			}
		} catch (Exception e) {
			return null;
		}
	}

	@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.GET_BOOKINGS)
	public ModelAndView getLandingPage(HttpServletRequest request, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView(WudstayConstants.SHOW_HOTEL_BOOKINGS_PAGE);
		User user = (User) session.getAttribute("user");
		try {
			List<HotelBooking> hotelBookingList = hotelBookingManager.getBookingsByHotelId(user.getHotelAdministrators().get(0).getHotel().getHotelId());
			modelAndView.addObject("hotelBookingList", hotelBookingList);
		} catch (Exception e) {
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return modelAndView;
	}
	
	@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.VIEW_HOTEL_DETAILS)
	public ModelAndView viewHotelDetails(HttpServletRequest request, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView(WudstayConstants.SHOW_HOTEL_DETAILS_PAGE);
		User user = (User) session.getAttribute(WudstayConstants.USER);
		try {
			Long hotelId = user.getHotelAdministrators().get(0).getHotel().getHotelId();
			Hotel hotel = hotelManager.getById(hotelId);
			//List<RoomTypeVO> roomTypeVOList = hotelRoomManager.getRoomTypeVOList(hotelId);
			//List<HotelRoom> hotelRoomList = hotelRoomManager.getHotelRoomsByHotelId(hotelId);
			List<HotelDescription> hotelDescriptionList = hotelDescriptionManager.getHotelDescriptionsByHotelId(hotelId);
			HotelAdministrator hotelAdministrator = hotelAdministratorManager.getHotelAdminByHotelId(hotelId);
			List<HotelAmenity> hotelAmenityList = hotelAmenityManager.getHotelAmenitiesByHotelId(hotelId);
			List<HotelRoom> hotelRoomList = hotelRoomManager.getHotelRoomsByHotelId(hotelId);
			modelAndView.addObject("hotel", hotel);
			//modelAndView.addObject("hotelRoomList", hotelRoomList);
			//modelAndView.addObject("roomTypeVOList", roomTypeVOList);
			modelAndView.addObject("hotelDescriptionList", hotelDescriptionList);
			modelAndView.addObject("hotelAdministrator", hotelAdministrator);
			modelAndView.addObject("hotelAmenityList", hotelAmenityList);
			modelAndView.addObject("hotelRoomList", hotelRoomList);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return modelAndView;
	}
	
	@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.LOGOUT)
	public ModelAndView logout(HttpServletRequest request, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView("redirect:" + WudstayMappings.LOGIN);
		try {
			session.removeAttribute(WudstayConstants.USER);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return modelAndView;
	}
}
