package com.queppelin.wudstay.web.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.queppelin.wudstay.exception.CustomGenericException;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.util.WudstayMappings;

@ControllerAdvice
public class GlobalExceptionController {
	
	@ExceptionHandler(CustomGenericException.class)
	public ModelAndView handleCustomException(CustomGenericException ex) {
 
		ModelAndView modelAndView = new ModelAndView(WudstayConstants.DYNAMIC_EXCEPTION);
		modelAndView.addObject("errorCode", ex.getErrCode());
		modelAndView.addObject("errorMessage", ex.getErrMsg());
 
		return modelAndView;
 
	}
 
	@ExceptionHandler(Exception.class)
	public ModelAndView handleAllException(Exception ex) {
 
		ModelAndView modelAndView = new ModelAndView(WudstayConstants.DYNAMIC_EXCEPTION);
		modelAndView.addObject("errorMessage", "this is Exception.class");
 
		return modelAndView;
 
	}

}
