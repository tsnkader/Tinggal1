package com.queppelin.wudstay.web.controller;

import com.queppelin.wudstay.exception.CustomGenericException;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.*;
import com.queppelin.wudstay.util.EmailSender;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.util.WudstayMappings;
import com.queppelin.wudstay.util.WudstayUtil;
import com.queppelin.wudstay.vo.*;
import com.queppelin.wudstay.vo.custom.BookingDetailsVO;
import com.queppelin.wudstay.vo.custom.DiscountCouponInfo;
import com.queppelin.wudstay.vo.custom.HotelAvailabilityVO;
import com.queppelin.wudstay.vo.custom.PayUVO;
import org.apache.commons.lang.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.InternalResourceView;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.security.MessageDigest;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@Controller
public class WebStaticController {

	public static final Logger logger = LoggerFactory.getLogger(WebStaticController.class);

	@RequestMapping(value = "/welcome", method = RequestMethod.GET)
	public String welcome() {
		return "welcome";
	}

	@RequestMapping(value = "/staticPage", method = RequestMethod.GET)
	public String redirect() {
		return "redirect:/staticContents/static.html";
	}
}
