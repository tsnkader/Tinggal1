package com.queppelin.wudstay.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.util.WudstayMappings;

@Controller
public class GlobalController {

	@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.GET_PRIVACY_POLICY)
	public ModelAndView getPrivacyPolicy(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		ModelAndView modelAndView =  new ModelAndView(WudstayConstants.PRIVACY_POLICY);
		return modelAndView;
	}
	
	@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.ABOUT_US)
	public ModelAndView getAboutUs(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		ModelAndView modelAndView =  new ModelAndView(WudstayConstants.ABOUT_US);
		return modelAndView;
	}
	
	@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.CONTACT_US)
	public ModelAndView getContactUs(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		ModelAndView modelAndView =  new ModelAndView(WudstayConstants.CONTACT_US);
		return modelAndView;
	}
	
	@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.CANCELLATION_POLICY)
	public ModelAndView getCancellationPolicy(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		ModelAndView modelAndView =  new ModelAndView(WudstayConstants.CANCELLATION_POLICY);
		return modelAndView;
	}
	
	@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.TERMS_AND_CONDITION)
	public ModelAndView getTermsAndCondition(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		ModelAndView modelAndView =  new ModelAndView(WudstayConstants.TERMS_AND_CONDITION);
		return modelAndView;
	}
}
