package com.queppelin.wudstay.web.controller;

import java.io.File;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.*;
import com.queppelin.wudstay.util.*;
import com.queppelin.wudstay.vo.*;
import com.queppelin.wudstay.vo.custom.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.queppelin.wudstay.exception.CustomGenericException;

@Controller
@RequestMapping("/customercare")
public class CustomerCareAdminController {



	@Autowired
	IUserManager userManager;

	@Autowired
	IHotelRoomBookingManager hotelRoomBookingManager;

	@Autowired
	IHotelBookingManager hotelBookingManager;

	@Autowired
	ICityManager cityManager;

	@Autowired
	IAmenityManager amenityManager;

	@Autowired
	IRoomTypeManager roomTypeManager;

	@Autowired
	ILocationManager locationManager;

	@Autowired
	IHotelManager hotelManager;

	@Autowired
	IHotelRoomManager hotelRoomManager;

	@Autowired
	IHotelDescriptionManager hotelDescriptionManager;

	@Autowired
	IHotelAdministratorManager hotelAdministratorManager;

	@Autowired
	IHotelAmenityManager hotelAmenityManager;

	@Autowired
	ICouponCodeManager couponCodeManager;

	@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.LOGIN)
	public ModelAndView getLoginPage(HttpServletRequest request, HttpSession session, RedirectAttributes redirectAttributes) {
		ModelAndView modelAndView = new ModelAndView(WudstayConstants.LOGIN_PAGE);
		try{
			Boolean isLoginSuccess = (Boolean) session.getAttribute("isLoginSuccess");		
			if(isLoginSuccess != null && !isLoginSuccess) {
				modelAndView.addObject("isLoginSuccess", isLoginSuccess);
			}
			session.removeAttribute("isLoginSuccess");
		}catch(Exception e){
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return modelAndView;
	}

	@RequestMapping(method = RequestMethod.POST, value = WudstayMappings.VERIFY_CREDENTIALS)
	public ModelAndView login(@ModelAttribute User user, HttpServletRequest request, HttpServletResponse response, HttpSession session, RedirectAttributes redirectAttributes) {
		try {
			
			user = userManager.login(user, WudstayConstants.CUSTOMER_CARE_ADMIN);
			if (user != null) {
				session.setAttribute(WudstayConstants.USER, user);
				return new ModelAndView("redirect:" + WudstayMappings.GET_BOOKINGS);
			} else {
				session.setAttribute("isLoginSuccess", Boolean.FALSE);
				return new ModelAndView("redirect:" + WudstayMappings.LOGIN);
			}
		} catch (Exception e) {
			return null;
		}
	}

	@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.GET_BOOKINGS)
	public ModelAndView getLandingPage(HttpServletRequest request, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView(WudstayConstants.SHOW_HOTEL_BOOKINGS_PAGE);
		List<HotelBooking> hotelBookingList = hotelBookingManager.list();
		try {
			modelAndView.addObject("hotelBookingList", hotelBookingList);
		} catch (Exception e) {
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return modelAndView;
	}

	@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.GET_All_LOCATIONS_BY_CITY_ID)
	public @ResponseBody List<Location> getAllLocationsByCityId(@RequestParam Long cityId, HttpServletRequest request, HttpServletResponse response,HttpSession session) {
		List<Location> locationList = new ArrayList<Location>();
		try {
			locationList = locationManager.getLocationsByCityId(cityId);
		} catch (Exception e) {
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return locationList;
	}

	@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.VIEW_HOTELS)
	public ModelAndView viewHotels(@ModelAttribute HotelVO hotelVO, HttpServletRequest request, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView(WudstayConstants.SHOW_HOTELS_PAGE);
		try {
			List<Hotel> hotelList = hotelManager.list();
			modelAndView.addObject("hotelList", hotelList);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return modelAndView;
	}

	@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.LOGOUT)
	public ModelAndView logout(HttpServletRequest request, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView("redirect:" + WudstayMappings.LOGIN);
		try {
			session.removeAttribute(WudstayConstants.USER);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return modelAndView;
	}

	@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.VIEW_HOTEL_DETAILS)
	public ModelAndView viewHotelDetails(@RequestParam Long hotelId, HttpServletRequest request, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView(WudstayConstants.SHOW_HOTEL_DETAILS_PAGE);
		try {
			Boolean isSuccess = (Boolean) session.getAttribute("isSuccess");
			if(isSuccess != null) {
				modelAndView.addObject("isSuccess", isSuccess);
				session.removeAttribute("isSuccess");
			}

			Hotel hotel = hotelManager.getById(hotelId);
			//List<RoomTypeVO> roomTypeVOList = hotelRoomManager.getRoomTypeVOList(hotelId);
			//List<HotelRoom> hotelRoomList = hotelRoomManager.getHotelRoomsByHotelId(hotelId);
			List<HotelDescription> hotelDescriptionList = hotelDescriptionManager.getHotelDescriptionsByHotelId(hotelId);
			HotelAdministrator hotelAdministrator = hotelAdministratorManager.getHotelAdminByHotelId(hotelId);
			List<HotelAmenity> hotelAmenityList = hotelAmenityManager.getHotelAmenitiesByHotelId(hotelId);
			List<HotelRoom> hotelRoomList = hotelRoomManager.getHotelRoomsByHotelId(hotelId);
			List<String> hotelImageList = WudstayUtil.getHotelImages(hotel.getHotelId(),request);
			modelAndView.addObject("hotel", hotel);
			//modelAndView.addObject("hotelRoomList", hotelRoomList);
			//modelAndView.addObject("roomTypeVOList", roomTypeVOList);
			modelAndView.addObject("hotelDescriptionList", hotelDescriptionList);
			modelAndView.addObject("hotelAdministrator", hotelAdministrator);
			modelAndView.addObject("hotelAmenityList", hotelAmenityList);
			modelAndView.addObject("hotelRoomList", hotelRoomList);
			modelAndView.addObject("hotelImageList", hotelImageList);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return modelAndView;
	}

	@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.EDIT_HOTEL_DETAILS)
	public ModelAndView editHotelDetails(@RequestParam Long hotelId, HttpServletRequest request, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView(WudstayConstants.EDIT_HOTEL_DETAILS_PAGE);
		try {
			Hotel hotel = hotelManager.getById(hotelId);
			List<Location> locationList = locationManager.getLocationsByCityId(hotel.getLocation().getCity().getCityId());
			//List<HotelRoom> hotelRoomList = hotelRoomManager.getHotelRoomsByHotelId(hotelId);
			List<City> cityList = cityManager.list();
			List<Amenity> amenitiyList = amenityManager.list();
			List<RoomType> roomTypeList = roomTypeManager.list();
			List<HotelRoom> hotelRoomList = hotelRoomManager.getHotelRoomsByHotelId(hotelId);
			List<String> hotelImageList = WudstayUtil.getHotelImages(hotel.getHotelId(),request);
			//List<RoomTypeVO> roomTypeVOList = hotelRoomManager.getRoomTypeVOList(hotelId);

			List<HotelDescription> hotelDescriptionVOList = hotelDescriptionManager.getHotelDescriptionsByHotelId(hotelId);
			HotelAdministrator hotelAdministrator = hotelAdministratorManager.getHotelAdminByHotelId(hotelId);

			List<HotelAmenity> hotelAmenityList = hotelAmenityManager.getHotelAmenitiesByHotelId(hotelId);

			WudstayUtil.processAmenityList(amenitiyList, hotelAmenityList);
			/*List<RoomTypeVO> processedRoomTypeVOList = WudstayUtil.processRoomTypeVOList(roomTypeList, roomTypeVOList);*/
			modelAndView.addObject("hotel", hotel);
			//modelAndView.addObject("roomTypeVOList", processedRoomTypeVOList);
			modelAndView.addObject("roomTypeList", roomTypeList);
			modelAndView.addObject("hotelDescriptionVOList", hotelDescriptionVOList);
			modelAndView.addObject("hotelAdministrator", hotelAdministrator);
			modelAndView.addObject("hotelAmenityList", hotelAmenityList);
			modelAndView.addObject("cityList", cityList);
			modelAndView.addObject("locationList", locationList);
			modelAndView.addObject("amenityList", amenitiyList);
			modelAndView.addObject("hotelRoomList", hotelRoomList);
			modelAndView.addObject("hotelImageList", hotelImageList);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return modelAndView;
	}

	@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.IS_USERNAME_EXISTS)
	public @ResponseBody Boolean isUsernameExists(@RequestParam String username, HttpServletRequest request, HttpSession session) {
		try {
			return userManager.isUsernameExists(username);
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		return Boolean.FALSE;
	}
	
	@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.ADD_CITY)
	public ModelAndView addCity(HttpServletRequest request, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView(WudstayConstants.ADD_CITY_PAGE);
		try {
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return modelAndView;
	}
	
	@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.EDIT_CITY)
	public ModelAndView editCity(@RequestParam Long cityId, HttpServletRequest request, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView(WudstayConstants.ADD_CITY_PAGE);
		try {
			City city = cityManager.getById(cityId);
			modelAndView.addObject("city", city);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return modelAndView;
	}
	
	@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.GET_ALL_CITIES)
	public ModelAndView getAllCities(HttpServletRequest request, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView(WudstayConstants.SHOW_CITIES_PAGE);
		try {
			
			Boolean isSuccess = (Boolean) session.getAttribute("isSuccess");
			if(isSuccess != null) {
				modelAndView.addObject("isSuccess", isSuccess);
				session.removeAttribute("isSuccess");
			}
			
			Boolean isUpdateSuccess = (Boolean) session.getAttribute("isUpdateSuccess");
			if(isUpdateSuccess != null) {
				modelAndView.addObject("isUpdateSuccess", isUpdateSuccess);
				session.removeAttribute("isUpdateSuccess");
			}
			
			List<City> cityList = cityManager.list();
			modelAndView.addObject("cityList", cityList);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return modelAndView;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = WudstayMappings.SAVE_UPDATE_CITY)
	public ModelAndView addUpdateCity(@ModelAttribute City city, HttpServletRequest request, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView("redirect:" + WudstayMappings.GET_All_CITIES);
		Long cityId = city.getCityId();
		try {
			User user = (User) session.getAttribute(WudstayConstants.USER);
			if(city.getIsActive() == null) {
				city.setIsActive(Boolean.FALSE);
			}
			city.setLastUpdatedBy(user.getUsername());
			city.setLastUpdatedDate(new Date());
			cityManager.saveOrUpdate(city);
			if(cityId != null) {
				session.setAttribute("isUpdateSuccess", Boolean.TRUE);
			} else {
				session.setAttribute("isSuccess", Boolean.TRUE);
			}
		} catch (Exception e) {
			e.printStackTrace();
			if(cityId != null) {
				session.setAttribute("isUpdateSuccess", Boolean.FALSE);
			} else {
				session.setAttribute("isSuccess", Boolean.FALSE);
			}
		}
		return modelAndView;
	}
	
	@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.ADD_LOCATION)
	public ModelAndView addLocation(HttpServletRequest request, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView(WudstayConstants.ADD_LOCATION_PAGE);
		try {
			List<City> cityList = cityManager.list();
			modelAndView.addObject("cityList", cityList);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return modelAndView;
	}
	
	@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.EDIT_LOCATION)
	public ModelAndView editLocation(@RequestParam Long locationId, HttpServletRequest request, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView(WudstayConstants.ADD_LOCATION_PAGE);
		try {
			Location location = locationManager.getById(locationId);
			List<City> cityList = cityManager.list();
			modelAndView.addObject("cityList", cityList);
			modelAndView.addObject("location", location);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return modelAndView;
	}
	
	@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.GET_ALL_LOCATIONS)
	public ModelAndView getAllLocations(HttpServletRequest request, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView(WudstayConstants.SHOW_LOCATIONS_PAGE);
		try {
			
			Boolean isSuccess = (Boolean) session.getAttribute("isSuccess");
			if(isSuccess != null) {
				modelAndView.addObject("isSuccess", isSuccess);
				session.removeAttribute("isSuccess");
			}
			
			Boolean isUpdateSuccess = (Boolean) session.getAttribute("isUpdateSuccess");
			if(isUpdateSuccess != null) {
				modelAndView.addObject("isUpdateSuccess", isUpdateSuccess);
				session.removeAttribute("isUpdateSuccess");
			}
			
			List<Location> locationList = locationManager.list();
			modelAndView.addObject("locationList", locationList);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return modelAndView;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = WudstayMappings.SAVE_UPDATE_LOCATION)
	public ModelAndView addUpdateLocation(@ModelAttribute Location location, HttpServletRequest request, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView("redirect:" + WudstayMappings.GET_ALL_LOCATIONS);
		Long locationId = location.getLocationId();
		try {
			Long cityId = location.getCityId();
			location.setCity(cityManager.getById(cityId));
			User user = (User) session.getAttribute(WudstayConstants.USER);
			if(location.getIsActive() == null) {
				location.setIsActive(Boolean.FALSE);
			}
			location.setLastUpdatedBy(user.getUsername());
			location.setLastUpdatedDate(new Date());
			locationManager.saveOrUpdate(location);
			if(locationId != null) {
				session.setAttribute("isUpdateSuccess", Boolean.TRUE);
			} else {
				session.setAttribute("isSuccess", Boolean.TRUE);
			}
		} catch (Exception e) {
			e.printStackTrace();
			if(locationId != null) {
				session.setAttribute("isUpdateSuccess", Boolean.FALSE);
			} else {
				session.setAttribute("isSuccess", Boolean.FALSE);
			}
		}
		return modelAndView;
	}
	
	@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.DELETE_HOTEL_IMAGE)
	public @ResponseBody Boolean deleteHotelImage(@RequestParam Long hotelId, @RequestParam String imageName, HttpServletRequest request, HttpSession session) {
		try {
			///String directoryPath = WudstayUtil.getOtherImagesDirPath(hotelId);
	    	String directoryPath =  request.getRealPath("/")+"hotel_images/"+hotelId+"/others/";
			File imageFile = new File(directoryPath + File.separator + imageName);
			return imageFile.delete();
		} catch (Exception e) {
			//ignore
			
		}
		return Boolean.FALSE;
	}

	/*@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.GET_HOTEL_BOOKINGS_BY_ADMIN)
	public @ResponseBody ResponseMessage getHotelBokings(HttpServletRequest request, HttpSession session) {
		//Fetch the page number from client
    	Integer pageNumber = 0;
    	if (null != request.getParameter("iDisplayStart"))
    		pageNumber = (Integer.valueOf(request.getParameter("iDisplayStart"))/10)+1;		

    	//Fetch search parameter
    	String searchParameter = request.getParameter("sSearch");

    	//Fetch Page display length
    	Integer pageDisplayLength = Integer.valueOf(request.getParameter("iDisplayLength"));

    	//Create page list data
    	List<Person> personsList = createPaginationData(pageDisplayLength);

		//Here is server side pagination logic. Based on the page number you could make call 
		//to the data base create new list and send back to the client. For demo I am shuffling 
		//the same list to show data randomly
		if (pageNumber == 1) {
			Collections.shuffle(personsList);
		}else if (pageNumber == 2) {
			Collections.shuffle(personsList);
		}else {
			Collections.shuffle(personsList);
		}

		//Search functionality: Returns filtered list based on search parameter
		//personsList = getListBasedOnSearchParameter(searchParameter,personsList);


		ResponseMessage personJsonObject = new ResponseMessage();
		//Set Total display record
		personJsonObject.setiTotalDisplayRecords(500);
		//Set Total record
		personJsonObject.setiTotalRecords(500);
		personJsonObject.setAaData(personsList);

		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String json2 = gson.toJson(personJsonObject);

		return personJsonObject;
    }

	private List<Person> getListBasedOnSearchParameter(String searchParameter,List<Person> personsList) {

		if (null != searchParameter && !searchParameter.equals("")) {
			List<Person> personsListForSearch = new ArrayList<Person>();
			searchParameter = searchParameter.toUpperCase();
			for (Person person : personsList) {
				if (person.getName().toUpperCase().indexOf(searchParameter)!= -1 || person.getOffice().toUpperCase().indexOf(searchParameter)!= -1
						|| person.getPhone().toUpperCase().indexOf(searchParameter)!= -1 || person.getPosition().toUpperCase().indexOf(searchParameter)!= -1
						|| person.getSalary().toUpperCase().indexOf(searchParameter)!= -1 || person.getStart_date().toUpperCase().indexOf(searchParameter)!= -1) {
					personsListForSearch.add(person);					
				}

			}
			personsList = personsListForSearch;
			personsListForSearch = null;
		}
		return personsList;
	}

	private List<Person> createPaginationData(Integer pageDisplayLength) {
		List<Person> personsList = new ArrayList<Person>();
		for (int i = 0; i < 1; i++) {
		    Person person2 = new Person();
	            person2.setName("John Landy");
	            person2.setPosition("System Architect");
	            person2.setSalary("$320,800");
	            person2.setOffice("NY");
	            person2.setPhone("999999999");
	            person2.setStart_date("05/05/2010");
	            personsList.add(person2);  

	            person2 = new Person();
	            person2.setName("Igor Vornovitsky");
	            person2.setPosition("Solution Architect");
	            person2.setSalary("$340,800");
	            person2.setOffice("NY");
	            person2.setPhone("987897899");
	            person2.setStart_date("05/05/2010");
	            personsList.add(person2); 

	            person2 = new Person();
	            person2.setName("Java Honk");
	            person2.setPosition("Architect");
	            person2.setSalary("$380,800");
	            person2.setOffice("NY");
	            person2.setPhone("1234567890");
	            person2.setStart_date("05/05/2010");
	            personsList.add(person2); 

	            person2 = new Person();
	            person2.setName("Ramesh Arrepu");
	            person2.setPosition("Sr. Architect");
	            person2.setSalary("$310,800");
	            person2.setOffice("NY");
	            person2.setPhone("4654321234");
	            person2.setStart_date("05/05/2010");
	            personsList.add(person2); 

	            person2 = new Person();
	            person2.setName("Bob Sidebottom");
	            person2.setPosition("Architect");
	            person2.setSalary("$300,800");
	            person2.setOffice("NJ");
	            person2.setPhone("9876543212");
	            person2.setStart_date("05/05/2010");
	            personsList.add(person2); 

		}

		for (int i = 0; i < pageDisplayLength-5; i++) {
		    Person person2 = new Person();
	            person2.setName("Zuke Torres");
	            person2.setPosition("System Architect");
	            person2.setSalary("$320,800");
	            person2.setOffice("NY");
	            person2.setPhone("999999999");
	            person2.setStart_date("05/05/2010");
	            personsList.add(person2);  
		}
		return personsList;
	}*/

	//Customer Care Portal
	@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.GET_CUSTOMER_CARE_DETAILS)
	public ModelAndView getCustomerCareDetails(@RequestParam Long bookingId,@RequestParam Long hotelId, HttpServletRequest request, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView(WudstayConstants.CUSTOMER_CARE_DETAILS);
		try {
			List<HotelBooking> hotelBookingList = hotelBookingManager.getBookingsForCustomerCare(bookingId, hotelId);
					
			modelAndView.addObject("hotelBookingList", hotelBookingList);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return modelAndView;
	}

	@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST}, value = WudstayMappings.CANCEL_BOOKING)
	public ModelAndView custCareCancelBooking(@RequestParam Long bookingId, HttpServletRequest request, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView(WudstayConstants.CUSTOMER_CARE_DETAILS);

		Long hotelId =null;
		//customerCareDetails.do?bookingId=328&hotelId=71

		HotelBooking hotelBooking = hotelBookingManager.getById(bookingId);
		hotelBooking.setIsCancelled(Boolean.TRUE);
		hotelBookingManager.saveOrUpdate(hotelBooking);
		try{
			WudstayEmailUtil.sendCancellationMail( hotelBookingManager, hotelAdministratorManager,   bookingId );
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			hotelId =  hotelBooking.getHotel().getHotelId();
			//modelAndView  = new ModelAndView("redirect:" + WudstayConstants.CUSTOMER_CARE_DETAILS + "?bookingId="+ bookingId + "&hotelId=" + hotelId) ;
			List<HotelBooking> hotelBookingList = hotelBookingManager.getBookingsForCustomerCare(bookingId, hotelId);
			modelAndView.addObject("hotelBookingList", hotelBookingList);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		//ModelAndView modelAndView  = new ModelAndView("redirect:" + WudstayConstants.CUSTOMER_CARE_DETAILS + "?bookingId="+ bookingId + "&hotelId=" + hotelId) ;

		return modelAndView;
	}



	private ModelAndView newCustCareBooking(CustCareBookingForm bookingForm, ModelAndView modelAndView){
		modelAndView.addObject("EDIT_MODE", Boolean.FALSE);
		try {
			modelAndView.addObject("errorMsg", "");
			modelAndView.addObject("bookingForm", bookingForm);

			List<City> cityList = cityManager.getAllCities();
			modelAndView.addObject("cityList", cityList);

			Date today = new Date();
			modelAndView.addObject("checkIn", DateFormatConversionUtil.getDisplayFormatDate(today));
			modelAndView.addObject("checkOut", DateFormatConversionUtil.getDisplayFormatDate(DateFormatConversionUtil.getNextDate(today)));

		} catch (Exception e) {
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return modelAndView;
	}

	/*@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST}, value = WudstayMappings.ADD_CUST_CARE_BOOKING)
	public ModelAndView getBookingSummary(HttpServletRequest request, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView(WudstayConstants.ADD_CUST_CARE_BOOKING_SUMMARY_PAGE);

		return  newCustCareBooking( new CustCareBookingForm(), modelAndView);
	}*/
	@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST}, value = WudstayMappings.ADD_CUST_CARE_BOOKING)
	public ModelAndView addCustCareBooking(HttpServletRequest request, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView(WudstayConstants.ADD_CUST_CARE_BOOKING_PAGE);

		return  newCustCareBooking( new CustCareBookingForm(), modelAndView);
	}
	@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST}, value = WudstayMappings.SUBMIT_ADD_CUST_CARE_BOOKING)
	public ModelAndView saveCustCareBooking(HttpServletRequest request, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView(WudstayConstants.ADD_CUST_CARE_BOOKING_PAGE);
		DiscountCouponInfo discountCouponInfo = new DiscountCouponInfo();
		String errMessage="";
		CustCareBookingForm bookingForm = new CustCareBookingForm();
		HttpRequestToBeanUtil.populateBean(bookingForm, request);
		modelAndView = newCustCareBooking( bookingForm, modelAndView);

		Long cityId = Long.parseLong(bookingForm.getCity());
		City city = cityManager.getById(cityId);

		String checkIn = bookingForm.getStrCheckIn();
		String checkOut = bookingForm.getStrCheckOut();
		try {
			checkIn = WudstayUtil.getFormattedCheckInDate(checkIn.trim());
			checkOut = WudstayUtil.getFormattedCheckOutDate(checkOut.trim());
		} catch (ParseException e) {
			e.printStackTrace();
		}



		//return  newCustCareBooking( new CustCareBookingForm(), modelAndView);
		HotelAvailabilityVO  hotelAvailability = checkAvailability( bookingForm.getStrCheckIn(),  bookingForm.getStrCheckOut(),  bookingForm.getNoOfRooms(), Long.parseLong(bookingForm.getHotel()));
		if(bookingForm.isEmptyFinalTotalPrice() ){
			errMessage = errMessage + "<br/> Please enter TotalPrice.";
			modelAndView.addObject("errorMsg", errMessage);
			return modelAndView;
		}else if (hotelAvailability.getIsAvailable()) {
			BookingDetailsVO bookingDetails = bookHotel(bookingForm.getStrCheckIn(), bookingForm.getStrCheckOut(), bookingForm.getNoOfRooms(), bookingForm.getNoOfGuest(), cityId, Long.parseLong(bookingForm.getHotel()));
			Integer sourceOfBooking = WudstayConstants.getSourceOfBooking(WudstayConstants.WEB_APP_TYPE_CUST_CARE, WudstayConstants.SOURCE_OF_BOOKING_CUST_CARE);
			if (!"".equals(bookingForm.getDiscountCouponCode())){
				discountCouponInfo = getDiscountCouponInfo(bookingForm.getDiscountCouponCode(), bookingDetails, city, bookingForm.getMobileNumber(), sourceOfBooking);
			}

			HashMap<String, Object> searchParamMap = getSearchParamHashMap(city.getCityName(), cityId, checkIn, checkOut, bookingForm.getNoOfRooms(), bookingForm.getNoOfGuest());
			try {
				Integer discount =0;

				Integer subSourceOfBooking= Integer.parseInt(bookingForm.getBookingSource());
				Integer totalBookingPrice = bookingDetails.getTotalPrice();
				Integer finalBookingPrice = Integer.parseInt(bookingForm.getFinalTotalPrice());
				if(!finalBookingPrice.equals(totalBookingPrice)){
					discount = finalBookingPrice.intValue() - totalBookingPrice.intValue();
					bookingDetails.setTotalPrice(finalBookingPrice.intValue());
				}
				Boolean isOnlinePaid = bookingForm.getIsOnlinePaid();
				String transactionId = null;
				String payuTransactionId = null;
				//if(isOnlinePaid==true){
					transactionId = bookingForm.getTransactionId();
					payuTransactionId = bookingForm.getPaymentGatewayTransId();
				//}
				confirmBooking(bookingForm.getMobileNumber(), bookingForm.getGuestName(), bookingForm.getGuestEmail(), bookingDetails, searchParamMap, discount, sourceOfBooking, subSourceOfBooking,
						isOnlinePaid, transactionId, payuTransactionId);
			}catch (Exception ex){
				ex.printStackTrace();
				errMessage = errMessage + "An error (" + ex.getMessage() + ") has occurred please contact system administrator for rectification.";
				modelAndView.addObject("errorMsg", errMessage);
			}

			modelAndView = new ModelAndView(WudstayConstants.ADD_CUST_CARE_BOOKING_SUMMARY_PAGE);
			modelAndView.addObject("name",         bookingForm.getGuestName());
			modelAndView.addObject("mobileNumber", bookingForm.getMobileNumber());
			modelAndView.addObject("email",        bookingForm.getGuestEmail());
			modelAndView.addObject("rooms",        bookingForm.getNoOfRooms());
			modelAndView.addObject("persons",      bookingForm.getNoOfGuest());
			modelAndView.addObject("totalAmountPaid", 0);
			modelAndView.addObject("bookingDetailsVO", bookingDetails);
			return modelAndView;
		}else{
			errMessage = errMessage + "<br/> Only " + hotelAvailability.getRooms() + " room(s) are availabile in hotel.";
			modelAndView.addObject("errorMsg", errMessage);
			return modelAndView;
		}
	}
	private DiscountCouponInfo getDiscountCouponInfo(String couponCode, BookingDetailsVO bookingDetailsVO, City city, String mobileNumber, Integer sourceOfBooking ){
		DiscountCouponInfo discountCouponInfo = new DiscountCouponInfo();
		if(bookingDetailsVO.getTotalPrice()!=null && !bookingDetailsVO.getTotalPrice().equals( bookingDetailsVO.getTotalPriceBeforeDiscount())){
			bookingDetailsVO.setTotalPrice(bookingDetailsVO.getTotalPriceBeforeDiscount());
		}
		try {
			String strCheckOut = bookingDetailsVO.getCheckOutDate();
			DateFormat dateFormat = new SimpleDateFormat("EEEE, dd MMMMM yyyy");
			dateFormat.setLenient(false);
			Date dtCheckOut = dateFormat.parse(strCheckOut);
			Integer totalAmount = bookingDetailsVO.getTotalPrice();
			discountCouponInfo = couponCodeManager.calculateCouponCodeDiscount(city, couponCode, totalAmount, dtCheckOut, bookingDetailsVO.getNights(), mobileNumber, sourceOfBooking);
			bookingDetailsVO.setDiscountCoupon(discountCouponInfo);
			return discountCouponInfo;
		}catch (Exception ex){
			ex.printStackTrace();
			return discountCouponInfo;
		}
	}
	//checkIn = 16/10/2015  checkOut =  17/10/2015
	@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST}, value = WudstayMappings.CALCULATE_COUPONCODE_DISCOUNT)
	public @ResponseBody Map calculateCouponCodeDiscount(@RequestParam String txtDate, @RequestParam String rooms,
														 @RequestParam String persons, @RequestParam String cityId, @RequestParam String hotelId,
														 @RequestParam String couponCode, @RequestParam String mobileNumber,
														 HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		String checkIn="";
		String checkOut="";
		Map<String, Object> map = new HashMap<String, Object>();
		BookingDetailsVO bookingDetailsVO = null;
		Integer intRooms=0;
		Integer intPersons=0;
		Long lngCityId;
		Long lngHotelId;

		DiscountCouponInfo discountCouponInfo = new DiscountCouponInfo();
		map.put("success", Boolean.FALSE);
		try{
			intRooms = Integer.parseInt(rooms);
			intPersons = Integer.parseInt(persons);
			lngCityId = Long.parseLong(cityId);
			//lngCityId = lngCityId==null || lngCityId.longValue()==0 ? null : lngCityId;
			lngHotelId = Long.parseLong(hotelId);
			//lngHotelId = lngHotelId==null || lngHotelId.longValue()==0 ? null : lngHotelId;

			// txtDate = 05/10/2015 - 07/10/2015
			try{
				String []strDates = txtDate.split(" - ");
				checkIn = strDates[0].trim();
				checkOut = strDates[1].trim();
			} catch (Exception e) {
				e.printStackTrace();
				map.put("success", Boolean.FALSE);
				return map;
			}
			if((lngCityId==null || lngCityId.longValue()==0) || (lngHotelId==null || lngHotelId.longValue()==0)){
				map.put("success", Boolean.FALSE);
				return map;
			}
		}catch (Exception ex){
			map.put("success", Boolean.FALSE);
			return map;
		}
		try {
			City city = cityManager.getById(lngCityId);
			Hotel hotel = hotelManager.getById(lngHotelId);

			bookingDetailsVO = WudstayUtil.getBookingDetailsVO(city.getCityName(), checkIn, checkOut, intRooms, intPersons, hotel);
			Integer sourceOfBooking = WudstayConstants.getSourceOfBooking(WudstayConstants.WEB_APP_TYPE_CUST_CARE, WudstayConstants.SOURCE_OF_BOOKING_CUST_CARE);
			discountCouponInfo = getDiscountCouponInfo(couponCode, bookingDetailsVO, city, mobileNumber, sourceOfBooking );

			map.put("success", Boolean.TRUE);
			map.put("BookingDetails", bookingDetailsVO);
			return map;
		} catch (Exception e) {
			e.printStackTrace();
			map.put("success", Boolean.FALSE);
			map.put("ERROR", e.getMessage());
			return map;
			//throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		//return "success";
	}

	//searchHotelByCityId.do
	@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST}, value = WudstayMappings.SEARCH_HOTEL_BY_CITY_ID)
	public @ResponseBody List<KeyValueBean> searchHotels(@RequestParam Integer rooms, @RequestParam Integer persons, @RequestParam Long cityId,
													 HttpServletRequest request, HttpServletResponse response,HttpSession session) {
		try {
			//City city = cityManager.getById(cityId);
			List<Hotel> hotelList = hotelManager.getHotelByCityId(cityId, persons/rooms);
			List<KeyValueBean> lst = new ArrayList<KeyValueBean>();
			for(Hotel hotel:  hotelList){
				lst.add(new KeyValueBean(hotel.getHotelId(), hotel.getHotelDisplayName()));
			}
			return lst;
		} catch (WudstayException e) {
			e.printStackTrace();
			return new ArrayList<KeyValueBean>();
		}
	}


	private HashMap<String, Object> getSearchParamHashMap(String city, Long cityId,
										 String checkIn, String checkOut, Integer rooms, Integer persons) {
		HashMap<String, Object> searchParamsHashMap = new HashMap<String, Object>();
		searchParamsHashMap.put("city", city);
		searchParamsHashMap.put("cityId", cityId);
		searchParamsHashMap.put("checkIn", checkIn);
		searchParamsHashMap.put("checkOut", checkOut);
		searchParamsHashMap.put("rooms", rooms);
		searchParamsHashMap.put("persons", persons);
		return searchParamsHashMap;
	}
	private HotelAvailabilityVO checkAvailability( String checkIn,  String checkOut,  Integer rooms, Long hotelId) {
		HotelAvailabilityVO hotelAvailabilityVO = new HotelAvailabilityVO();
		try {
			Hotel hotel = hotelManager.getById(hotelId);
			String checkInDate = WudstayUtil.getFormattedCheckInDate(checkIn.trim());
			String checkOutDate = WudstayUtil.getFormattedCheckOutDate(checkOut.trim());
			return WudstayUtil.isAvailable(hotel, rooms, checkInDate, checkOutDate, hotelBookingManager);
		} catch (Exception e) {
			e.printStackTrace();
			hotelAvailabilityVO.setStatus(Boolean.FALSE);
		}
		return hotelAvailabilityVO;
	}

	private BookingDetailsVO bookHotel(String checkIn, String checkOut,  Integer rooms, Integer persons, Long cityId, Long hotelId) {
		ModelAndView modelAndView =  new ModelAndView("booking");
		try {
			City city = cityManager.getById(cityId);
			Hotel hotel = hotelManager.getById(hotelId);
			BookingDetailsVO bookingDetailsVO = WudstayUtil.getBookingDetailsVO(city.getCityName(), checkIn, checkOut, rooms, persons, hotel);
			return bookingDetailsVO;
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
	}
	/*public void confirmBooking(String mobileNumber,String name, String email, BookingDetailsVO bookingDetailsVO, HashMap<String, Object> searchParamMap, Integer discount, Integer sourceOfBooking, Integer subSourceOfBooking) {
		Boolean isOnlinePaid = Boolean.FALSE;
		String transactionId = null;
		String payuTransactionId = null;
		confirmBooking( mobileNumber, name,  email,  bookingDetailsVO, searchParamMap, discount, sourceOfBooking,  subSourceOfBooking, isOnlinePaid,  transactionId,  payuTransactionId);
	}*/
	public void confirmBooking(String mobileNumber,String name, String email, BookingDetailsVO bookingDetailsVO, HashMap<String, Object> searchParamMap, Integer discount, Integer sourceOfBooking, Integer subSourceOfBooking,
							   Boolean isOnlinePaid, String transactionId, String payuTransactionId) {
		try {
			List<String> ccList = new ArrayList<String>();
			Hotel hotel = hotelManager.getById(bookingDetailsVO.getHotelId());
			Integer persons = Integer.valueOf(searchParamMap.get("persons").toString());

			String bookingId = hotelBookingManager.makeBooking(bookingDetailsVO, name, mobileNumber, searchParamMap.get("checkIn").toString(), searchParamMap.get("checkOut").toString(),
					Integer.valueOf(searchParamMap.get("rooms").toString()), persons, email, isOnlinePaid, payuTransactionId, transactionId,  discount, sourceOfBooking, subSourceOfBooking);

			bookingDetailsVO.setBreakfastIncludedInPrice(hotel.getIsBreakfastIncludedInPrice());
			bookingDetailsVO.setPersons(persons);

			WudstayUtil.sendConfirmationMessage("Dear " + name + ", your Tinggal booking has been confirmed from " + bookingDetailsVO.getCheckInDate() + " to "
					+ bookingDetailsVO.getCheckOutDate() + " at " + bookingDetailsVO.getHotelName() + ". The address is "
					+ bookingDetailsVO.getAddress() + " and your booking id is " + bookingId + ". You can locate the stay at Google Maps on "
					+ "the link " + bookingDetailsVO.getMapLink() + ". For any assistance you can call us anytime at +62822 8539 0099. Please carry a valid govt. address and ID proof when you checkin.", mobileNumber);
			try {
				sendConfirmationMail(name, email, bookingDetailsVO, ccList, bookingId, new Integer(0), isOnlinePaid); // Empty ccList no one to cc, only to client

				String hotelAdministratorEmail = null;
				HotelAdministrator hotelAdministrator = hotelAdministratorManager.getHotelAdminByHotelId(bookingDetailsVO.getHotelId());
				if (hotelAdministrator.getUser().getEmail() != null && !hotelAdministrator.getUser().getEmail().trim().equals("")) {
					//ccList.add(hotelAdministrator.getUser().getEmail());
					hotelAdministratorEmail = hotelAdministrator.getUser().getEmail();
				}



				//List<String> ccList = new ArrayList<String>();
				if (hotel.getContactPersonEmail1() != null && !hotel.getContactPersonEmail1().trim().equals("")) {
					ccList.add(hotel.getContactPersonEmail1());
				}
				if (hotel.getContactPersonEmail2() != null && !hotel.getContactPersonEmail2().trim().equals("")) {
					ccList.add(hotel.getContactPersonEmail2());
				}

				//sendConfirmationMail(name, email, bookingDetailsVO, ccList, bookingId, new Integer(0));
				sendConfirmationMailToHotelAdmin(name, hotelAdministratorEmail, bookingDetailsVO, ccList, bookingId, new Integer(0), isOnlinePaid);
			}catch (Exception ex){
				ex.printStackTrace();
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
	}
	/*private void sendConfirmationMail(String name, String email,
									  BookingDetailsVO bookingDetailsVO, List<String> ccList, String bookingId, Integer paidAmount) throws MessagingException {
		sendConfirmationMail(name,  email, bookingDetailsVO,  ccList,  bookingId,  paidAmount, false);
	}*/
	private void sendConfirmationMail(String name, String email,
									  BookingDetailsVO bookingDetailsVO, List<String> ccList, String bookingId, Integer paidAmount, boolean isOnlinePaid) throws MessagingException {
		Map<String, Object> bookingConfirmationBodyDetails = new HashMap<String, Object>();
		bookingConfirmationBodyDetails.put("GUEST", name);
		bookingConfirmationBodyDetails.put("CHECK_IN", bookingDetailsVO.getCheckInDate().split(",")[1].trim());
		bookingConfirmationBodyDetails.put("CHECK_OUT", bookingDetailsVO.getCheckOutDate().split(",")[1].trim());
		bookingConfirmationBodyDetails.put("HOTEL_DISPLAY_NAME", bookingDetailsVO.getHotelDisplayName());
		bookingConfirmationBodyDetails.put("BOOKING_ID", bookingId);
		bookingConfirmationBodyDetails.put("ROOM_COUNT", bookingDetailsVO.getRoomDetailsVOList().size());
		bookingConfirmationBodyDetails.put("NIGHT_COUNT", bookingDetailsVO.getNights());
		bookingConfirmationBodyDetails.put("TOTAL_PRICE", WudstayUtil.rupiahCurrencyFormat(bookingDetailsVO.getTotalPrice()));
		bookingConfirmationBodyDetails.put("TOTAL_PRICE_CONTRACTUAL", "");
		bookingConfirmationBodyDetails.put("PAID", paidAmount);
		bookingConfirmationBodyDetails.put("ROOM_TYPE", bookingDetailsVO.getRoomTypeMaster());
		bookingConfirmationBodyDetails.put("MAP_LINK", bookingDetailsVO.getMapLink());
		bookingConfirmationBodyDetails.put("HOTEL_ACTUAL_NAME", bookingDetailsVO.getHotelName());
		bookingConfirmationBodyDetails.put("HOTEL_ACTUAL_ADD", bookingDetailsVO.getAddress());
		bookingConfirmationBodyDetails.put("GUEST_COUNT", bookingDetailsVO.getPersons());
		bookingConfirmationBodyDetails.put("INCLUDE_BREAKFAST", bookingDetailsVO.getBreakfastIncludedInPrice());
		if(isOnlinePaid) {
			EmailSender.getInstance().sendEmail(email, "Booking Confirmation", bookingConfirmationBodyDetails, WudstayConstants.BOOKING_CONFIRMATION_PRE_PAID_EMAIL_BODY, ccList);
		}else{
			EmailSender.getInstance().sendEmail(email, "Booking Confirmation", bookingConfirmationBodyDetails, WudstayConstants.BOOKING_CONFIRMATION_EMAIL_BODY, ccList);
		}
	}
	/*private void sendConfirmationMailToHotelAdmin(String name, String email,
												  BookingDetailsVO bookingDetailsVO, List<String> ccList, String bookingId, Integer paidAmount) throws MessagingException {
		boolean isOnlinePaid=false;
		sendConfirmationMailToHotelAdmin(name, email, bookingDetailsVO, ccList, bookingId, paidAmount, isOnlinePaid);
	}*/
	private void sendConfirmationMailToHotelAdmin(String name, String email,
												  BookingDetailsVO bookingDetailsVO, List<String> ccList, String bookingId, Integer paidAmount, boolean isOnlinePaid) throws MessagingException {
		Map<String, Object> bookingConfirmationBodyDetails = new HashMap<String, Object>();
		bookingConfirmationBodyDetails.put("GUEST", name);
		bookingConfirmationBodyDetails.put("CHECK_IN", bookingDetailsVO.getCheckInDate().split(",")[1].trim());
		bookingConfirmationBodyDetails.put("CHECK_OUT", bookingDetailsVO.getCheckOutDate().split(",")[1].trim());
		bookingConfirmationBodyDetails.put("HOTEL_DISPLAY_NAME", bookingDetailsVO.getHotelDisplayName());
		bookingConfirmationBodyDetails.put("BOOKING_ID", bookingId);
		bookingConfirmationBodyDetails.put("ROOM_COUNT", bookingDetailsVO.getRoomDetailsVOList().size());
		bookingConfirmationBodyDetails.put("NIGHT_COUNT", bookingDetailsVO.getNights());
		bookingConfirmationBodyDetails.put("TOTAL_PRICE", WudstayUtil.rupiahCurrencyFormat(bookingDetailsVO.getTotalPrice()));
		bookingConfirmationBodyDetails.put("TOTAL_PRICE_CONTRACTUAL", WudstayUtil.rupiahCurrencyFormat(bookingDetailsVO.getTotalPriceContractual()));
		bookingConfirmationBodyDetails.put("PAID", paidAmount);
		bookingConfirmationBodyDetails.put("ROOM_TYPE", bookingDetailsVO.getRoomTypeMaster());
		bookingConfirmationBodyDetails.put("MAP_LINK", bookingDetailsVO.getMapLink());
		bookingConfirmationBodyDetails.put("HOTEL_ACTUAL_NAME", bookingDetailsVO.getHotelName());
		bookingConfirmationBodyDetails.put("HOTEL_ACTUAL_ADD", bookingDetailsVO.getAddress());
		bookingConfirmationBodyDetails.put("GUEST_COUNT", bookingDetailsVO.getPersons());
		bookingConfirmationBodyDetails.put("INCLUDE_BREAKFAST", bookingDetailsVO.getBreakfastIncludedInPrice());
		//EmailSender.getInstance().sendEmail(email, "Booking Confirmation", bookingConfirmationBodyDetails, WudstayConstants.BOOKING_CONFIRMATION_EMAIL_BODY, ccList);
		if(isOnlinePaid) {
			EmailSender.getInstance().sendEmail(email, "Booking Confirmation", bookingConfirmationBodyDetails, WudstayConstants.BOOKING_CONFIRMATION_PRE_PAID_EMAIL_BODY, ccList);
		}else{
			EmailSender.getInstance().sendEmail(email, "Booking Confirmation", bookingConfirmationBodyDetails, WudstayConstants.BOOKING_CONFIRMATION_EMAIL_BODY, ccList);
		}
	}


	/*@RequestMapping(method = RequestMethod.GET, value = WudstayMappings.SEARCH_HOTELS)
	public ModelAndView searchHotels2(@RequestParam String checkIn, @RequestParam String checkOut, @RequestParam Integer rooms,
									 @RequestParam Integer persons, @RequestParam Long cityId, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		ModelAndView modelAndView =  new ModelAndView("results2");
		try {
			City city = cityManager.getById(cityId);
			if(checkIn == null || checkIn.equals(WudstayConstants.BLANK) || checkOut == null || checkOut.equals(WudstayConstants.BLANK)) {
				session.setAttribute(WudstayConstants.SEARCH_PARAM_MAP, getSearchParamHashMap(city.getCityName(), cityId, WudstayUtil.getDefaultCheckInDate(), WudstayUtil.getDefaultCheckOutDate(),
						rooms, persons));
			} else {
				session.setAttribute(WudstayConstants.SEARCH_PARAM_MAP, getSearchParamHashMap(city.getCityName(), cityId, WudstayUtil.getFormattedCheckInDate(checkIn), WudstayUtil.getFormattedCheckOutDate(checkOut),
						rooms, persons));
			}

			List<Hotel> hotelList = hotelManager.getHotelByCityId(cityId, persons/rooms);
			HashMap<String, Object> searchParamMap = (HashMap<String, Object>) session.getAttribute(WudstayConstants.SEARCH_PARAM_MAP);
			hotelList = WudstayUtil.processHotelList(hotelList, rooms, persons, hotelBookingManager, (String) searchParamMap.get("checkIn"), (String) searchParamMap.get("checkOut"), hotelManager);

			WudstayUtil.setAmenitiesForHotel(hotelList);

			List<Location> locationList = locationManager.getLocationsByCityId(cityId);
			List<RoomType> roomTypeList = roomTypeManager.list();
			modelAndView.addObject("city", city.getCityName());
			modelAndView.addObject("cityId", cityId);
			modelAndView.addObject("roomsAndPersons", WudstayUtil.getRoomsAndPersons(rooms, persons));
			modelAndView.addObject("stayPeriod", WudstayUtil.getStayPeriod((String) searchParamMap.get("checkIn"), (String) searchParamMap.get("checkOut")));
			modelAndView.addObject("locationList", locationList);
			modelAndView.addObject("roomTypeList", roomTypeList);
			modelAndView.addObject("hotelList", hotelList);

		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
		}
		return modelAndView;
	}*/

	
}


/*
Bookings -->       getBookings.do        --> GET_BOOKINGS          --> SHOW_HOTEL_BOOKINGS_PAGE   --> showHotelBookings
Create Booking --> addCustCareBooking.do --> ADD_CUST_CARE_BOOKING --> ADD_CUST_CARE_BOOKING_PAGE --> custCareBooking
View Hotels -->    viewHotels.do         --> VIEW_HOTELS           --> SHOW_HOTELS_PAGE           --> showHotels
View Cities -->    getAllCities.do       --> GET_ALL_CITIES        --> SHOW_CITIES_PAGE           --> showCities
View Locations --> getAllLocations.do    --> GET_ALL_LOCATIONS     --> SHOW_LOCATIONS_PAGE        --> showLocations
 */