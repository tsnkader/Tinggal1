package com.queppelin.wudstay.web.servlet;

import java.io.*;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by hp on 10/28/2015.
 */
public class SitemapXmlServlet extends HttpServlet {

        
    public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
        // output an HTML page
    	res.setContentType("text/xml;charset=UTF-8"); //res.setContentType("text/html");
        // print some html
        ServletOutputStream out = res.getOutputStream();
        //out. println("<html>");
        //out.println("<head><title>sitemap.xml</title></head>");
        //out.println("<body>");

        // print the file
        //InputStream in = null;

        ServletContext ctx = getServletContext();
        InputStream in = ctx.getResourceAsStream("/sitemap.xml");

        BufferedReader br = null;
        StringBuilder sb = new StringBuilder();

        String line;

        try {
            br = new BufferedReader(new InputStreamReader(in));
            while ((line = br.readLine()) != null) {
                //sb.append(line);
            	out.print(line );//out.print(line + "<br/>");
            }
        }
        finally {
            if (in != null) in.close();  // very important
        }

        // finish up
        //out.println("</body></html>");
    }
}