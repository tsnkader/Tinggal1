package com.queppelin.wudstay.web.servlet;

import java.io.*;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by hp on 10/28/2015.
 */
public class SitemapTxtServlet extends HttpServlet {

    private static final int BYTES_DOWNLOAD = 1024;

    public void doGet_1(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/plain");
        response.setHeader("Content-Disposition", "attachment;filename=sitemap.txt");
        ServletContext ctx = getServletContext();
        InputStream is = ctx.getResourceAsStream("/sitemap.txt");

        int read = 0;
        byte[] bytes = new byte[BYTES_DOWNLOAD];
        OutputStream os = response.getOutputStream();

        while ((read = is.read(bytes)) != -1) {
            os.write(bytes, 0, read);
        }
        os.flush();
        os.close();
    }

    public void doGet_2(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
        // output an HTML page
        res.setContentType("text/html");

        // load a configuration parameter (you must set this yourself)
        //String root = getInitParameter("root");

        // print some html
        ServletOutputStream out = res.getOutputStream();
        out. println("<html>");
        out.println("<head><title>sitemap.txt</title></head>");
        out.println("<body>");

        // print the file
        //InputStream in = null;

        ServletContext ctx = getServletContext();
        InputStream in = ctx.getResourceAsStream("/sitemap.txt");

        try {
            in = new BufferedInputStream(in); //new FileInputStream(root + "/message.txt") );
            int ch;
            while ((ch = in.read()) !=-1) {
                out.print((char)ch);
            }
        }
        finally {
            if (in != null) in.close();  // very important
        }

        // finish up
        out.println("</body></html>");
    }
    public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
        // output an HTML page
        res.setContentType("text/html");
        // print some html
        ServletOutputStream out = res.getOutputStream();
        out. println("<html>");
        out.println("<head><title>sitemap.txt</title></head>");
        out.println("<body>");

        // print the file
        //InputStream in = null;

        ServletContext ctx = getServletContext();
        InputStream in = ctx.getResourceAsStream("/sitemap.txt");

        BufferedReader br = null;
        StringBuilder sb = new StringBuilder();

        String line;

        try {
            br = new BufferedReader(new InputStreamReader(in));
            while ((line = br.readLine()) != null) {
                //sb.append(line);
                out.print(line + "<br/>");
            }
        }
        finally {
            if (in != null) in.close();  // very important
        }

        // finish up
        out.println("</body></html>");
    }
}