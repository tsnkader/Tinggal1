package com.queppelin.wudstay.web.servlet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * Created by hp on 10/28/2015.
 */
public class RobotsTxtServlet extends HttpServlet {

        
    public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
        // output an HTML page
    	res.setContentType("text/html");
        // print some html
        ServletOutputStream out = res.getOutputStream();
        //out. println("<html>");
        //out.println("<head><title>sitemap.xml</title></head>");
        //out.println("<body>");

        // print the file
        //InputStream in = null;

        ServletContext ctx = getServletContext();
        InputStream in = ctx.getResourceAsStream("/robots.txt");

        BufferedReader br = null;
        StringBuilder sb = new StringBuilder();

        String line;

        try {
            br = new BufferedReader(new InputStreamReader(in));
            while ((line = br.readLine()) != null) {
                //sb.append(line);
            	out.println(line );//out.print(line + "<br/>");
            }
        }
        finally {
            if (in != null) in.close();  // very important
        }

        // finish up
        //out.println("</body></html>");
    }
}