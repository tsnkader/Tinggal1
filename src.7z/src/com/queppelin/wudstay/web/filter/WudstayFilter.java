package com.queppelin.wudstay.web.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.queppelin.wudstay.util.UAgentInfo;




public class WudstayFilter implements Filter{

	private final Logger logger = LoggerFactory.getLogger(WudstayFilter.class);

	@Override
	public void destroy() {

	}

	private String getStringArrayElement(String [] urlParts, int index){
		String urlPart = "";
		try{
			urlPart = urlParts[index].trim();
		}catch (Exception ex){
			//ex.printStackTrace();
			urlPart="";
		}
		return urlPart;
	}
	private String parseUrlForCityAndHotelId(String redirectURL, final String contextPath, final String uri, final String queryString) throws Exception {
		//String str = "/wudstay/Manali/hotel?hotelId=31";
		//String str = "/wudstay/Manali/hotel?priceSortType=0&ratingSortType=0&cityId=5&sortBy=&locationId=&roomTypeIds=&isAllRoomTypeSelected=false&hotel Id=33";
		String [] urlParts = uri.split("/");

		int iCounter=0;
		String urlPart = getStringArrayElement(urlParts, iCounter);// <<EMPTY-STRING>>
		iCounter++;
		if("".equals(urlPart) || contextPath.equalsIgnoreCase(urlPart)){
			urlPart = getStringArrayElement(urlParts, iCounter); // <<wudstay>>
			iCounter++;
		}
		urlPart = getStringArrayElement(urlParts, iCounter); // <<Manali>>
		iCounter++;
		if(!"".equals(urlPart)){ // <<EMPTY-STRING>>/<<wudstay>>/<<[Manali]>>/<<EMPTY-STRING>>
			redirectURL = redirectURL + urlPart ; // /wudstay/m/Manali/

			urlPart = getStringArrayElement(urlParts, iCounter);
			iCounter++;
			if("".equals(urlPart) ){ // <<EMPTY-STRING>>/<<[wudstay]>>/<<Manali>>/<<EMPTY-STRING>>
				// do nothing
			}else if(urlPart.startsWith("hotel")){
				StringBuilder myNumbers = new StringBuilder();
				int i = 0;
				int j=0;
				if(queryString.startsWith("hotelId=")){
					i = queryString.indexOf("hotelId=");
					j= "hotelId=".length();
				}else{ //&hotelId=32
					i = queryString.indexOf("&hotelId=");
					j= "&hotelId=".length();
				}
				if(i>=0){
					i=i+j;
					boolean loopContinueFlag = true;
					while(loopContinueFlag && i< queryString.length()){
						if (Character.isDigit(queryString.charAt(i))) {
							myNumbers.append(queryString.charAt(i));
							System.out.println(queryString.charAt(i) + " is a digit.");
						} else {
							System.out.println(queryString.charAt(i) + " not a digit.");
							loopContinueFlag=false;
						}
						i++;
					}
					redirectURL = redirectURL + "/hotel?hotelId=" + myNumbers.toString();
				}
			}
		}
		System.out.println(redirectURL);
		return redirectURL;
	}

	/*
	//hsr.sendRedirect(contextPathM2);
				String redirectURL = new String(contextPathM2);
				try {
					redirectURL = parseUrlForCityAndHotelId(redirectURL, contextPath, uri);
				} catch (Exception e) {
					e.printStackTrace();
					redirectURL  = new String(contextPathM2);
				}
				hsr.sendRedirect(redirectURL);
				return;
			}
	 */


	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException  {
		HttpServletResponse hsr = (HttpServletResponse) response;
		HttpServletRequest hRequest = (HttpServletRequest) request;
		boolean isMobileDevice =  isRequestComingFromAMobileDevice(hRequest);

		final String contextPath = hRequest.getContextPath();  // "/wudstay"
		final String uri = hRequest.getRequestURI();//            "/wudstay/m/"
		final String queryString = hRequest.getQueryString();
		if(isMobileDevice && isIgnorableUrl(contextPath, uri)) {
			System.out.println("IGNORE URL: " + uri);
		}else if(isMobileDevice){
			String mobileContextPath = contextPath + "/m";
			String mobileContextPath2 = contextPath + "/m/";

			if(uri.equalsIgnoreCase(mobileContextPath) || uri.equalsIgnoreCase(mobileContextPath2) || uri.startsWith(mobileContextPath2)){
				// already Mobile URL
			}else if(uri.contains("permata25")){
				String redirectURL = new String(mobileContextPath2+ "permata25");
				hsr.sendRedirect(redirectURL);
				return;
			}else if(uri.contains("permata")){
				String redirectURL = new String(mobileContextPath2+ "permata");
				hsr.sendRedirect(redirectURL);
				return;
			}else if(uri.contains("citibank")){
				String redirectURL = new String(mobileContextPath2+ "citibank");
				hsr.sendRedirect(redirectURL);
				return;
			}else if(uri.contains("google")){
				String redirectURL = new String(mobileContextPath2+ "google");
				hsr.sendRedirect(redirectURL);
				return;
			}else if(uri.contains("JGOS2016")){
				String redirectURL = new String(mobileContextPath2+ "JGOS2016");
				hsr.sendRedirect(redirectURL);
				return;
			}else if(uri.contains("jgos2016")){
				String redirectURL = new String(mobileContextPath2+ "jgos2016");
				hsr.sendRedirect(redirectURL);
				return;
			}else if(uri.contains("LineJGOS")){
				String redirectURL = new String(mobileContextPath2+ "LineJGOS");
				hsr.sendRedirect(redirectURL);
				return;
			}else if(uri.contains("linejgos")){
				String redirectURL = new String(mobileContextPath2+ "linejgos");
				hsr.sendRedirect(redirectURL);
				return;
			}else if(uri.contains("LINEJGOS")){
				String redirectURL = new String(mobileContextPath2+ "LINEJGOS");
				hsr.sendRedirect(redirectURL);
				return;
			}else if(uri.contains("TselJGOS")){
				String redirectURL = new String(mobileContextPath2+ "TselJGOS");
				hsr.sendRedirect(redirectURL);
				return;
			}else if(uri.contains("tseljgos")){
				String redirectURL = new String(mobileContextPath2+ "tseljgos");
				hsr.sendRedirect(redirectURL);
				return;
			}else if(uri.contains("TSELJGOS")){
				String redirectURL = new String(mobileContextPath2+ "TSELJGOS");
				hsr.sendRedirect(redirectURL);
				return;
			}else if(uri.contains("sgholiday")){
				String redirectURL = new String(mobileContextPath2+ "sgholiday");
				hsr.sendRedirect(redirectURL);
				return;
			}else if(uri.contains("ramadhan")){
				String redirectURL = new String(mobileContextPath2+ "ramadhan");
				hsr.sendRedirect(redirectURL);
				return;
			}else{
				//hsr.sendRedirect(contextPathM2);
				String redirectURL = new String(mobileContextPath2);
				try {
					redirectURL = parseUrlForCityAndHotelId(redirectURL, contextPath, uri, queryString);
				} catch (Exception e) {
					e.printStackTrace();
					redirectURL  = new String(mobileContextPath2);
				}
				hsr.sendRedirect(redirectURL);
				return;
			}
		}
		//====================================================================================
		chain.doFilter(request, response);
	}


	@Override
	public void init(FilterConfig arg0) throws ServletException {

	}
	
	private boolean isIgnorableUrl(final String contextPath, final String uri){
		if(uri.startsWith(contextPath + "/pages/") || uri.startsWith(contextPath + "/resources/") ||
				uri.startsWith(contextPath + "/hotel_images") ||   uri.startsWith(contextPath + "/sendMobileNumberVerificationCode.do") ||
				uri.startsWith(contextPath + "/calculateCouponCodeDiscount.do") || uri.startsWith(contextPath + "/verifyMobileNumber.do") ||
		        uri.startsWith(contextPath + "/isMaximumNightsReached.do")  ){
			return true;
		}else if(uri.startsWith(contextPath + "/veritrans") || uri.startsWith(contextPath + "/booking-confirmation")) {
			return true;
		}else if(uri.startsWith(contextPath + "/admin") || uri.startsWith(contextPath + "/customercare")  || uri.startsWith(contextPath + "/corporate")) {
			return true;
		}else if(uri.startsWith(contextPath + "/sitemap.xml") || uri.startsWith(contextPath + "/robots.txt")) {
			return true;
		}else{
			return false;
		}
	}


	public static boolean isRequestComingFromAMobileDevice(final HttpServletRequest request){
		// http://www.hand-interactive.com/m/resources/detect-mobile-java.htm
		final String userAgent = request.getHeader("User-Agent");
		final String httpAccept = request.getHeader("Accept");

		final UAgentInfo detector = new UAgentInfo(userAgent, httpAccept);

		return detector.detectMobileQuick();
	}

}
