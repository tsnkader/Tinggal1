package com.queppelin.wudstay.manager;

import com.queppelin.wudstay.vo.PgType;

public interface IPgTypeManager extends IBaseManager<PgType> {

}
