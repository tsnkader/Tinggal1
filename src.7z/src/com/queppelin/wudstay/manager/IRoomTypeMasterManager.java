package com.queppelin.wudstay.manager;

import java.util.List;

import com.queppelin.wudstay.vo.RoomTypeMaster;

public interface IRoomTypeMasterManager extends IBaseManager<RoomTypeMaster>{
	 
	 List<RoomTypeMaster> list();
}
