package com.queppelin.wudstay.manager;

import com.queppelin.wudstay.vo.PayPalTranLogVO;

public interface IPaypalTranLogManager extends IBaseManager<PayPalTranLogVO> {
    public PayPalTranLogVO saveLog(PayPalTranLogVO obj);
    public PayPalTranLogVO getBySecureToken(String secureToken);
    public PayPalTranLogVO getBySecureToken(PayPalTranLogVO tranLog);


}
