package com.queppelin.wudstay.manager;

import java.util.List;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.City;
import com.queppelin.wudstay.vo.CityWithHotelCountMVO;

public interface ICityManager extends IBaseManager<City> {

	public List<City> getAllPgCities() throws WudstayException;

	List<City> getAllCities() throws WudstayException;

	City getByCityName(String cityName) throws WudstayException;

	List<CityWithHotelCountMVO> getAllCitiesWithHotelCount()  throws WudstayException;

	public CityWithHotelCountMVO getCityByIdWithHotelCount(Long cityId)  throws WudstayException;

}
