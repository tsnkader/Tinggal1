package com.queppelin.wudstay.manager;

import java.util.List;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.Location;

public interface ILocationManager extends IBaseManager<Location> {

	List<Location> getLocationsByCityId(Long cityId) throws WudstayException;
}
