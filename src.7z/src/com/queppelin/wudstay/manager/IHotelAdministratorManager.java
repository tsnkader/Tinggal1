package com.queppelin.wudstay.manager;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.HotelAdministrator;

public interface IHotelAdministratorManager extends IBaseManager<HotelAdministrator> {

	HotelAdministrator getHotelAdminByHotelId(Long hotelId) throws WudstayException;
	
}
