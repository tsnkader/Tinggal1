package com.queppelin.wudstay.manager;

import com.queppelin.wudstay.vo.PgScheduleVisits;

public interface IPgScheduleVisitsManager extends IBaseManager<PgScheduleVisits> {

}
