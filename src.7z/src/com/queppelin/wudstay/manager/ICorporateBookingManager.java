package com.queppelin.wudstay.manager;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.CorporateBookingVO;

import java.util.List;

public interface ICorporateBookingManager extends IBaseManager<CorporateBookingVO> {

	
	List<CorporateBookingVO> getAllBookings(Long corpId, Long corpLoginUserId) throws WudstayException;
	
	String addCorporateBooking(com.queppelin.wudstay.vo.custom.CorporateBookingVO corporateBookingVO)  throws WudstayException;
	
	List<CorporateBookingVO> getCorporateBookingsByCorporateId(Long corpId) throws WudstayException;
	
	List<CorporateBookingVO> getCorporateBookingList() throws WudstayException;
	
}
