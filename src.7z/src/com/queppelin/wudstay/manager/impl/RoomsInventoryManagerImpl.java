package com.queppelin.wudstay.manager.impl;

import com.queppelin.wudstay.dao.IHotelBookingDao;
import com.queppelin.wudstay.dao.IRoomsInventoryDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.IHotelBookingManager;
import com.queppelin.wudstay.manager.IRoomsInventoryManager;
import com.queppelin.wudstay.util.DateUtil;
import com.queppelin.wudstay.util.WudstayUtil;
import com.queppelin.wudstay.vo.*;
import com.queppelin.wudstay.vo.custom.RoomAvailabilityDayWise;
import com.queppelin.wudstay.vo.custom.RoomsInventoryForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.print.attribute.HashAttributeSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
@Transactional
public class RoomsInventoryManagerImpl extends BaseManagerImpl<RoomsInventoryVO, IRoomsInventoryDao> implements IRoomsInventoryManager {
	private static SimpleDateFormat dateFormat_ddMMyyyy = new SimpleDateFormat("dd/MM/yyyy");
	private static SimpleDateFormat dateFormat_yyyyMMdd = new SimpleDateFormat("yyyyMMdd");
	private static final Logger logger = LoggerFactory.getLogger(HotelBookingManagerImpl.class);

	@Autowired
	IRoomsInventoryDao roomsInventoryDao;

	@Autowired
	IHotelBookingDao hotelBookingDao;

	@Autowired
	IHotelBookingManager hotelBookingManager;

	
	public IRoomsInventoryDao getDao() {
		return roomsInventoryDao;
	}



	private Long toInventoryLongDate(String date){
		try {
			return toInventoryLongDate(dateFormat_ddMMyyyy.parse(date));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return 0L;
	}
	private Long toInventoryLongDate(Date date){
		String dt =  dateFormat_yyyyMMdd.format(date);
		return Long.parseLong(dt.replace("/", "").trim());
	}
	
	public List<RoomsInventoryVO> getListByHotelId(Long hotelId){
		return roomsInventoryDao.getListByHotelId(hotelId);
	}

	
	public RoomsInventoryVO getListByDate(Long hotelId, String date) throws WudstayException {
		return roomsInventoryDao.getListByDate(hotelId, toInventoryLongDate(date));
	}

	
	public List<RoomsInventoryVO> getListByDate(Long hotelId, String fromDate, String toDate) throws WudstayException {
		return roomsInventoryDao.getListByDate(hotelId, toInventoryLongDate(fromDate), toInventoryLongDate(toDate));
	}

	public RoomsInventoryVO getListByDate(Long hotelId, Date date) throws WudstayException{
		return roomsInventoryDao.getListByDate(hotelId, toInventoryLongDate(date));
	}
	public List<RoomsInventoryVO> getListByDate(Long hotelId, Date fromDate, Date toDate) throws WudstayException{
		return roomsInventoryDao.getListByDate(hotelId, toInventoryLongDate(fromDate), toInventoryLongDate(toDate));
	}

	public Integer getMinRoomAvailable(Long hotelId, Date fromDate, Date toDate) throws WudstayException{
		return roomsInventoryDao.getMinRoomAvailable(hotelId, toInventoryLongDate(fromDate), toInventoryLongDate(toDate));
	}

	public Integer getMinRoomAvailable(Long hotelId, String fromDate, String toDate) throws WudstayException{
		return roomsInventoryDao.getMinRoomAvailable(hotelId, toInventoryLongDate(fromDate), toInventoryLongDate(toDate));
	}

	public Map<Long, RoomAvailabilityDayWise > getRoomAvailabilityDayWise(Long hotelId, String fromDate, String toDate) {
		Map<Long, RoomAvailabilityDayWise > map = new HashMap();
		try {
			List<RoomsInventoryVO> lst = roomsInventoryDao.getListByDate(hotelId, toInventoryLongDate(fromDate), toInventoryLongDate(toDate));
			for (RoomsInventoryVO vo : lst) {
				map.put(vo.getInventoryLongDate(), new RoomAvailabilityDayWise(vo.getInventoryLongDate(), vo.getNoOfRooms(), 0));
			}
		}catch (Exception ex){
			ex.printStackTrace();
		}
		return map;
	}
	public Map<Long, RoomAvailabilityDayWise > getRoomAvailabilityDayWise(Long hotelId, Date fromDate, Date toDate){
		Map<Long, RoomAvailabilityDayWise > map = new HashMap();
		try {
			List<RoomsInventoryVO> lst = roomsInventoryDao.getListByDate(hotelId, toInventoryLongDate(fromDate), toInventoryLongDate(toDate));
			for (RoomsInventoryVO vo : lst) {
				map.put(vo.getInventoryLongDate(), new RoomAvailabilityDayWise(vo.getInventoryLongDate(), vo.getNoOfRooms(), 0));
			}
		}catch (Exception ex){
			ex.printStackTrace();
		}
		return map;
	}
	//------------------------------------------------------------------------------------------------------------------
	public List<HotelBooking> getBookingsByDate(Long hotelId, Date checkIn) throws WudstayException {
		long date = checkIn.getTime();
		DateUtil dateUtil = new DateUtil(new Date(date));
		return hotelBookingDao.getBookingsBetweenSelectedDates(hotelId, dateUtil.toDate(), dateUtil.moveNexDay());
	}
	public Integer getBookedRoomsByDate(Long hotelId, Date checkIn){
		int bookedRooms=0;
		/*try {
			List<HotelBooking> lstBooking = getBookingsByDate(hotelId, checkIn);
			for(HotelBooking booking: lstBooking){
				bookedRooms += booking.getNoOfRooms();
			}
			return bookedRooms;
		} catch (Exception e) {
			e.printStackTrace();
			return bookedRooms;
		}*/
		DateUtil dateUtil = new DateUtil(checkIn);
		dateUtil.moveNexDay();
		try {
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String strCheckInDate = WudstayUtil.getFormattedCheckInDate( DateUtil.toDisplayDate(checkIn) );
			String strCheckOutDate = WudstayUtil.getFormattedCheckOutDate(DateUtil.toDisplayDate(dateUtil.toDate()));

			//Map<Long, RoomAvailabilityDayWise> bookingsRooms = hotelBookingManager.getRoomBookingsDayWise(hotelId, checkIn, dateUtil.toDate());
			Map<Long, RoomAvailabilityDayWise> bookingsRooms = hotelBookingManager.getRoomBookingsDayWise(hotelId, format.parse(strCheckInDate),format.parse(strCheckOutDate));

			for (Map.Entry<Long, RoomAvailabilityDayWise> entryBooking : bookingsRooms.entrySet()) {
				bookedRooms += entryBooking.getValue().getBookedRooms();
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}



		return bookedRooms;
	}
	//------------------------------------------------------------------------------------------------------------------
	
	public RoomsInventoryForm getRoomAvailabilityCalendar(Hotel hotel, int month, int year)  {
		DateUtil dateUtil = new DateUtil(1, month, year);
		Date date = dateUtil.toDate();
		RoomsInventoryForm calender = new RoomsInventoryForm(hotel.getHotelId(), date);
		//--------------------------------------------------------------------------------------------------------------
		int dayOfWeek = dateUtil.dayOfWeek();
		for(int i=1; i<dayOfWeek; i++ ){
			calender.addCalenderDay(null);
		}
		//--------------------------------------------------------------------------------------------------------------
		int maxDay = dateUtil.getMaxDayInMonth();
		RoomsInventoryVO vo;
		for(int i=1; i <= maxDay; i++){
			int noOfRooms=0;
			int bookedRooms=0;
			String strDate = DateUtil.toDisplayDate(date);
			try{
				//vo = getListByDate(hotel.getHotelId(), date);
				vo = roomsInventoryDao.getListByDate(hotel.getHotelId(), toInventoryLongDate(date));
				noOfRooms = vo.getNoOfRooms();
			}catch (Exception ex){}

			bookedRooms = getBookedRoomsByDate(hotel.getHotelId(), date);
			calender.addCalenderDay(noOfRooms, bookedRooms, strDate);
			date = dateUtil.moveNexDay();
		}
		//--------------------------------------------------------------------------------------------------------------
		/*if(calender.calenderSize()<=35){
			for (int j = calender.calenderSize() + 1; j < 36; j++) {
				calender.addCalenderDay(null);
			}
		}else {
			for (int j = calender.calenderSize() + 1; j < 43; j++) {
				calender.addCalenderDay(null);
			}
		}*/
		for (int j = calender.calenderSize() + 1; j < 43; j++) {
			calender.addCalenderDay(null);
		}
		//--------------------------------------------------------------------------------------------------------------
		return calender;
	}
	public void updateInventory(Long hotelId, int noOfRooms, Date date){
		RoomsInventoryVO vo = null;
		try {
			vo = roomsInventoryDao.getListByDate(hotelId, toInventoryLongDate(date));
		} catch (WudstayException e) {
			e.printStackTrace();
		}
		if(vo==null)
			vo = new RoomsInventoryVO();
		vo.setLastUpdatedDate(new Date());
		vo.setHotelId(hotelId);
		vo.setNoOfRooms(noOfRooms);
		vo.setInventoryDate(date);
		try {
			vo.setInventoryLongDate(Long.parseLong(dateFormat_yyyyMMdd.format(date)));
		}catch (Exception ex){
			ex.printStackTrace();
		}
		super.saveOrUpdate(vo);
	}
	public void updateInventory(Long hotelId, int noOfRooms, Date fromDate, Date toDate){
		DateUtil dateUtil = new DateUtil(fromDate);
		int days = (int)dateUtil.getDifferenceInDays(toDate);
		for(int i=0; i< days ; i++){
			RoomsInventoryVO vo = null;
			try {
				vo = roomsInventoryDao.getListByDate(hotelId, toInventoryLongDate(dateUtil.toDate()));
			} catch (WudstayException e) {
				e.printStackTrace();
			}
			if(vo==null){
				vo = new RoomsInventoryVO();
			}
			vo.setLastUpdatedDate(new Date());
			vo.setHotelId(hotelId);
			vo.setNoOfRooms(noOfRooms);
			vo.setInventoryDate(dateUtil.toDate());
			try {
				vo.setInventoryLongDate(Long.parseLong(dateFormat_yyyyMMdd.format(dateUtil.toDate())));
			}catch (Exception ex){
				ex.printStackTrace();
			}
			super.saveOrUpdate(vo);
			dateUtil.moveNexDay();
		}
	}

}
