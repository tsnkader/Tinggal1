
package com.queppelin.wudstay.manager.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.queppelin.wudstay.dao.IHotelDescriptionDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.IHotelDescriptionManager;
import com.queppelin.wudstay.vo.HotelDescription;

@Service
@Transactional
public class HotelDescriptionManagerImpl extends BaseManagerImpl<HotelDescription, IHotelDescriptionDao>
		implements IHotelDescriptionManager {

	private static final Logger logger = LoggerFactory.getLogger(HotelDescriptionManagerImpl.class);

	@Autowired
	IHotelDescriptionDao hotelDescriptionDao;

	
	public IHotelDescriptionDao getDao() {
		return hotelDescriptionDao;
	}

	
	public List<HotelDescription> getHotelDescriptionsByHotelId(Long hotelId)
			throws WudstayException {
		return hotelDescriptionDao.getHotelDescriptionsByHotelId(hotelId);
	}
}
