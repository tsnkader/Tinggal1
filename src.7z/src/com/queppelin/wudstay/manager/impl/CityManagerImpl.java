
package com.queppelin.wudstay.manager.impl;

import java.util.ArrayList;
import java.util.List;

import com.queppelin.wudstay.dao.IPgCityDao;
import com.queppelin.wudstay.vo.CityWithHotelCountMVO;
import com.queppelin.wudstay.vo.PgCity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.queppelin.wudstay.dao.ICityDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.ICityManager;
import com.queppelin.wudstay.vo.City;

@Service
@Transactional
public class CityManagerImpl extends BaseManagerImpl<City, ICityDao>
		implements ICityManager {

	private static final Logger logger = LoggerFactory.getLogger(CityManagerImpl.class);

	@Autowired
	ICityDao cityDao;

	@Autowired
	IPgCityDao pgCityDao;

	
	public ICityDao getDao() {
		return cityDao;
	}



	
	public List<City> getAllPgCities() throws WudstayException {
		List<City> lstCity = new ArrayList<City>();

		List<PgCity> lst = pgCityDao.list();
		for(PgCity city: lst){
			lstCity.add(city.getCity());
		}
		return lstCity;
	}

	
	public List<City> getAllCities() throws WudstayException {
		return cityDao.getAllCities();
	}

	
	public City getByCityName(String cityName) throws WudstayException {
		return cityDao.getByCityName(cityName);
	}

	
	public List<CityWithHotelCountMVO> getAllCitiesWithHotelCount()  throws WudstayException{
		try {
			return (List<CityWithHotelCountMVO> )(cityDao.getNamedQuery("callSpCityWithHotelCount").list());
		}catch (Exception ex){
			ex.printStackTrace();
			throw new WudstayException(logger, "CityManagerImpl.getAllCitiesWithHotelCount()", "Error to fetching data: " + ex.getMessage(), null, ex);
		}
	}

	
	public CityWithHotelCountMVO getCityByIdWithHotelCount(Long cityId)  throws WudstayException{
		try {
			List<CityWithHotelCountMVO> cityList = (List<CityWithHotelCountMVO> )(cityDao.getNamedQuery("callSpCityByIdWithHotelCount", new String[]{"v_cityid"},  new Object[]{cityId}).list());
			if(cityList==null)
				return null;
			return cityList.get(0);
		}catch (Exception ex){
			ex.printStackTrace();
			throw new WudstayException(logger, "CityManagerImpl.getAllCitiesWithHotelCount()", "Error to fetching data: " + ex.getMessage(), null, ex);
		}
	}
}
