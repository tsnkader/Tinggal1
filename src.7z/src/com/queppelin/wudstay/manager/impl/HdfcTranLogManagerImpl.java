
package com.queppelin.wudstay.manager.impl;

import com.queppelin.wudstay.dao.*;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.ICouponCodeManager;
import com.queppelin.wudstay.manager.IHdfcTranLogManager;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.*;
import com.queppelin.wudstay.vo.custom.DiscountCouponInfo;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Service
@Transactional
public class HdfcTranLogManagerImpl extends BaseManagerImpl<HdfcTranLogVO, IHdfcTranLogDao> implements IHdfcTranLogManager {
	private static final Logger logger = LoggerFactory.getLogger(HdfcTranLogManagerImpl.class);

	@Autowired
	IHdfcTranLogDao hdfcTranLogDao;
	@Autowired
	IHdfcTranResponseDao hdfcTranResponseDao;

	
	public IHdfcTranLogDao getDao() {
		return hdfcTranLogDao;
	}

	public HdfcTranLogVO saveLog(HdfcTranLogVO obj) {
		obj.setLogTime(new Date());
		hdfcTranLogDao.saveOrUpdate(obj);
		return obj;
	}

	public HdfcTranResponseVO saveResponse(HdfcTranResponseVO obj) {
		obj.setLogTime(new Date());
		hdfcTranResponseDao.saveOrUpdate(obj);
		return obj;
	}
	public HdfcTranLogVO getBySecureHash(String secureHash){
		return hdfcTranLogDao.getSecureHash(secureHash);
	}



}

