
package com.queppelin.wudstay.manager.impl;

import java.text.SimpleDateFormat;
import java.util.*;
import java.text.ParseException;

import com.queppelin.wudstay.manager.ICouponCodeManager;
import com.queppelin.wudstay.manager.IRoomsInventoryManager;
import com.queppelin.wudstay.vo.CouponCodeUsedVO;
import com.queppelin.wudstay.vo.custom.DiscountCouponInfo;
import com.queppelin.wudstay.vo.custom.RoomAvailabilityDayWise;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.queppelin.wudstay.dao.IBlackoutDateForCheckOutDao;
import com.queppelin.wudstay.dao.IBlackoutDateForPayAtHotelDao;
import com.queppelin.wudstay.dao.IHotelBookingDao;
import com.queppelin.wudstay.dao.IHotelDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.IHotelBookingManager;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.util.WudstayUtil;
import com.queppelin.wudstay.vo.HotelBooking;
import com.queppelin.wudstay.vo.custom.BookingDetailsVO;

@Service
@Transactional
public class HotelBookingManagerImpl extends BaseManagerImpl<HotelBooking, IHotelBookingDao>
		implements IHotelBookingManager {

	private static final Logger logger = LoggerFactory.getLogger(HotelBookingManagerImpl.class);

	@Autowired
	IHotelBookingDao hotelBookingDao;
	
	@Autowired
	IHotelDao hotelDao;

	@Autowired
	ICouponCodeManager couponCodeManager;

	@Autowired
	IRoomsInventoryManager roomsInventoryManager;

	
	public IHotelBookingDao getDao() {
		return hotelBookingDao;
	}

	@Autowired
	IBlackoutDateForPayAtHotelDao blackoutDateForPayAtHotelDao;

	@Autowired
	IBlackoutDateForCheckOutDao blackoutDateForCheckOutDao;

	
	public List<HotelBooking> getBookingsByHotelId(Long hotelId)
			throws WudstayException {
		return hotelBookingDao.getBookingsByHotelId(hotelId);
	}



	/*
	public String makeBooking(BookingDetailsVO bookingDetailsVO, String name, String mobileNumber, String checkIn, String checkOut, Integer rooms, Integer persons,
							  String email, Boolean isPaid, String transactionId, String payuTransactionId)
			throws WudstayException {
		Integer discount =0;
		Integer sourceOfBooking=WudstayConstants.SOURCE_OF_BOOKING_DEFAULT;
		return makeBooking( bookingDetailsVO,  name,  mobileNumber,  checkIn,  checkOut,  rooms,  persons, email,
				isPaid,  transactionId,  payuTransactionId,  discount,  sourceOfBooking);
	}*/
	
	
	public String  makeBooking(BookingDetailsVO bookingDetailsVO, String name, String mobileNumber, String checkIn, String checkOut, Integer rooms, Integer persons, String email, Boolean isPaid, String transactionId, String payuTransactionId, Integer discount, Integer sourceOfBooking) throws WudstayException{
		return makeBooking( bookingDetailsVO,  name,  mobileNumber,  checkIn,  checkOut,  rooms,  persons,  email,  isPaid,  transactionId,  payuTransactionId,  discount,  sourceOfBooking, 0);
	}
	
	
	public String makeBooking(BookingDetailsVO bookingDetailsVO, String name, String mobileNumber, String checkIn, String checkOut, Integer rooms, Integer persons,
			String email, Boolean isPaid, String transactionId, String payuTransactionId, Integer discount, Integer sourceOfBooking, Integer subSourceOfBooking)
			throws WudstayException {
		try {
			HotelBooking hotelBooking = new HotelBooking();
			hotelBooking.setBookersName(name);
			hotelBooking.setHotel(hotelDao.getById(bookingDetailsVO.getHotelId()));
			SimpleDateFormat simpleDateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			hotelBooking.setCheckIn(simpleDateFormatter.parse(checkIn));
			hotelBooking.setCheckOut(simpleDateFormatter.parse(checkOut));
			hotelBooking.setIsActive(Boolean.TRUE);
			hotelBooking.setNoOfRooms(rooms);
			hotelBooking.setNoOfPeople(persons);
			hotelBooking.setLastUpdatedDate(new Date());
			hotelBooking.setContactNumber(mobileNumber);
			hotelBooking.setIsPaid(isPaid);
			hotelBooking.setEmail(email);
			hotelBooking.setDisplayBookingId(WudstayUtil.getBookingId());
			hotelBooking.setTotalAmount(bookingDetailsVO.getTotalPrice());
			hotelBooking.setIsCancelled(Boolean.FALSE);
			hotelBooking.setTransactionId(transactionId);
			hotelBooking.setPayuTransactionId(payuTransactionId);
			hotelBooking.setNights(bookingDetailsVO.getNights());
			Calendar cal = Calendar.getInstance();
			String currentDate = simpleDateFormatter.format(cal.getTime()); 
			hotelBooking.setBookingDate(simpleDateFormatter.parse(currentDate));
			hotelBooking.setBookingSource(sourceOfBooking);
			hotelBooking.setBookingSubSource(subSourceOfBooking);
			hotelBooking.setDiscount(discount);
			hotelBookingDao.save(hotelBooking);
			//----------------------------------------------------------------------------------------------------------
			try {
				DiscountCouponInfo discountCouponInfo = bookingDetailsVO.getDiscountCoupon();
				if (discountCouponInfo != null && discountCouponInfo.getDiscount() > 0) {
					CouponCodeUsedVO couponCodeUsedVO = new CouponCodeUsedVO();
					couponCodeUsedVO.setLastUpdatedDate(new Date());
					couponCodeUsedVO.setCouponId(discountCouponInfo.getCouponCodeId());
					couponCodeUsedVO.setCouponUsedDate(hotelBooking.getCheckOut());
					couponCodeUsedVO.setBookingId(hotelBooking.getBookingId());
					couponCodeUsedVO.setDiscountAmt(discountCouponInfo.getDiscount());
					CouponCodeUsedVO obj = couponCodeManager.saveCouponCodeUsed(couponCodeUsedVO);
				}
			}catch (Exception ex){
				ex.printStackTrace();
			}
			//----------------------------------------------------------------------------------------------------------

			return hotelBooking.getDisplayBookingId();
		} catch(Exception e) {
			e.printStackTrace();
			throw new WudstayException(logger, "HotelBookingManagerImpl.makeBooking()", WudstayConstants.MAKE_BOOKING_ERROR, null, e);
		}
	}

	
	public List<HotelBooking> getBookingsBetweenSelectedDates(Long hotelId,
			Date checkIn, Date checkOut) throws WudstayException {
		return hotelBookingDao.getBookingsBetweenSelectedDates(hotelId, checkIn, checkOut);
	}

	//,  transactionId,  payuTransactionId,
	
	public String makeBookingFromMobile(BookingDetailsVO bookingDetailsVO, String name, String mobileNumber, String email, String checkIn,
										String checkOut, Integer rooms, Integer persons, Long hotelId, Integer totalAmount, Integer discount, Boolean isPaid, Integer sourceOfBooking) throws WudstayException {
		return makeBookingFromMobile(bookingDetailsVO, name, mobileNumber, email, checkIn, checkOut,  rooms,  persons,  hotelId,  totalAmount,  discount,  isPaid,  sourceOfBooking, null, null);
	}
	
	public String makeBookingFromMobile(BookingDetailsVO bookingDetailsVO, String name, String mobileNumber, String email, String checkIn,
			String checkOut, Integer rooms, Integer persons, Long hotelId, Integer totalAmount, Integer discount, Boolean isPaid, Integer sourceOfBooking,
			String transactionId, String payuTransactionId) throws WudstayException {
		try {
			HotelBooking hotelBooking = new HotelBooking();
			hotelBooking.setBookersName(name);
			hotelBooking.setHotel(hotelDao.getById(hotelId));
			SimpleDateFormat simpleDateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			/*checkIn = "2015-06-01 12:00:00";
			checkOut = "2015-06-02 11:00:00";*/
			hotelBooking.setCheckIn(simpleDateFormatter.parse(checkIn));
			hotelBooking.setCheckOut(simpleDateFormatter.parse(checkOut));
			hotelBooking.setIsActive(Boolean.TRUE);
			hotelBooking.setNoOfRooms(rooms);
			hotelBooking.setNoOfPeople(persons);
			hotelBooking.setLastUpdatedDate(new Date());
			hotelBooking.setContactNumber(mobileNumber);
			hotelBooking.setIsPaid(isPaid); //hotelBooking.setIsPaid(Boolean.FALSE);

			if(email==null || "".equals(email.trim()))
				hotelBooking.setEmail("bookings.dump@tinggal.com");
			else
				hotelBooking.setEmail(email);

			hotelBooking.setDisplayBookingId(WudstayUtil.getBookingId());
			hotelBooking.setTotalAmount(totalAmount);
			hotelBooking.setIsCancelled(Boolean.FALSE);
			Calendar cal = Calendar.getInstance();
			String currentDate = simpleDateFormatter.format(cal.getTime()); 
			hotelBooking.setBookingDate(simpleDateFormatter.parse(currentDate));
			hotelBooking.setBookingSource(sourceOfBooking);
			hotelBooking.setDiscount(discount);

			if(transactionId!=null)
				hotelBooking.setTransactionId(transactionId);
			if(payuTransactionId!=null)
				hotelBooking.setPayuTransactionId(payuTransactionId);

			hotelBookingDao.save(hotelBooking);
			//----------------------------------------------------------------------------------------------------------
			try {
				if(bookingDetailsVO!=null) {
					DiscountCouponInfo discountCouponInfo = bookingDetailsVO.getDiscountCoupon();
					if (discountCouponInfo != null && discountCouponInfo.getDiscount() > 0) {
						CouponCodeUsedVO couponCodeUsedVO = new CouponCodeUsedVO();
						couponCodeUsedVO.setLastUpdatedDate(new Date());
						couponCodeUsedVO.setCouponId(discountCouponInfo.getCouponCodeId());
						couponCodeUsedVO.setCouponUsedDate(hotelBooking.getCheckOut());
						couponCodeUsedVO.setBookingId(hotelBooking.getBookingId());
						couponCodeUsedVO.setDiscountAmt(discountCouponInfo.getDiscount());
						CouponCodeUsedVO obj = couponCodeManager.saveCouponCodeUsed(couponCodeUsedVO);
					}
				}
			}catch (Exception ex){
				ex.printStackTrace();
			}
			//----------------------------------------------------------------------------------------------------------
			return hotelBooking.getDisplayBookingId();
		} catch(Exception e) {
			throw new WudstayException(logger, "HotelBookingManagerImpl.makeBooking()", WudstayConstants.MAKE_BOOKING_ERROR, null, e);
		}
	}

	
	public List<HotelBooking> getBookingsByContactNumber(String mobileNumber)
			throws WudstayException {
		return hotelBookingDao.getBookingsByContactNumber(mobileNumber);
	}

	
	public List<HotelBooking> getBookingsByHotelId(Long hotelId,
			String contactNumber) throws WudstayException {
		return hotelBookingDao.getBookingsByHotelId(hotelId, contactNumber);
	}
	
	
	
	public List<HotelBooking> getBookingsForCustomerCare(Long bookingId, Long hotelId) throws WudstayException {
		
		return hotelBookingDao.getBookingsForCustomerCare(bookingId, hotelId);

	}

	public Map<Long, RoomAvailabilityDayWise > getRoomAvailabilityDayWise(Long hotelId, Date checkIn, Date checkOut) {
		//return roomsInventoryManager.getRoomAvailabilityDayWise(hotelId, fromDate, toDate);

		Map<Long, RoomAvailabilityDayWise> map = new HashMap<Long, RoomAvailabilityDayWise>();

		Map<Long, RoomAvailabilityDayWise> mapTotalRooms = roomsInventoryManager.getRoomAvailabilityDayWise(hotelId, checkIn, checkOut);
		Map<Long, RoomAvailabilityDayWise> mapBooking = hotelBookingDao.getRoomBookingsDayWise(hotelId, checkIn, checkOut);

		for (Map.Entry<Long, RoomAvailabilityDayWise> entryTotalRooms : mapTotalRooms.entrySet()) {
			//System.out.println(entryTotalRooms.getKey() + "/" + entryTotalRooms.getValue());
			RoomAvailabilityDayWise day = entryTotalRooms.getValue();
			for (Map.Entry<Long, RoomAvailabilityDayWise> entryBooking : mapBooking.entrySet()) {
				//System.out.println(entryBooking.getKey() + "/" + entryBooking.getValue());
				if(entryTotalRooms.getKey().equals( entryBooking.getKey())){
					day.setBookedRooms(entryBooking.getValue().getBookedRooms());
					map.put(entryBooking.getKey(), day);
				}
			}
		}
		return map;


	}

	/*public Map<Long, RoomAvailabilityDayWise > getRoomAvailabilityDayWise(Long hotelId, String fromDate, String toDate){
		return roomsInventoryManager.getRoomAvailabilityDayWise(hotelId, fromDate, toDate);
	}*/
	public Map<Long, RoomAvailabilityDayWise> getRoomBookingsDayWise(Long hotelId, Date checkIn, Date checkOut){
		return  hotelBookingDao.getRoomBookingsDayWise(hotelId, checkIn, checkOut);

		/*Map<Long, RoomAvailabilityDayWise> map = new HashMap<Long, RoomAvailabilityDayWise>();

		Map<Long, RoomAvailabilityDayWise> mapBooking = hotelBookingDao.getRoomBookingsDayWise(hotelId, checkIn, checkOut);
		Map<Long, RoomAvailabilityDayWise> mapTotalRooms = roomsInventoryManager.getRoomAvailabilityDayWise(hotelId, checkIn, checkOut);

		for (Map.Entry<Long, RoomAvailabilityDayWise> entryBooking : mapBooking.entrySet()){
			System.out.println(entryBooking.getKey() + "/" + entryBooking.getValue());
			RoomAvailabilityDayWise day = entryBooking.getValue();
			for (Map.Entry<Long, RoomAvailabilityDayWise> entryTotalRooms : mapTotalRooms.entrySet()){
				System.out.println(entryTotalRooms.getKey() + "/" + entryTotalRooms.getValue());
				if(entryBooking.getKey().equals(entryTotalRooms.getKey())){
					day.setBookedRooms(entryTotalRooms.getValue().getBookedRooms());
					map.put(entryBooking.getKey(), day);
				}
			}
		}

		return map;*/
	}

	
	public boolean isBlackoutDateForPayAtHotel(Date checkIn, Date checkOut, long cityId) {
		return blackoutDateForPayAtHotelDao.isBlackoutOn(checkIn, checkOut, cityId);
	}
	
	public boolean isBlackoutDateForCheckOut(Date checkOut, long cityId) throws ParseException {
		return blackoutDateForCheckOutDao.isBlackoutOn(checkOut, cityId);
	}
	
	
	public List<HotelBooking> getBookingsByTransactionId(String transactionId)
			throws WudstayException {
		return hotelBookingDao.getBookingsByTransactionId(transactionId);
	}

}
