package com.queppelin.wudstay.manager.impl;

import com.queppelin.wudstay.dao.ICorporateBookingDao;
import com.queppelin.wudstay.dao.ICorporateDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.ICorporateBookingManager;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.CorporateBookingVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.List;

@Service
@Transactional
public class CorporateBookingManagerImpl extends BaseManagerImpl<CorporateBookingVO, ICorporateBookingDao> implements ICorporateBookingManager {

	private static final Logger logger = LoggerFactory.getLogger(HotelBookingManagerImpl.class);

	@Autowired
	ICorporateBookingDao corporateBookingDao;
	
	@Autowired
	ICorporateDao corporateDao;
	
	
	public List<CorporateBookingVO> getAllBookings(Long corpId, Long corpLoginUserId) throws WudstayException {
		// TODO Auto-generated method stub
		return corporateBookingDao.getAllBookings(corpId,  corpLoginUserId);
	}

	
	public ICorporateBookingDao getDao() {
		// TODO Auto-generated method stub
		return corporateBookingDao;
	}

	
	public String addCorporateBooking(com.queppelin.wudstay.vo.custom.CorporateBookingVO corporateBookingVO) throws WudstayException {
		// TODO Auto-generated method stub
		try {
			CorporateBookingVO corporateBooking = new CorporateBookingVO();
			corporateBooking.setBookingName(corporateBookingVO.getBookingName());
			//Dummy Values
			SimpleDateFormat simpleDateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			
			corporateBooking.setBookingDate(simpleDateFormatter.parse("2015-01-01 12:01:01"));
			corporateBooking.setCheckIn(simpleDateFormatter.parse("2015-01-01 12:01:01"));
			corporateBooking.setCheckOut(simpleDateFormatter.parse("2015-01-01 12:01:01"));
			//corporateBooking.setCity("test");
			/*Corporate corporate = new Corporate();
			corporate.setCorpId((long) 1);
			corporate.setCorpAddress("sdfasdf");*/
			
			corporateBooking.setCorporate(corporateDao.getById(corporateBookingVO.getCorpId()));
			corporateBookingDao.save(corporateBooking);
			
			
		} catch(Exception e) {
			e.printStackTrace();
			throw new WudstayException(logger, "CorporateBookingManagerImpl.addCorporateBooking()", WudstayConstants.MAKE_BOOKING_ERROR, null, e);
		}	
		return null;
	}

	
	public List<CorporateBookingVO> getCorporateBookingsByCorporateId(Long corpId) throws WudstayException {
		// TODO Auto-generated method stub
		return corporateBookingDao.getCorporateBookingsByCorporateId(corpId);
	}

	
	public List<CorporateBookingVO> getCorporateBookingList() throws WudstayException {
		// TODO Auto-generated method stub
		return corporateBookingDao.getCorporateBookingList();
	}

	
	
	

}
