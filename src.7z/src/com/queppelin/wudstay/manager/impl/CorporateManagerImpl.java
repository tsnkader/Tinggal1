package com.queppelin.wudstay.manager.impl;

import com.queppelin.wudstay.dao.ICorporateDao;
import com.queppelin.wudstay.dao.ICorporateLoginDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.ICorporateManager;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.Corporate;
import com.queppelin.wudstay.vo.CorporateLoginVO;
import com.queppelin.wudstay.vo.custom.CorporateVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

@Service
@Transactional
public class CorporateManagerImpl extends BaseManagerImpl<Corporate, ICorporateDao> implements ICorporateManager {

	private static final Logger logger = LoggerFactory.getLogger(HotelBookingManagerImpl.class);

	@Autowired
	ICorporateDao corporateDao;
	@Autowired
	ICorporateLoginDao corporateLoginDao;
	
	
	public CorporateLoginVO login(CorporateLoginVO corporate) throws WudstayException {
		// TODO Auto-generated method stub
		//return corporateDao.login(corporate);
		return corporateLoginDao.login(corporate);
	}

	
	public Boolean isUsernameExists(String corpUserName) throws WudstayException {
		// TODO Auto-generated method stub
		return corporateDao.isUsernameExists(corpUserName);
	}

	
	public String addCorporate(Corporate corpVO) throws WudstayException {
		// TODO Auto-generated method stub
		try {
			
			/*Corporate corporate = new Corporate();
			corporate.setCorpName(corpVO.getCorpName());
			corporate.setCorpAddress(corpVO.getCorpAddress());
			corporate.setCorpContactPerson(corpVO.getCorpContactPerson());
			corporate.setCorpContactNo(corpVO.getCorpContactNo());
			corporate.setCorpTIN(corpVO.getCorpTIN());
			corporate.setCorpTAN(corpVO.getCorpTAN());
			corporate.setCorpCIN(corpVO.getCorpCIN());
			corporate.setCorpLoginID(corpVO.getCorpLoginID());
			corporate.setCorpLoginPassword(corpVO.getCorpLoginPassword());
			SimpleDateFormat simpleDateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Calendar cal = Calendar.getInstance();
			String currentDate = simpleDateFormatter.format(cal.getTime());
			corporate.setLastUpdatedDate(simpleDateFormatter.parse(currentDate));*/
			corporateDao.save(corpVO);
		} catch(Exception e) {
			throw new WudstayException(logger, "HotelBookingManagerImpl.makeBooking()", WudstayConstants.MAKE_BOOKING_ERROR, null, e);
		}
		return null;
	}



	
	public List<Corporate> getAllCorporates() throws WudstayException {
		// TODO Auto-generated method stub
		return corporateDao.getAllCorporates();
	}

	
	public ICorporateDao getDao() {
		// TODO Auto-generated method stub
		return corporateDao;
	}

	
	 public Corporate getCorporateById(Long corpId) throws WudstayException {
		// TODO Auto-generated method stub
		return corporateDao.getCorporateById(corpId);
	}
	
	public CorporateLoginVO getCorporateLoginById(Long corporateLoginId) throws WudstayException {
		// TODO Auto-generated method stub
		return corporateLoginDao.getById(corporateLoginId);
	}

	
	public CorporateLoginVO saveCorporateLoginVO(CorporateLoginVO vo) throws WudstayException{
		corporateLoginDao.saveOrUpdate(vo);
		return vo;
	}
	
	public Boolean isCorpNameExists(String corpName) throws WudstayException {
		return corporateDao.isCorpNameExists(corpName);
	}
	
	public Boolean isCorpNameExists(Long id, String corpName) throws WudstayException{
		return corporateDao.isCorpNameExists(id, corpName);
	}
	
	public Boolean isCorpLoginIdExists(String corpLoginId) throws WudstayException{
		return corporateLoginDao.isCorpLoginIdExists(corpLoginId);
	}
	public Boolean isCorpLoginIdExists(Long id, String corpLoginId) throws WudstayException{
		return corporateLoginDao.isCorpLoginIdExists(id, corpLoginId);
	}

}
