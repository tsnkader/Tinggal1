
package com.queppelin.wudstay.manager.impl;

import com.queppelin.wudstay.dao.*;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.IHotelManager;
import com.queppelin.wudstay.manager.IPgHotelManager;
import com.queppelin.wudstay.util.DateUtil;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.util.WudstayUtil;
import com.queppelin.wudstay.vo.*;
import com.queppelin.wudstay.vo.custom.HotelDescriptionVO;
import com.queppelin.wudstay.vo.custom.HotelRoomVO;
import com.queppelin.wudstay.vo.custom.HotelVO;
import com.queppelin.wudstay.vo.custom.PgHotelForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Date;
import java.util.List;

@Service
@Transactional
public class PgHotelManagerImpl extends BaseManagerImpl<PgHotel, IPgHotelDao>
implements IPgHotelManager {

	private static final Logger logger = LoggerFactory.getLogger(PgHotelManagerImpl.class);

	@Autowired
	IPgHotelDao pgHotelDao;

	@Autowired
	ICityDao cityDao;

	@Autowired
	ILocationDao locationDao;

	@Autowired
	IRoomTypeDao roomTypeDao;

	@Autowired
	IHotelRoomDao hotelRoomDao;

	@Autowired
	IPgAmenityDao pgAmenityDao;

	@Autowired
	IPgHotelAmenityDao PgHotelAmenityDao;

	@Autowired
	IHotelDescriptionDao hotelDescriptionDao;

	@Autowired
	IPgHotelDescriptionDao pgHotelDescriptionDao;

	@Autowired
	IUserDao userDao;

	@Autowired
	IPgHotelAdministratorDao pgHotelAdministratorDao;

	@Autowired
	IPgTypeDao pgTypeDao;

	@Autowired
	public IPgHotelAmenityDao pgHotelAmenityDao;


	
	public IPgHotelDao getDao() {
		return pgHotelDao;
	}


	public List<PgHotelAmenity> getPgHotelAmenitiesByHotelId(Long hotelId) throws WudstayException{
		return pgHotelAmenityDao.getPgHotelAmenitiesByHotelId(hotelId);
	}
	public List<PgHotelDescription> getPgHotelDescriptionsByHotelId(Long hotelId) throws WudstayException {
		return pgHotelDescriptionDao.getHotelDescriptionsByHotelId(hotelId);
	}


	
	@Transactional
	public Long addHotel(PgHotelForm hotelVO, User user) throws WudstayException {

		try {
			//Saving Hotel
			PgHotel hotel = populatePgHotel(hotelVO, user);
			pgHotelDao.save(hotel);
			saveHotelImages(hotel.getId(), hotelVO.getHotelImages());
			
			//Saving Rooms
			//Inventory saveHotelRooms(hotelVO.getHotelRoomVOList(), hotel, user);
			saveHotelRoomImage(hotel.getId(), hotelVO.getRoomImage());



			//Saving Amenities
			saveAmenities( hotelVO, hotel, user );

			//Saving Hotel Description
			saveHotelDescription(hotelVO.getHotelDescriptionVOList(), hotel, user);

			//Saving User
			User hotelAdmin = populateHotelAdmin(hotelVO, hotel, user, userDao.encryptPassword(hotelVO.getPassword()));
			userDao.save(hotelAdmin);

			//Saving Hotel Admin
			saveHotelAdmin(hotelAdmin, hotel, user);

			return hotel.getId();
		} catch(Exception e) {
			throw new WudstayException(logger, "HotelManagerImpl.addHotel()", WudstayConstants.ADD_HOTEL_ERROR, null, e);
		}
	}
	private PgHotel populatePgHotel(PgHotelForm hotelVO, User user) {
		PgHotel hotel = new PgHotel();
		Location location = locationDao.getById(hotelVO.getLocationId());
		hotel.setName(hotelVO.getHotelName());
		hotel.setDisplayName(hotelVO.getHotelDisplayName());
		hotel.setAddress(hotelVO.getHotelAddress());
		hotel.setHowToReach(hotelVO.getHowToReach());
		hotel.setLocation(location);
		//hotel.setRoomType(roomTypeDao.getById(hotelVO.getRoomTypeId()));
		if(hotelVO.getIsActiveHotel() != null) {
			hotel.setIsActive(Boolean.TRUE);
		} else {
			hotel.setIsActive(Boolean.FALSE);
		}
		//hotel.setPrice(hotelVO.getPrice());
		hotel.setMapLink(hotelVO.getMapLink());
		hotel.setDisplayAddress(hotelVO.getHotelDisplayAddress());
		hotel.setContactPersonName1(hotelVO.getContactPersonName1());
		hotel.setContactPersonName2(hotelVO.getContactPersonName2());
		hotel.setContactPersonNumber1(hotelVO.getContactPersonNumber1());
		hotel.setContactPersonNumber2(hotelVO.getContactPersonNumber2());
		hotel.setContactPersonEmail1(hotelVO.getContactPersonEmail1());
		hotel.setContactPersonEmail2(hotelVO.getContactPersonEmail2());
		hotel.setSingleOccupancyPrice(hotelVO.getSingleOccupancyPrice());
		hotel.setDoubleOccupancyPrice(hotelVO.getDoubleOccupancyPrice());
		hotel.setTripleOccupancyPrice(hotelVO.getTripleOccupancyPrice());
		hotel.setSingleOccupancyWudstayPrice(hotelVO.getSingleOccupancyWudstayPrice());
		hotel.setDoubleOccupancyWudstayPrice(hotelVO.getDoubleOccupancyWudstayPrice());
		hotel.setTripleOccupancyWudstayPrice(hotelVO.getTripleOccupancyWudstayPrice());

		hotel.setLatitude(hotelVO.getLatitude());
		hotel.setLongitude(hotelVO.getLongitude());
		hotel.setLastUpdatedBy(user.getUsername());
		hotel.setLastUpdatedDate(new Date());

		hotel.setSingleOccupancyBeds(hotelVO.getSingleOccupancyBeds());
		hotel.setDoubleOccupancyBeds(hotelVO.getDoubleOccupancyBeds());
		hotel.setTripleOccupancyBeds(hotelVO.getTripleOccupancyBeds());

		hotel.setPgType(pgTypeDao.getById(hotelVO.getPgTypeId()));

		return hotel;
	}
	private void saveHotelImages(Long hotelId, MultipartFile multipartFiles[]) {

		try {
			for (MultipartFile multipartFile : multipartFiles) {
				if(!multipartFile.isEmpty()) {
					byte[] bytes = multipartFile.getBytes();

					String directoryPath = WudstayUtil.getOtherImagesDirPath(hotelId) + "_pg";
					File directory = new File(directoryPath);

					if(!directory.exists()) {
						directory.mkdirs();
					}

					// Create the file on server
					File serverFile = new File(directory.getAbsolutePath() + File.separator + multipartFile.getOriginalFilename());
					BufferedOutputStream stream = new BufferedOutputStream( new FileOutputStream(serverFile));
					stream.write(bytes);
					stream.close();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private void saveHotelRoomImage(Long hotelId, MultipartFile file) {
		if (!file.isEmpty()) {
			try {
				byte[] bytes = file.getBytes();

				String directoryPath = WudstayUtil.getRoomImageDirPath(hotelId)+"_pg";
				File directory = new File(directoryPath);

				if(!directory.exists()) {
					directory.mkdirs();
				}

				// Create the file on server
				File serverFile = new File(directory.getAbsolutePath() + File.separator + "room.png");
				BufferedOutputStream stream = new BufferedOutputStream( new FileOutputStream(serverFile));
				stream.write(bytes);
				stream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}


	private void saveAmenities(PgHotelForm hotelVO, PgHotel hotel, User user) {
		String[] amenities = hotelVO.getAmenities();
		if(amenities != null) {
			PgHotelAmenity hotelAmenity = null;
			for (int i = 0; i < amenities.length; i++) {
				hotelAmenity = new PgHotelAmenity();
				hotelAmenity.setHotel(hotel);
				PgAmenity amenity = pgAmenityDao.getById(Long.valueOf(amenities[i]));
				hotelAmenity.setAmenity(amenity);
				hotelAmenity.setAmenityListingOrder(i + 1);
				hotelAmenity.setIsActive(amenity.getIsActive());
				hotelAmenity.setLastUpdatedBy(user.getUsername());
				hotelAmenity.setLastUpdatedDate(new Date());
				PgHotelAmenityDao.save(hotelAmenity);
			}
		}
	}
	private User populateHotelAdmin(PgHotelForm hotelVO, PgHotel hotel, User user, String encPassword) {
		User hotelAdmin = new User();
		hotelAdmin.setUsername(hotelVO.getUsername());
		hotelAdmin.setUserFullName(hotelVO.getUserFullName());
		hotelAdmin.setPassword(encPassword);
		hotelAdmin.setUserType(WudstayConstants.HOTEL_ADMIN);
		hotelAdmin.setEmail(hotelVO.getEmail());
		hotelAdmin.setPhone(hotelVO.getMobileNumber());
		if(hotelVO.getIsActiveUser() != null) {
			hotelAdmin.setIsActive(Boolean.TRUE);
		} else {
			hotelAdmin.setIsActive(Boolean.FALSE);
		}
		hotelAdmin.setLastUpdatedBy(user.getUsername());
		hotelAdmin.setLastUpdatedDate(new Date());
		return hotelAdmin;
	}



	private void saveHotelAdmin(User hotelAdmin, PgHotel hotel, User user) {
		PgHotelAdministrator hotelAdministrator = new PgHotelAdministrator();
		hotelAdministrator.setUser(hotelAdmin);
		hotelAdministrator.setHotel(hotel);
		hotelAdministrator.setIsActive(hotelAdmin.getIsActive());
		hotelAdministrator.setLastUpdatedBy(user.getUsername());
		hotelAdministrator.setLastUpdatedDate(new Date());
		pgHotelAdministratorDao.save(hotelAdministrator);
	}



	private void saveHotelDescription( List<HotelDescriptionVO> hotelDescriptionList, PgHotel hotel, User user) {
		PgHotelDescription hotelDescription = null;
		for (HotelDescriptionVO hotelDescriptionVO : hotelDescriptionList) {
			if(hotelDescriptionVO.getDescriptionTitle() != null && !hotelDescriptionVO.getDescriptionTitle().equals(WudstayConstants.BLANK)
					  && hotelDescriptionVO.getDescription() != null && !hotelDescriptionVO.getDescription().equals(WudstayConstants.BLANK)) {
				hotelDescription = new PgHotelDescription();
				hotelDescription.setPgHotel(hotel);
				hotelDescription.setDescriptionTitle(hotelDescriptionVO.getDescriptionTitle());
				hotelDescription.setDescription(hotelDescriptionVO.getDescription());
				hotelDescription.setIsActive(Boolean.TRUE);
				hotelDescription.setLastUpdatedBy(user.getUsername());
				hotelDescription.setLastUpdatedDate(new Date());
				pgHotelDescriptionDao.save(hotelDescription);
			}
		}
	}


/*
	private void saveHotelRooms(List<HotelRoomVO> hotelRoomVOList, Hotel hotel, User user) {
		HotelRoom hotelRoom = null;
		for (HotelRoomVO hotelRoomVO : hotelRoomVOList) {
			if(hotelRoomVO.getRoomNo() !=  null && !hotelRoomVO.getRoomNo().equals(WudstayConstants.BLANK)) {
				hotelRoom = new HotelRoom();
				hotelRoom.setHotelRoomId(hotelRoomVO.getHotelRoomId());
				hotelRoom.setHotel(hotel);
				hotelRoom.setRoom(hotelRoomVO.getRoomNo());
				//hotelRoom.setRoomType(roomTypeDao.getById(hotelRoomVO.getRoomTypeId()));
				if(hotelRoomVO.getRoomStatus() == null) {
					hotelRoom.setIsActive(Boolean.FALSE);
				} else {
					hotelRoom.setIsActive(hotelRoomVO.getRoomStatus());
				}
				hotelRoom.setLastUpdatedBy(user.getUsername());
				hotelRoom.setLastUpdatedDate(new Date());
				hotelRoomDao.saveOrUpdate(hotelRoom);


			}
		}

	}
	*/
	
	public List<PgHotel> getHotelByCityId(Long cityId) throws WudstayException{
		return pgHotelDao.getHotelByCityId(cityId);
	}
	public List<PgHotel> getHotelBylocationIds(List<Long> locationIdsList) throws WudstayException{
		return pgHotelDao.getHotelBylocationIds(locationIdsList);
	}


	
	public List<PgHotel> getHotelByCityId(Long cityId, int minPax) throws WudstayException {
		return pgHotelDao.getHotelByCityId(cityId, minPax);
	}

	
	public List<PgHotel> filterHotels(List<Long> locationIdList, Long cityId,
									List<Long> roomTypeIdList, String sortBy, Integer priceSortType, Integer ratingSortType, int minPax)
			throws WudstayException {
		return pgHotelDao.filterHotels(locationIdList, cityId, roomTypeIdList, sortBy, priceSortType, ratingSortType, minPax);
	}
	/*
	public List<PgHotel> filterHotels(List<Long> locationIdList, Long cityId, List<Long> pgTypeIdList,
                                      String sortBy, Integer priceSortType, Integer ratingSortType, int minPax) throws WudstayException;
                                      public List<PgHotel> filterHotels(Long locationId, Long cityId,
									List<Long> roomTypeIdList, String sortBy, Integer priceSortType, Integer ratingSortType, int minPax)
			throws WudstayException {
		return pgHotelDao.filterHotels(locationId, cityId, roomTypeIdList, sortBy, priceSortType, ratingSortType, minPax);
	}
	 */
	
	public List<PgHotel> getSuggestedHotelList(PgHotel hotel) throws WudstayException {
		return pgHotelDao.getSuggestedHotelList(hotel);
	}

}
