
package com.queppelin.wudstay.manager.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.queppelin.wudstay.dao.IRoomTypeDao;
import com.queppelin.wudstay.manager.IRoomTypeManager;
import com.queppelin.wudstay.vo.RoomType;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@Service
@Transactional
public class RoomTypeManagerImpl extends BaseManagerImpl<RoomType, IRoomTypeDao>
		implements IRoomTypeManager {

	private static final Logger logger = LoggerFactory.getLogger(RoomTypeManagerImpl.class);

	@Autowired
	IRoomTypeDao roomTypeDao;

	
	public IRoomTypeDao getDao() {
		return roomTypeDao;
	}

	
	public List<RoomType> list(){
		List<RoomType> lst = super.list();
		Collections.sort(lst, new Comparator<RoomType>() {
			public int compare(RoomType o1, RoomType o2) {
				return o1.getListingOrder().compareTo(o2.getListingOrder());
			}
		});
		return lst;
	}
}
