
package com.queppelin.wudstay.manager.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.queppelin.wudstay.dao.IHotelAdministratorDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.IHotelAdministratorManager;
import com.queppelin.wudstay.vo.HotelAdministrator;

@Service
@Transactional
public class HotelAdministratorManagerImpl extends BaseManagerImpl<HotelAdministrator, IHotelAdministratorDao>
		implements IHotelAdministratorManager {

	private static final Logger logger = LoggerFactory.getLogger(HotelAdministratorManagerImpl.class);

	@Autowired
	IHotelAdministratorDao hotelAdministratorDao;

	
	public IHotelAdministratorDao getDao() {
		return hotelAdministratorDao;
	}

	
	public HotelAdministrator getHotelAdminByHotelId(Long hotelId)
			throws WudstayException {
		return hotelAdministratorDao.getHotelAdminByHotelId(hotelId);
	}
}
