
package com.queppelin.wudstay.manager.impl;

import com.queppelin.wudstay.dao.ICityDao;
import com.queppelin.wudstay.dao.ICouponCodeUsedDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.ICityManager;
import com.queppelin.wudstay.manager.ICouponCodeUsedManager;
import com.queppelin.wudstay.vo.City;
import com.queppelin.wudstay.vo.CouponCodeUsedVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class CouponCodeUsedManagerImpl extends BaseManagerImpl<CouponCodeUsedVO, ICouponCodeUsedDao>
		implements ICouponCodeUsedManager {

	private static final Logger logger = LoggerFactory.getLogger(CouponCodeUsedManagerImpl.class);

	@Autowired
	ICouponCodeUsedDao couponCodeUsedDao;

	
	public ICouponCodeUsedDao getDao() {
		return couponCodeUsedDao;
	}

	
	public List<CouponCodeUsedVO> getByCouponCodeIdAndMobile(Long couponCodeId, String mobileNo) throws WudstayException {
		return couponCodeUsedDao.getByCouponCodeIdAndMobile(couponCodeId, mobileNo);
	}


}
