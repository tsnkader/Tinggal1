
package com.queppelin.wudstay.manager.impl;

import com.queppelin.wudstay.dao.ICouponCodeDao;
import com.queppelin.wudstay.dao.ICouponCodeDao;
import com.queppelin.wudstay.dao.ICouponCodeInCityDao;
import com.queppelin.wudstay.dao.ICouponCodeUsedDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.ICouponCodeManager;
import com.queppelin.wudstay.manager.ICouponCodeUsedManager;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.City;
import com.queppelin.wudstay.vo.CouponCodeInCityVO;
import com.queppelin.wudstay.vo.CouponCodeUsedVO;
import com.queppelin.wudstay.vo.CouponCodeVO;
import com.queppelin.wudstay.vo.custom.DiscountCouponInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
@Transactional
public class CouponCodeManagerImpl extends BaseManagerImpl<CouponCodeVO, ICouponCodeDao> implements ICouponCodeManager {

	private static final Logger logger = LoggerFactory.getLogger(CouponCodeManagerImpl.class);

	@Autowired
	ICouponCodeDao couponCodeDao;
	@Autowired
	ICouponCodeUsedDao couponCodeUsedDao;
	@Autowired
	ICouponCodeInCityDao couponCodeInCityDao;

	
	public ICouponCodeDao getDao() {
		return couponCodeDao;
	}



	public List<CouponCodeInCityVO> getCouponCodeCityByCouponId(Long couponId) throws WudstayException{
		return couponCodeInCityDao.getByCouponId(couponId);
	}

	public CouponCodeInCityVO getCouponCodeCityByCouponAndcityId(Long couponId, Long cityId) throws WudstayException{
		return couponCodeInCityDao.getByCouponAndcityId(couponId, cityId);
	}
	public CouponCodeInCityVO saveCouponCodeCity(CouponCodeInCityVO vo) {
		try {
			couponCodeInCityDao.saveOrUpdate(vo);
		}catch (Exception ex){
			ex.printStackTrace();
		}
		return vo;
	}

	public CouponCodeVO getByCouponCode(String couponCode) throws WudstayException {
		return couponCodeDao.getByCouponCode(couponCode);
	}

	public Date getEndOfDay(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.SECOND, 59);
		calendar.set(Calendar.MILLISECOND, 999);
		return calendar.getTime();
	}

	public Date getStartOfDay(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 1);
		return calendar.getTime();
	}

	public List<CouponCodeUsedVO> getUsedCouponCodesById(Long couponCodeId) throws WudstayException{
		return couponCodeUsedDao.getByCouponCodeId(couponCodeId);
	}

	private boolean isValid_NoOfTimes(CouponCodeVO couponCodeVO) throws WudstayException {
		//Set<CouponCodeUsedVO> set = couponCodeVO.getListOfEmployee();
		List<CouponCodeUsedVO> lst = couponCodeUsedDao.getByCouponCodeId(couponCodeVO.getCouponId());
		int countUsed = 0;
		if(lst==null || lst.size()==0)
			countUsed = 0;
		else
			countUsed = lst.size();
		int countRestUsed = couponCodeVO.getCouponValidTillTimes()-countUsed;
		if(countRestUsed>0) {
			return true;
		}else {
			return false;
		}
	}

	private boolean isValid_TillDate(CouponCodeVO couponCodeVO, Date checkOut){
		//long diff = d2.getTime() - d1.getTime(); //in milliseconds
		Date date = getStartOfDay(couponCodeVO.getCouponValidFromDate());
		Date date2 = new Date();
		if(couponCodeVO.getCouponValidityDateApplyOnCheckout()==1) {
			date2 = checkOut;
		}
		date2 = getStartOfDay(date2);
		if(date.getTime() > date2.getTime()){
			return false;
		}
		date = getEndOfDay(couponCodeVO.getCouponValidTillDate());
		if(date.getTime() < date2.getTime()){
			return false;
		}
		return true;
		/*
		if (oldDate.compareTo(newDate) > 0) {
            System.out.println(df.format(oldDate) + " is greater than " + df.format(newDate));
        }
		Read more: http://javarevisited.blogspot.com/2012/02/3-example-to-compare-two-dates-in-java.html#ixzz3nJvn4WOV
		*/
	}
	public CouponCodeVO checkCouponCodeValidity(City city, String couponCode, Date checkOut) throws WudstayException {
		CouponCodeVO couponCodeVO = couponCodeDao.getByCouponCode(couponCode);
		boolean available=false;

		boolean couponCodeInGivenCity = true;

		if(couponCodeVO != null) {

		try {
			CouponCodeInCityVO couponCodeInCityVO = couponCodeInCityDao.getByCouponAndcityId(couponCodeVO.getCouponId(), city.getCityId());
			couponCodeInGivenCity = (couponCodeInCityVO==null)?false: true;
			if(couponCodeInGivenCity==false) {
				List<CouponCodeInCityVO> lst  = couponCodeInCityDao.getByCouponId (couponCodeVO.getCouponId());
				if(lst.size()==0)
					couponCodeInGivenCity=true;
			}
			if(couponCodeInGivenCity==false){
				return null;
			}
		}catch (Exception ex){
			ex.printStackTrace();
			return null;
		}



			if(couponCodeVO.getCouponValidTillTimes()!=null && couponCodeVO.getCouponValidTillTimes()>0){ //Valid till no of times
				available = isValid_NoOfTimes(couponCodeVO);
				if(available==true && couponCodeVO.getCouponIgnoreValidityDate()==0) { //Validity in Mix mode
					available = isValid_TillDate(couponCodeVO, checkOut);
				}
			}else {
				available = isValid_TillDate(couponCodeVO, checkOut);
			}

			/*if (couponCodeVO.getCouponValidityMode() == 1) {       // 1--> Validity in Mix mode
				if(isValid_TillDate(couponCodeVO)==true){
					return isValid_NoOfTimes(couponCodeVO)==true ? couponCodeVO : null;
				}else{
					return null;
				}
			}else if (couponCodeVO.getCouponValidityMode() == 2) {  // 2--> Valid till no of times Only
				return isValid_NoOfTimes(couponCodeVO)==true ? couponCodeVO : null;
			}else { //if (couponCodeVO.getCouponValidityMode() == 0) { // 0--> Valid till date Only
				return  isValid_TillDate(couponCodeVO)==true ? couponCodeVO : null;
			}*/
			return available==true ? couponCodeVO : null;
		}else {
			return null;
		}
	}

	/*public DiscountCouponInfo calculateCouponCodeDiscount(City city, String couponCode, Integer totalAmount, Date checkOut, int noOfNight)throws WudstayException{
		return calculateCouponCodeDiscount(city, couponCode, totalAmount, checkOut, noOfNight, null, 0);
	}*/

	public DiscountCouponInfo calculateCouponCodeDiscount(City city, String couponCode, Integer totalAmount, Date checkOut, int noOfNight,
														  String mobileNo, int bookingSource) throws WudstayException { //, int noOfNight) throws WudstayException {
		CouponCodeVO couponCodeVO = checkCouponCodeValidity(city, couponCode, checkOut);
		DiscountCouponInfo coupon = new DiscountCouponInfo();

		coupon.setOnlyForOnlinePayment(couponCodeVO.getIsValidForOnlinePaymentOnly().equals(1));

		if(couponCodeVO != null && couponCodeVO.getIsValidForUniqueUser() > 0 && mobileNo!=null && !"".equals(mobileNo.trim())) {
			List<CouponCodeUsedVO> lst = couponCodeUsedDao.getByCouponCodeIdAndMobile(couponCodeVO.getCouponId(), mobileNo);
			if(lst.size()>0){
				couponCodeVO = null;
			}
		}

		int isValidForBookingsource = (couponCodeVO == null || couponCodeVO.getValidForBookingsource() ==null ? 0: couponCodeVO.getValidForBookingsource());
		if(isValidForBookingsource>0 && isValidForBookingsource == WudstayConstants.SOURCE_OF_BOOKING_MOBILE ){
				if(!( bookingSource == WudstayConstants.SOURCE_OF_BOOKING_MOBILE || bookingSource == WudstayConstants.SOURCE_OF_BOOKING_MOBILE_WEB || bookingSource == WudstayConstants.SOURCE_OF_BOOKING_ANDROID || bookingSource == WudstayConstants.SOURCE_OF_BOOKING_WINDOWS || bookingSource == WudstayConstants.SOURCE_OF_BOOKING_IPHONE)) {
					couponCodeVO = null;
				}
		}/*else if(isValidForBookingsource>0 && (isValidForBookingsource == WudstayConstants.SOURCE_OF_BOOKING_MOBILE || isValidForBookingsource == WudstayConstants.SOURCE_OF_BOOKING_MOBILE_WEB || isValidForBookingsource == WudstayConstants.SOURCE_OF_BOOKING_ANDROID || isValidForBookingsource == WudstayConstants.SOURCE_OF_BOOKING_WINDOWS || isValidForBookingsource == WudstayConstants.SOURCE_OF_BOOKING_IPHONE) ){
			if( bookingSource == WudstayConstants.SOURCE_OF_BOOKING_MOBILE || bookingSource == WudstayConstants.SOURCE_OF_BOOKING_MOBILE_WEB || bookingSource == WudstayConstants.SOURCE_OF_BOOKING_ANDROID || bookingSource == WudstayConstants.SOURCE_OF_BOOKING_WINDOWS || bookingSource == WudstayConstants.SOURCE_OF_BOOKING_IPHONE ) {
				// do nothing
			}else{
				couponCodeVO = null;
			}
		}*/else if(isValidForBookingsource>0 && isValidForBookingsource != bookingSource ){
			couponCodeVO = null;
		}

		if(couponCodeVO!=null) {
			coupon.setCouponCodeAndId(couponCodeVO.getCouponCode(), couponCodeVO.getCouponId());
			if (couponCodeVO.getIsDiscountPercentageMode() == 1) {       // 1--> Discount is in Percentage
				coupon.setDiscount((int)((totalAmount*couponCodeVO.getCouponAmtValue())/100));
			} else{ // if (couponCodeVO.getIsDiscountPercentageMode() == 0) { // 2--> Fixed Discount
				coupon.setDiscount(couponCodeVO.getCouponAmtValue());
			}

			int discountUpperLimit = 0;
			if(couponCodeVO.getDiscountUpperLimit() != null)
				discountUpperLimit = couponCodeVO.getDiscountUpperLimit();
			discountUpperLimit = discountUpperLimit * noOfNight;

			if(discountUpperLimit > 0 && discountUpperLimit < coupon.getDiscount() ){
				coupon.setDiscount(discountUpperLimit) ;
			}
			/*if(couponCodeVO.getDiscountUpperLimit()>0 &&
					couponCodeVO.getDiscountUpperLimit() < coupon.getDiscount() ){
				coupon.setDiscount(couponCodeVO.getDiscountUpperLimit()) ;
			}*/
		}else {
			coupon.setDiscount(0);
		}
		return coupon;
	}


	public CouponCodeUsedVO saveCouponCodeUsed(CouponCodeUsedVO obj) {
		try {
			couponCodeUsedDao.saveOrUpdate(obj);
			return obj;
		}catch (Exception ex){
			ex.printStackTrace();
			return null;
		}
	}
}
