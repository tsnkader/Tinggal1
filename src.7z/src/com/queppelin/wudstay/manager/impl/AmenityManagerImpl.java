
package com.queppelin.wudstay.manager.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.queppelin.wudstay.dao.IAmenityDao;
import com.queppelin.wudstay.manager.ICityManager;
import com.queppelin.wudstay.vo.Amenity;
import com.queppelin.wudstay.web.controller.IAmenityManager;

@Service
@Transactional
public class AmenityManagerImpl extends BaseManagerImpl<Amenity, IAmenityDao>
		implements IAmenityManager {

	private static final Logger logger = LoggerFactory.getLogger(AmenityManagerImpl.class);

	@Autowired
	IAmenityDao amenityDao;

	
	public IAmenityDao getDao() {
		return amenityDao;
	}
}
