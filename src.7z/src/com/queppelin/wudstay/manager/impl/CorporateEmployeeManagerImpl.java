package com.queppelin.wudstay.manager.impl;

import com.queppelin.wudstay.dao.ICorporateEmployeeDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.ICorporateEmployeeManager;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.City;
import com.queppelin.wudstay.vo.CorporateEmployeeVO;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class CorporateEmployeeManagerImpl extends BaseManagerImpl<CorporateEmployeeVO, ICorporateEmployeeDao> implements ICorporateEmployeeManager {

	private static final Logger logger = LoggerFactory.getLogger(HotelBookingManagerImpl.class);

	@Autowired
	ICorporateEmployeeDao corporateEmployeeDao;

	
	public ICorporateEmployeeDao getDao() {
		return corporateEmployeeDao;
	}


	public List<CorporateEmployeeVO> getListByCorpBookingId(Long corpBookingId) throws WudstayException {
		return corporateEmployeeDao.getListByCorpBookingId(corpBookingId);
	}
}
