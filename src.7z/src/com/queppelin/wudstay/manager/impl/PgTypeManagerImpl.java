
package com.queppelin.wudstay.manager.impl;

import com.queppelin.wudstay.dao.IPgTypeDao;
import com.queppelin.wudstay.manager.IPgTypeManager;
import com.queppelin.wudstay.vo.PgType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class PgTypeManagerImpl extends BaseManagerImpl<PgType, IPgTypeDao> implements IPgTypeManager {
	private static final Logger logger = LoggerFactory.getLogger(PgTypeManagerImpl.class);

	@Autowired
	IPgTypeDao pgTypeDao;

	
	public IPgTypeDao getDao() {
		return pgTypeDao;
	}
}
