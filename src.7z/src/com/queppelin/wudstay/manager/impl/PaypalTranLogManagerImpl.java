
package com.queppelin.wudstay.manager.impl;

import com.queppelin.wudstay.dao.IPaypalTranLogDao;
import com.queppelin.wudstay.manager.IPaypalTranLogManager;
import com.queppelin.wudstay.vo.PayPalTranLogVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service
@Transactional
public class PaypalTranLogManagerImpl extends BaseManagerImpl<PayPalTranLogVO, IPaypalTranLogDao> implements IPaypalTranLogManager {
	private static final Logger logger = LoggerFactory.getLogger(PaypalTranLogManagerImpl.class);

	@Autowired
	IPaypalTranLogDao  tranLogDao;

	
	public IPaypalTranLogDao getDao() {
		return tranLogDao;
	}

	public PayPalTranLogVO saveLog(PayPalTranLogVO obj) {
		obj.setLogTime(new Date());
		tranLogDao.saveOrUpdate(obj);
		return obj;
	}
	public PayPalTranLogVO getBySecureToken(String secureToken){
		return tranLogDao.getBySecureToken(secureToken);
	}
	public PayPalTranLogVO getBySecureToken(PayPalTranLogVO tranLog){
		String secureToken = tranLog.getSecureToken();
		PayPalTranLogVO tranLogDb = tranLogDao.getBySecureToken(secureToken);

		tranLogDb.setPnref(tranLog.getPnref());
		tranLogDb.setResult(tranLog.getResult());
		tranLogDb.setTransTime(tranLog.getTransTime());
		tranLogDb.setTax(tranLog.getTax());
		tranLogDb.setCountryToShip(tranLog.getCountryToShip());
		tranLogDb.setAvsData(tranLog.getAvsData());
		tranLogDb.setAmt(tranLog.getAmt());
		tranLogDb.setCountry(tranLog.getCountry());
		tranLogDb.setAcct(tranLog.getAcct());
		tranLogDb.setTender(tranLog.getTender());
		tranLogDb.setTrxType(tranLog.getTrxType());
		tranLogDb.setShipToCountry(tranLog.getShipToCountry());
		tranLogDb.setBillTocountry(tranLog.getBillTocountry());
		tranLogDb.setExpDate(tranLog.getExpDate());
		tranLogDb.setFpsPrexmlData(tranLog.getFpsPrexmlData());
		tranLogDb.setRespMsg(tranLog.getRespMsg());
		tranLogDb.setMethod(tranLog.getMethod());
		tranLogDb.setCardType(tranLog.getCardType());
		tranLogDb.setType(tranLog.getType());
		tranLogDb.setPreFpsMsg(tranLog.getPreFpsMsg());
		return tranLogDb;
	}

}

