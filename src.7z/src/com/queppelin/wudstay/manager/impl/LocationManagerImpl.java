
package com.queppelin.wudstay.manager.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.queppelin.wudstay.dao.ILocationDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.ILocationManager;
import com.queppelin.wudstay.vo.Location;

@Service
@Transactional
public class LocationManagerImpl extends BaseManagerImpl<Location, ILocationDao>
		implements ILocationManager {

	private static final Logger logger = LoggerFactory.getLogger(LocationManagerImpl.class);

	@Autowired
	ILocationDao locationDao;

	
	public ILocationDao getDao() {
		return locationDao;
	}

	
	public List<Location> getLocationsByCityId(Long cityId) throws WudstayException {
		return locationDao.getLocationsByCityId(cityId);
	}
}
