
package com.queppelin.wudstay.manager.impl;

import com.queppelin.wudstay.dao.ILogsTableDao;
import com.queppelin.wudstay.dao.IPayuMobTranDao;
import com.queppelin.wudstay.manager.IPayuMobTranManager;
import com.queppelin.wudstay.vo.LogsTable;
import com.queppelin.wudstay.vo.PayuMobTran;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class PayuMobTranManagerImpl extends BaseManagerImpl<PayuMobTran, IPayuMobTranDao>
		implements IPayuMobTranManager {

	private static final Logger logger = LoggerFactory.getLogger(PayuMobTranManagerImpl.class);

	@Autowired
	IPayuMobTranDao payuMobTranDao;

	@Autowired
	ILogsTableDao logsTableDao;

	
	public IPayuMobTranDao getDao() {
		return payuMobTranDao;
	}

	
	public LogsTable saveLogsTable(LogsTable logsTable){
		logsTableDao.saveOrUpdate(logsTable);
		return logsTable;
	}
}
