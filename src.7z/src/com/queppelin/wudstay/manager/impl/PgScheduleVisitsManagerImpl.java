
package com.queppelin.wudstay.manager.impl;

import com.queppelin.wudstay.dao.IPgScheduleVisitsDao;
import com.queppelin.wudstay.manager.IPgScheduleVisitsManager;
import com.queppelin.wudstay.vo.PgScheduleVisits;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class PgScheduleVisitsManagerImpl extends BaseManagerImpl<PgScheduleVisits, IPgScheduleVisitsDao> implements IPgScheduleVisitsManager {
	private static final Logger logger = LoggerFactory.getLogger(PgScheduleVisitsManagerImpl.class);

	@Autowired
	IPgScheduleVisitsDao pgScheduleVisitsDao;

	
	public IPgScheduleVisitsDao getDao() {
		return pgScheduleVisitsDao;
	}
}
