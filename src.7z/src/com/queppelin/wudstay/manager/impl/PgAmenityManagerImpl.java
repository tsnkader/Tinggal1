
package com.queppelin.wudstay.manager.impl;

import com.queppelin.wudstay.dao.IAmenityDao;
import com.queppelin.wudstay.dao.IPgAmenityDao;
import com.queppelin.wudstay.manager.IPgAmenityManager;
import com.queppelin.wudstay.vo.Amenity;
import com.queppelin.wudstay.vo.PgAmenity;
import com.queppelin.wudstay.web.controller.IAmenityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class PgAmenityManagerImpl extends BaseManagerImpl<PgAmenity, IPgAmenityDao> implements IPgAmenityManager {

	private static final Logger logger = LoggerFactory.getLogger(PgAmenityManagerImpl.class);

	@Autowired
	IPgAmenityDao amenityDao;

	
	public IPgAmenityDao getDao() {
		return amenityDao;
	}
}
