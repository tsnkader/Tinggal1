
package com.queppelin.wudstay.manager.impl;

import java.io.Serializable;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.queppelin.wudstay.dao.IBaseDao;
import com.queppelin.wudstay.manager.IBaseManager;

@Service
@Transactional
public abstract class BaseManagerImpl<T, DAO extends IBaseDao<T>> implements IBaseManager<T>{

	public abstract DAO getDao();

	
	public void save(T obj) {
		getDao().save(obj);
	}

	
	public void saveOrUpdate(T obj) {
		getDao().saveOrUpdate(obj);
	}

	
	public T getById(Serializable id) {
		return getDao().getById(id);
	}

	
	public void delete(T obj) {
		getDao().delete(obj);
	}

	
	public List<T> list(String propertyName, String orderType) {
		return getDao().list(propertyName, orderType);
	}

	
	public List<T> list() {
		return getDao().list();
	}

}
