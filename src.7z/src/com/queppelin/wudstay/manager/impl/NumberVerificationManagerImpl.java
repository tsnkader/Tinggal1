
package com.queppelin.wudstay.manager.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.queppelin.wudstay.dao.INumberVerificationDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.INumberVerificationManager;
import com.queppelin.wudstay.vo.NumberVerification;


@Service
@Transactional
public class NumberVerificationManagerImpl extends BaseManagerImpl<NumberVerification, INumberVerificationDao>
		implements INumberVerificationManager {

	private static final Logger logger = LoggerFactory.getLogger(NumberVerificationManagerImpl.class);

	@Autowired
	INumberVerificationDao numberVerificationDao;

	
	public INumberVerificationDao getDao() {
		return numberVerificationDao;
	}

	
	public Boolean verifyMobileNumber(String verificationCode,
			String mobileNumber) throws WudstayException {
		return numberVerificationDao.verifyMobileNumber(verificationCode, mobileNumber);
	}

	
	public Boolean isRegisteredMobileNumber(String mobileNumber)
			throws WudstayException {
		return numberVerificationDao.isRegisteredMobileNumber(mobileNumber);
	}
	
	
	public NumberVerification getCustomerInfoByMobileNumber(String mobileNumber)
			throws WudstayException {
		return numberVerificationDao.getCustomerInfoByMobileNumber(mobileNumber);
	}
}
