
package com.queppelin.wudstay.manager.impl;

import com.queppelin.wudstay.dao.IAppVersionDao;
import com.queppelin.wudstay.dao.ICityDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.IAppVersionManager;
import com.queppelin.wudstay.manager.ICityManager;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.vo.AppVersion;
import com.queppelin.wudstay.vo.City;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class AppVersionManagerImpl extends BaseManagerImpl<AppVersion, IAppVersionDao>
        implements IAppVersionManager {

    private static final Logger logger = LoggerFactory.getLogger(AppVersionManagerImpl.class);

    @Autowired
    IAppVersionDao appVersionDao;

    
    public IAppVersionDao getDao() {
        return appVersionDao;
    }


    
    public List<AppVersion> getAppVersionList(String appType) throws WudstayException {
        return appVersionDao.getAppVersionList(appType);
    }

    public Map<String, Object> newUpdateIsMandatory(String appType, String currentVersion) throws WudstayException {
        Map<String, Object> map = new HashMap<String, Object>();
        try {
            if(appType != null &&
                    (appType.trim().equals(WudstayConstants.MOBILE_APP_TYPE_ANDROID) ||
                            appType.trim().equals(WudstayConstants.MOBILE_APP_TYPE_IPHONE)  ||
                            appType.trim().equals(WudstayConstants.MOBILE_APP_TYPE_WINDOWS) ) ) {
                List<AppVersion> lst = appVersionDao.getAppVersionList(appType);
                boolean foundCurrentVersionFlag = false;
                try{
                    if(lst.size()>0){
                        map.put("LATEST_VERSION", lst.get(lst.size() - 1));
                    }else{
                        map.put("LATEST_VERSION", null);
                    }
                }catch (Exception ex){
                    ex.printStackTrace();
                }

                for (AppVersion appVersion : lst) {
                    if (!foundCurrentVersionFlag && appVersion.getCurrentVersion().equals(currentVersion.trim())) {
                            foundCurrentVersionFlag = true;
                    } else { //if(foundCurrentVersionFlag{
                        if (appVersion.getIsMandatoryUpdate()) {
                            map.put("NEW_UPDATE_IS_MANDATORY", Boolean.TRUE);
                            return map; //Boolean.TRUE;
                        }
                    }
                }
                if (foundCurrentVersionFlag) {
                    map.put("NEW_UPDATE_IS_MANDATORY", Boolean.FALSE);
                    return map; //Boolean.FALSE;
                }else{
                    map.put("NEW_UPDATE_IS_MANDATORY", Boolean.TRUE);
                    return map; //Boolean.TRUE;
                }
            }else{
                throw new IllegalArgumentException("appType should be ANDROID, WINDOWS or IPHONE ");
            }
        } catch (Exception e) {
            throw new WudstayException(logger, "AppVersionDaoImpl.getAppVersionList()", WudstayConstants.FETCH_MOBILE_APP_VERSION_ERROR, null, e);
        }
    }

	/*
    http://stackoverflow.com/questions/6701948/efficient-way-to-compare-version-strings-in-java
	public static int compareVersions(String v1, String v2) {
		String[] components1 = v1.split("\\.");
		String[] components2 = v2.split("\\.");
		int length = Math.min(components1.length, components2.length);
		for(int i = 0; i < length; i++) {
			int result = new Integer(components1[i]).compareTo(Integer.parseInt(components2[i]));
			if(result != 0) {
				return result;
			}
		}
		return Integer.compare(components1.length, components2.length);
	}*/
}
