
package com.queppelin.wudstay.manager.impl;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.queppelin.wudstay.dao.*;
import com.queppelin.wudstay.util.DateUtil;
import com.queppelin.wudstay.util.ImageScalrUtil;
import com.queppelin.wudstay.vo.*;
import com.queppelin.wudstay.vo.custom.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.IHotelManager;
import com.queppelin.wudstay.util.WudstayConstants;
import com.queppelin.wudstay.util.WudstayUtil;

@Service
@Transactional
public class HotelManagerImpl extends BaseManagerImpl<Hotel, IHotelDao>
implements IHotelManager {

	private static final Logger logger = LoggerFactory.getLogger(HotelManagerImpl.class);

	@Autowired
	IHotelDao hotelDao;

	@Autowired
	ISurchargeOnPriceDao surchargeOnPriceDao;

	@Autowired
	IBlackoutDateForPayAtHotelDao blackoutDateForPayAtHotelDao;

	@Autowired
	IBlackoutDateForCheckOutDao blackoutDateForCheckOutDao;

	@Autowired
	ICityDao cityDao;

	@Autowired
	ILocationDao locationDao;

	@Autowired
	IRoomTypeDao roomTypeDao;
	
	@Autowired
	IRoomTypeMasterDao roomTypeMasterDao;

	@Autowired
	IHotelRoomDao hotelRoomDao;

	@Autowired
	IAmenityDao amenityDao;

	@Autowired
	IHotelAmenityDao hotelAmenityDao;

	@Autowired
	IHotelDescriptionDao hotelDescriptionDao;

	@Autowired
	IUserDao userDao;

	@Autowired
	IHotelAdministratorDao hotelAdministratorDao;

	@Override
	public IHotelDao getDao() {
		return hotelDao;
	}



	@Override
	@Transactional
	public Long addHotel(HotelVO hotelVO, User user,HttpServletRequest request, HttpSession session) throws WudstayException {

		try {
			//Saving Hotel
			Hotel hotel = populateHotel(hotelVO, user);
			hotelDao.save(hotel);
			saveHotelImages(hotel.getHotelId(), hotelVO.getHotelImages(), request);
			
			//Saving Rooms
			//Inventory saveHotelRooms(hotelVO.getHotelRoomVOList(), hotel, user);
			saveHotelRoomImage(hotel.getHotelId(), hotelVO.getRoomImage(),request);

			//Saving Amenities
			saveAmenities(hotelVO, hotel, user);

			//Saving Hotel Description
			saveHotelDescription(hotelVO.getHotelDescriptionVOList(), hotel, user);

			//Saving User
			User hotelAdmin = populateHotelAdmin(hotelVO, hotel, user, userDao.encryptPassword(hotelVO.getPassword()));
			userDao.save(hotelAdmin);

			//Saving Hotel Admin
			saveHotelAdmin(hotelAdmin, hotel, user);

			return hotel.getHotelId();
		} catch(Exception e) {
			e.printStackTrace();
			throw new WudstayException(logger, "HotelManagerImpl.addHotel()", WudstayConstants.ADD_HOTEL_ERROR, null, e);
		}
	}
	private void saveSurchargeOnPrice(HotelVO hotelVO, Hotel hotel, User user) {
		List<SurchargeOnPriceVO> lst = new ArrayList<SurchargeOnPriceVO>();
		for(SurchargeOnPrice sur: hotelVO.getSurchargeOnPriceList()){
			lst.add(new SurchargeOnPriceVO());
		}
		Long amenityId=null;
		String[] amenities = hotelVO.getAmenities();
		Boolean isBreakfastIncludedInPrice = hotel.getIsBreakfastIncludedInPrice();
		Amenity freeBreakfastAmenity = amenityDao.getFreeBreakfastAmenity();
		Amenity amenity = null;
		HotelAmenity hotelAmenity = null;
		int i=0;
		if(amenities != null) {
			for (i = 0; i < amenities.length; i++) {
				amenityId = Long.valueOf(amenities[i]);
				if(freeBreakfastAmenity.getAmenityId().equals(amenityId)){
					continue;
				}else{
					amenity = amenityDao.getById(amenityId);
				}
				hotelAmenity = new HotelAmenity(hotel, amenity, i + 1,  user);
				hotelAmenityDao.save(hotelAmenity);
			}
			if(isBreakfastIncludedInPrice==true && freeBreakfastAmenity!=null) {
				hotelAmenity = new HotelAmenity(hotel, freeBreakfastAmenity, i + 1, user);
				hotelAmenityDao.save(hotelAmenity);
			}
		}
	}

	private void saveHotelAdmin(User hotelAdmin, Hotel hotel, User user) {
		HotelAdministrator hotelAdministrator = new HotelAdministrator();
		hotelAdministrator.setUser(hotelAdmin);
		hotelAdministrator.setHotel(hotel);
		hotelAdministrator.setIsActive(hotelAdmin.getIsActive());
		hotelAdministrator.setLastUpdatedBy(user.getUsername());
		hotelAdministrator.setLastUpdatedDate(new Date());
		hotelAdministratorDao.save(hotelAdministrator);
	}

	private User populateHotelAdmin(HotelVO hotelVO, Hotel hotel, User user, String encPassword) {
		User hotelAdmin = new User();
		hotelAdmin.setUsername(hotelVO.getUsername());
		hotelAdmin.setUserFullName(hotelVO.getUserFullName());
		hotelAdmin.setPassword(encPassword);
		hotelAdmin.setUserType(WudstayConstants.HOTEL_ADMIN);
		hotelAdmin.setEmail(hotelVO.getEmail());
		hotelAdmin.setPhone(hotelVO.getMobileNumber());
		if(hotelVO.getIsActiveUser() != null) {
			hotelAdmin.setIsActive(Boolean.TRUE);
		} else {
			hotelAdmin.setIsActive(Boolean.FALSE);
		}
		hotelAdmin.setLastUpdatedBy(user.getUsername());
		hotelAdmin.setLastUpdatedDate(new Date());
		return hotelAdmin;
	}

	private void saveHotelDescription(
			List<HotelDescriptionVO> hotelDescriptionList, Hotel hotel, User user) {
		HotelDescription hotelDescription = null;
		for (HotelDescriptionVO hotelDescriptionVO : hotelDescriptionList) {
			if(hotelDescriptionVO.getDescriptionTitle() != null && !hotelDescriptionVO.getDescriptionTitle().equals(WudstayConstants.BLANK)
					&& hotelDescriptionVO.getDescription() != null && !hotelDescriptionVO.getDescription().equals(WudstayConstants.BLANK)) {
				hotelDescription = new HotelDescription();
				hotelDescription.setHotel(hotel);
				hotelDescription.setDescriptionTitle(hotelDescriptionVO.getDescriptionTitle());
				hotelDescription.setDescription(hotelDescriptionVO.getDescription());
				hotelDescription.setIsActive(Boolean.TRUE);
				hotelDescription.setLastUpdatedBy(user.getUsername());
				hotelDescription.setLastUpdatedDate(new Date());
				hotelDescriptionDao.save(hotelDescription);
			}
		}
	}

	private void saveAmenities(HotelVO hotelVO, Hotel hotel, User user) {
		Long amenityId=null;
		String[] amenities = hotelVO.getAmenities();
		Boolean isBreakfastIncludedInPrice = hotel.getIsBreakfastIncludedInPrice();
		Amenity freeBreakfastAmenity = amenityDao.getFreeBreakfastAmenity();
		Amenity amenity = null;
		HotelAmenity hotelAmenity = null;
		int i=0;
		if(amenities != null) {
			for (i = 0; i < amenities.length; i++) {
				amenityId = Long.valueOf(amenities[i]);
				if(freeBreakfastAmenity.getAmenityId().equals(amenityId)){
					continue;
				}else{
					amenity = amenityDao.getById(amenityId);
				}
				hotelAmenity = new HotelAmenity(hotel, amenity, i + 1,  user);
				hotelAmenityDao.save(hotelAmenity);
			}
			if(isBreakfastIncludedInPrice==true && freeBreakfastAmenity!=null) {
				hotelAmenity = new HotelAmenity(hotel, freeBreakfastAmenity, i + 1, user);
				hotelAmenityDao.save(hotelAmenity);
			}
		}
	}

	private void saveHotelRooms(List<HotelRoomVO> hotelRoomVOList, Hotel hotel, User user) {
		HotelRoom hotelRoom = null;
		for (HotelRoomVO hotelRoomVO : hotelRoomVOList) {
			if(hotelRoomVO.getRoomNo() !=  null && !hotelRoomVO.getRoomNo().equals(WudstayConstants.BLANK)) {
				hotelRoom = new HotelRoom();
				hotelRoom.setHotelRoomId(hotelRoomVO.getHotelRoomId());
				hotelRoom.setHotel(hotel);
				hotelRoom.setRoom(hotelRoomVO.getRoomNo());
				//hotelRoom.setRoomType(roomTypeDao.getById(hotelRoomVO.getRoomTypeId()));
				if(hotelRoomVO.getRoomStatus() == null) {
					hotelRoom.setIsActive(Boolean.FALSE);
				} else {
					hotelRoom.setIsActive(hotelRoomVO.getRoomStatus());
				}
				hotelRoom.setLastUpdatedBy(user.getUsername());
				hotelRoom.setLastUpdatedDate(new Date());
				hotelRoomDao.saveOrUpdate(hotelRoom);

				/*if(hotelRoomVO.getRoomImage() != null) {
					saveHotelRoomImage(hotel.getHotelId(), hotelRoom.getHotelRoomId(), hotelRoomVO.getRoomImage());
				}*/
			}
		}

	}

	private void saveHotelRoomImage(Long hotelId, MultipartFile file,HttpServletRequest request) {
		String roomsFilePath="";
		if (!file.isEmpty()) {
			try {
				byte[] bytes = file.getBytes();
				String directoryPath =  request.getRealPath("/")+"hotel_images/"+hotelId+"/rooms/";
				//String directoryPath = WudstayUtil.getRoomImageDirPath(hotelId);
				File directory = new File(directoryPath);

				if(!directory.exists()) {
					directory.mkdirs();
				}

				// Create the file on server
				roomsFilePath = directory.getAbsolutePath() + File.separator + "room.png";
				File serverFile = new File(roomsFilePath);
				BufferedOutputStream stream = new BufferedOutputStream( new FileOutputStream(serverFile));
				stream.write(bytes);
				stream.close();
				ImageScalrUtil.reScaleImages(roomsFilePath);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void saveHotelImages(Long hotelId, MultipartFile multipartFiles[],HttpServletRequest request) {

		try {
			for (MultipartFile multipartFile : multipartFiles) {
				if(!multipartFile.isEmpty()) {
					byte[] bytes = multipartFile.getBytes();
					String directoryPath =  request.getRealPath("/")+"hotel_images/"+hotelId+"/others/";
					//String directoryPath = WudstayUtil.getOtherImagesDirPath(hotelId);
					File directory = new File(directoryPath);

					if(!directory.exists()) {
						directory.mkdirs();
					}

					// Create the file on server
					File serverFile = new File(directory.getAbsolutePath() + File.separator + multipartFile.getOriginalFilename());

					BufferedOutputStream stream = new BufferedOutputStream( new FileOutputStream(serverFile));
					stream.write(bytes);
					stream.close();
				}
			}
			ImageScalrUtil.reScaleAllImagesOfHotel(hotelId,request);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private Hotel populateHotel(HotelVO hotelVO, User user) {
		Hotel hotel = new Hotel();
		Location location = locationDao.getById(hotelVO.getLocationId());
		hotel.setHotelName(hotelVO.getHotelName());
		hotel.setHotelDisplayName(hotelVO.getHotelDisplayName());
		hotel.setHotelAddress(hotelVO.getHotelAddress());
		hotel.setHowToReach(hotelVO.getHowToReach());
		hotel.setLocation(location);
		hotel.setRoomType(roomTypeDao.getById(hotelVO.getRoomTypeId()));
		hotel.setRoomTypeMaster(roomTypeMasterDao.getById(hotelVO.getRoomTypeMasterId()));
		hotel.setStarRating(hotelVO.getStarRating());
		if(hotelVO.getIsActiveHotel() != null) {
			hotel.setIsActive(Boolean.TRUE);
		} else {
			hotel.setIsActive(Boolean.FALSE);
		}
		//hotel.setPrice(hotelVO.getPrice());
		hotel.setMapLink(hotelVO.getMapLink());
		hotel.setHotelDisplayAddress(hotelVO.getHotelDisplayAddress());
		hotel.setContactPersonName1(hotelVO.getContactPersonName1());
		hotel.setContactPersonName2(hotelVO.getContactPersonName2());
		hotel.setContactPersonNumber1(hotelVO.getContactPersonNumber1());
		hotel.setContactPersonNumber2(hotelVO.getContactPersonNumber2());
		hotel.setContactPersonEmail1(hotelVO.getContactPersonEmail1());
		hotel.setContactPersonEmail2(hotelVO.getContactPersonEmail2());
		hotel.setSingleOccupancyPrice(hotelVO.getSingleOccupancyPrice());
		hotel.setDoubleOccupancyPrice(hotelVO.getDoubleOccupancyPrice());
		hotel.setTripleOccupancyPrice(hotelVO.getTripleOccupancyPrice());
		hotel.setSingleOccupancyContractualPrice(hotelVO.getSingleOccupancyContractualPrice());
		hotel.setDoubleOccupancyContractualPrice(hotelVO.getDoubleOccupancyContractualPrice());
		hotel.setTripleOccupancyContractualPrice(hotelVO.getTripleOccupancyContractualPrice());
		hotel.setMaxBookingPerMobNum(hotelVO.getMaxBookingPerMobNum());
		hotel.setLatitude(hotelVO.getLatitude());
		hotel.setLongitude(hotelVO.getLongitude());
		hotel.setLastUpdatedBy(user.getUsername());
		hotel.setLastUpdatedDate(new Date());
		hotel.setNoOfRooms(hotelVO.getNoOfRooms());
		hotel.setAllowTripleOccupancy(hotelVO.getAllowTripleOccupancy());
		try {
			DateUtil dateUtil = new DateUtil(new Date());
			if (hotelVO.getValidFromDate() == null || "".equals(hotelVO.getValidFromDate().trim())) {
				hotelVO.setValidFromDate(DateUtil.toDisplayDate(dateUtil.toDate()));
			}
			if (hotelVO.getValidToDate() == null || "".equals(hotelVO.getValidToDate().trim())) {
				DateUtil dateUtil2 = new DateUtil(dateUtil.getDay(), dateUtil.getMonth(), dateUtil.getYear() + 1);
				hotelVO.setValidToDate(DateUtil.toDisplayDate(dateUtil2.toDate()));
			}
			hotel.setValidFromDate(DateUtil.toDisplayDate(hotelVO.getValidFromDate()));
			hotel.setValidToDate(DateUtil.toDisplayDate(hotelVO.getValidToDate()));
		}catch (Exception ex){
			ex.printStackTrace();
		}
		hotel.setIsBreakfastIncludedInPrice(hotelVO.getBreakfastIncludedInPrice()>0);
		return hotel;
	}
	private void saveRoomsInventory(Hotel hotel){

	}

	@Override
	public Hotel updateHotel(HotelVO hotelVO, User user,HttpServletRequest request,HttpSession session) throws WudstayException {
		try {
			//Saving Hotel
			Long hotelId = hotelVO.getHotelId();
			Hotel hotel = populateHotel(hotelVO, user);
			hotel.setHotelId(hotelId);
			hotelDao.saveOrUpdate(hotel);


			saveHotelImages(hotelId, hotelVO.getHotelImages(),request);

			//Delete Rooms
			//deleteHotelRooms(hotelId);

			//Saving Rooms
			//saveHotelRooms(hotelVO.getRoomTypeVOList(), hotel, user);
			//saveHotelRooms(hotelVO.getHotelRoomVOList(), hotel, user);
			saveHotelRooms(hotelVO.getHotelRoomVOList(), hotel, user);
			saveHotelRoomImage(hotel.getHotelId(), hotelVO.getRoomImage(), request);

			//Delete Hotel amenities
			deleteHotelAmenities(hotelId);

			//Saving Amenities
			saveAmenities(hotelVO, hotel, user);

			//Delete Hotel Description
			deleteHotelDescriptions(hotelId);

			//Saving Hotel Description
			saveHotelDescription(hotelVO.getHotelDescriptionVOList(), hotel, user);

			//Saving User
			User hotelAdmin = populateHotelAdmin(hotelVO, hotel, user, userDao.encryptPassword(hotelVO.getPassword()));
			hotelAdmin.setUserId(hotelVO.getUserId());
			userDao.saveOrUpdate(hotelAdmin);
			return hotel;

			//Saving Hotel Admin
			//saveHotelAdmin(hotelAdmin, hotel, user);
		} catch(Exception e) {
			e.printStackTrace();
			throw new WudstayException(logger, "HotelManagerImpl.addHotel()", WudstayConstants.ADD_HOTEL_ERROR, null, e);
		}
	}

	private void deleteHotelDescriptions(Long hotelId) throws WudstayException {
		hotelDescriptionDao.deleteHotelDescriptionsByHotelId(hotelId);

	}

	private void deleteHotelAmenities(Long hotelId) throws WudstayException {
		hotelAmenityDao.deleteHotelAmenitiesByHotelId(hotelId);

	}

	@Override
	public List<Hotel> getHotelByCityId(Long cityId) throws WudstayException{
		return hotelDao.getHotelByCityId(cityId);
	}

	@Override
	public List<Hotel> getHotelByCityId(Long cityId, int minPax) throws WudstayException {
		return hotelDao.getHotelByCityId(cityId, minPax);
	}

	@Override
	public List<Hotel> filterHotels(Long locationId, Long cityId,
			List<Long> roomTypeIdList, String sortBy, Integer priceSortType, Integer ratingSortType, int minPax)
			throws WudstayException {
		return hotelDao.filterHotels(locationId, cityId, roomTypeIdList, sortBy, priceSortType, ratingSortType, minPax);
	}

	@Override
	public List<Hotel> getSuggestedHotelList(Hotel hotel)
			throws WudstayException {
		return hotelDao.getSuggestedHotelList(hotel);
	}

	/*private void deleteHotelRooms(Long hotelId) throws WudstayException {
		hotelRoomDao.deleteHotelRoomsByHotelId(hotelId);
	}*/

	@Override
	public boolean isBlackoutDateForPayAtHotel(Date checkIn, Date checkOut, long cityId) {
		return blackoutDateForPayAtHotelDao.isBlackoutOn(checkIn, checkOut, cityId);
	}
	@Override
	public boolean isBlackoutDateForCheckOut( Date checkOut, long cityId) throws ParseException {
		return blackoutDateForCheckOutDao.isBlackoutOn(checkOut, cityId);
	}

	@Override
	public List<HotelDetailDto> getHotelsDetailWithAmenity(long cityId, int sortOn, String hotelOrPg,HttpServletRequest request)  throws WudstayException{
		List<HotelDetailDto> list = new ArrayList<HotelDetailDto>();
		boolean hotelIsPg = (hotelOrPg!=null && !"".equals(hotelOrPg.trim()) && !"HOTEL".equalsIgnoreCase(hotelOrPg.trim()));
		try {
			String spName = hotelIsPg ? "callSpPgDetailByCity" : "callSpHotelDetailByCity";
			List<HotelDetailMVO> hotelList = (List<HotelDetailMVO> )(hotelDao.getNamedQuery(spName, new String[]{"v_city_id", "v_sort_on"},  new Object[]{cityId, sortOn}).list());

			spName = hotelIsPg ? "callSpPgAmenities" : "callSpHotelAmenities";
			for(HotelDetailMVO hotel: hotelList){
				List<HotelAmenityMVO> hotelAmenity = (List<HotelAmenityMVO> )(hotelDao.getNamedQuery(spName, new String[]{"v_hotelid"},  new Object[]{hotel.getHotelId()}).list());
				HotelDetailDto dto = new HotelDetailDto(hotel,request);
				dto.setHotelAmenities(hotelAmenity);
				list.add(dto);
			}
			return list;
		}catch (Exception ex){
			ex.printStackTrace();
			throw new WudstayException(logger, "HotelManagerImpl.getHotelDetail()", "Error to fetching data: " + ex.getMessage(), null, ex);
		}
	}
	@Override
	public  HotelDetailDto  getHotelDetailWithAmenity(long v_hotelid, String hotelOrPg,HttpServletRequest request)  throws WudstayException{
		boolean hotelIsPg = (hotelOrPg!=null && !"".equals(hotelOrPg.trim()) && !"HOTEL".equalsIgnoreCase(hotelOrPg.trim()));
		List<HotelDetailDto> list = new ArrayList<HotelDetailDto>();
		try {
			String spName = hotelIsPg ? "callSpPgDetail" : "callSpHotelDetail";
			List<HotelDetailMVO> hotelList = (List<HotelDetailMVO> )(hotelDao.getNamedQuery(spName, new String[]{"v_hotelid"},  new Object[]{v_hotelid}).list());

			spName = hotelIsPg ? "callSpPgAmenities" : "callSpHotelAmenities";
			for(HotelDetailMVO hotel: hotelList){
				List<HotelAmenityMVO> hotelAmenity = (List<HotelAmenityMVO> )(hotelDao.getNamedQuery(spName, new String[]{"v_hotelid"},  new Object[]{hotel.getHotelId()}).list());
				HotelDetailDto dto = new HotelDetailDto(hotel,request);
				dto.setHotelAmenities(hotelAmenity);
				list.add(dto);
			}
			if(list==null || list.size()==0)
				return null;
			return list.get(0);
		}catch (Exception ex){
			ex.printStackTrace();
			throw new WudstayException(logger, "HotelManagerImpl.getHotelDetail()", "Error to fetching data: " + ex.getMessage(), null, ex);
		}
	}
}
