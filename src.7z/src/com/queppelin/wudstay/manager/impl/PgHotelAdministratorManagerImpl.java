
package com.queppelin.wudstay.manager.impl;


import com.queppelin.wudstay.dao.IPgHotelAdministratorDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.IPgHotelAdministratorManager;
import com.queppelin.wudstay.vo.PgHotelAdministrator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class PgHotelAdministratorManagerImpl extends BaseManagerImpl<PgHotelAdministrator, IPgHotelAdministratorDao>
		implements IPgHotelAdministratorManager {

	private static final Logger logger = LoggerFactory.getLogger(PgHotelAdministratorManagerImpl.class);

	@Autowired
	IPgHotelAdministratorDao hotelAdministratorDao;

	
	public IPgHotelAdministratorDao getDao() {
		return hotelAdministratorDao;
	}


	
	public PgHotelAdministrator getPgHotelAdminByHotelId(Long hotelId) throws WudstayException {
		return hotelAdministratorDao.getHotelAdminByHotelId(hotelId);
	}
}
