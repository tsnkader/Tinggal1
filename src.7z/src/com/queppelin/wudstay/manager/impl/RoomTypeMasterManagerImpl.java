
package com.queppelin.wudstay.manager.impl;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.queppelin.wudstay.dao.IRoomTypeMasterDao;
import com.queppelin.wudstay.manager.IRoomTypeMasterManager;
import com.queppelin.wudstay.vo.RoomTypeMaster;

@Service
@Transactional
public class RoomTypeMasterManagerImpl extends BaseManagerImpl<RoomTypeMaster, IRoomTypeMasterDao>
		implements IRoomTypeMasterManager {

	private static final Logger logger = LoggerFactory.getLogger(RoomTypeMasterManagerImpl.class);

	@Autowired
	IRoomTypeMasterDao roomTypeMasterDao;

	
	public IRoomTypeMasterDao getDao() {
		return roomTypeMasterDao;
	}

	
	public List<RoomTypeMaster> list(){
		List<RoomTypeMaster> lst = super.list();
		Collections.sort(lst, new Comparator<RoomTypeMaster>() {
			public int compare(RoomTypeMaster o1, RoomTypeMaster o2) {
				return o1.getRoomTypeId().compareTo(o2.getRoomTypeId());
			}
		});
		return lst;
	}
}
