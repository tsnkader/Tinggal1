
package com.queppelin.wudstay.manager.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.queppelin.wudstay.dao.IHotelRoomDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.IHotelRoomManager;
import com.queppelin.wudstay.vo.HotelRoom;

@Service
@Transactional
public class HotelRoomManagerImpl extends BaseManagerImpl<HotelRoom, IHotelRoomDao>
		implements IHotelRoomManager {

	private static final Logger logger = LoggerFactory.getLogger(HotelRoomManagerImpl.class);

	@Autowired
	IHotelRoomDao hotelRoomDao;

	
	public IHotelRoomDao getDao() {
		return hotelRoomDao;
	}

	
	public List<HotelRoom> getHotelRoomsByHotelId(Long hotelId)
			throws WudstayException {
		return hotelRoomDao.getHotelRoomsByHotelId(hotelId);
	}
}
