
package com.queppelin.wudstay.manager.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.queppelin.wudstay.dao.IUserDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.IUserManager;
import com.queppelin.wudstay.vo.User;

@Service
@Transactional
public class UserManagerImpl extends BaseManagerImpl<User, IUserDao>
		implements IUserManager {

	private static final Logger logger = LoggerFactory.getLogger(UserManagerImpl.class);

	@Autowired
	IUserDao userDao;

	
	public IUserDao getDao() {
		return userDao;
	}

	
	public User login(User user, String userType) throws WudstayException {
		return userDao.login(user, userType);
	}

	
	public Boolean isUsernameExists(String username) throws WudstayException {
		return userDao.isUsernameExists(username);
	}
}
