
package com.queppelin.wudstay.manager.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.queppelin.wudstay.dao.IHotelRoomBookingDao;
import com.queppelin.wudstay.manager.IHotelRoomBookingManager;
import com.queppelin.wudstay.vo.HotelRoomBooking;

@Service
@Transactional
public class HotelRoomBookingManagerImpl extends BaseManagerImpl<HotelRoomBooking, IHotelRoomBookingDao>
		implements IHotelRoomBookingManager {

	private static final Logger logger = LoggerFactory.getLogger(HotelRoomBookingManagerImpl.class);

	@Autowired
	IHotelRoomBookingDao hotelRoomBookingDao;

	
	public IHotelRoomBookingDao getDao() {
		return hotelRoomBookingDao;
	}
}
