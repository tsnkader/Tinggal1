package com.queppelin.wudstay.manager;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.Corporate;
import com.queppelin.wudstay.vo.CorporateLoginVO;
import com.queppelin.wudstay.vo.Hotel;
import com.queppelin.wudstay.vo.RoomsInventoryVO;
import com.queppelin.wudstay.vo.custom.RoomAvailabilityDayWise;
import com.queppelin.wudstay.vo.custom.RoomsInventoryForm;

import java.util.Date;
import java.util.List;
import java.util.Map;

public interface IRoomsInventoryManager extends IBaseManager<RoomsInventoryVO> {
    public List<RoomsInventoryVO> getListByHotelId(Long hotelId);

    public RoomsInventoryVO getListByDate(Long hotelId, String date) throws WudstayException;
    public List<RoomsInventoryVO> getListByDate(Long hotelId, String fromDate, String toDate) throws WudstayException;

    public RoomsInventoryVO getListByDate(Long hotelId, Date date) throws WudstayException;
    public List<RoomsInventoryVO> getListByDate(Long hotelId, Date fromDate, Date toDate) throws WudstayException;

    public Integer getMinRoomAvailable(Long hotelId, Date fromDate, Date toDate) throws WudstayException;
    public Integer getMinRoomAvailable(Long hotelId, String fromDate, String toDate) throws WudstayException;

    public Map<Long, RoomAvailabilityDayWise > getRoomAvailabilityDayWise(Long hotelId, Date fromDate, Date toDate);
    public Map<Long, RoomAvailabilityDayWise > getRoomAvailabilityDayWise(Long hotelId, String fromDate, String toDate);

    public RoomsInventoryForm getRoomAvailabilityCalendar(Hotel hotel, int month, int year);

    public void updateInventory(Long hotelId, int noOfRooms, Date date);

    public void updateInventory(Long hotelId, int noOfRooms, Date fromDate, Date toDate);

}
