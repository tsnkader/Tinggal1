package com.queppelin.wudstay.manager;

import com.queppelin.wudstay.vo.RoomType;

import java.util.List;

public interface IRoomTypeManager extends IBaseManager<RoomType> {
    
    List<RoomType> list();
}
