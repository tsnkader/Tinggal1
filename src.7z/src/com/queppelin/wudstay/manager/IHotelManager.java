
package com.queppelin.wudstay.manager;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.Hotel;
import com.queppelin.wudstay.vo.HotelDetailMVO;
import com.queppelin.wudstay.vo.User;
import com.queppelin.wudstay.vo.custom.HotelDetailDto;
import com.queppelin.wudstay.vo.custom.HotelVO;

public interface IHotelManager extends IBaseManager<Hotel> {

	Long addHotel(HotelVO hotelVO, User user,HttpServletRequest request, HttpSession session) throws WudstayException;

	Hotel updateHotel(HotelVO hotelVO, User user,HttpServletRequest request,HttpSession session) throws WudstayException;

	public List<Hotel> getHotelByCityId(Long cityId) throws WudstayException;

	List<Hotel> getHotelByCityId(
			Long cityId, int minPax) throws WudstayException;

	List<Hotel> filterHotels(Long locationId, Long cityId,
							 List<Long> roomTypeIdList, String sortBy, Integer priceSortType, Integer ratingSortType, int minPax) throws WudstayException;

	List<Hotel> getSuggestedHotelList(Hotel hotel) throws WudstayException;

	public boolean isBlackoutDateForPayAtHotel(Date checkIn, Date checkOut, long cityId);
	public boolean isBlackoutDateForCheckOut(Date checkOut, long cityId) throws ParseException;

	public List<HotelDetailDto> getHotelsDetailWithAmenity(long cityId, int sortOn, String hotelOrPg,HttpServletRequest request)  throws WudstayException;

	public  HotelDetailDto  getHotelDetailWithAmenity(long v_hotelid, String hotelOrPg,HttpServletRequest request)  throws WudstayException;

}
