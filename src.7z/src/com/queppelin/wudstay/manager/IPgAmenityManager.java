package com.queppelin.wudstay.manager;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.HotelAmenity;
import com.queppelin.wudstay.vo.PgAmenity;

import java.util.List;

public interface IPgAmenityManager extends IBaseManager<PgAmenity> {

	//List<PgAmenity> getHotelAmenitiesByHotelId(Long hotelId) throws WudstayException;

}
