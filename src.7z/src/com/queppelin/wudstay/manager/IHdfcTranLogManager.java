package com.queppelin.wudstay.manager;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.*;
import com.queppelin.wudstay.vo.custom.DiscountCouponInfo;

import java.util.Date;
import java.util.List;

public interface IHdfcTranLogManager extends IBaseManager<HdfcTranLogVO> {
    public HdfcTranLogVO saveLog(HdfcTranLogVO obj);
    public HdfcTranResponseVO saveResponse(HdfcTranResponseVO obj);
    public HdfcTranLogVO getBySecureHash(String secureHash);

}
