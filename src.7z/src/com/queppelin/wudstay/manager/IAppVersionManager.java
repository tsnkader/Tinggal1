package com.queppelin.wudstay.manager;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.AppVersion;
import com.queppelin.wudstay.vo.City;

import java.util.List;
import java.util.Map;

public interface IAppVersionManager extends IBaseManager<AppVersion> {

	public List<AppVersion> getAppVersionList(String appType) throws WudstayException;
	public Map<String, Object> newUpdateIsMandatory(String appType, String currentVersion) throws WudstayException;

}
