package com.queppelin.wudstay.manager;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.City;
import com.queppelin.wudstay.vo.CouponCodeInCityVO;
import com.queppelin.wudstay.vo.CouponCodeUsedVO;
import com.queppelin.wudstay.vo.CouponCodeVO;
import com.queppelin.wudstay.vo.custom.DiscountCouponInfo;

import java.util.Date;
import java.util.List;

public interface ICouponCodeManager extends IBaseManager<CouponCodeVO> {
    public CouponCodeVO getByCouponCode(String couponCode) throws WudstayException;
    public List<CouponCodeUsedVO> getUsedCouponCodesById(Long couponCodeId) throws WudstayException;
    public CouponCodeVO checkCouponCodeValidity(City city, String couponCode, Date checkOut) throws WudstayException;
    // public DiscountCouponInfo calculateCouponCodeDiscount(City city, String couponCode, Integer totalAmount, Date checkOut, int noOfNight)throws WudstayException;
    public DiscountCouponInfo calculateCouponCodeDiscount(City city, String couponCode, Integer totalAmount, Date checkOut, int noOfNight,
                                                          String mobileNo, int bookingSource) throws WudstayException;
    public CouponCodeUsedVO saveCouponCodeUsed(CouponCodeUsedVO obj);

    public List<CouponCodeInCityVO> getCouponCodeCityByCouponId(Long couponId) throws WudstayException;
    public CouponCodeInCityVO getCouponCodeCityByCouponAndcityId(Long couponId, Long cityId) throws WudstayException;
    public CouponCodeInCityVO saveCouponCodeCity(CouponCodeInCityVO vo);


}
