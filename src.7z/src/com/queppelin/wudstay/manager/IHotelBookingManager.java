package com.queppelin.wudstay.manager;

import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.HotelBooking;
import com.queppelin.wudstay.vo.custom.BookingDetailsVO;
import com.queppelin.wudstay.vo.custom.RoomAvailabilityDayWise;

public interface IHotelBookingManager extends IBaseManager<HotelBooking> {

	List<HotelBooking> getBookingsByHotelId(Long hotelId) throws WudstayException;
	
	List<HotelBooking> getBookingsByHotelId(Long hotelId, String contactNumber) throws WudstayException;

	//String makeBooking(BookingDetailsVO bookingDetailsVO, String name, String mobileNumber, String checkIn, String checkOut, Integer rooms, Integer persons, String email, Boolean isPaid, String transactionId, String payuTransactionId) throws WudstayException;

	String makeBooking(BookingDetailsVO bookingDetailsVO, String name, String mobileNumber, String checkIn, String checkOut, Integer rooms, Integer persons, String email, Boolean isPaid, String transactionId, String payuTransactionId, Integer discount, Integer sourceOfBooking) throws WudstayException;
	String makeBooking(BookingDetailsVO bookingDetailsVO, String name, String mobileNumber, String checkIn, String checkOut, Integer rooms, Integer persons, String email, Boolean isPaid, String transactionId, String payuTransactionId, Integer discount, Integer sourceOfBooking, Integer subSourceOfBooking) throws WudstayException;

	List<HotelBooking> getBookingsBetweenSelectedDates(Long hotelId,
													   Date checkIn, Date checkOut) throws WudstayException;

	List<HotelBooking> getBookingsByContactNumber(String mobileNumber) throws WudstayException;

	String makeBookingFromMobile(BookingDetailsVO bookingDetailsVO, String name, String mobileNumber, String email,
								 String formattedCheckInDate, String formattedCheckOutDate,
								 Integer rooms, Integer persons, Long hotelId, Integer totalAmount, Integer discount, Boolean isPaid, Integer sourceOfBooking) throws WudstayException;

	String makeBookingFromMobile(BookingDetailsVO bookingDetailsVO, String name, String mobileNumber, String email,
								 String formattedCheckInDate, String formattedCheckOutDate,
								 Integer rooms, Integer persons, Long hotelId, Integer totalAmount, Integer discount, Boolean isPaid, Integer sourceOfBooking,
								 String transactionId, String payuTransactionId) throws WudstayException;


	
	List<HotelBooking> getBookingsForCustomerCare(Long bookingId, Long hotelId) throws WudstayException;

	public Map<Long, RoomAvailabilityDayWise> getRoomAvailabilityDayWise(Long hotelId, Date fromDate, Date toDate);
	//public Map<Long, RoomAvailabilityDayWise> getRoomAvailabilityDayWise(Long hotelId, String fromDate, String toDate);
	public Map<Long, RoomAvailabilityDayWise> getRoomBookingsDayWise(Long hotelId, Date checkIn, Date checkOut);

	public boolean isBlackoutDateForPayAtHotel(Date checkIn, Date checkOut, long cityId);
	public boolean isBlackoutDateForCheckOut(Date checkOut, long cityId) throws ParseException;

	List<HotelBooking> getBookingsByTransactionId(String transactionId) throws WudstayException;
}
