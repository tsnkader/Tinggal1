package com.queppelin.wudstay.manager;

import com.queppelin.wudstay.vo.HotelRoomBooking;

public interface IHotelRoomBookingManager extends IBaseManager<HotelRoomBooking> {

}
