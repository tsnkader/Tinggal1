package com.queppelin.wudstay.manager;

import java.util.List;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.HotelDescription;

public interface IHotelDescriptionManager extends IBaseManager<HotelDescription> {

	List<HotelDescription> getHotelDescriptionsByHotelId(Long hotelId) throws WudstayException;

}
