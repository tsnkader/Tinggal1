package com.queppelin.wudstay.manager;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.PgHotelAdministrator;

public interface IPgHotelAdministratorManager extends IBaseManager<PgHotelAdministrator> {

	PgHotelAdministrator getPgHotelAdminByHotelId(Long hotelId) throws WudstayException;
	
}
