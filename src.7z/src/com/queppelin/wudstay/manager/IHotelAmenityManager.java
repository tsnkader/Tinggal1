package com.queppelin.wudstay.manager;

import java.util.List;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.HotelAmenity;

public interface IHotelAmenityManager extends IBaseManager<HotelAmenity> {

	List<HotelAmenity> getHotelAmenitiesByHotelId(Long hotelId) throws WudstayException;

}
