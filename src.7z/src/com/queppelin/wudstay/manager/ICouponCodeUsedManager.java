package com.queppelin.wudstay.manager;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.City;
import com.queppelin.wudstay.vo.CouponCodeUsedVO;

import java.util.List;

public interface ICouponCodeUsedManager extends IBaseManager<CouponCodeUsedVO> {
    public List<CouponCodeUsedVO> getByCouponCodeIdAndMobile(Long couponCodeId, String mobileNo) throws WudstayException;
}
