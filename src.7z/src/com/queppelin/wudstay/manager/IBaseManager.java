
package com.queppelin.wudstay.manager;

import java.io.Serializable;
import java.util.List;


public interface IBaseManager<T> {


	public void save(T obj);


	public void saveOrUpdate(T obj);


	public T getById(Serializable id);


	public void delete(T obj);


	public List<T> list();


	public List<T> list(String propertyName, String orderType);

}
