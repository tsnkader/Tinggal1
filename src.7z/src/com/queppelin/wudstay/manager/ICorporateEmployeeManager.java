package com.queppelin.wudstay.manager;


import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.CorporateEmployeeVO;

import java.util.List;

public interface ICorporateEmployeeManager extends IBaseManager<CorporateEmployeeVO> {

    public List<CorporateEmployeeVO> getListByCorpBookingId(Long corpBookingId) throws WudstayException;

}
