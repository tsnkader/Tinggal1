package com.queppelin.wudstay.manager;

import com.queppelin.wudstay.vo.LogsTable;
import com.queppelin.wudstay.vo.PayuMobTran;


public interface IPayuMobTranManager extends IBaseManager<PayuMobTran> {
    public LogsTable saveLogsTable(LogsTable logsTable);

}
