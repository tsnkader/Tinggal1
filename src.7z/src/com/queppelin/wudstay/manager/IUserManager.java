package com.queppelin.wudstay.manager;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.User;

public interface IUserManager extends IBaseManager<User> {

	User login(User user, String userType) throws WudstayException;

	Boolean isUsernameExists(String username) throws WudstayException;

}
