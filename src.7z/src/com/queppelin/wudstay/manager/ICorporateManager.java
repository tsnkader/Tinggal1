package com.queppelin.wudstay.manager;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.Corporate;
import com.queppelin.wudstay.vo.CorporateLoginVO;
import com.queppelin.wudstay.vo.custom.CorporateVO;

import java.util.List;

public interface ICorporateManager extends IBaseManager<Corporate> {
	
	String addCorporate(Corporate corpVO)  throws WudstayException;
	
	public List<Corporate> getAllCorporates() throws WudstayException;

	CorporateLoginVO login(CorporateLoginVO corporate) throws WudstayException;

	Boolean isUsernameExists(String corpUserName) throws WudstayException;
	
	Corporate getCorporateById(Long corpId) throws WudstayException;

	public CorporateLoginVO getCorporateLoginById(Long corporateLoginId) throws WudstayException;

	CorporateLoginVO saveCorporateLoginVO(CorporateLoginVO vo) throws WudstayException;

	public Boolean isCorpNameExists(String corpName) throws WudstayException;

	public Boolean isCorpNameExists(Long id, String corpName) throws WudstayException;

	public Boolean isCorpLoginIdExists(String corpLoginId) throws WudstayException ;

	public Boolean isCorpLoginIdExists(Long id, String corpLoginId) throws WudstayException;


}
