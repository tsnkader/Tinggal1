
package com.queppelin.wudstay.manager;

import com.queppelin.wudstay.dao.IPgHotelDescriptionDao;
import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.vo.*;
import com.queppelin.wudstay.vo.custom.HotelVO;
import com.queppelin.wudstay.vo.custom.PgHotelForm;

import java.util.List;

public interface IPgHotelManager extends IBaseManager<PgHotel> {
	public List<PgHotelAmenity> getPgHotelAmenitiesByHotelId(Long hotelId) throws WudstayException;
	public List<PgHotelDescription> getPgHotelDescriptionsByHotelId(Long hotelId) throws WudstayException;


	public Long addHotel(PgHotelForm hotelVO, User user) throws WudstayException;
	public List<PgHotel> getHotelByCityId(Long cityId) throws WudstayException;
	public List<PgHotel> getHotelBylocationIds(List<Long> locationIdsList) throws WudstayException;
	List<PgHotel> getHotelByCityId(Long cityId, int minPax) throws WudstayException;
	public List<PgHotel> filterHotels(List<Long> locationIdList, Long cityId,
									  List<Long> roomTypeIdList, String sortBy, Integer priceSortType, Integer ratingSortType, int minPax)
			throws WudstayException;
	/*public List<PgHotel> filterHotels(Long locationId, Long cityId,
									  List<Long> roomTypeIdList, String sortBy, Integer priceSortType, Integer ratingSortType, int minPax)
			throws WudstayException;*/

	public List<PgHotel> getSuggestedHotelList(PgHotel hotel) throws WudstayException;

	//Long addHotel(PgHotel hotelVO, User user) throws WudstayException;

	//Hotel updateHotel(PgHotel hotelVO, User user) throws WudstayException;
}
