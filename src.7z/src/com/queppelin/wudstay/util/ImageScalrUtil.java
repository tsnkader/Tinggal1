package com.queppelin.wudstay.util;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import java.awt.image.BufferedImage;
import java.io.*;
import org.imgscalr.Scalr;


/**  reScale image
 * Created by hp on 1/13/2016.
 */
public class ImageScalrUtil {
    final static String hotel_images_folder = "hotel_images";
    final static String hotel_mobile_images_folder = hotel_images_folder + File.separator + "m";

    public static void reScaleAllImagesOfHotel(Long hotelId,HttpServletRequest request) {
       // String hotelImageDirectoryPath = WudstayUtil.getOtherImagesDirPath(hotelId);
		String hotelImageDirectoryPath =  request.getRealPath("/")+"hotel_images/"+hotelId+"/others/";
        File[] files = new File(hotelImageDirectoryPath).listFiles();

        hotelImageDirectoryPath = hotelImageDirectoryPath.replace(hotel_images_folder, hotel_mobile_images_folder);
        File  desFolder = new File(hotelImageDirectoryPath);
        purgeDirectory(desFolder);

        reScaleAllImagesInFolder(files);
    }

    public static void  reScaleAllImagesInFolder(File[] files) {
        for (File file : files) {
            String directoryPath = file.getAbsolutePath();
            directoryPath = directoryPath.replace(hotel_images_folder, hotel_mobile_images_folder);

            if (file.isDirectory()) {
                //System.out.println("Directory: " + file.getName());
                File theDir = new File(directoryPath);
                if (!theDir.exists())
                    theDir.mkdir();
                else
                    purgeDirectory(theDir);
                reScaleAllImagesInFolder(file.listFiles()); // Calls same method again.
            } else {
                //System.out.println("File: " + file.getName());
                //System.out.print(" . ");
                try {
                    resizeFile(file, 420, 278);
                }catch (Exception ex){
                    System.out.println("FILE: " + file.getAbsolutePath() + "   " + file.getName());
                    ex.printStackTrace();
                }
            }
        }
    }
    public static void resizeFile(File file , int targetWidth, int targetHeight)throws IOException {
        String fileName = file.getName();
        if("Thumbs.db".equalsIgnoreCase(fileName)){
            return ;
        }

        String aPath = file.getAbsolutePath();
        aPath = aPath.replace(hotel_images_folder, hotel_mobile_images_folder);

        BufferedImage img = ImageIO.read(file);
        BufferedImage scaledImg = Scalr.resize(img, Scalr.Method.ULTRA_QUALITY, targetWidth, targetHeight);

        File destFile = new File(aPath);
        if(!destFile.exists()) {
        	destFile.getParentFile().mkdirs();
            String fileFormat = getExtension(file.getName());
            ImageIO.write(scaledImg, fileFormat, destFile);
        }
    }
    public static void resizeFileTo420x278(File file ) throws IOException {
        resizeFile( file , 420, 278);
    }

    public static void resizeFileTo740x490(File file )throws IOException {
        resizeFile( file , 740, 490);
    }

    public static String getExtension(String fileName){
        String extension = "jpg";
        int i = fileName.lastIndexOf('.');
        if (i > 0) {
            extension = fileName.substring(i+1);
        }
        return extension;
    }
    public static void purgeDirectory(File dir) {
        try {
            for (File file : dir.listFiles()) {
                if (file.isDirectory())
                    purgeDirectory(file);
                file.delete();
            }
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    public static void  reScaleImages(String   roomsFilePath) {
        try {
            File file = new File(roomsFilePath);
            resizeFile(file, 420, 278);
        }catch (Exception ex){
            //System.out.println("FILE: " + file.getAbsolutePath() + "   " + file.getName());
            ex.printStackTrace();
        }
    }

}
