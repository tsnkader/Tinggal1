package com.queppelin.wudstay.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by hp on 10/11/2015.
 *  DateFormatConversionUtil getDisplayFormatDate
 */
public class DateFormatConversionUtil {
    public static SimpleDateFormat displayFormat = new SimpleDateFormat("dd/MM/yyyy");
    public static SimpleDateFormat displayLongFormat = new SimpleDateFormat("EEEE, dd MMMMM yyyy");


    public static Date getNextDate(Date today){
        try {
            Calendar c = Calendar.getInstance();
            c.setTime(today);
            c.add(Calendar.DATE, 1);
            Date tomorrow = c.getTime();
            return tomorrow;
        }catch (Exception ex){
            ex.printStackTrace();
            return null;
        }
    }
    //DateFormatConversionUtil.getDisplayFormatDate()
    public static String getDisplayFormatDate(Date date){
        try {
            return displayFormat.format(date);
        }catch (Exception ex){
            ex.printStackTrace();
            return "";
        }
    }

    public static String getDisplayLongFormatDate(Date date){
        try {
            return displayLongFormat.format(date);
        }catch (Exception ex){
            ex.printStackTrace();
            return "";
        }
    }
}
