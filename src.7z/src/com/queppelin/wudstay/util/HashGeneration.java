package com.queppelin.wudstay.util;

import com.queppelin.wudstay.vo.custom.PayuHashVO;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by hp on 12/7/2015.
 */
public class HashGeneration {
    String key = "gtKFFx";
    String salt = "eCwWELxi";

    public HashGeneration(String key, String salt) {
        this.key = key;
        this.salt = salt;
    }

    public PayuHashVO getHashes(String txnid, String amount, String productInfo, String firstname, String email,
                            String user_credentials, String udf1, String udf2, String udf3, String udf4, String udf5) {
        //JSONObject response = new JSONObject(); Map<String, String> response = new HashMap<String, String>();
        //JSONObject jsonObject = new JSONObject();
        PayuHashVO jsonObject = new PayuHashVO();

        jsonObject.setKey(key);
        jsonObject.setSalt(salt);


        String ph = checkNull(key) + "|" + checkNull(txnid) + "|" + checkNull(amount) + "|" + checkNull(productInfo)
                + "|" + checkNull(firstname) + "|" + checkNull(email) + "|" + checkNull(udf1) + "|" + checkNull(udf2)
                + "|" + checkNull(udf3) + "|" + checkNull(udf4) + "|" + checkNull(udf5) + "||||||" + salt;
        String paymentHash = getSHA(ph);
        //jsonObject.put("paymentHash", paymentHash);
        jsonObject.setPaymentHash(paymentHash);

        String cmnNameMerchantCodes = "get_merchant_ibibo_codes";
        String mch = key + "|" + cmnNameMerchantCodes + "|" + "default" + "|" + salt;
        String merchantCodesHash = getSHA(mch);
        //jsonObject.put("merchantCodesHash", merchantCodesHash);
        jsonObject.setMerchantCodesHash(merchantCodesHash);

        String cmnMobileSdk = "vas_for_mobile_sdk";
        String msdk = key + "|" + cmnMobileSdk + "|" + "default" + "|" + salt;
        String mobileSdk = getSHA(msdk);
        //jsonObject.put("mobileSdk", mobileSdk);
        jsonObject.setMobileSdk(mobileSdk);

        String cmnPaymentRelatedDetailsForMobileSdk1 = "payment_related_details_for_mobile_sdk";
        String dtlk = key + "|" + cmnPaymentRelatedDetailsForMobileSdk1 + "|" + "default" + "|" + salt;
        String detailsForMobileSdk = getSHA(dtlk);
        //jsonObject.put("detailsForMobileSdk", detailsForMobileSdk);
        jsonObject.setDetailsForMobileSdk(detailsForMobileSdk);

        if (user_credentials != null && user_credentials != "") {

            String cmnNameDeleteCard = "delete_user_card";
            String dh = key + "|" + cmnNameDeleteCard + "|" + user_credentials + "|" + salt;
            String deleteHash = getSHA(dh);
            //jsonObject.put("deleteHash", deleteHash);
            jsonObject.setDeleteHash(deleteHash);

            String cmnNameGetUserCard = "get_user_cards";
            String gth = key + "|" + cmnNameGetUserCard + "|" + user_credentials + "|" + salt;
            String getUserCardHash = getSHA(gth);
            //jsonObject.put("getUserCardHash", getUserCardHash);
            jsonObject.setGetUserCardHash(getUserCardHash);

            String cmnNameEditUserCard = "edit_user_card";
            String edh = key + "|" + cmnNameEditUserCard + "|" + user_credentials + "|" + salt;
            String editUserCardHash = getSHA(edh);
            //jsonObject.put("editUserCardHash", editUserCardHash);
            jsonObject.setEditUserCardHash(editUserCardHash);

            String cmnNameSaveUserCard = "save_user_card";
            String sdh = key + "|" + cmnNameSaveUserCard + "|" + user_credentials + "|" + salt;
            String saveUserCardHash = getSHA(sdh);
            //jsonObject.put("saveUserCardHash", saveUserCardHash);
            jsonObject.setSaveUserCardHash(saveUserCardHash);

            String cmnPaymentRelatedDetailsForMobileSdk = "payment_related_details_for_mobile_sdk";
            String dhh = key + "|" + cmnPaymentRelatedDetailsForMobileSdk + "|" + user_credentials + "|" + salt;
            detailsForMobileSdk = getSHA(dhh);
            //jsonObject.put("detailsForMobileSdk", detailsForMobileSdk);
            jsonObject.setDetailsForMobileSdk(detailsForMobileSdk);
        }
        //response.put("result", jsonObject);

        //return response.toJSONString();
        return jsonObject;

    }

    private String checkNull(String value) {
        if (value == null) {
            return "";
        } else {
            return value;
        }
    }

    private String getSHA(String str) {

        MessageDigest md;
        String out = "";
        try {
            md = MessageDigest.getInstance("SHA-512");
            md.update(str.getBytes());
            byte[] mb = md.digest();

            for (int i = 0; i < mb.length; i++) {
                byte temp = mb[i];
                String s = Integer.toHexString(new Byte(temp));
                while (s.length() < 2) {
                    s = "0" + s;
                }
                s = s.substring(s.length() - 2);
                out += s;
            }

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return out;

    }

}
