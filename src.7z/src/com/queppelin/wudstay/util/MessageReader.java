
package com.queppelin.wudstay.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class MessageReader {

private static Properties properties = null;
	
	private static MessageReader self;
	
	private MessageReader(){
		
	}
	
	public static MessageReader getInstance(){
		if(self == null){
			synchronized (MessageReader.class) {
				if(self == null){
					self = new MessageReader();
					InputStream propStream = self.getClass().getClassLoader()
							.getResourceAsStream(WudstayConstants.MESSAGES);
					if(propStream != null){
						properties = new Properties();
						try {
							properties.load(propStream);
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}
				else{
					return self;
				}
			}
		}
		return self;
	}
	
	public String getProperty(String key){
		return properties.getProperty(key);	
	}
}
