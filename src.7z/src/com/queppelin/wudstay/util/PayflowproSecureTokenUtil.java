package com.queppelin.wudstay.util;

import com.queppelin.wudstay.vo.HdfcTranLogVO;
import com.queppelin.wudstay.vo.PayPalTranLogVO;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by hp on 3/8/2016.
 */
public class PayflowproSecureTokenUtil {
    private static final String USER_AGENT = "Mozilla/5.0";
    public static final String url = "https://pilot-payflowpro.paypal.com";
    //public static final String url = "https://pilot-payflowpro.paypal.com";

    private String amt;
    private String token;

    private int result=0;
    private String respMsg;
    private String secureToken;
    private String secureTokenId;


    private PayflowproSecureTokenUtil(String amt, Long startTime, Long trnId) {
        //String amt = tranLogVO.getAmount();
        int amtLength = amt.length();
        if(!amt.contains(".")){
            amt=amt+".00";
        }else {
            amtLength=amt.indexOf(".");
            amt=amt+"00";
        }
        amtLength=amtLength+3;
        this.amt = amt.substring(0, amtLength);;

        //Date dt = tranLogVO.getLogTime();
        //Long startTime = dt.getTime();
        //Long trnId = tranLogVO.getLogId();

        this.token = MD5(startTime + "TINGGAL-" + trnId);
    }

    public static PayflowproSecureTokenUtil execute(PayPalTranLogVO tranLogVO){
        try {
            PayflowproSecureTokenUtil dto = new PayflowproSecureTokenUtil(tranLogVO.getAmount(),tranLogVO.getLogTime().getTime(),tranLogVO.getLogId() );
            String [] paramName = {"PARTNER", "VENDOR", "USER", "PWD", "TRXTYPE", "AMT", "CREATESECURETOKEN", "SECURETOKENID"};
            String [] paramValue = {WudstayConstants.PAYPAL_PARTNER_NAME, WudstayConstants.PAYPAL_MERCHANT_NAME, WudstayConstants.PAYPAL_USER_NAME, WudstayConstants.PAYPAL_PASSWORD, "S", dto.amt, "Y", dto.token };

            String response =  doPostRequest(url, paramName, paramValue);

            dto.resetServerResponse(response);
            return dto;
        } catch (Exception e) {
            return null;
        }
    }

    private void resetServerResponse(String response){
        //RESULT=0&RESPMSG=Approved&SECURETOKEN=9hGmbx938mUC7dYgaoyuFrgJ0&SECURETOKENID=eeae8f325729e980ed1c0c6146751656
        String[] res = response.split("&");
        for(String item : res) {
            String[] keyValue = item.split("=");
            String key = keyValue[0].trim();
            String value = keyValue[1].trim();
            if("RESULT".equals(key)){
                result = Integer.parseInt(value);
            }else if("RESPMSG".equals(key)){
                respMsg = value;
            }else if("SECURETOKEN".equals(key)){
                secureToken = value;
            }else if("SECURETOKENID".equals(key)){
                secureTokenId = value;
            }
            System.out.println("Key: " + keyValue[0] + ", Value: " + keyValue[1]);
        }
    }

    public static String MD5(String md5) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
            byte[] array = md.digest(md5.getBytes());
            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < array.length; ++i) {
                sb.append(Integer.toHexString((array[i] & 0xFF) | 0x100).substring(1, 3));
            }
            return sb.toString();
        } catch (java.security.NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String doPostRequest(String url, String [] paramName, String [] paramValue) throws Exception {
        HttpClient client = HttpClientBuilder.create().build();
        HttpPost post = new HttpPost(url);

        // add header
        post.setHeader("User-Agent", USER_AGENT);

        List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
        int l = paramName.length > paramValue.length? paramValue.length : paramName.length;
        for(int i=0 ; i<l ; i++) {
            urlParameters.add(new BasicNameValuePair(paramName[i], paramValue[i]));
        }
        post.setEntity(new UrlEncodedFormEntity(urlParameters));

        HttpResponse response = client.execute(post);
        System.out.println("Response Code : " + response.getStatusLine().getStatusCode());

        BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

        StringBuffer result = new StringBuffer();
        String line = "";
        System.out.println("\n--------------------------------------------------------------------------");
        while ((line = rd.readLine()) != null) {
            System.out.println(line);
            result.append(line);
        }
        System.out.println("\n--------------------------------------------------------------------------");

        return result.toString();
    }
    // ==========================================================================================================

    public String getSecureTokenId() {
        return secureTokenId;
    }

    public String getSecureToken() {
        return secureToken;
    }

    public String getRespMsg() {
        return respMsg;
    }

    public int getResult() {
        return result;
    }

    public String getToken() {
        return token;
    }

    public String getAmt() {
        return amt;
    }
}
