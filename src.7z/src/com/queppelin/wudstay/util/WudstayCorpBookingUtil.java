package com.queppelin.wudstay.util;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.*;
import com.queppelin.wudstay.vo.*;
import com.queppelin.wudstay.vo.custom.BookingDetailsVO;
import com.queppelin.wudstay.vo.custom.HotelAvailabilityVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.mail.MessagingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by hp on 9/28/2015.
 */
public class WudstayCorpBookingUtil {
    private static final Logger logger = LoggerFactory.getLogger(WudstayCorpBookingUtil.class);
    static SimpleDateFormat userDateFormat = new SimpleDateFormat("dd/MM/yyyy");
    static SimpleDateFormat dbDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    private IHotelBookingManager hotelBookingManager;
    private IHotelAdministratorManager hotelAdministratorManager;

    private BookingDetailsVO bookingDetailsVO = null;

    private City city = null;
    private Hotel hotel = null;
    private Corporate corporate = null;
    private CorporateLoginVO corporateUser=null;
    private Date bookingDate = null;
    private Integer price_TARIFF_PER_NIGHT = 0;


    public WudstayCorpBookingUtil(Integer price, Date bookingDate, Corporate corporate, CorporateLoginVO corporateUser, IHotelBookingManager hotelBookingManager, IHotelAdministratorManager hotelAdministratorManager, City city) {
        this.hotelBookingManager = hotelBookingManager;
        this.hotelAdministratorManager = hotelAdministratorManager;
        this.city = city;
        this.corporate = corporate;
        this.corporateUser=corporateUser;
        this.bookingDate = bookingDate;
        this.price_TARIFF_PER_NIGHT = price;
    }

    public String getCorporateAdminName() {
        return corporate.getCorpContactPersonName();
    }

    public String getCorporateAdminEmail() {
        return corporate.getCorpContactPersonEmail();
    }

    public String getCorporateAdminContactNo() {
        return corporate.getCorpContactNo();
    }

    public String getCorporateUserName() {
        return corporateUser.getCorpContactPersonName();
    }

    public String getCorporateUserEmail() {
        return corporateUser.getCorpContactPersonEmail();
    }

    public String getCorporateUserContactNo() {
        return corporateUser.getCorpContactNo();
    }

    public String getBookingDisplayDate() {
        try {
            return DateFormatConversionUtil.getDisplayFormatDate(bookingDate);
        } catch (Exception ex) {
            ex.printStackTrace();
            return "";
        }
    }

    public String getDisplayLongFormatDate() {
        try {
            return DateFormatConversionUtil.getDisplayLongFormatDate(bookingDate);
        } catch (Exception ex) {
            ex.printStackTrace();
            return "";
        }
    }

    public Date getBookingDate() {
        return bookingDate;
    }

    public String bookAndConfirmHotel(String checkIn, String checkOut, Integer rooms, Integer persons) {
        /*return bookAndConfirmHotel(checkIn, checkOut, rooms, persons,
                this.getCorporateContactPersonName(), this.getCorporateContactPersonEmail(), this.getCorporateContactPersonContactNo());*/
        return bookAndConfirmHotel(checkIn, checkOut, rooms, persons,
                this.getCorporateUserName(), this.getCorporateUserEmail(), this.getCorporateUserContactNo());
    }

    private String bookAndConfirmHotel(String checkIn, String checkOut, Integer rooms, Integer persons,
                                       String name, String email, String mobileNumber) {
        String bookingId = null;
        this.bookingDetailsVO = WudstayUtil.getBookingDetailsVO(city.getCityName(), checkIn, checkOut, rooms, persons, this.hotel);

        int totalPrice = price_TARIFF_PER_NIGHT * bookingDetailsVO.getNights() * rooms;

        bookingDetailsVO.setTotalPrice(totalPrice);

        try {
            Integer discount =0;
            Integer sourceOfBooking = WudstayConstants.getSourceOfBooking(WudstayConstants.WEB_APP_TYPE_CORP, WudstayConstants.SOURCE_OF_BOOKING_CORP);
            bookingId = hotelBookingManager.makeBooking(this.bookingDetailsVO, name, mobileNumber, toDbFormatDate(checkIn), toDbFormatDate(checkOut), rooms, persons, email, Boolean.FALSE, null, null, discount, sourceOfBooking);
        } catch (Exception e) {
            e.printStackTrace();
            //throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return bookingId;
    }

    public Map<String, Object> commonBbookingConfirmationBodyDetails(String bookingId, Integer paidAmount, int persions, String guestRequest, int billPayAt ){
        Map<String, Object> bookingConfirmationBodyDetails = new HashMap<String, Object>();

        //bookingConfirmationBodyDetails.put("GUEST", name);
        //bookingConfirmationBodyDetails.put("PHONE", mobileNumber);
        //bookingConfirmationBodyDetails.put("EMAIL", email);

        bookingConfirmationBodyDetails.put("CHECK_IN", bookingDetailsVO.getCheckInDate().split(",")[1].trim());
        bookingConfirmationBodyDetails.put("CHECK_OUT", bookingDetailsVO.getCheckOutDate().split(",")[1].trim());
        bookingConfirmationBodyDetails.put("HOTEL_DISPLAY_NAME", bookingDetailsVO.getHotelDisplayName());
        bookingConfirmationBodyDetails.put("BOOKING_ID", bookingId);
        bookingConfirmationBodyDetails.put("ROOM_COUNT", bookingDetailsVO.getRoomDetailsVOList().size());
        bookingConfirmationBodyDetails.put("NIGHT_COUNT", bookingDetailsVO.getNights());
        bookingConfirmationBodyDetails.put("ROOMS_NIGHT_COUNT", bookingDetailsVO.getNights() * bookingDetailsVO.getRoomDetailsVOList().size() );

        bookingConfirmationBodyDetails.put("TARIFF_PER_NIGHT", price_TARIFF_PER_NIGHT);
        bookingConfirmationBodyDetails.put("TOTAL_PRICE", bookingDetailsVO.getTotalPrice());
        if(billPayAt==0)
            bookingConfirmationBodyDetails.put("PAYABLE_AT", "HOTEL");
        else
            bookingConfirmationBodyDetails.put("PAYABLE_AT", "B To C");
        bookingConfirmationBodyDetails.put("PAID", paidAmount);
        //bookingConfirmationBodyDetails.put("MAP_LINK", bookingDetailsVO.getMapLink());
        bookingConfirmationBodyDetails.put("GUEST_COUNT", persions);
        bookingConfirmationBodyDetails.put("HOTEL_ADDRESS", bookingDetailsVO.getDisplayAddress());
        bookingConfirmationBodyDetails.put("BOOKING_DATE", this.getDisplayLongFormatDate().split(",")[1].trim());
        bookingConfirmationBodyDetails.put("CITY", bookingDetailsVO.getCity());
        bookingConfirmationBodyDetails.put("GUEST_REQUEST", guestRequest);

        return bookingConfirmationBodyDetails;
    }

    public void sendConfirmationMailAndSmsToGuest(CorporateEmployeeVO guest, String bookingId, Map<String, Object> mapEmailBodyData) {
        String name = guest.getEmpName();
        String email = guest.getEmpEmail();
        String mobileNumber = guest.getEmpContactNumber();
        List<String> ccList = new ArrayList<String>();
        //ccList.add(getCorporateAdminEmail());
        ccList.add(getCorporateUserEmail());
        if(mobileNumber==null || "".equalsIgnoreCase(mobileNumber.trim())){
            mobileNumber = getCorporateUserContactNo();
        }
        if(email==null || "".equalsIgnoreCase(email.trim())){
            email = getCorporateUserEmail();
        }

        try {
            WudstayUtil.sendConfirmationMessage("Dear " + name + ", your Tinggal booking has been confirmed from " + bookingDetailsVO.getCheckInDate() + " to "
                    + bookingDetailsVO.getCheckOutDate() + " at " + bookingDetailsVO.getHotelName() + ". The address is "
                    + bookingDetailsVO.getAddress() + " and your booking id is " + bookingId + ". You can locate the stay at Google Maps on "
                    + "the link " + bookingDetailsVO.getMapLink() + ". For any assistance you can call us anytime at +62822 8539 0099. Please carry a valid govt. address and ID proof when you checkin.", mobileNumber);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        try {
            mapEmailBodyData.put("GUEST", name);
            mapEmailBodyData.put("PHONE", mobileNumber);
            mapEmailBodyData.put("EMAIL", email);
            EmailSender.getInstance().sendEmailWithoutImage(email, "Booking Confirmation", mapEmailBodyData, WudstayConstants.CORP_BOOKING_CONFIRMATION_EMAIL_BODY, ccList);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void sendConfirmationMailAndSmsToCorporatAdmin(String bookingId, Map<String, Object> mapEmailBodyData, String nameCSV) {
        List<String> ccList = new ArrayList<String>();
        ccList.add(getCorporateAdminEmail());

        String name=getCorporateUserName();
        String email=getCorporateUserEmail();
        String mobileNumber=getCorporateUserContactNo();

       /* try {
            WudstayUtil.sendConfirmationMessage("Dear " + name + ", your WudStay booking has been confirmed from " + bookingDetailsVO.getCheckInDate() + " to "
                    + bookingDetailsVO.getCheckOutDate() + " at " + bookingDetailsVO.getHotelName() + ". The address is "
                    + bookingDetailsVO.getAddress() + " and your booking id is " + bookingId + ". You can locate the stay at Google Maps on "
                    + "the link " + bookingDetailsVO.getMapLink() + ". For any assistance you can call us anytime at 9555900500. Please carry a valid govt. address and ID proof when you checkin.", mobileNumber);
        } catch (Exception ex) {
            ex.printStackTrace();
        }*/

        try {
            //mapEmailBodyData.put("GUEST", getCorporateUserName() + "(Corporate Booking)");
            mapEmailBodyData.put("EMAIL_TO", name);
            mapEmailBodyData.put("GUEST", "Corporate Booking(" + nameCSV + " )");
            mapEmailBodyData.put("PHONE", getCorporateUserEmail()); //mobileNumber);
            mapEmailBodyData.put("EMAIL", getCorporateUserContactNo()); //email);
            EmailSender.getInstance().sendEmailWithoutImage(email, "Booking Confirmation", mapEmailBodyData, WudstayConstants.CORP_ADMIN_BOOKING_VOUCHER_EMAIL_BODY, ccList);
        } catch (Exception e) {
            e.printStackTrace();
            //logger.error("error:", e);
        }
    }
    public void sendConfirmationMailAndSmsToHotelAdmin(IHotelAdministratorManager hotelAdministratorManager, Long hotelId, String nameCSV, String bookingId, Map<String, Object> mapEmailBodyData) {
        List<String> ccList = new ArrayList<String>();
        String hotelAdministratorEmail = null;
        HotelAdministrator hotelAdministrator = null;
        String emailTo="";
        try {
            hotelAdministrator = hotelAdministratorManager.getHotelAdminByHotelId(hotelId);
            emailTo = hotelAdministrator.getUser().getUserFullName();

            if (hotelAdministrator.getUser().getEmail() != null && !hotelAdministrator.getUser().getEmail().trim().equals("")) {
                hotelAdministratorEmail = hotelAdministrator.getUser().getEmail();
            }

            if (hotel.getContactPersonEmail1() != null && !hotel.getContactPersonEmail1().trim().equals("")) {
                ccList.add(hotel.getContactPersonEmail1());
            }
            if (hotel.getContactPersonEmail2() != null && !hotel.getContactPersonEmail2().trim().equals("")) {
                ccList.add(hotel.getContactPersonEmail2());
            }

        } catch (WudstayException e) {
            e.printStackTrace();
        }

        try {
            //mapEmailBodyData.put("GUEST", getCorporateUserName() + "(Corporate Booking)");
            mapEmailBodyData.put("EMAIL_TO", emailTo);
            mapEmailBodyData.put("GUEST", "Corporate Booking(" + nameCSV + " )");
            mapEmailBodyData.put("PHONE", getCorporateUserEmail()); //mobileNumber);
            mapEmailBodyData.put("EMAIL", "-");//getCorporateUserContactNo()); //email);
            EmailSender.getInstance().sendEmailWithoutImage(hotelAdministratorEmail, "Booking Confirmation", mapEmailBodyData, WudstayConstants.CORP_HOTEL_ADMIN_BOOKING_VOUCHER_EMAIL_BODY, ccList);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String arrayToCsv(String [] toArray ){
        List<String> ids = Arrays.asList(toArray);
        return listToCsv( ids );
    }
    public static String listToCsv(List<String> ids ){
        // CSV format
        String csv = ids.toString().replace("[", "").replace("]", "").replace(", ", ",");

        // CSV format surrounded by single quote // Useful for SQL IN QUERY
        //String csvWithQuote = ids.toString().replace("[", "'").replace("]", "'").replace(", ", "','");
        return csv;
    }

    public CorporateEmployeeVO updateAndSendConfirmationMailToCorporateGuest(ICorporateEmployeeManager corporateEmployeeManager,
                                                                             CorporateEmployeeVO corpEmp, Long hotelId, Integer persons, String bookingId, List<String> ccList) {
        corpEmp.setHotelId(hotelId);
        corpEmp.setIsApproved(1);
        corporateEmployeeManager.saveOrUpdate(corpEmp);
        //------------------------------------------------
        try {
            WudstayCorpBookingUtil.sendConfirmationMail_corpBooking(
                    corpEmp.getEmpName(), corpEmp.getEmpEmail(), corpEmp.getEmpContactNumber(),
                    persons, price_TARIFF_PER_NIGHT, this.getBookingDetailsVO(), ccList, bookingId, 0);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
        return corpEmp;
    }

    public BookingDetailsVO getBookingDetailsVO() {
        return this.bookingDetailsVO;
    }

    public City getCity() {
        return city;
    }

    public Hotel getHotel() {
        return hotel;
    }

    public void setHotel(Hotel hotel) {
        this.hotel = hotel;
        this.bookingDetailsVO = null;
    }

    public HotelAvailabilityVO checkAvailability(String checkIn, String checkOut, Integer rooms) {
        HotelAvailabilityVO hotelAvailabilityVO = new HotelAvailabilityVO();
        try {
            String checkInDate = WudstayUtil.getFormattedCheckInDate(checkIn.trim());
            String checkOutDate = WudstayUtil.getFormattedCheckOutDate(checkOut.trim());
            return WudstayUtil.isAvailable(this.hotel, rooms, checkInDate, checkOutDate, hotelBookingManager);
        } catch (Exception e) {
            e.printStackTrace();
            hotelAvailabilityVO.setStatus(Boolean.FALSE);
        }
        return hotelAvailabilityVO;
    }


 /*
    public void bookingEmailAndSmsNotification(BookingDetailsVO bookingDetailsVO, String bookingId, String name, String email, String mobileNumber) {
        List<String> ccList = new ArrayList<String>();
        try {
            WudstayUtil.sendConfirmationMessage("Dear " + name + ", your WudStay booking has been confirmed from " + bookingDetailsVO.getCheckInDate() + " to "
                    + bookingDetailsVO.getCheckOutDate() + " at " + bookingDetailsVO.getHotelName() + ". The address is "
                    + bookingDetailsVO.getAddress() + " and your booking id is " + bookingId + ". You can locate the stay at Google Maps on "
                    + "the link " + bookingDetailsVO.getMapLink() + ". For any assistance you can call us anytime at 9555900500. Please carry a valid govt. address and ID proof when you checkin.", mobileNumber);
        }catch (Exception ex){
            ex.printStackTrace();
        }
        try {
            sendConfirmationMail(name, email, bookingDetailsVO, ccList, bookingId, new Integer(0)); // Empty ccList no one to cc, only to client
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    public void bookingEmailAndSmsNotification(BookingDetailsVO bookingDetailsVO, String bookingId, List<CorporateEmployeeVO> corpEmpList) {
        try {
            for(CorporateEmployeeVO vo: corpEmpList ) { //String mobileNumber, String name, String email)
                //bookingNotification_toGuest(bookingDetailsVO, bookingId, vo.getEmpName(), vo.getEmpEmail(),  vo.getEmpContactNumber());
            }
        } catch (Exception e) {
            e.printStackTrace();
            //throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
    }


    public void bookingNotification(String bookingId, String name, String email, String mobileNumber ) { //String mobileNumber, String name, String email) {
        try {
            List<String> ccList = new ArrayList<String>();

            WudstayUtil.sendConfirmationMessage("Dear " + name + ", your WudStay booking has been confirmed from " + this.bookingDetailsVO.getCheckInDate() + " to "
                    + this.bookingDetailsVO.getCheckOutDate() + " at " + this.bookingDetailsVO.getHotelName() + ". The address is "
                    + this.bookingDetailsVO.getAddress() + " and your booking id is " + bookingId + ". You can locate the stay at Google Maps on "
                    + "the link " + this.bookingDetailsVO.getMapLink() + ". For any assistance you can call us anytime at 9555900500. Please carry a valid govt. address and ID proof when you checkin.", mobileNumber);

            sendConfirmationMail(name, email, this.bookingDetailsVO, ccList, bookingId, new Integer(0)); // Empty ccList no one to cc, only to client

            String hotelAdministratorEmail = null;
            HotelAdministrator hotelAdministrator = hotelAdministratorManager.getHotelAdminByHotelId(this.bookingDetailsVO.getHotelId());
            if(hotelAdministrator.getUser().getEmail() != null && !hotelAdministrator.getUser().getEmail().trim().equals("")) {
                //ccList.add(hotelAdministrator.getUser().getEmail());
                hotelAdministratorEmail = hotelAdministrator.getUser().getEmail();
            }

            if(hotel.getContactPersonEmail1() != null && !hotel.getContactPersonEmail1().trim().equals("")) {
                ccList.add(hotel.getContactPersonEmail1());
            }
            if(hotel.getContactPersonEmail2() != null && !hotel.getContactPersonEmail2().trim().equals("")) {
                ccList.add(hotel.getContactPersonEmail2());
            }

            //sendConfirmationMail(name, email, bookingDetailsVO, ccList, bookingId, new Integer(0));
            sendConfirmationMail(name, hotelAdministratorEmail, bookingDetailsVO, ccList, bookingId, new Integer(0));

        } catch (Exception e) {
            e.printStackTrace();
            //throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
    }


   public void bookingNotificationToCorpGuest(String bookingId, String name, String email, String mobileNumber , String ccEmail ) {
        List<String> ccList = new ArrayList<String>();
        if(ccEmail!= null){
            ccList.add(ccEmail);
        }
        try{
            WudstayUtil.sendConfirmationMessage("Dear " + name + ", your WudStay booking has been confirmed from " + this.bookingDetailsVO.getCheckInDate() + " to "
                    + this.bookingDetailsVO.getCheckOutDate() + " at " + this.bookingDetailsVO.getHotelName() + ". The address is "
                    + this.bookingDetailsVO.getAddress() + " and your booking id is " + bookingId + ". You can locate the stay at Google Maps on "
                    + "the link " + this.bookingDetailsVO.getMapLink() + ". For any assistance you can call us anytime at 9555900500. Please carry a valid govt. address and ID proof when you checkin.", mobileNumber);

            sendConfirmationMail(name, email, this.bookingDetailsVO, ccList, bookingId, new Integer(0)); // Empty ccList no one to cc, only to client
        } catch (Exception e) {
            e.printStackTrace();
            //throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
    }*/


    public static void sendInvoiceMail_corpBooking(String name, String email, String mobileNumber, int persions, int tariffPerNight,
                                                   String bookingDate, String guestReq,
                                                   BookingDetailsVO bookingDetailsVO, List<String> ccList, String bookingId, Integer paidAmount) {
        Map<String, Object> bookingConfirmationBodyDetails = new HashMap<String, Object>();
        bookingConfirmationBodyDetails.put("GUEST", name);
        bookingConfirmationBodyDetails.put("CHECK_IN", bookingDetailsVO.getCheckInDate().split(",")[1].trim());
        bookingConfirmationBodyDetails.put("CHECK_OUT", bookingDetailsVO.getCheckOutDate().split(",")[1].trim());
        bookingConfirmationBodyDetails.put("HOTEL_DISPLAY_NAME", bookingDetailsVO.getHotelDisplayName());
        bookingConfirmationBodyDetails.put("BOOKING_ID", bookingId);
        bookingConfirmationBodyDetails.put("ROOM_COUNT", bookingDetailsVO.getRoomDetailsVOList().size());
        bookingConfirmationBodyDetails.put("NIGHT_COUNT", bookingDetailsVO.getNights());
        bookingConfirmationBodyDetails.put("TOTAL_PRICE", bookingDetailsVO.getTotalPrice());
        bookingConfirmationBodyDetails.put("PAID", paidAmount);
        //bookingConfirmationBodyDetails.put("MAP_LINK", bookingDetailsVO.getMapLink());

        bookingConfirmationBodyDetails.put("PHONE", mobileNumber);
        bookingConfirmationBodyDetails.put("EMAIL", email);
        bookingConfirmationBodyDetails.put("GUEST_COUNT", persions);
        bookingConfirmationBodyDetails.put("HOTEL_ADDRESS", bookingDetailsVO.getDisplayAddress());
        bookingConfirmationBodyDetails.put("TARIFF_PER_NIGHT", tariffPerNight);

        bookingConfirmationBodyDetails.put("CITY", bookingDetailsVO.getCity());
        bookingConfirmationBodyDetails.put("BOOKING_DATE", bookingDate);
        bookingConfirmationBodyDetails.put("GUEST_REQUEST", guestReq);


        try {
           /* WudstayUtil.sendConfirmationMessage("Dear " + name + ", your WudStay booking has been confirmed from " + bookingDetailsVO.getCheckInDate() + " to "
                    + bookingDetailsVO.getCheckOutDate() + " at " + bookingDetailsVO.getHotelName() + ". The address is "
                    + bookingDetailsVO.getAddress() + " and your booking id is " + bookingId + ". You can locate the stay at Google Maps on "
                    + "the link " + bookingDetailsVO.getMapLink() + ". For any assistance you can call us anytime at 9555900500. Please carry a valid govt. address and ID proof when you checkin.", mobileNumber);
            */
            EmailSender.getInstance().sendEmailWithoutImage(email, "Booking Confirmation", bookingConfirmationBodyDetails, WudstayConstants.CORP_ADMIN_BOOKING_VOUCHER_EMAIL_BODY, ccList);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    public static void sendConfirmationMail_corpBooking(String name, String email, String mobileNumber, int persions, int tariffPerNight,
                                                        BookingDetailsVO bookingDetailsVO, List<String> ccList, String bookingId, Integer paidAmount) throws MessagingException {
        Map<String, Object> bookingConfirmationBodyDetails = new HashMap<String, Object>();
        bookingConfirmationBodyDetails.put("GUEST", name);
        bookingConfirmationBodyDetails.put("CHECK_IN", bookingDetailsVO.getCheckInDate().split(",")[1].trim());
        bookingConfirmationBodyDetails.put("CHECK_OUT", bookingDetailsVO.getCheckOutDate().split(",")[1].trim());
        bookingConfirmationBodyDetails.put("HOTEL_DISPLAY_NAME", bookingDetailsVO.getHotelDisplayName());
        bookingConfirmationBodyDetails.put("BOOKING_ID", bookingId);
        bookingConfirmationBodyDetails.put("ROOM_COUNT", bookingDetailsVO.getRoomDetailsVOList().size());
        bookingConfirmationBodyDetails.put("NIGHT_COUNT", bookingDetailsVO.getNights());
        bookingConfirmationBodyDetails.put("TOTAL_PRICE", bookingDetailsVO.getTotalPrice());
        bookingConfirmationBodyDetails.put("PAID", paidAmount);
        //bookingConfirmationBodyDetails.put("MAP_LINK", bookingDetailsVO.getMapLink());

        bookingConfirmationBodyDetails.put("PHONE", mobileNumber);
        bookingConfirmationBodyDetails.put("EMAIL", email);
        bookingConfirmationBodyDetails.put("GUEST_COUNT", persions);
        bookingConfirmationBodyDetails.put("HOTEL_ADDRESS", bookingDetailsVO.getDisplayAddress());
        bookingConfirmationBodyDetails.put("TARIFF_PER_NIGHT", tariffPerNight);

        try {
            WudstayUtil.sendConfirmationMessage("Dear " + name + ", your Tinggal booking has been confirmed from " + bookingDetailsVO.getCheckInDate() + " to "
                    + bookingDetailsVO.getCheckOutDate() + " at " + bookingDetailsVO.getHotelName() + ". The address is "
                    + bookingDetailsVO.getAddress() + " and your booking id is " + bookingId + ". You can locate the stay at Google Maps on "
                    + "the link " + bookingDetailsVO.getMapLink() + ". For any assistance you can call us anytime at +62822 8539 0099. Please carry a valid govt. address and ID proof when you checkin.", mobileNumber);

            EmailSender.getInstance().sendEmailWithoutImage(email, "Booking Confirmation", bookingConfirmationBodyDetails, WudstayConstants.CORP_BOOKING_CONFIRMATION_EMAIL_BODY, ccList);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String toDbFormatDate(final String dt) {
        Date date = null;
        try {
            date = userDateFormat.parse(dt);
            return dbDateFormat.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }
}
