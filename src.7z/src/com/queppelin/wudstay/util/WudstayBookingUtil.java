package com.queppelin.wudstay.util;

import com.queppelin.wudstay.manager.ICityManager;
import com.queppelin.wudstay.manager.IHotelAdministratorManager;
import com.queppelin.wudstay.manager.IHotelBookingManager;
import com.queppelin.wudstay.manager.IHotelManager;
import com.queppelin.wudstay.vo.City;
import com.queppelin.wudstay.vo.CorporateEmployeeVO;
import com.queppelin.wudstay.vo.Hotel;
import com.queppelin.wudstay.vo.HotelAdministrator;
import com.queppelin.wudstay.vo.custom.BookingDetailsVO;
import com.queppelin.wudstay.vo.custom.HotelAvailabilityVO;

import javax.mail.MessagingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by hp on 9/28/2015.
 */
public class WudstayBookingUtil {
    static SimpleDateFormat userDateFormat = new SimpleDateFormat("dd/MM/yyyy");
    static SimpleDateFormat dbDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    private IHotelBookingManager hotelBookingManager;
    private IHotelAdministratorManager hotelAdministratorManager;

    private BookingDetailsVO bookingDetailsVO = null;

    private City city = null;
    private Hotel hotel = null;


    public WudstayBookingUtil(IHotelBookingManager hotelBookingManager, IHotelAdministratorManager hotelAdministratorManager, City city) {
        this.hotelBookingManager = hotelBookingManager;
        this.hotelAdministratorManager = hotelAdministratorManager;
        this.city=city;
    }

    public BookingDetailsVO getBookingDetailsVO() {
        return this.bookingDetailsVO;
    }

    public City getCity() {
        return city;
    }

    public Hotel getHotel() {
        return hotel;
    }

    public void setHotel(Hotel hotel) {
        this.hotel = hotel;
        this.bookingDetailsVO=null;
    }

    public HotelAvailabilityVO checkAvailability(String checkIn, String checkOut, Integer rooms ) {
        HotelAvailabilityVO hotelAvailabilityVO = new HotelAvailabilityVO();
        try {
            String checkInDate = WudstayUtil.getFormattedCheckInDate(checkIn.trim());
            String checkOutDate = WudstayUtil.getFormattedCheckOutDate(checkOut.trim());
            return WudstayUtil.isAvailable(this.hotel, rooms, checkInDate, checkOutDate, hotelBookingManager);
        } catch (Exception e) {
            e.printStackTrace();
            hotelAvailabilityVO.setStatus(Boolean.FALSE);
        }
        return hotelAvailabilityVO;
    }

    public String bookAndConfirmHotel(String checkIn, String checkOut, Integer rooms, Integer persons, String name, String email, String mobileNumber,
                                      Integer discount, Integer sourceOfBooking ) {
        String bookingId = null;
        this.bookingDetailsVO = WudstayUtil.getBookingDetailsVO(city.getCityName(), checkIn, checkOut, rooms, persons, this.hotel);
        try{
            bookingId = hotelBookingManager.makeBooking(this.bookingDetailsVO, name, mobileNumber, toDbFormatDate(checkIn), toDbFormatDate(checkOut), rooms, persons, email, Boolean.FALSE, null, null, discount, sourceOfBooking);
        } catch (Exception e) {
            e.printStackTrace();
            //throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return bookingId;
    }
 /*
    public void bookingEmailAndSmsNotification(BookingDetailsVO bookingDetailsVO, String bookingId, String name, String email, String mobileNumber) {
        List<String> ccList = new ArrayList<String>();
        try {
            WudstayUtil.sendConfirmationMessage("Dear " + name + ", your WudStay booking has been confirmed from " + bookingDetailsVO.getCheckInDate() + " to "
                    + bookingDetailsVO.getCheckOutDate() + " at " + bookingDetailsVO.getHotelName() + ". The address is "
                    + bookingDetailsVO.getAddress() + " and your booking id is " + bookingId + ". You can locate the stay at Google Maps on "
                    + "the link " + bookingDetailsVO.getMapLink() + ". For any assistance you can call us anytime at 9555900500. Please carry a valid govt. address and ID proof when you checkin.", mobileNumber);
        }catch (Exception ex){
            ex.printStackTrace();
        }
        try {
            sendConfirmationMail(name, email, bookingDetailsVO, ccList, bookingId, new Integer(0)); // Empty ccList no one to cc, only to client
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    public void bookingEmailAndSmsNotification(BookingDetailsVO bookingDetailsVO, String bookingId, List<CorporateEmployeeVO> corpEmpList) {
        try {
            for(CorporateEmployeeVO vo: corpEmpList ) { //String mobileNumber, String name, String email)
                //bookingNotification_toGuest(bookingDetailsVO, bookingId, vo.getEmpName(), vo.getEmpEmail(),  vo.getEmpContactNumber());
            }
        } catch (Exception e) {
            e.printStackTrace();
            //throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
    }


    public void bookingNotification(String bookingId, String name, String email, String mobileNumber ) { //String mobileNumber, String name, String email) {
        try {
            List<String> ccList = new ArrayList<String>();

            WudstayUtil.sendConfirmationMessage("Dear " + name + ", your WudStay booking has been confirmed from " + this.bookingDetailsVO.getCheckInDate() + " to "
                    + this.bookingDetailsVO.getCheckOutDate() + " at " + this.bookingDetailsVO.getHotelName() + ". The address is "
                    + this.bookingDetailsVO.getAddress() + " and your booking id is " + bookingId + ". You can locate the stay at Google Maps on "
                    + "the link " + this.bookingDetailsVO.getMapLink() + ". For any assistance you can call us anytime at 9555900500. Please carry a valid govt. address and ID proof when you checkin.", mobileNumber);

            sendConfirmationMail(name, email, this.bookingDetailsVO, ccList, bookingId, new Integer(0)); // Empty ccList no one to cc, only to client

            String hotelAdministratorEmail = null;
            HotelAdministrator hotelAdministrator = hotelAdministratorManager.getHotelAdminByHotelId(this.bookingDetailsVO.getHotelId());
            if(hotelAdministrator.getUser().getEmail() != null && !hotelAdministrator.getUser().getEmail().trim().equals("")) {
                //ccList.add(hotelAdministrator.getUser().getEmail());
                hotelAdministratorEmail = hotelAdministrator.getUser().getEmail();
            }

            if(hotel.getContactPersonEmail1() != null && !hotel.getContactPersonEmail1().trim().equals("")) {
                ccList.add(hotel.getContactPersonEmail1());
            }
            if(hotel.getContactPersonEmail2() != null && !hotel.getContactPersonEmail2().trim().equals("")) {
                ccList.add(hotel.getContactPersonEmail2());
            }

            //sendConfirmationMail(name, email, bookingDetailsVO, ccList, bookingId, new Integer(0));
            sendConfirmationMail(name, hotelAdministratorEmail, bookingDetailsVO, ccList, bookingId, new Integer(0));

        } catch (Exception e) {
            e.printStackTrace();
            //throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
    }


   public void bookingNotificationToCorpGuest(String bookingId, String name, String email, String mobileNumber , String ccEmail ) {
        List<String> ccList = new ArrayList<String>();
        if(ccEmail!= null){
            ccList.add(ccEmail);
        }
        try{
            WudstayUtil.sendConfirmationMessage("Dear " + name + ", your WudStay booking has been confirmed from " + this.bookingDetailsVO.getCheckInDate() + " to "
                    + this.bookingDetailsVO.getCheckOutDate() + " at " + this.bookingDetailsVO.getHotelName() + ". The address is "
                    + this.bookingDetailsVO.getAddress() + " and your booking id is " + bookingId + ". You can locate the stay at Google Maps on "
                    + "the link " + this.bookingDetailsVO.getMapLink() + ". For any assistance you can call us anytime at 9555900500. Please carry a valid govt. address and ID proof when you checkin.", mobileNumber);

            sendConfirmationMail(name, email, this.bookingDetailsVO, ccList, bookingId, new Integer(0)); // Empty ccList no one to cc, only to client
        } catch (Exception e) {
            e.printStackTrace();
            //throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
    }*/


    public static  void sendInvoiceMail_corpBooking(String name, String email, String mobileNumber , int persions, int tariffPerNight,
                                                    String bookingDate, String guestReq,
                                                         BookingDetailsVO bookingDetailsVO, List<String> ccList, String bookingId, Integer paidAmount)  {
        Map<String, Object> bookingConfirmationBodyDetails = new HashMap<String, Object>();
        bookingConfirmationBodyDetails.put("GUEST", name);
        bookingConfirmationBodyDetails.put("CHECK_IN", bookingDetailsVO.getCheckInDate().split(",")[1].trim());
        bookingConfirmationBodyDetails.put("CHECK_OUT", bookingDetailsVO.getCheckOutDate().split(",")[1].trim());
        bookingConfirmationBodyDetails.put("HOTEL_DISPLAY_NAME", bookingDetailsVO.getHotelDisplayName());
        bookingConfirmationBodyDetails.put("BOOKING_ID", bookingId);
        bookingConfirmationBodyDetails.put("ROOM_COUNT", bookingDetailsVO.getRoomDetailsVOList().size());
        bookingConfirmationBodyDetails.put("NIGHT_COUNT", bookingDetailsVO.getNights());
        bookingConfirmationBodyDetails.put("TOTAL_PRICE", bookingDetailsVO.getTotalPrice());
        bookingConfirmationBodyDetails.put("PAID", paidAmount);
        //bookingConfirmationBodyDetails.put("MAP_LINK", bookingDetailsVO.getMapLink());

        bookingConfirmationBodyDetails.put("PHONE", mobileNumber);
        bookingConfirmationBodyDetails.put("EMAIL", email);
        bookingConfirmationBodyDetails.put("GUEST_COUNT", persions);
        bookingConfirmationBodyDetails.put("HOTEL_ADDRESS", bookingDetailsVO.getDisplayAddress());
        bookingConfirmationBodyDetails.put("TARIFF_PER_NIGHT",tariffPerNight);

        bookingConfirmationBodyDetails.put("CITY",bookingDetailsVO.getCity());
        bookingConfirmationBodyDetails.put("BOOKING_DATE", bookingDate);
        bookingConfirmationBodyDetails.put("GUEST_REQUEST", guestReq);



        try{
           /* WudstayUtil.sendConfirmationMessage("Dear " + name + ", your WudStay booking has been confirmed from " + bookingDetailsVO.getCheckInDate() + " to "
                    + bookingDetailsVO.getCheckOutDate() + " at " + bookingDetailsVO.getHotelName() + ". The address is "
                    + bookingDetailsVO.getAddress() + " and your booking id is " + bookingId + ". You can locate the stay at Google Maps on "
                    + "the link " + bookingDetailsVO.getMapLink() + ". For any assistance you can call us anytime at 9555900500. Please carry a valid govt. address and ID proof when you checkin.", mobileNumber);
            */
            EmailSender.getInstance().sendEmailWithoutImage(email, "Booking Confirmation", bookingConfirmationBodyDetails, WudstayConstants.CORP_ADMIN_BOOKING_VOUCHER_EMAIL_BODY, ccList);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static  void sendConfirmationMail_corpBooking(String name, String email, String mobileNumber , int persions, int tariffPerNight,
                                                         BookingDetailsVO bookingDetailsVO, List<String> ccList, String bookingId, Integer paidAmount) throws MessagingException {
        Map<String, Object> bookingConfirmationBodyDetails = new HashMap<String, Object>();
        bookingConfirmationBodyDetails.put("GUEST", name);
        bookingConfirmationBodyDetails.put("CHECK_IN", bookingDetailsVO.getCheckInDate().split(",")[1].trim());
        bookingConfirmationBodyDetails.put("CHECK_OUT", bookingDetailsVO.getCheckOutDate().split(",")[1].trim());
        bookingConfirmationBodyDetails.put("HOTEL_DISPLAY_NAME", bookingDetailsVO.getHotelDisplayName());
        bookingConfirmationBodyDetails.put("BOOKING_ID", bookingId);
        bookingConfirmationBodyDetails.put("ROOM_COUNT", bookingDetailsVO.getRoomDetailsVOList().size());
        bookingConfirmationBodyDetails.put("NIGHT_COUNT", bookingDetailsVO.getNights());
        bookingConfirmationBodyDetails.put("TOTAL_PRICE", bookingDetailsVO.getTotalPrice());
        bookingConfirmationBodyDetails.put("PAID", paidAmount);
        //bookingConfirmationBodyDetails.put("MAP_LINK", bookingDetailsVO.getMapLink());

        bookingConfirmationBodyDetails.put("PHONE", mobileNumber);
        bookingConfirmationBodyDetails.put("EMAIL", email);
        bookingConfirmationBodyDetails.put("GUEST_COUNT", persions);
        bookingConfirmationBodyDetails.put("HOTEL_ADDRESS", bookingDetailsVO.getDisplayAddress());
        bookingConfirmationBodyDetails.put("TARIFF_PER_NIGHT",tariffPerNight);

        try{
            WudstayUtil.sendConfirmationMessage("Dear " + name + ", your Tinggal booking has been confirmed from " + bookingDetailsVO.getCheckInDate() + " to "
                    + bookingDetailsVO.getCheckOutDate() + " at " + bookingDetailsVO.getHotelName() + ". The address is "
                    + bookingDetailsVO.getAddress() + " and your booking id is " + bookingId + ". You can locate the stay at Google Maps on "
                    + "the link " + bookingDetailsVO.getMapLink() + ". For any assistance you can call us anytime at +62822 8539 0099. Please carry a valid govt. address and ID proof when you checkin.", mobileNumber);

            EmailSender.getInstance().sendEmailWithoutImage(email, "Booking Confirmation", bookingConfirmationBodyDetails, WudstayConstants.CORP_BOOKING_CONFIRMATION_EMAIL_BODY, ccList);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String toDbFormatDate(final String dt){
        Date date = null;
        try {
            date = userDateFormat.parse(dt);
            return dbDateFormat.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }
}
