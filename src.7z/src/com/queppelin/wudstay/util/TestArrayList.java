package com.queppelin.wudstay.util;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.List;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
public class TestArrayList {
	 public static void main(String args[]){
	        try{
	            BufferedImage img = new BufferedImage( 
	                500, 500, BufferedImage.TYPE_INT_RGB );

	            File f = new File("MyFile.png");
	            int r = 5;
	            int g = 25;
	            int b = 255;
	            int col = (r << 16) | (g << 8) | b;
	            for(int x = 0; x < 500; x++){
	                for(int y = 20; y < 300; y++){
	                    img.setRGB(x, y, col);
	                }
	            }
	            ImageIO.write(img, "PNG", f);
	        }
	        catch(Exception e){
	            e.printStackTrace();
	        }
	    }
}