package com.queppelin.wudstay.util;

/**
 * Created by hp on 11/15/2015.
 */

import com.queppelin.wudstay.manager.IHotelAdministratorManager;
import com.queppelin.wudstay.manager.IHotelBookingManager;
import com.queppelin.wudstay.manager.IHotelManager;
import com.queppelin.wudstay.manager.IPayuMobTranManager;
import com.queppelin.wudstay.vo.*;
import com.queppelin.wudstay.vo.custom.BookingDetailsVO;
import com.queppelin.wudstay.vo.custom.PayUVO;
import com.queppelin.wudstay.vo.custom.PayuHashVO;
import org.apache.commons.lang.RandomStringUtils;

import javax.mail.MessagingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by hp on 11/15/2015.
 */
public class PayuPaymentUtil {
    private IPayuMobTranManager payuMobTranManager;

    public static String PAYMENT_SOURCE_TYPE_PAYU = "PAYU";
    public static String PAYMENT_SOURCE_TYPE_PAYZAP = "PAYZAP";


    public PayuPaymentUtil(IPayuMobTranManager payuMobTranManager) {
        this.payuMobTranManager = payuMobTranManager;
    }

    public PayuMobTran autoConfirmMobileBooking(PayuMobTran payuMobTran, IHotelManager hotelManager, IHotelBookingManager hotelBookingManager, IHotelAdministratorManager hotelAdministratorManager){
        //PayuMobTran payuMobTran = payuMobTranManager.getById(payuMobTranId);
        Integer discount = 0;
        Integer sourceOfBooking = WudstayConstants.getSourceOfBooking(payuMobTran.getSource(), WudstayConstants.SOURCE_OF_BOOKING_MOBILE);

        String bookingId = doConfirmMobileBooking( hotelManager, hotelBookingManager, hotelAdministratorManager,
                                        payuMobTran.getCheckIn(),  payuMobTran.getCheckOut(),  payuMobTran.getRooms(),
                                        payuMobTran.getPersons(),  payuMobTran.getPhone(),     payuMobTran.getFirstName(),
                                        payuMobTran.getHotelId(),  payuMobTran.getTotalAmount(),
                                        discount, Boolean.TRUE, sourceOfBooking, payuMobTran.getCityName(), payuMobTran.getEmail(),
                                        payuMobTran.getTransactionId(), payuMobTran.getPayuTransactionId(), payuMobTran.getPayuAmount());

        payuMobTran.setBookingId(bookingId);
        payuMobTran.setBookingTime(new Date());
        payuMobTranManager.saveOrUpdate(payuMobTran);
        return payuMobTran;
    }

    public  String doConfirmMobileBooking( IHotelManager hotelManager, IHotelBookingManager hotelBookingManager, IHotelAdministratorManager hotelAdministratorManager,
                                           String checkIn,  String checkOut,  Integer rooms,
                                           Integer persons, String mobileNumber,  String name, Long hotelId, Integer totalAmount,
                                           Integer discount, Boolean isPaid, Integer sourceOfBooking, String cityName, String email,
                                           String transactionId, String payuTransactionId, String strPayuAmount) {
        String bookingId = null;
        try {
            bookingId = hotelBookingManager.makeBookingFromMobile(null, name, mobileNumber, email, WudstayUtil.getFormattedCheckInDate(checkIn), WudstayUtil.getFormattedCheckOutDate(checkOut),
                    rooms, persons, hotelId, totalAmount, discount, isPaid, sourceOfBooking, transactionId, payuTransactionId);
            Hotel hotel = hotelManager.getById(hotelId);

            WudstayUtil.sendConfirmationMessage("Dear " + name + ", your Tinggal booking has been confirmed from " + checkIn + " to "
                    + checkOut + " at " + hotel.getHotelName() + ". The address is "
                    + hotel.getHotelAddress() + " and your booking id is " + bookingId + ". You can locate the stay at Google Maps on "
                    + "the link " + hotel.getMapLink() + ". For any assistance you can call us anytime at +62822 8539 0099. Please carry a valid govt. address and ID proof when you checkin.", mobileNumber);
            // ----------------- ------- Send email notification ---------- -----------------
            if(cityName !=null && email != null && !"NULL".equals(cityName) && !"NULL".equals(email)) {
                List<String> ccList = new ArrayList<String>();

                BookingDetailsVO bookingDetailsVO = WudstayUtil.getBookingDetailsVO(cityName, checkIn, checkOut, rooms, persons, hotel);

                Integer intPayuAmount = new Integer(0);
                try{
                    intPayuAmount = Integer.parseInt(strPayuAmount.trim());
                }catch (Exception ex){
                    try{
                        Double dAmount = Double.valueOf(strPayuAmount.trim());
                        intPayuAmount = dAmount.intValue();
                    }catch (Exception ex2){
                        ex2.printStackTrace();
                        intPayuAmount = new Integer(0);
                    }
                }

                sendConfirmationMail(name, email, bookingDetailsVO, ccList, bookingId, intPayuAmount);

                String hotelAdministratorEmail = null;
                HotelAdministrator hotelAdministrator = hotelAdministratorManager.getHotelAdminByHotelId(bookingDetailsVO.getHotelId());
                if (hotelAdministrator.getUser().getEmail() != null && !hotelAdministrator.getUser().getEmail().trim().equals("")) {
                    //ccList.add(hotelAdministrator.getUser().getEmail());
                    hotelAdministratorEmail = hotelAdministrator.getUser().getEmail();
                }

                if (hotel.getContactPersonEmail1() != null && !hotel.getContactPersonEmail1().trim().equals("")) {
                    ccList.add(hotel.getContactPersonEmail1());
                }
                if (hotel.getContactPersonEmail2() != null && !hotel.getContactPersonEmail2().trim().equals("")) {
                    ccList.add(hotel.getContactPersonEmail2());
                }

                //sendConfirmationMail(name, email, bookingDetailsVO, ccList, bookingId, new Integer(0));
                sendConfirmationMail(name, hotelAdministratorEmail, bookingDetailsVO, ccList, bookingId, intPayuAmount);
            }
            // ----------------- ------- ----------------------- ---------- -----------------
        } catch (Exception e) {
            bookingId = null;
        }
        return bookingId;
    }

    private void sendConfirmationMail(String name, String email, BookingDetailsVO bookingDetailsVO, List<String> ccList, String bookingId, Integer paidAmount) throws MessagingException {
        Map<String, Object> bookingConfirmationBodyDetails = new HashMap<String, Object>();
        bookingConfirmationBodyDetails.put("GUEST", name);
        bookingConfirmationBodyDetails.put("CHECK_IN", bookingDetailsVO.getCheckInDate().split(",")[1].trim());
        bookingConfirmationBodyDetails.put("CHECK_OUT", bookingDetailsVO.getCheckOutDate().split(",")[1].trim());
        bookingConfirmationBodyDetails.put("HOTEL_DISPLAY_NAME", bookingDetailsVO.getHotelDisplayName());
        bookingConfirmationBodyDetails.put("BOOKING_ID", bookingId);
        bookingConfirmationBodyDetails.put("ROOM_COUNT", bookingDetailsVO.getRoomDetailsVOList().size());
        bookingConfirmationBodyDetails.put("NIGHT_COUNT", bookingDetailsVO.getNights());
        bookingConfirmationBodyDetails.put("TOTAL_PRICE", bookingDetailsVO.getTotalPrice());
        bookingConfirmationBodyDetails.put("PAID", paidAmount);
        //bookingConfirmationBodyDetails.put("MAP_LINK", bookingDetailsVO.getMapLink());
        EmailSender.getInstance().sendEmail(email, "Booking Confirmation", bookingConfirmationBodyDetails, WudstayConstants.BOOKING_CONFIRMATION_EMAIL_BODY, ccList);
    }

    @SuppressWarnings("unused")
    public PayuMobTran  saveMobPaymentTranLog(City city, Hotel hotel,  String name, String email, String mobileNumber,
                                        String checkIn, String checkOut, Integer rooms, Integer persons, String cityName, Long hotelId, Integer totalAmount,
                                        String couponCode, String source, String paymentSource) {
        PayuMobTran payuMobTran = new PayuMobTran();
        payuMobTran.setFirstName(name);
        payuMobTran.setEmail(email);
        payuMobTran.setPhone(mobileNumber);
        payuMobTran.setCouponCode(couponCode);
        payuMobTran.setSource(source);
        payuMobTran.setCityName(city.getCityName());
        payuMobTran.setHotelId(hotel.getHotelId());
        payuMobTran.setCheckIn(checkIn);
        payuMobTran.setCheckOut(checkOut);
        payuMobTran.setRooms(rooms);
        payuMobTran.setPersons(persons);
        payuMobTran.setTotalAmount(totalAmount);
        payuMobTran.setLogTime(new Date());
        payuMobTran.setPaymentSource(paymentSource);
        payuMobTranManager.saveOrUpdate(payuMobTran);
        return payuMobTran;
    }

    @SuppressWarnings("unused")
    public HashMap<String, Object>  doProcessPayNow(City city, Hotel hotel,
                                                    String name, String email, String mobileNumber,
                                                     String checkIn, String checkOut, Integer rooms, Integer persons, String cityName, Long hotelId, Integer totalAmount,
                                                     String couponCode, String source, String salt, String merchantKey, String user_credentials) throws ParseException, NoSuchAlgorithmException {
        HashMap<String, Object> map = new HashMap<String, Object>();
        PayuMobTran payuMobTran = saveMobPaymentTranLog(city, hotel, name, email, mobileNumber, checkIn, checkOut, rooms, persons, cityName, hotelId, totalAmount, couponCode, source, PayuPaymentUtil.PAYMENT_SOURCE_TYPE_PAYU);
        //----------------------------------------------------------------------------------------------------------
        HashMap<String, Object> searchParamMap = new HashMap<String, Object>();
        searchParamMap.put("city",   city.getCityName());
        searchParamMap.put("cityId", city.getCityId());

        searchParamMap.put("checkIn",  WudstayUtil.getFormattedCheckInDate(checkIn.trim()));
        searchParamMap.put("checkOut", WudstayUtil.getFormattedCheckOutDate(checkOut.trim()));

        searchParamMap.put("rooms",   rooms);
        searchParamMap.put("persons", persons);

        BookingDetailsVO bookingDetailsVO = WudstayUtil.getBookingDetailsVO(city.getCityName(), checkIn, checkOut, rooms, persons, hotel);

        map.put("PayUlogId", payuMobTran.getLogId());
        //----------------------------------------------------------------------------------------------------------
        PayUVO payUVO = getPayUVO( payuMobTran.getLogId(),  salt, merchantKey, bookingDetailsVO, searchParamMap,  name,  email,  mobileNumber,  totalAmount);
        map.put("PayUVO", payUVO);
        //---------------------------------------------------------------------------------------------------------

        HashGeneration hash = new HashGeneration(merchantKey, salt);
        PayuHashVO payuHashs = hash.getHashes(payUVO.getTransactionId(), totalAmount + "", "Hotel Booking", name, email, user_credentials, payUVO.getUdf1(), payUVO.getUdf2(), null, null, null);
        map.put("PayuHashs", payuHashs);

        payuMobTranManager.saveOrUpdate(payuMobTran);
        return map;
    }

    @SuppressWarnings("unused")
    private PayUVO getPayUVO(Long payuMobTran_LogId, String salt, String merchantKey, BookingDetailsVO bookingDetailsVO, HashMap<String, Object> searchParamMap,
                             String name, String email, String mobileNumber, Integer totalAmount) throws NoSuchAlgorithmException {
        PayUVO payUVO = new PayUVO();
        //payUVO.setPayUlogId(payuMobTran_LogId);
        payUVO.setFirstName(name);
        payUVO.setEmail(email);
        payUVO.setAmount(totalAmount);//bookingDetailsVO.getTotalPrice());
        payUVO.setMerchantKey(merchantKey);
        payUVO.setProductInfo("Hotel Booking");
        payUVO.setSalt(salt);
        String transactionId = RandomStringUtils.randomAlphanumeric(15).toUpperCase();
        payUVO.setTransactionId(transactionId);
        payUVO.setPhone(mobileNumber);

        //payUVO.setCurl(WudstayConstants.BASE_URL + "webservice/payuResponse/PAYU_PAYMENT_CANCEL/" + payuMobTran_LogId);
        //payUVO.setSurl(WudstayConstants.BASE_URL + "webservice/payuResponse/PAYU_PAYMENT_SUCCESS/" + payuMobTran_LogId);
        //payUVO.setFurl(WudstayConstants.BASE_URL + "webservice/payuResponse/PAYU_PAYMENT_FAILURE/" + payuMobTran_LogId);

//        payUVO.setCurl(WudstayConstants.BASE_URL + "payuResponse/PAYU_PAYMENT_CANCEL/" + payuMobTran_LogId);
//        payUVO.setSurl(WudstayConstants.BASE_URL + "payuResponse/PAYU_PAYMENT_SUCCESS/" + payuMobTran_LogId);
//        payUVO.setFurl(WudstayConstants.BASE_URL + "payuResponse/PAYU_PAYMENT_FAILURE/" + payuMobTran_LogId);

        payUVO.setCurl(WudstayConstants.BASE_URL + "payuResponseForAndroid/PAYU_PAYMENT_CANCEL/" + payuMobTran_LogId);
        payUVO.setSurl(WudstayConstants.BASE_URL + "payuResponseForAndroid/PAYU_PAYMENT_SUCCESS/" + payuMobTran_LogId);
        payUVO.setFurl(WudstayConstants.BASE_URL + "payuResponseForAndroid/PAYU_PAYMENT_FAILURE/" + payuMobTran_LogId);


        StringBuffer buffer = new StringBuffer();
        buffer.append(payUVO.getMerchantKey());
        buffer.append("|");
        buffer.append(payUVO.getTransactionId());
        buffer.append("|");
        buffer.append(payUVO.getAmount());
        buffer.append("|");
        buffer.append(payUVO.getProductInfo());
        buffer.append("|");
        buffer.append(payUVO.getFirstName());
        buffer.append("|");
        buffer.append(payUVO.getEmail());
        buffer.append("|");

        payUVO.setUdf1(WudstayUtil.getUDFBookingDetails(bookingDetailsVO));

        buffer.append(payUVO.getUdf1());
        buffer.append("|");

        String udf2 = WudstayUtil.getUDFSearchParam(searchParamMap);
        udf2 = udf2 + WudstayConstants.HASH + payuMobTran_LogId;
        //payUVO.setUdf2(WudstayUtil.getUDFSearchParam(searchParamMap, payuMobTran_LogId));
        payUVO.setUdf2(udf2);

        buffer.append(payUVO.getUdf2());

        buffer.append("|||||||||");
        buffer.append(payUVO.getSalt());

        MessageDigest md = MessageDigest.getInstance("SHA-512");
        md.update(buffer.toString().getBytes());

        byte byteData[] = md.digest();

        //convert the byte to hex format method 1
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < byteData.length; i++) {
            sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
        }

        payUVO.setHash(sb.toString()); //paymentHash

        return payUVO;
    }

    private String getDetailsForMobileSdk(String merchantKey, String salt) throws NoSuchAlgorithmException {
    	/*$cmnPaymentRelatedDetailsForMobileSdk1 = 'payment_related_details_for_mobile_sdk';
        $detailsForMobileSdk_str1 = $key  . '|' . $cmnPaymentRelatedDetailsForMobileSdk1 . '|default|' . $salt ;
        $detailsForMobileSdk1 = strtolower(hash('sha512', $detailsForMobileSdk_str1));
        $arr['detailsForMobileSdk'] = $detailsForMobileSdk1; */
        StringBuffer buffer = new StringBuffer();
        buffer.append(merchantKey);
        buffer.append("|");
        buffer.append("payment_related_details_for_mobile_sdk");
        buffer.append("|default|");
        buffer.append(salt);
        return getHash_SHA512(buffer.toString());
    }

    private String getMobileSdk(String merchantKey, String salt) throws NoSuchAlgorithmException {
    	/*
        $cmnMobileSdk = 'vas_for_mobile_sdk';
        $mobileSdk_str = $key . '|' . $cmnMobileSdk . '|default|' . $salt;
        $mobileSdk = strtolower(hash('sha512', $mobileSdk_str));
        $arr['mobileSdk'] = $mobileSdk;
        */
        StringBuffer buffer = new StringBuffer();
        buffer.append(merchantKey);
        buffer.append("|");
        buffer.append("vas_for_mobile_sdk");
        buffer.append("|default|");
        buffer.append(salt);
        return getHash_SHA512(buffer.toString());
    }

    private String getMerchantCodesHash(String merchantKey, String salt) throws NoSuchAlgorithmException {
    	/*$cmnPaymentRelatedDetailsForMobileSdk1 = 'payment_related_details_for_mobile_sdk';
        $detailsForMobileSdk_str1 = $key  . '|' . $cmnPaymentRelatedDetailsForMobileSdk1 . '|default|' . $salt ;
        $detailsForMobileSdk1 = strtolower(hash('sha512', $detailsForMobileSdk_str1));
        $arr['detailsForMobileSdk'] = $detailsForMobileSdk1; */
        StringBuffer buffer = new StringBuffer();
        buffer.append(merchantKey);
        buffer.append("|");
        buffer.append("payment_related_details_for_mobile_sdk");
        buffer.append("|default|");
        buffer.append(salt);
        return getHash_SHA512(buffer.toString());
    }

    private String getHash_SHA512(final String inputString) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-512");
        md.update(inputString.getBytes());

        byte byteData[] = md.digest();

        //convert the byte to hex format method 1
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < byteData.length; i++) {
            sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
        }

        return sb.toString(); //paymentHash
    }




}
