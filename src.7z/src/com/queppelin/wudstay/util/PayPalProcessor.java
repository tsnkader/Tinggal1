package com.queppelin.wudstay.util;

import paypal.payflow.*;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by hp on 3/7/2016.
 */
public class PayPalProcessor implements Serializable {

    public static final int NO_OF_DECIMAL_DGITS = 2;

    private static final String USER_NAME =     "WS032016";
    private static final String MERCHANT_NAME = USER_NAME;
    private static final String PASSWORD =      "Hello1234";
    private static final String PARTNER_NAME =  "PayPal";

    public static final String HOST_ADDRESS= "pilot-payflowpro.paypal.com"; //TEST
    //public static final String HOST_ADDRESS = "payflowpro.paypal.com";    //PRODUCTION
    public static final int HOST_PORT = 443;
    public static final int TIMEOUT = 20;
    public static final String LOG_FILE_NAME = "..\\standalone\\log\\payflow_java.log";
    public static final int LOGGING_LEVEL = PayflowConstants.SEVERITY_ERROR;
    public static final int MAX_LOG_FILE_SIZE = 1000000;
    public static final String SUCCESS = "success";


    private Double amount=new Double(0.0);
    private String comment = "No Comment";
    private String purchaseOrderNumber = "EmptyPO number";
    private String billToStreet = "Street 124";
    private String billToZip = "12101";
    private String creditCardNo = "4111111111111111";
    private String expiryDate = "0317";

    private PayPalProcessor() {
        System.out.println(">>> Constructor called... " + this.hashCode());
        SDKProperties.setHostAddress(HOST_ADDRESS);
        SDKProperties.setHostPort(HOST_PORT);
        SDKProperties.setTimeOut(TIMEOUT);
        SDKProperties.setLogFileName(LOG_FILE_NAME);
        SDKProperties.setLoggingLevel(LOGGING_LEVEL);
        SDKProperties.setMaxLogFileSize(MAX_LOG_FILE_SIZE);
    }

    public PayPalProcessor(Double amount, String comment, String purchaseOrderNumber,
                           String billToStreet, String billToZip,
                           String creditCardNo, String expiryDate) {
        this();
        this.amount = amount;
        this.comment = comment;
        this.purchaseOrderNumber = purchaseOrderNumber;
        this.billToStreet = billToStreet;
        this.billToZip = billToZip;
        this.creditCardNo = creditCardNo;
        this.expiryDate = expiryDate;
    }

    private UserInfo getUserInfo(){
        return new UserInfo(USER_NAME, MERCHANT_NAME, PARTNER_NAME, PASSWORD);
    }

    private Currency toAmount(){
        Currency amt = new Currency(amount);
        amt.setNoOfDecimalDigits(NO_OF_DECIMAL_DGITS);
        amt.setRound(true);
        return amt;
    }
    private BillTo getBillTo(){
        BillTo bill = new BillTo();
        bill.setStreet(billToStreet);
        bill.setZip(billToZip);
        return bill;
    }
    private Invoice getInvoice(){
        Invoice inv = new Invoice();
        inv.setAmt(toAmount());
        inv.setComment1(new String(comment));           // Comment 1
        inv.setPoNum(new String(purchaseOrderNumber));  // Purchase Order Number
        inv.setBillTo(getBillTo());
        return inv;
    }

    private CardTender getCreditCard(){
        CreditCard cc = new CreditCard(creditCardNo, expiryDate);
        return  new CardTender(cc);
    }


    public Map<String, String> doAuthorizePayment() {
        // Create the Payflow Connection data object with the required connection details.
        PayflowConnectionData connection = new PayflowConnectionData();
        // Create a new Invoice data object with the Amount, Billing Address etc. details.
        Invoice inv = getInvoice();

        BrowserInfo browserInfo = new BrowserInfo();
        browserInfo.setButtonSource("BNCode");
        inv.setBrowserInfo(browserInfo);

        // Create a new Payment Device - Credit Card data object.
        // The input parameters are Credit Card No. and Expiry Date for the
        // Credit Card.
        CardTender card = getCreditCard();

        SaleTransaction trans = new SaleTransaction(getUserInfo(), connection, inv, card, PayflowUtility.getRequestId());
        Response resp = trans.submitTransaction();


        HashMap<String, String> responseMap = new HashMap<String, String>();
        if (resp != null) {
            TransactionResponse trxnResponse = null;
            trxnResponse = resp.getTransactionResponse();
            Integer resultCode = trxnResponse.getResult();

            responseMap.put("PAYMENT_TRANSACTION_ID", trxnResponse.getPnref());
            responseMap.put("PAYMENT_RESPONSE",       trxnResponse.getRespMsg());
            responseMap.put("RESULT_CODE",            resultCode.toString());
            responseMap.put("AUTH_CODE",              trxnResponse.getAuthCode());
            // Added field to handle response text from multiple gateways
            responseMap.put("PAYMENT_STATUS", trxnResponse.getRespMsg());
        }
        return responseMap;
    }

    // ==========================================

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getPurchaseOrderNumber() {
        return purchaseOrderNumber;
    }

    public void setPurchaseOrderNumber(String purchaseOrderNumber) {
        this.purchaseOrderNumber = purchaseOrderNumber;
    }

    public String getBillToStreet() {
        return billToStreet;
    }

    public void setBillToStreet(String billToStreet) {
        this.billToStreet = billToStreet;
    }

    public String getBillToZip() {
        return billToZip;
    }

    public void setBillToZip(String billToZip) {
        this.billToZip = billToZip;
    }

    public String getCreditCardNo() {
        return creditCardNo;
    }

    public void setCreditCardNo(String creditCardNo) {
        this.creditCardNo = creditCardNo;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }
}
