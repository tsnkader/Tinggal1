
package com.queppelin.wudstay.util;


public class WudstayConstants {

	public static final String MESSAGES = "wudstay.properties";

	public static final String EMPTY = "EMPTY";
	
	public static final String OK = "OK";

	public static final String MESSAGE_KEY_NOT_FOUND = "Message key not found in the properties file";

	public static final String FETCH_HOTEL_ERROR = "FETCH_HOTEL_ERROR";
	
	public static final String FETCH_CITY_ERROR = "FETCH_CITY_ERROR";
	
	public static final String FETCH_LOCATION_ERROR = "FETCH_LOCATION_ERROR";
	
	public static final String FETCH_HOTEL_ROOM_ERROR = "FETCH_HOTEL_ROOM_ERROR";

	public static final String SPACE = " ";

	public static final String GUESTS = "Guests";

	public static final String IN = "in";

	public static final String ROOMS = "Rooms";

	public static final String PRICE = "price";
	
	public static final String RATING = "rating";

	public static final String BLANK = "";

	public static final String COMMA_REGEX = "\\s*,\\s*";

	public static final String TO = "to";

	public static final String LOGIN_PAGE = "login";

	public static final String COMMA = ",";

	public static final String SHOW_HOTEL_BOOKINGS_PAGE = "showHotelBookings";

	public static final String LOGIN_ERROR = "LOGIN_ERROR";

	public static final String SUCCESS = "Success";
	
	public static final String FAILURE = "Failure";

	public static final String ERROR = "Error";

	public static final String SEARCH_HOTELS = "searchHotels";

	public static final String PERMATA = "permata";

	public static final String USER = "user";
	
	public static final String FETCH_HOTEL_BOOKINGS_ERROR = "FETCH_HOTEL_BOOKINGS_ERROR";

	public static final String ADD_HOTEL_PAGE = "addHotel";

	public static final String FETCH_HOTEL_AMENITIES_ERROR = "FETCH_HOTEL_AMENITIES_ERROR";

	public static final String HOTEL_ADMIN = "Hotel Admin";

	public static final String SHOW_HOTEL_DETAILS_PAGE = "showHotelDetails";

	public static final String FETCH_HOTEL_DETAILS_ERROR = "FETCH_HOTEL_DETAILS_ERROR";

	public static final String FETCH_HOTEL_DESCRIPTION_ERROR = "FETCH_HOTEL_DESCRIPTION_ERROR";

	public static final String FETCH_HOTEL_ADMINISTRATOR_ERROR = "FETCH_HOTEL_ADMINISTRATOR_ERROR";
	
	public static final String SHOW_HOTELS_PAGE = "showHotels";

	public static final String EDIT_HOTEL_DETAILS_PAGE = "editHotelDetails";

	public static final String FETCH_ROOM_TYPE_ERROR = "FETCH_ROOM_TYPE_ERROR";

	public static final String ADD_HOTEL_ERROR = "ADD_HOTEL_ERROR";

	public static final String DELETE_HOTEL_ROOMS_ERROR = "DELETE_HOTEL_ROOMS_ERROR";

	public static final String DELETE_HOTEL_AMENITIES_ERROR = "DELETE_HOTEL_AMENITIES_ERROR";

	public static final String DELETE_HOTEL_DESCRIPTIONS_ERROR = "DELETE_HOTEL_DESCRIPTIONS_ERROR";

	public static final String UPDATE_HOTEL_SUCCESS = "UPDATE_HOTEL_SUCCESS";

	public static final String UPDATE_HOTEL_ERROR = "UPDATE_HOTEL_ERROR";

	public static final String CHECKING_DUPlICATE_USERNAME_ERROR = "CHECKING_DUPlICATE_USERNAME_ERROR";

	public static final String SUPER_ADMIN = "Super Admin";

	public static final Integer DEFAULT_ROOMS = Integer.valueOf(1);

	public static final Integer DEFAULT_PERSONS = Integer.valueOf(1);

	public static final String SEARCH_PARAM_MAP = "searchParamsHashMap";

	public static final String BOOKING_DETAILS = "Booking Details";

	public static final String MOBILE_NUMBER_VERIFICATION_ERROR = "MOBILE_NUMBER_VERIFICATION_ERROR";
	
	public static final String FETCH_CUSTOMER_VERIFICATION_DETAILS_ERROR = "FETCH_CUSTOMER_VERIFICATION_DETAILS_ERROR";
	
	public static final String MAKE_BOOKING_ERROR = "MAKE_BOOKING_ERROR";

	public static final String BOOKING_CONFIRM_PAGE = "bookingConfirm";
	
	public static final String ENCODING_UTF_8 =  "UTF-8";

	public static final String BOOKING_CONFIRMATION_EMAIL_BODY = "bookingConfirmationEmailBody.vm";
	public static final String BOOKING_CONFIRMATION_PRE_PAID_EMAIL_BODY = "bookingConfirmationPrepaidEmailBody.vm";

	public static final String ADD_CITY_PAGE = "addCity";

	public static final String SHOW_CITIES_PAGE = "showCities";
	
	public static final String ADD_LOCATION_PAGE = "addLocation";

	public static final String SHOW_LOCATIONS_PAGE = "showLocations";

	public static final String PRIVACY_POLICY = "privacyPolicy";

	public static final String REGISTERED_MOBILE_NUMBER_CHEKING_ERROR = "REGISTERED_MOBILE_NUMBER_CHEKING_ERROR";

	public static final String ABOUT_US = "aboutUs";

	public static final String CONTACT_US = "contactUs";

	public static final String CANCELLATION_POLICY = "cancellationPolicy";

	public static final String TERMS_AND_CONDITION = "termsAndCondition";

	//public static final String BASE_URL = "http://54.251.116.126:8080/wudstay/";
	
	//public static final String BASE_URL = "http://www.wudstay.com/";
	
	public static final String BASE_URL = "http://orthopluscenter.com/";
	
	//public static final String BASE_URL = "http://192.168.1.6:8080/wudstay/";

	public static final String PAYU_DETAILS = "PAYU DETAILS";

	public static final String TEST_MERCHANT_KEY = "gtKFFx";

	public static final String TEST_SALT = "eCwWELxi";
	
	public static final String LIVE_MERCHANT_KEY = "44fZt5";

	public static final String LIVE_SALT = "t5vIbSb7";

	public static final String ENCRYPT_PASSWORD_ERROR = "ENCRYPT_PASSWORD_ERROR";

	public static final String PAYPAL_USER_NAME     = "WS032016";
	public static final String PAYPAL_MERCHANT_NAME = PAYPAL_USER_NAME;
	public static final String PAYPAL_PASSWORD      = "Hello1234";
	public static final String PAYPAL_PARTNER_NAME  = "PayPal";

	
	
	//CustomerCare
	
	public static final String CUSTOMER_CARE_ADMIN = "Cutomer Care Admin";
	
	public static final String CUSTOMER_CARE_DETAILS = "customerCareDetails";
	
	
	//Dynamic Exception Page

	public static final String DYNAMIC_EXCEPTION = "exceptionPage";

	public static final String HASH = "#";
	public static final String SEPARATOR_1 = "<#>";

	//Corporate Portal

	public static final String CORPORATE_PORTAL = "Corporate Admin";

	public static final String SHOW_CORP_BOOKINGS_PAGE = "showCorpBookings";

	public static final String SHOW_BULK_BOOKINGS_PAGE = "addBulkBooking";

	public static final String SHOW_CORP_HOTELS_PAGE = "showCorpHotels";

	public static final String SHOW_ADD_CORP_PAGE = "addCorporate";

	public static final String SHOW_CORP_PAGE = "viewCorporates";

	public static final String CORP_CorporateVO = "corp_CorporateVO";
	public static final String CORP_CorporateLoginVO = "corp_CorporateLoginVO";

	public static final String SHOW_APPROVE_BOOKING_PAGE = "approveCorporateBookings";

	public static final String SHOW_APPROVE_BOOKING_DETAILS_PAGE = "approveCorporateBookingsDetails";
	
	//Dynamic Exception Page
		public static final String MOBILE_APP_TYPE_ANDROID = "ANDROID";
		public static final String MOBILE_APP_TYPE_WINDOWS = "WINDOWS";
		public static final String MOBILE_APP_TYPE_IPHONE  = "IPHONE";
	public static final String MOBILE_APP_TYPE_ANY  = "MOBILE";
	public static final String WEB_APP_TYPE_ONLINE = "WEB";
	public static final String WEB_APP_TYPE_CUST_CARE = "CUST_CARE";
	public static final String WEB_APP_TYPE_CORP = "CORP";
	public static final String WEB_APP_TYPE_UNKNOWN = "UNKNOWN";
	public static final String WEB_APP_TYPE_MOBILE_WEB = "MOBILE-WEB";
		public static final String FETCH_MOBILE_APP_VERSION_ERROR = "FETCH_MOBILE_APP_VERSION_ERROR";

	public static final String ROOM_TYPE_SINGLE = "Single";
	public static final String ROOM_TYPE_DOUBLE = "Double";
	public static final String ROOM_TYPE_TRIPLE = "Triple";

	public static final String CORP_BOOKING_CONFIRMATION_EMAIL_BODY = "corpBookingConfirmationEmailBody.vm";
	public static final String CORP_ADMIN_BOOKING_VOUCHER_EMAIL_BODY = "corpAdminBookingVoucherEmailBody.vm";
	public static final String CORP_HOTEL_ADMIN_BOOKING_VOUCHER_EMAIL_BODY = "corpAdminBookingVoucherEmailBody_hotel.vm";

	public static final String ADD_CUST_CARE_BOOKING_PAGE = "custCareBooking";
	public static final String ADD_CUST_CARE_BOOKING_SUMMARY_PAGE = "bookingSummary";

	public static final String BOOKING_CANCELLATION_EMAIL_BODY_CUST = "bookingCancellationCustEmail.vm";
	public static final String BOOKING_CANCELLATION_EMAIL_BODY_HOTEL = "bookingCancellationHotelEmail.vm";

	public static final int SOURCE_OF_BOOKING_ANDROID = 21; //sourceOfBooking
	public static final int SOURCE_OF_BOOKING_WINDOWS = 23;
	public static final int SOURCE_OF_BOOKING_IPHONE  = 22;
	public static final int SOURCE_OF_BOOKING_MOBILE  = 20;
	//public static final int SOURCE_OF_BOOKING_WEB = 10;
	public static final int SOURCE_OF_BOOKING_WEB = 2;
	public static final int SOURCE_OF_BOOKING_DEFAULT = 11;
	public static final int SOURCE_OF_BOOKING_CUST_CARE = 12 ; //WudstayConstants.SOURCE_OF_BOOKING_CUST_CARE
	public static final int SOURCE_OF_BOOKING_CORP = 13 ;
	public static final int SOURCE_OF_BOOKING_MOBILE_WEB = 14;


   //WudstayConstants.getSourceOfBooking WudstayConstants.getSourceOfBooking(SOURCE_OF_BOOKING_WEB, int defaultValue)
	public static final int getSourceOfBooking(String source, int defaultValue){
		if(source==null || "".equals(source.trim()) || "null".equalsIgnoreCase(source.trim())){
			return defaultValue;
		}else if(WudstayConstants.MOBILE_APP_TYPE_ANDROID.equalsIgnoreCase(source.trim())){
			return WudstayConstants.SOURCE_OF_BOOKING_ANDROID; // "ANDROID"
		}else if(WudstayConstants.MOBILE_APP_TYPE_IPHONE.equalsIgnoreCase(source.trim())){
			return WudstayConstants.SOURCE_OF_BOOKING_IPHONE;// IPHONE;
		}else if(WudstayConstants.MOBILE_APP_TYPE_WINDOWS.equalsIgnoreCase(source.trim())) {
			return WudstayConstants.SOURCE_OF_BOOKING_WINDOWS;// "WINDOWS";

		}else if(WudstayConstants.WEB_APP_TYPE_ONLINE.equalsIgnoreCase(source.trim())) {
			return WudstayConstants.SOURCE_OF_BOOKING_WEB;//10;
		}else if(WudstayConstants.WEB_APP_TYPE_CUST_CARE.equalsIgnoreCase(source.trim())) {
			return WudstayConstants.SOURCE_OF_BOOKING_CUST_CARE;//12;
		}else if(WudstayConstants.WEB_APP_TYPE_CORP.equalsIgnoreCase(source.trim())) {
			return WudstayConstants.SOURCE_OF_BOOKING_CORP;//13;
		}else if(WudstayConstants.WEB_APP_TYPE_MOBILE_WEB.equalsIgnoreCase(source.trim())) {
			return WudstayConstants.SOURCE_OF_BOOKING_MOBILE_WEB;//14;
		}else{
			return defaultValue;
		}
	}
	//WudstayConstants.getSourceOfBooking
	public static final String getSourceOfBooking(Integer source){
		if(source==null || source.intValue()==0){
			return WudstayConstants.WEB_APP_TYPE_UNKNOWN;
		}else if(source.intValue() == WudstayConstants.SOURCE_OF_BOOKING_MOBILE){
			return WudstayConstants.MOBILE_APP_TYPE_ANY; // "ANDROID"
		}else if(source.intValue() == WudstayConstants.SOURCE_OF_BOOKING_ANDROID){
			return WudstayConstants.MOBILE_APP_TYPE_ANDROID;//21;
		}else if(source.intValue() == WudstayConstants.SOURCE_OF_BOOKING_IPHONE){
			return WudstayConstants.MOBILE_APP_TYPE_IPHONE;//22;
		}else if(source.intValue() == WudstayConstants.SOURCE_OF_BOOKING_WINDOWS) {
			return WudstayConstants.MOBILE_APP_TYPE_WINDOWS;//WINDOWS;

		}else if(source.intValue() == WudstayConstants.SOURCE_OF_BOOKING_WEB) {
			return WudstayConstants.WEB_APP_TYPE_ONLINE;//10;
		}else if(source.intValue() == WudstayConstants.SOURCE_OF_BOOKING_CUST_CARE) {
			return WudstayConstants.WEB_APP_TYPE_CUST_CARE;//12;
		}else if(source.intValue() == WudstayConstants.SOURCE_OF_BOOKING_CORP) {
			return WudstayConstants.WEB_APP_TYPE_CORP;
		}else if(source.intValue() == WudstayConstants.SOURCE_OF_BOOKING_MOBILE_WEB) {
			return WudstayConstants.WEB_APP_TYPE_UNKNOWN;
		}else{
			return WudstayConstants.WEB_APP_TYPE_UNKNOWN;
		}
	}

	public static final String HDFC_RESPONSE_PAGE = "response";
	public static final String ADD_PG_PAGE = "addPg"; //"addHotel";
	public static final String SCHEDULE_CONFIRM_PAGE = "scheduleConfirm"; // "bookingConfirm";

	public static final String VISIT_CONFIRMATION_EMAIL_BODY = "pgVisitSchedulingEmailBody.vm";

	public static final Integer DEFAULT_PG_ROOMS = Integer.valueOf(1);

	public static final Integer DEFAULT_PG_PERSONS = Integer.valueOf(3);


}
