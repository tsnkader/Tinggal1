package com.queppelin.wudstay.util;

import com.queppelin.wudstay.util.WudstayCorpBookingUtil;
import java.io.File;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import org.apache.velocity.app.VelocityEngine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.ui.velocity.VelocityEngineUtils;

@Service
public class EmailSender {
    private static final Logger logger = LoggerFactory.getLogger((Class)EmailSender.class);
    @Autowired
    private static JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
    private static VelocityEngine velocityEngine;
    private static EmailSender self;
    private static String fromAddress;
    private static String[] ccList;

    @Autowired
    public void setVelocityEngine(VelocityEngine ve) {
        velocityEngine = ve;
    }

    private EmailSender() {
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
	public static EmailSender getInstance(){
		if(self == null){
			synchronized (EmailSender.class) {
				if(self == null){
					self = new EmailSender();
					self.setConfiguration();					
				}
				else{
					return self;
				}
			}
		}
		return self;
	}

    public void setConfiguration() {
        mailSender.setHost("email-smtp.us-west-2.amazonaws.com");
        mailSender.setPort(25);
        mailSender.setUsername("AKIAJGWKHKQ4TVTSFQJQ");
        mailSender.setPassword("AvNclX+FqOT2ecasfordZcWpw5HC7WdjD/qN/hvPX/VL");
        Properties properties = new Properties();
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.starttls.required", "true");
        mailSender.setJavaMailProperties(properties);
        fromAddress = "bookings@tinggal.com";
        ///fromAddress = "arjun@tinggal.com";
    }

    public void sendEmail(String to, String subject, Map<String, Object> hTemplateVariables, String emailBody, List<String> ccList) throws MessagingException {
        String[] bccArray = new String[]{"prafulla@wudstay.com", "arjun@tinggal.com", "hendry@tinggal.com", "support@tinggal.com", "surender.r@wudstay.com"};
        this.sendEmail(to, subject, hTemplateVariables, emailBody, ccList, bccArray);
    }

    public void sendEmail_2(String to, String subject, Map<String, Object> hTemplateVariables, String emailBody, List<String> ccList, String[] bccArray) throws MessagingException {
        this.sendEmail(to, subject, hTemplateVariables, emailBody, ccList, bccArray);
    }

    public void sendEmail(String to, String subject, Map<String, Object> hTemplateVariables, String emailBody, List<String> ccList, String[] bccArray) throws MessagingException {
        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true);
        String toAddress = to.replaceAll(" ", "");
        String[] toArray = toAddress.split(",");
        helper.setTo(toArray);
        helper.setSubject(subject);
        helper.setFrom(new InternetAddress(fromAddress));
        String body = VelocityEngineUtils.mergeTemplateIntoString((VelocityEngine)velocityEngine, (String)emailBody, (String)"UTF-8", hTemplateVariables);
        System.out.println("=========================================================================================");
        try {
            System.out.println("Email: TO:      " + toArray.toString());
            System.out.println("Email: subject: " + subject);
            System.out.println("Email: CC:      " + ccList.toString());
            System.out.println("Email: BCC:     " + Arrays.toString(bccArray));
            System.out.println("=========================================================================================");
            System.out.println(body);
            System.out.println("=========================================================================================");
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        helper.setText(body, true);
        if (emailBody.equals("bookingConfirmationEmailBody.vm")) {
            FileSystemResource emaillogoResource = new FileSystemResource(new File("/home/ubuntu/wudstay/mail_images/tinggal_logo_mail.png"));
            helper.addInline("emaillogo", (Resource)emaillogoResource);
            FileSystemResource timeiconResource = new FileSystemResource(new File("/home/ubuntu/wudstay/mail_images/time_icon.png"));
            helper.addInline("timeicon", (Resource)timeiconResource);
            FileSystemResource custcareiconResource = new FileSystemResource(new File("/home/ubuntu/wudstay/mail_images/customer_care_tinggal.png"));
            helper.addInline("custcareicon", (Resource)custcareiconResource);
        } else {
            FileSystemResource logoResource = new FileSystemResource(new File("/home/ubuntu/wudstay/mail_images/logo.png"));
            helper.addInline("logo", (Resource)logoResource);
            FileSystemResource thanksIconResource = new FileSystemResource(new File("/home/ubuntu/wudstay/mail_images/thanks-icon.png"));
            helper.addInline("thanks-icon", (Resource)thanksIconResource);
            FileSystemResource icon01Resource = new FileSystemResource(new File("/home/ubuntu/wudstay/mail_images/icon01.png"));
            helper.addInline("icon01", (Resource)icon01Resource);
            FileSystemResource icon02Resource = new FileSystemResource(new File("/home/ubuntu/wudstay/mail_images/icon02.png"));
            helper.addInline("icon02", (Resource)icon02Resource);
            FileSystemResource icon03Resource = new FileSystemResource(new File("/home/ubuntu/wudstay/mail_images/icon03.png"));
            helper.addInline("icon03", (Resource)icon03Resource);
            FileSystemResource rsResource = new FileSystemResource(new File("/home/ubuntu/wudstay/mail_images/Rp.png"));
            helper.addInline("Rp", (Resource)rsResource);
            FileSystemResource rsImagesResource = new FileSystemResource(new File("/home/ubuntu/wudstay/mail_images/rp-images.png"));
            helper.addInline("rp-images", (Resource)rsImagesResource);
            FileSystemResource printResource = new FileSystemResource(new File("/home/ubuntu/wudstay/mail_images/print.png"));
            helper.addInline("print", (Resource)printResource);
        }
        if (ccList != null) {
            String[] ccArray = new String[ccList.size()];
            ccArray = ccList.toArray(ccArray);
            helper.setCc(ccArray);
        }
        helper.setBcc(bccArray);
        try {
            mailSender.send(message);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            logger.error("Error in send e-mail to", (Throwable)ex);
            System.out.println("\nError in send e-mail to " + toArray.toString());
        }
    }

    public void sendEmailWithoutImage(String commaSeparatedToEmailIds, String subject, Map<String, Object> hTemplateVariables, String emailBody, List<String> ccList) throws MessagingException {
        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true);
        String toAddress = commaSeparatedToEmailIds.replaceAll(" ", "");
        String[] toArray = toAddress.split(",");
        helper.setTo(toArray);
        helper.setSubject(subject);
        helper.setFrom(new InternetAddress(fromAddress));
        String body = VelocityEngineUtils.mergeTemplateIntoString((VelocityEngine)velocityEngine, (String)emailBody, (String)"UTF-8", hTemplateVariables);
        System.out.println("=========================================================================================");
        try {
            System.out.println("Email: TO:      " + WudstayCorpBookingUtil.arrayToCsv((String[])toArray));
            System.out.println("Email: CC:      " + WudstayCorpBookingUtil.listToCsv(ccList));
            System.out.println("Email: subject: " + subject);
            System.out.println("=========================================================================================");
            System.out.println(body);
            System.out.println("=========================================================================================");
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        helper.setText(body, true);
        if (ccList != null) {
            String[] ccArray = new String[ccList.size()];
            ccArray = ccList.toArray(ccArray);
            helper.setCc(ccArray);
        }
        helper.setBcc(new String[]{"prafulla@wudstay.com", "arjun@tinggal.com", "hendry@tinggal.com", "support@tinggal.com", "surender.r@wudstay.com"});
        mailSender.send(message);
    }
}