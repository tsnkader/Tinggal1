package com.queppelin.wudstay.util;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by hp on 5/18/2016.
 */
public class VtResponse implements java.io.Serializable {
    /*private String statusCode;
    private String transactionId;
    private String orderId;
    private String paymentMethod;
    private Date transactionTime;
    private TransactionStatus transactionStatus;
    private String approvalCode;
    private BigDecimal grossAmount;
    private FraudStatus fraudStatus;
    private String maskedCardNumber;

    private String statusMessage;
    private String permataVaNumber;
    private String signatureKey;
    private String cardToken;
    private String savedCardToken;
    private Date savedCardTokenExpiredAt;
    private Boolean secureToken;
    private id.co.veritrans.mdk.v1.gateway.model.vtdirect.paymentmethod.CreditCard.Bank bank;
    private String billerCode;
    private String billKey;
    private String xlTunaiOrderId;
    private String biiVaNumber;
    private String redirectUrl;
    private String eci;
    private String validationMessages[];
    private Integer page;
    private Integer totalPage;
    private Integer totalRecord;
    private OrderStatus listTransactionStatus[];
    private String customField1;
    private String customField2;
    private String customField3;*/







}
