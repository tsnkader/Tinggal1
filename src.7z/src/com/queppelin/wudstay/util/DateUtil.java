package com.queppelin.wudstay.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class DateUtil {
    private static SimpleDateFormat dateFormat_ddMMyyyy = new SimpleDateFormat("dd/MM/yyyy");
    private static SimpleDateFormat dateFormat_yyyyMMdd = new SimpleDateFormat("yyyyMMdd");
    private static final Logger logger = LoggerFactory.getLogger(DateUtil.class);
    public static String[] namesOfDays = {"SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"};
    public static String[] monthNames = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};

    private Calendar cal = Calendar.getInstance();
    public static boolean isValidDate(int day, int month, int year) {
        int daysInMonth=0;
        if (month >= 1 && month <= 12) {
            if (year >= 1590 && year <= 2400) {
                if(day >= 1) {

                    if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12)
                        daysInMonth = 31;
                    else if (month == 4 || month == 6 || month == 9 || month == 11)
                        daysInMonth = 30;
                    else if (month == 2) {
                        daysInMonth = 28;
                        boolean leapyear = ((year % 4) == 0 && ((year % 100) != 0) || (year % 400) == 0);
                        if (leapyear)
                            daysInMonth = 29;
                    }

                    if (day <= daysInMonth) {
                        return true;
                    } else {
                        throw new IllegalArgumentException("Invalid Day" + day);
                    }
                }else{
                    throw new IllegalArgumentException("Invalid Day" + day);
                }
            } else {
                throw new IllegalArgumentException("Invalid Year" + year);
            }
        } else {
            throw new IllegalArgumentException("Invalid Month " + month);
        }
    }

    public DateUtil(int day, int month, int year) {
        isValidDate(day, month, year);//DateUtil.isValidDate(day, month, year);
        cal.set(Calendar.MONTH, month -1);// month -- Value to be used for MONTH field. 0 is January //Calendar set(Calendar.MONTH, month)
        cal.set(Calendar.YEAR, year);
        cal.set(Calendar.DAY_OF_MONTH, day);// This is necessary to get proper results
        //cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE));
    }
    public DateUtil(String ddMMyyyyDate){
       this(DateUtil.toDisplayDate(ddMMyyyyDate));
    }

    public DateUtil(int month, int year) {
        this(1, month, year);
    }

    public DateUtil(Date date) {
        cal.setTime(date);
    }

    public DateUtil() {
        cal.setTime(new Date());
    }

    public Date toDate() {
        return toDate(cal.getTime());
    }
    public static Date toDate(Date dt) {
        long time = dt.getTime();
        return new Date(time);
    }

    public Date moveLastDay() {
        cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE));
        return toDate();
    }

    public Date moveFirstDay() {
        cal.set(Calendar.DATE, cal.getActualMinimum(Calendar.DATE));
        return toDate();
    }

    public Date moveNexDay() {
        cal.add(Calendar.DATE, 1);
        return toDate();
    }
    public Date movePreviousDay() {
        cal.add(Calendar.DATE, -1);
        return toDate();
    }
    public Date moveNexMonth() {
        cal.add(Calendar.MONTH, 1);
        return toDate();
    }
    public Date movePreviousMonth() {
        cal.add(Calendar.MONTH, -1);  //adding a month directly - gives the start of next month.
        return toDate();
    }
    //SUN -->   1
    public int dayOfWeek() {
        return cal.get(Calendar.DAY_OF_WEEK);
    }

    public String getWeekDayName() {
        int day = cal.get(Calendar.DAY_OF_WEEK);
        return namesOfDays[day - 1];
    }

    public int getDay() {
        return cal.get(Calendar.DAY_OF_MONTH);
    }

    public int getMonth() {
        return cal.get(Calendar.MONTH)+1;
    }

    public int getYear() {
        return cal.get(Calendar.YEAR);
    }

    public int getLastDayOfMonth() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE));
        return c.get(Calendar.DAY_OF_MONTH);
    }

    public int getMaxDayInMonth(){
        return cal.getActualMaximum(Calendar.DAY_OF_MONTH);
    }

    public static String[] getMonthlyAttendaceArray(int month, int year) {
        DateUtil toDayDateUtil = new DateUtil(new Date());
        int toDay = toDayDateUtil.getDay();

        DateUtil dateUtil = new DateUtil(month, year);
        //int toDay = dateUtil.getDay();
        dateUtil.moveLastDay();
        int lastDay = dateUtil.getDay();
        dateUtil.moveFirstDay();
        String[] day01_31 = new String[31];
        dateUtil.moveFirstDay();
        //int firstDay = dateUtil.getDay();
        int i = 1;
        for (; i <= lastDay; i++) {
            if ("SUN".equalsIgnoreCase(dateUtil.getWeekDayName())) {
                day01_31[i - 1] = "H";
            } else if (i <= toDay) {
                day01_31[i - 1] = "P";
            } else {
                day01_31[i - 1] = "-";
            }
            dateUtil.moveNexDay();
        }
        for (; i <= 31; i++) {
            day01_31[i - 1] = "X";
        }
        return day01_31;
    }


    public static int daysBetween(String firstDate, String secondDate) throws ParseException {
        String dateFormat ="dd/MM/yyyy";
        return daysBetween(firstDate, secondDate, dateFormat);

    }
    public static int daysBetween(String firstDate, String secondDate, String dateFormat) throws ParseException {
        Calendar cal1 = new GregorianCalendar();
        Calendar cal2 = new GregorianCalendar();

        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);

        Date date = sdf.parse(firstDate);
        cal1.setTime(date);
        date = sdf.parse(secondDate);
        cal2.setTime(date);

        //cal1.set(2008, 8, 1);
        //cal2.set(2008, 9, 31);
        //System.out.println("Days= "+daysBetween(cal1.getTime(), cal2.getTime()));

        Date d1 = cal1.getTime();
        Date d2 = cal2.getTime();

        return (int)( (d2.getTime() - d1.getTime()) / (1000 * 60 * 60 * 24));

    }

    public String getMonthFullName() {
        //return cal.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.ENGLISH );
        return new String(monthNames[getMonth()-1]);
    }

    public long getDifferenceInDays(Date d2) {
        Date d1 = toDate();
        long diff = d2.getTime() - d1.getTime();
        return TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
    }

    /*public long getDifferenceInDays(Date d1, Date d2) {
        SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
        Date d1 = toDate();
        long diff = d2.getTime() - d1.getTime();
        return TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
    }*/

    public static Long toLongDate(Date date){
        if(date==null)
            return 0L;
        try {
            String strDate = dateFormat_yyyyMMdd.format(date);
            return Long.parseLong(strDate);
        } catch (Exception e) {
            return 0L;
        }
    }
    public static String toDisplayDate(Date date){
        if(date==null)
            return null;
        try {
            return dateFormat_ddMMyyyy.format(date);
        } catch (Exception e) {
            return null;
        }
    }
    public static Date toDisplayDate(String date){
        try {
            return dateFormat_ddMMyyyy.parse(date);
        } catch (ParseException e) {
            return null;
        }
    }

    public String getRdNdStFormate() {
        SimpleDateFormat dd = new SimpleDateFormat("d");
        SimpleDateFormat mmyyyy = new SimpleDateFormat("MMM, yyyy");

        int day = getDay();
        Date date = toDate();
        String daySuffix = "";

        switch (day) {
            case 1: case 21: case 31:
                daySuffix = "st" ;
                break;
            case 2: case 22:
                daySuffix = "nd";
                break;
            case 3: case 23:
                daySuffix = "rd";
                break;
            default:
                daySuffix = "th";
        }

        String formattedDate = dd.format(date) + daySuffix + " " + mmyyyy.format(date);
        return formattedDate;
    }
}
