package com.queppelin.wudstay.util;

import com.queppelin.wudstay.vo.custom.wibmo.DataPickupRequest;
import com.queppelin.wudstay.vo.custom.wibmo.MerchantInfo;
import com.queppelin.wudstay.vo.custom.wibmo.WPayDataPickupResponse;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.NoSuchAlgorithmException;

import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by hp on 11/17/2015.
 */
public class WibmoInAppMerchantUtility {
    private static final Logger logger = LoggerFactory.getLogger(WibmoInAppMerchantUtility.class);

    //for localhost testing only
    static {
        javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
                new javax.net.ssl.HostnameVerifier(){
                    public boolean verify(String hostname, javax.net.ssl.SSLSession sslSession) {
                        return true;
                    }
                });
    }

    public static String transactionalAmount(String amountStr){
        String txnAmt = "0";
        try{
            Double d = Double.parseDouble(amountStr);
            long amt = Math.round(d * 100);
            txnAmt = String.valueOf(amt);
            return txnAmt;
        }catch (Exception ex){
            ex.printStackTrace();
            return txnAmt;
        }
    }

    /*
        Format used to hash:
        wpay|<merchant_id>|<mer_app_id>|<mer_txn_id>|<mer_ap_data>|<txn_amount>|<txn_currency>|<supported_payment_type>|<hashkey>|

        urlEncode : pass true, if generated hash has to be encoded.
    */
    public static String generateWPayInitReqHash(String merId, String merAppId, String merTxnId,
                                                 String merAppData, String txnAmount, String txnCurrency,
                                                 String supportedPaymentType, String hashKey, boolean urlEncode) throws NoSuchAlgorithmException, UnsupportedEncodingException, NullPointerException {

        java.security.MessageDigest messageDigest = null;
        try {
            //messageDigest = java.security.MessageDigest.getInstance("SHA-1");
            messageDigest = java.security.MessageDigest.getInstance("SHA-256");
            //SSR messageDigest =java.security.MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException nsae) {
            logger.error("SEVERE: Exception {0} : " + nsae.getMessage());
            throw nsae;
        }
        //Base64(sha1(wpay|<merchant_id>|<mer_app_id>|<mer_txn_id>|<wibmo_txn_id>|<datapickup_code>|<hashkey>|))
        StringBuilder serverMsg = new StringBuilder();
        serverMsg.append("wpay").append("|");
        serverMsg.append(merId).append("|");
        serverMsg.append(merAppId).append("|");
        serverMsg.append(merTxnId).append("|");

        if(merAppData!=null){
            serverMsg.append(merAppData).append("|");
        }else{
            serverMsg.append("|");
        }

        if(txnAmount==null) {
            logger.error("Transaction amount cannot be null");
            throw new NullPointerException("Transaction amount cannot be null");
        }

        serverMsg.append(txnAmount).append("|");
        serverMsg.append(txnCurrency).append("|");
        serverMsg.append(supportedPaymentType).append("|");
        serverMsg.append(hashKey).append("|");

        String initReqMsgHash = serverMsg.toString();
        try {
            initReqMsgHash = new String(Base64.encode(messageDigest.digest(initReqMsgHash.getBytes("UTF-8"))));
        } catch(Exception e) {
            e.printStackTrace();
        }

        return initReqMsgHash;
    }

    /*
        Format used to hash:
        wpay|<merchant_id>|<mer_app_id>|<mer_txn_id>|<wibmo_txn_id>|<datapickup_code>|<hashkey>|

        urlEncode : pass true, if generated hash has to be encoded.
    */
    public static String generateWpayPickupReqMsgHash(MerchantInfo merchantInfo, String merchantTxnId, String wibmoTxnId, String dataPickupcode, String msgHashKey, boolean urlEncode) throws NoSuchAlgorithmException, UnsupportedEncodingException{

        if(msgHashKey==null){
            return null;
        }

        java.security.MessageDigest messageDigest = null;
        try {
            //messageDigest = java.security.MessageDigest.getInstance("SHA-1");
            messageDigest = java.security.MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException nsae) {
            logger.error("SEVERE: Exception {0} : " + nsae.getMessage());
            throw nsae;
        }

        StringBuilder pickReqMsgHashFormatStr = new StringBuilder();
        pickReqMsgHashFormatStr.append("wpay").append("|");
        pickReqMsgHashFormatStr.append(merchantInfo.getMerId()).append("|");
        pickReqMsgHashFormatStr.append(merchantInfo.getMerAppId()).append("|");
        pickReqMsgHashFormatStr.append(merchantTxnId).append("|");

        pickReqMsgHashFormatStr.append(wibmoTxnId).append("|");
        pickReqMsgHashFormatStr.append(dataPickupcode).append("|");
        pickReqMsgHashFormatStr.append(msgHashKey).append("|");

        String pickupReqMsgHash = pickReqMsgHashFormatStr.toString();

        logger.info("INFO: Hashing data: {0}: " + pickupReqMsgHash);
        try {
            pickupReqMsgHash = new String(Base64.encode(messageDigest.digest(pickupReqMsgHash.getBytes("UTF-8"))));
            if(urlEncode){
                pickupReqMsgHash = URLEncoder.encode(pickupReqMsgHash, "UTF-8");
            }
        } catch(UnsupportedEncodingException usee) {
            logger.error("SEVERE: Exception while encoding : " + usee.getMessage());
            throw usee;
        }
        logger.info("INFO: Hashed data: {0}: " + pickupReqMsgHash);
        return pickupReqMsgHash;
    }

    public static WPayDataPickupResponse pickupWpayDataFromWibmoServer(String wibmoDomain, DataPickupRequest pickupReq) throws Exception{
        try {
            //TODO: take this from property file
            boolean skipSSLCheck = true;

            Client client = null;
            if(skipSSLCheck) {
                client = JerseyClientHelper.createClient();
            } else {
                client = Client.create();
            }

            WebResource webResource = client.resource(wibmoDomain + "/v1/wPay/pickup");
            String jsonInput = pickupReq.toJSON();
            ClientResponse response = webResource.type("application/json").post(ClientResponse.class, jsonInput);

            if (response.getStatus() != 200) {
                throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
            }

            String outputRawJsonStr = response.getEntity(String.class);

            ObjectMapper outputJsonMapper = new ObjectMapper();
            return outputJsonMapper.readValue(outputRawJsonStr, WPayDataPickupResponse.class);
        } catch (Exception e) {
            logger.warn("WARNING: Exception : " + e.getMessage());
            throw e;
        }
    }
}
