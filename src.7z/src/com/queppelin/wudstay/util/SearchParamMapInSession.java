package com.queppelin.wudstay.util;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.IHotelBookingManager;
import com.queppelin.wudstay.manager.IHotelManager;
import com.queppelin.wudstay.vo.City;
import com.queppelin.wudstay.vo.CityWithHotelCountMVO;
import com.queppelin.wudstay.vo.Hotel;
import com.queppelin.wudstay.vo.custom.BookingDetailsVO;
import com.queppelin.wudstay.vo.custom.HotelAvailabilityVO;

import javax.servlet.http.HttpSession;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

/**
 * Created by hp on 12/31/2015.
 */
public class SearchParamMapInSession implements java.io.Serializable {
    private static final long serialVersionUID = -1416558226382783771L;
    public static final String SEARCH_PARAM_DATA_IN_SESSION = "searchParamsInSession";

    private static final SimpleDateFormat longFormattedDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private static final SimpleDateFormat shortIndianFormattedDate = new SimpleDateFormat("dd/MM/yyyy");

    public static final String checkIn_HHMMSS = WudstayUtil.getDefaultCheckInDate().substring(11);
    public static final String checkOut_HHMMSS = WudstayUtil.getDefaultCheckOutDate().substring(11);

    private String checkIn = WudstayUtil.getDefaultCheckInDate();
    private String checkOut = WudstayUtil.getDefaultCheckOutDate();
    private Integer rooms = WudstayConstants.DEFAULT_ROOMS;
    private Integer persons = WudstayConstants.DEFAULT_PERSONS;
    private CityWithHotelCountMVO selectedCity = null;
    private String seletedHotelOrPg="HOTEL";
    private Long selectedHotelId=null;



    public SearchParamMapInSession(CityWithHotelCountMVO selectedCity) {
        this.selectedCity = selectedCity;
    }

    public static String[] toCheckInOutDates(String daterange) {
        daterange = daterange.replaceAll("\\s+", ""); //removes all whitespaces and non visible characters such as tab, \n .
        String [] arrDateRange = daterange.split("-");
        String checkIn = arrDateRange[0];
        String checkOut = arrDateRange[1];
        return new String[]{checkIn, checkOut};
    }
    public void setCheckInOut(String daterange) {
        daterange = daterange.replaceAll("\\s+", ""); //removes all whitespaces and non visible characters such as tab, \n .
        String [] arrDateRange = daterange.split("-");
        String checkIn = arrDateRange[0];
        String checkOut = arrDateRange[1];

        try {
            this.setCheckIn(WudstayUtil.getFormattedCheckInDate(checkIn));
            this.setCheckOut(WudstayUtil.getFormattedCheckOutDate(checkOut));
        }catch (Exception ex){
            ex.printStackTrace();
            this.setCheckIn(WudstayUtil.getDefaultCheckInDate());
            this.setCheckOut(WudstayUtil.getDefaultCheckOutDate());
        }
    }
    public void setRoomsAndGuests(String wudstayGuestsAndRooms){
        wudstayGuestsAndRooms = wudstayGuestsAndRooms.replaceAll("\\s+","").replace("Guest", "").replace("Room", "").replace("(s)", "");
        String [] arrGuesrRoom = wudstayGuestsAndRooms.split(",");

        try {
            this.setRooms(Integer.parseInt(arrGuesrRoom[0]));
            this.setPersons(Integer.parseInt(arrGuesrRoom[1]));
        }catch (Exception ex){
            ex.printStackTrace();
            this.setRooms(WudstayConstants.DEFAULT_ROOMS);
            this.setPersons(WudstayConstants.DEFAULT_PERSONS);
        }
    }

    public String getCheckIn() {
        return checkIn;
    }

    public static Date toDate(String longOrShortDate){
        String hhmmss = "12:00:00";
        return toDate(longOrShortDate, hhmmss);
    }
    public static Date toDate(String longOrShortDate, String hhmmss){
        try {
            return longFormattedDate.parse(longOrShortDate); // yyyy-MM-dd HH:mm:ss
        } catch (ParseException e) {
            String strDt = longOrShortDate + " " + hhmmss;
            try{
                return shortIndianFormattedDate.parse(longOrShortDate); // dd/MM/yyyy
            }catch (ParseException e1) {
                e1.printStackTrace();
                return null;
            }
        }
    }

    public static String toValidStrDate(String longOrShortDate, String hhmmss){
        return longFormattedDate.format(toDate(longOrShortDate, hhmmss));
    }

    public void setCheckIn(String checkIn) {
        this.checkIn = toValidStrDate(checkIn, checkIn_HHMMSS);
    }

    public String getCheckOut() {
        return checkOut;
    }

    public void setCheckOut(String checkOut) {
        this.checkOut = toValidStrDate(checkOut, checkOut_HHMMSS);
    }

    public Integer getRooms() {
        return rooms;
    }

    public void setRooms(Integer rooms) {
        this.rooms = rooms;
    }

    public Integer getPersons() {
        return persons;
    }

    public void setPersons(Integer persons) {
        this.persons = persons;
    }

    public CityWithHotelCountMVO getSelectedCity() {
        return selectedCity;
    }

    public void setSelectedCity(CityWithHotelCountMVO selectedCity) {
        this.selectedCity = selectedCity;
    }

    public Long getCityId() {
        return selectedCity.getCityId();
    }

    public void setCityId(Long cityId) {
        selectedCity.setCityId(cityId);
    }

    public String getCityName() {
        return selectedCity.getCityName();
    }

    public void setCityName(String cityName) {
        selectedCity.setCityName(cityName);
    }
    //-------------------------------------
    public static Date getLongFormattedDateObject(String fromDate) throws ParseException {
        Calendar checkInDate = Calendar.getInstance();
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        checkInDate.setTime(dateFormat.parse(fromDate));
        checkInDate.set(Calendar.HOUR_OF_DAY, 12);
        checkInDate.set(Calendar.MINUTE, 0);
        checkInDate.set(Calendar.SECOND, 0);
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String formattedCheckInDate = format.format(checkInDate.getTime());
        //return formattedCheckInDate;
        return format.parse(formattedCheckInDate);
    }

    public Date getCheckOutDate() {
        try {
            return longFormattedDate.parse(checkOut);
        } catch (ParseException e) {
            return null;
        }
    }

    public void setCheckOutDate(Date checkOutDate) {
        //this.checkOutDate = checkOutDate;
    }

    public Date getCheckInDate() {
        try {
            return longFormattedDate.parse(checkIn);
        } catch (ParseException e) {
            return null;
        }
    }

    public void setCheckInDate(Date checkInDate) {
        //this.checkInDate = checkInDate;
    }

    public String getSeletedCheckIn() {
        return shortIndianFormattedDate.format(getCheckInDate());
    }

    public void setSeletedCheckIn(String seletedCheckIn) {
        //this.seletedCheckIn = seletedCheckIn;
    }

    public String getSeletedCheckOut() {
        return shortIndianFormattedDate.format(getCheckOutDate());
    }

    public void setSeletedCheckOut(String seletedCheckOut) {
        //this.seletedCheckOut = seletedCheckOut;
    }

    public String getSeletedHotelOrPg() {
        seletedHotelOrPg =  (seletedHotelOrPg == null || "".equals(seletedHotelOrPg.trim()) || "HOTEL".equalsIgnoreCase(seletedHotelOrPg.trim())) ? "HOTEL" : "PG";
        return seletedHotelOrPg;
    }

    public void setSeletedHotelOrPg(String seletedHotelOrPg1) {
        this.seletedHotelOrPg = seletedHotelOrPg1;
        this.seletedHotelOrPg =  (seletedHotelOrPg == null || "".equals(seletedHotelOrPg.trim()) || "HOTEL".equalsIgnoreCase(seletedHotelOrPg.trim())) ? "HOTEL" : "PG";
    }

    public Long getSelectedHotelId() {
        return selectedHotelId;
    }

    public void setSelectedHotelId(Long selectedHotelId) {
        this.selectedHotelId = selectedHotelId;
    }

    public HashMap<String, Object> getSearchParamMap(){
        HashMap<String, Object> searchParamsHashMap = new HashMap<String, Object>();
        searchParamsHashMap.put("checkIn",  checkIn);
        searchParamsHashMap.put("checkOut", checkOut);
        searchParamsHashMap.put("rooms",    rooms);
        searchParamsHashMap.put("persons",  persons);
        searchParamsHashMap.put("cityId",   getCityId());
        searchParamsHashMap.put("city",     getCityName());
        return searchParamsHashMap;
    }

    /*static public SearchParamMapInSession refreshSearchParamMap(HttpSession session, ICityManager cityManager) throws WudstayException {
        if(session == null || session.getAttribute(WudstayConstants.SEARCH_PARAM_MAP)==null){
            SearchParamMapInSession searchParamMapInSession = new SearchParamMapInSession(cityManager.getCityByIdWithHotelCount(2L));
            session.setAttribute(WudstayConstants.SEARCH_PARAM_MAP, searchParamMapInSession);
        }
    }*/


    static public SearchParamMapInSession refreshSearchParamMap(HttpSession session) throws WudstayException {
        SearchParamMapInSession searchParamMapInSession = null;
        if(session == null || session.getAttribute(SEARCH_PARAM_DATA_IN_SESSION)==null){
            try {
                searchParamMapInSession = new SearchParamMapInSession(new CityWithHotelCountMVO(2L, "Gurgaon"));
            }catch (Exception ex){
                ex.printStackTrace();
            }
        }else {
            searchParamMapInSession =  (SearchParamMapInSession) session.getAttribute(SEARCH_PARAM_DATA_IN_SESSION);
        }
        session.setAttribute(SEARCH_PARAM_DATA_IN_SESSION, searchParamMapInSession);
        return searchParamMapInSession;
    }
    static public SearchParamMapInSession refreshSearchParamMap(HttpSession session, CityWithHotelCountMVO selectedCity) throws WudstayException {
        SearchParamMapInSession searchParamMapInSession = refreshSearchParamMap( session);
        searchParamMapInSession.setSelectedCity(selectedCity);
        session.setAttribute(SEARCH_PARAM_DATA_IN_SESSION, searchParamMapInSession);
        return searchParamMapInSession;
    }
    static public SearchParamMapInSession refreshSearchParamMap(HttpSession session, CityWithHotelCountMVO selectedCity, String hotelOrPg)throws WudstayException {
        SearchParamMapInSession searchParamMapInSession = refreshSearchParamMap(session, selectedCity);
        searchParamMapInSession.setSeletedHotelOrPg(hotelOrPg);
        session.setAttribute(SEARCH_PARAM_DATA_IN_SESSION, searchParamMapInSession);
        return searchParamMapInSession;
    }
    static public SearchParamMapInSession cleanSearchParamMap(HttpSession session)throws WudstayException {
        session.removeAttribute(WudstayConstants.SEARCH_PARAM_MAP);
        session.removeAttribute(WudstayConstants.BOOKING_DETAILS);
        session.removeAttribute("totalAmountPaid");
        session.removeAttribute("isPaymentSuccess");
        session.removeAttribute("name");
        session.removeAttribute("email");
        session.removeAttribute("mobileNumber");
        session.removeAttribute(SEARCH_PARAM_DATA_IN_SESSION);

        SearchParamMapInSession searchParamMapInSession = refreshSearchParamMap(session);
        return searchParamMapInSession;
    }
    static public SearchParamMapInSession refreshSearchParamMap(HttpSession session, SearchParamMapInSession searchParamMapInSession)throws WudstayException {
        session.setAttribute(SEARCH_PARAM_DATA_IN_SESSION, searchParamMapInSession);
        return searchParamMapInSession;
    }

    static public SearchParamMapInSession refreshSearchParamMap(HttpSession session, String daterange1, String wudstayGuestsAndRooms1)throws WudstayException {
        SearchParamMapInSession searchParamMapInSession = refreshSearchParamMap(session);
        searchParamMapInSession.setCheckInOut(daterange1);
        searchParamMapInSession.setRoomsAndGuests(wudstayGuestsAndRooms1);

        session.setAttribute(SEARCH_PARAM_DATA_IN_SESSION, searchParamMapInSession);
        return searchParamMapInSession;
    }


    static public SearchParamMapInSession getSearchParamMap(HttpSession session){
        SearchParamMapInSession sessonData = null;
        try {
            return refreshSearchParamMap(session);
        } catch (Exception e) {
            e.printStackTrace();
            return sessonData;
        }
    }

    static public SearchParamMapInSession getAndRefreshSearchParamMap(HttpSession session, String daterange, int persons, int rooms){
        SearchParamMapInSession sessonData = null;
        try {
            sessonData = SearchParamMapInSession.refreshSearchParamMap(session, daterange, persons, rooms);
            return sessonData;
        } catch (WudstayException e) {
            e.printStackTrace();
            return sessonData;
        }
    }


    static public SearchParamMapInSession refreshSearchParamMap(HttpSession session, String daterange, int persons, int rooms)throws WudstayException {
        SearchParamMapInSession searchParamMapInSession = refreshSearchParamMap(session);
        searchParamMapInSession.setCheckInOut(daterange);

        searchParamMapInSession.setRooms(rooms);
        searchParamMapInSession.setPersons(persons );

        session.setAttribute(SEARCH_PARAM_DATA_IN_SESSION, searchParamMapInSession);
        return searchParamMapInSession;
    }


    public SearchParamMapInSession putSearchParamMapInSession(HttpSession session, City city){
        session.setAttribute(WudstayConstants.SEARCH_PARAM_MAP, getSearchParamHashMap(city.getCityName(), city.getCityId(), this.getCheckIn(), this.getCheckOut(), rooms, persons));
        return this;
    }
    public SearchParamMapInSession putSearchParamMapInSession(HttpSession session, Hotel hotel){
        City city = hotel.getLocation().getCity();
        return putSearchParamMapInSession( session, city);
    }

    static public  Object getSearchParamHashMap(String city, Long cityId, String checkIn, String checkOut, Integer rooms, Integer persons) {
        HashMap<String, Object> searchParamsHashMap = new HashMap<String, Object>();
        searchParamsHashMap.put("city", city);
        searchParamsHashMap.put("cityId", cityId);
        searchParamsHashMap.put("checkIn", checkIn);
        searchParamsHashMap.put("checkOut", checkOut);
        searchParamsHashMap.put("rooms", rooms);
        searchParamsHashMap.put("persons", persons);
        return searchParamsHashMap;
    }

    public HotelAvailabilityVO checkHotelAvailability(Hotel hotel, IHotelBookingManager hotelBookingManager){
        HotelAvailabilityVO hotelAvailabilityVO = new HotelAvailabilityVO();
        try {
            hotelAvailabilityVO = WudstayUtil.isAvailable(hotel, this.getRooms(), this.getCheckIn(), this.getCheckOut(), hotelBookingManager);
        } catch (Exception e) {
            e.printStackTrace();
            hotelAvailabilityVO.setStatus(Boolean.FALSE);
        }
        return hotelAvailabilityVO;
    }

    public BookingDetailsVO getBookingDetailsVO(Hotel hotel){
        City city = hotel.getLocation().getCity();
        BookingDetailsVO bookingDetailsVO = WudstayUtil.getBookingDetailsVO(city.getCityName(), this.getSeletedCheckIn(), this.getSeletedCheckOut(), this.getRooms(), this.getPersons(), hotel);
        return bookingDetailsVO;
    }

    public Boolean isBlackoutDateForPayAtHotel(Hotel hotel, IHotelManager hotelManager){
        City city = hotel.getLocation().getCity();
        return isBlackoutDateForPayAtHotel( city, hotelManager);
    }
    public Boolean isBlackoutDateForPayAtHotel(City city, IHotelManager hotelManager){
        try {
            return hotelManager.isBlackoutDateForPayAtHotel(this.getCheckInDate(), this.getCheckOutDate(), city.getCityId());
        }catch (Exception ex){
            return Boolean.FALSE;
        }
    }

}
