package com.queppelin.wudstay.util;

import java.util.*;
import javax.servlet.http.*;
import org.apache.commons.beanutils.BeanUtils;

/**
 * Created by hp on 10/2/2015.
 */
public class HttpRequestToBeanUtil {	
	

    public static boolean populateCorporateUserBean(int index, Object formBean, HttpServletRequest request) {
        String st = "_"+index+"_";
        Map<String, String> mapParam = new HashMap<String, String>();
        //Map<String, String> map = request.getParameterMap();
        
        Map map = request.getParameterMap();
        for (Iterator names = map.keySet().iterator(); names.hasNext(); ) {
	        String key = (String) names.next(); 
	        String[] value = (String[]) map.get(key);
	        try{
                if(key.lastIndexOf(st)>0) {
                    String propName = key.substring(0, key.lastIndexOf(st));
                    mapParam.put(key.substring(0, key.lastIndexOf(st)), value[0]);
                }
	        }catch(Exception ex){
        		ex.printStackTrace();
        	}
        }
        
        
        /*for (Map.Entry<String, String> entry : map.entrySet()){
            String key = entry.getKey();
            
            if (key.contains(st)){
            	String propName = key.substring(0, key.lastIndexOf(st));
            	String propValue ="";
            	try{
            		request.getParameterValues(key);
            		if(entry.getValue()!=null && entry.getValue().getClass().isArray()){
            			String [] strArray = (String []) entry.getValue();
            			propValue ="";
            		}else{
            			propValue = entry.getValue();
            		}
            		mapParam.put(propName, propValue); 
            	}catch(ClassCastException ex){
            		ex.printStackTrace();
            		mapParam.put(key.substring(0, key.lastIndexOf(st)), entry.getValue()); 
            	}catch(Exception ex){
            		ex.printStackTrace();
            	}
            }
            //System.out.println(entry.getKey() + "/" + entry.getValue());
        }*/
        if(mapParam.size()>0) {
            populateBean(formBean, mapParam);
            return true;
        }else{
            return false;
        }
    }

    public static void populateBean(Object formBean, HttpServletRequest request) {
        populateBean(formBean, request.getParameterMap());
    }

    public static void populateBean(Object bean, Map propertyMap) {
        try {
            BeanUtils.populate(bean, propertyMap);
        } catch(Exception e) {
            e.printStackTrace();
            // Empty catch. The two possible exceptions are
            // java.lang.IllegalAccessException and
            // java.lang.reflect.InvocationTargetException.
            // In both cases, just skip the bean operation.
        }
    }
}
