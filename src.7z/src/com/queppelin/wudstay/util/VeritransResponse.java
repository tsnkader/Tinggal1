package com.queppelin.wudstay.util;

import com.google.gson.Gson;

/**
 * Created by hp on 3/28/2016.
 {
 "status_code" : "201",
 "status_message" : "OK, success do VTWeb transaction, please go to redirect_url",
 "redirect_url" : "https://vtweb.sandbox.veritrans.co.id/v2/vtweb/f5b56ce0-33c0-4a41-998f-0bfcb1959ea8"
 }
 */
public class VeritransResponse {
    String status_code="0";
    String status_message = "";
    String redirect_url= "";
    public VeritransResponse(){}
    public VeritransResponse(String jsonString) {
        Gson gson = new Gson();
        VeritransResponse res = gson.fromJson(jsonString, VeritransResponse.class);
        this.status_code = new String(res.status_code==null?"0":res.status_code);
        this.status_message = new String(res.status_message==null?"":res.status_message);
        this.redirect_url = new String(res.redirect_url==null?"":res.redirect_url);
    }

    public String getStatus_code() {
        return status_code;
    }

    public void setStatus_code(String status_code) {
        this.status_code = status_code;
    }

    public String getStatus_message() {
        return status_message;
    }

    public void setStatus_message(String status_message) {
        this.status_message = status_message;
    }

    public String getRedirect_url() {
        return redirect_url;
    }

    public void setRedirect_url(String redirect_url) {
        if(redirect_url==null)
            this.redirect_url = redirect_url;
        else
            this.redirect_url = "";
    }

    
    public String toString() {
        return "VeritransResponse{" +
                "status_code='" + status_code + '\'' +
                ", status_message='" + status_message + '\'' +
                ", redirect_url='" + redirect_url + '\'' +
                '}';
    }
}
