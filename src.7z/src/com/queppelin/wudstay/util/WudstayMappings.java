package com.queppelin.wudstay.util;

public class WudstayMappings {

	public static final String GET_All_CITIES = "getAllCities.do";
	public static final String GET_All_LOCATIONS_BY_CITY_ID = "getAllLocationsByCityId.do";
	//public static final String SEARCH_HOTELS = "searchHotels.do";
	public static final String SEARCH_HOTELS = "{cityName}/hotels";
	public static final String FILTER_HOTELS = "filterHotels.do";
	//public static final String GET_HOTEL_DETAILS = "getHotelDetails.do";
	public static final String GET_HOTEL_DETAILS = "{cityName}/hotel";
	//public static final String SEARCH_HOTELS_BY_CITY = "searchHotelsByCity.do";
	public static final String SEARCH_HOTELS_BY_CITY = "{cityName}";
	public static final String SEARCH_HOTELS_BY_CITY_AND_HOTEL = "{cityName}/{hotelNameOrId}";
	public static final String GET_HOMEPAGE = "getHomepage.do";
	public static final String ABOUT_US = "aboutUs.do";
	public static final String CANCELLATION_POLICY = "cancellationPolicy.do";
	public static final String CONTACT_US = "contactUs.do";
	public static final String TERMS_AND_CONDITION = "termsAndCondition.do";
	public static final String GET_BOOKINGS_BY_CONTACT_NUMBER = "getBookingsByContactNumber.do";
	public static final String CHECK_AVAILABILITY = "checkAvailability.do";
	public static final String BOOK_HOTEL = "book-hotel";
	public static final String TEST_BOOK_HOTEL = "test-book-hotel";
	public static final String CONFIRM_BOOKING = "confirmBooking.do";
	public static final String BOOKING_CONFIRMATION = "booking-confirmation";
	public static final String VERIFY_MOBILE_NUMBER = "verifyMobileNumber.do";
	public static final String SEND_MOBILE_NUMBER_VERIFICATION_CODE = "sendMobileNumberVerificationCode.do";
	public static final String CANCEL_BOOKING = "cancelBooking.do";
	//public static final String BOOKING_DETAILS = "bookingDetails.do";
	public static final String PROCESS_PAY_NOW = "processPayNow.do";
	public static final String PAYU_PAYMENT_CANCEL = "paymentCancel.do";
	public static final String PAYU_PAYMENT_SUCCESS = "paymentSuccess.do";
	public static final String PAYU_PAYMENT_FAILURE = "paymentFailure.do";

	public static final String PROCESS_PAY_NOW_VERITRANS = "veritransPayNow.do";
	public static final String PROCESS_PAY_NOW_VERITRANS_BY_MOBILE = "veritransPayNowByMobile.do";
	public static final String NOTIFICATION_BY_VERITRANS = "notificationByveritrans.do";
	public static final String NOTIFICATION_BY_VERITRANS_1 = "notificationByveritrans1.do";
	public static final String TEST_NOTIFICATION_BY_VERITRANS = "testNotificationByveritrans.do";
	public static final String PAYMENT_RESPONSE_BY_VERITRANS = "veritrans/{responseType}";
	public static final String VERITRANS_LOG = "veritranslog";

	public static final String HDFC_PROCESS_PAY_NOW = "processHdfcPayNow.do";
	public static final String HDFC_PAYMENT_RESPONSE = "paymentResponse.do"; //"paymentHdfcResponse.do";

	public static final String PAYPAL_PAY_NOW = "paypalPayNow.do";
	public static final String PAYPAL_PAYMENT_CANCEL = "paypalPaymentCancel.do";
	public static final String PAYPAL_PAYMENT_SUCCESS = "paypalPaymentSuccess.do";
	public static final String PAYPAL_PAYMENT_FAILURE = "paypalPaymentFailure.do";


	public static final String IS_MAXIMUM_NIGHTS_REACHED = "isMaximumNightsReached.do";
	
	
	public static final String LOGIN = "login.do";
	public static final String VERIFY_CREDENTIALS = "verifyCredentials.do";
	public static final String GET_BOOKINGS = "getBookings.do";
	public static final String ADD_HOTEL = "addHotel.do";
	public static final String SAVE_HOTEL = "saveHotel.do";
	public static final String VIEW_HOTEL_DETAILS = "viewHotelDetails.do";
	public static final String VIEW_HOTELS = "viewHotels.do";
	public static final String LOGOUT = "logout.do";
	public static final String EDIT_HOTEL_DETAILS = "editHotelDetails.do";
	public static final String UPDATE_HOTEL = "updateHotel.do";
	public static final String IS_USERNAME_EXISTS = "isUsernameExists.do";
	public static final String ADD_CITY = "addCity.do";
	public static final String EDIT_CITY = "editCity.do";
	public static final String GET_ALL_CITIES = "getAllCities.do";
	public static final String SAVE_UPDATE_CITY = "saveUpdateCity.do";
	public static final String ADD_LOCATION = "addLocation.do";
	public static final String EDIT_LOCATION = "editLocation.do";
	public static final String GET_ALL_LOCATIONS = "getAllLocations.do";
	public static final String SAVE_UPDATE_LOCATION = "saveUpdateLocation.do";
	public static final String GET_PRIVACY_POLICY = "getPrivacyPolicy.do";
	public static final String IS_REGISTERED_MOBILE_NUMBER = "isRegisteredMobileNumber.do";
	public static final String DELETE_HOTEL_IMAGE = "deleteHotelImage.do";
	public static final String GET_UPDATED_HOTEL_PRICE = "getUpdatedHotelPrice.do";
	
	//Customer Care Portal
	public static final String GET_CUSTOMER_CARE_DETAILS = "customerCareDetails.do";

	//Corporate Booking
	public static final String GET_CORP_BOOKINGS = "getCorpBookings.do";
	public static final String ADD_BULK_BOOKING = "addBulkBooking.do";
	public static final String Edit_BULK_BOOKING = "editBulkBooking.do";
	public static final String VIEW_CORP_HOTELS = "showCorpHotels.do";
	public static final String ADD_CORP = "addCorporate.do";
	public static final String EDIT_CORP = "editCorporate.do";
	public static final String SUBMIT_ADD_CORP = "submitAddCorporate.do";
	public static final String VIEW_CORP = "viewCorporate.do";
	public static final String BULK_BOOKING_SUBMIT = "submitBulkBooking.do";
	public static final String CORP_APPROVE_BOOKINGS = "approveBookings.do";
	public static final String PROCEED_CORP_APPROVE_BOOKING = "proceedApproveCorpBooking.do";
	public static final String SUBMIT_PROCEED_CORP_APPROVE_BOOKING = "submitProceedApproveCorpBooking.do";
	public static final String VIEW_UPLOAD_EXCEL_FOR_BOOKING = "uploadBulkBookingExcelFile.do";

	public static final String GET_IF_ALREADY_EXIST_CORP_LOGIN_ID = "getAlreadyExistsCorpLoginId.do";
	public static final String GET_IF_ALREADY_EXIST_CORP_NAME = "getAlreadyExistsCorpName.do";

	//couponCode
	public static final String CREATE_COUPON_CODE = "createCouponCode.do";
	public static final String SUBMIT_NEW_COUPON_CODE = "createNewCouponCode.do";

	public static final String CALCULATE_COUPONCODE_DISCOUNT = "calculateCouponCodeDiscount.do";

	public static final String ADD_CUST_CARE_BOOKING = "addCustCareBooking.do";
	public static final String SUBMIT_ADD_CUST_CARE_BOOKING = "saveCustCareBooking.do";


	public static final String SEARCH_HOTEL_BY_CITY_ID = "searchHotelByCityId.do";
	public static final String GET_MONTHLY_INVENTORY = "getMonthlyRoomInventory.do";
	public static final String UPDATE_MONTHLY_INVENTORY = "updateMonthlyRoomInventory.do";
	public static final String UPDATE_IN_RANGE_MONTHLY_INVENTORY = "updateInRangeMonthlyRoomInventory.do";
	public static final String RESET_MONTHLY_INVENTORY = "resetMonthlyRoomInventory.do";


	public static final String ADD_PG = "addPg.do";
	public static final String SAVE_PG = "savePg.do";
	public static final String SCHEDULE_VISIT = "scheduleVisit.do";
	public static final String SEARCH_PG = "searchPg.do";


}
