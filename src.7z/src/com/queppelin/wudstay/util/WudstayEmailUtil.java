package com.queppelin.wudstay.util;

import com.queppelin.wudstay.exception.WudstayException;
import com.queppelin.wudstay.manager.IHotelAdministratorManager;
import com.queppelin.wudstay.manager.IHotelBookingManager;
import com.queppelin.wudstay.vo.Hotel;
import com.queppelin.wudstay.vo.HotelAdministrator;
import com.queppelin.wudstay.vo.HotelBooking;
import com.queppelin.wudstay.vo.custom.BookingDetailsVO;

import javax.mail.MessagingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by hp on 10/29/2015.
 */
public class WudstayEmailUtil {
    public static SimpleDateFormat dispalyDateFormat = new SimpleDateFormat("dd/MM/yyyy");

    public static Map<String, Object> getCancellationMailData( IHotelBookingManager hotelBookingManager, Long bookingId  ) {
        Map<String, Object> emailData = new HashMap<String, Object>();
        HotelBooking hotelBooking = hotelBookingManager.getById(bookingId);

        String  checkIn  = dispalyDateFormat.format(hotelBooking.getCheckIn());
        String  checkOut = dispalyDateFormat.format(hotelBooking.getCheckOut());
        String  bookingDt = dispalyDateFormat.format(hotelBooking.getBookingDate());
        Hotel   hotel    = hotelBooking.getHotel();

        emailData.put("HOTEL_DISPLAY_NAME", hotel.getHotelDisplayName());
        emailData.put("HOTEL_ACTUAL_NAME",  hotel.getHotelName());

        emailData.put("GUEST",       hotelBooking.getBookersName());
        emailData.put("CHECK_IN",    checkIn);
        emailData.put("CHECK_OUT",   checkOut);
        emailData.put("BOOKING_DISPLAY_ID",  hotelBooking.getDisplayBookingId());
        emailData.put("BOOKING_DATE",  bookingDt);
        emailData.put("ROOM_COUNT",  hotelBooking.getNoOfRooms());
        emailData.put("NIGHT_COUNT", hotelBooking.getNights());
        emailData.put("TOTAL_PRICE", hotelBooking.getTotalAmount());
        //emailData.put("PAID", hotelBooking.getIsPaid());
        emailData.put("PAID", ( hotelBooking.getIsPaid() ?  hotelBooking.getTotalAmount().intValue() : 0) );

        emailData.put("EMAIL", hotelBooking.getEmail());
        emailData.put("BOOKING_ID", hotelBooking.getBookingId());
        emailData.put("HOTEL", hotel);
        emailData.put("HOTEL_BOOKING", hotelBooking);

        //EmailSender.getInstance().sendEmail(email, "Booking Confirmation", bookingConfirmationBodyDetails, WudstayConstants.BOOKING_CONFIRMATION_EMAIL_BODY, ccList);
        return emailData;
    } //WudstayEmailUtil.sendCancellationMail( IHotelBookingManager hotelBookingManager,IHotelAdministratorManager hotelAdministratorManager,  Long bookingId  )
    //WudstayEmailUtil.sendCancellationMail( IHotelBookingManager hotelBookingManager,IHotelAdministratorManager hotelAdministratorManager,  Long bookingId  )
    public static void sendCancellationMail( IHotelBookingManager hotelBookingManager,IHotelAdministratorManager hotelAdministratorManager,  Long bookingId  ) throws MessagingException, WudstayException {
        List<String> ccList = new ArrayList<String>();
        Map<String, Object> emailData = getCancellationMailData( hotelBookingManager, bookingId );
        String email = (String) emailData.get("EMAIL");
        emailData.put("EMAIL", null);
        HotelBooking hotelBooking = (HotelBooking) emailData.get("HOTEL_BOOKING");
        emailData.put("HOTEL_BOOKING", null);
        Hotel hotel = (Hotel) emailData.get("HOTEL");
        emailData.put("HOTEL", null);
        //---------------------------------------
        //ccList.add("support@wudstay.com");
        try {
            EmailSender.getInstance().sendEmail(email, "Booking Confirmation", emailData, WudstayConstants.BOOKING_CANCELLATION_EMAIL_BODY_CUST, ccList);
        }catch (Exception ex){
            ex.printStackTrace();
        }
        //---------------------------------------
        String hotelAdministratorEmail = null;
        HotelAdministrator hotelAdministrator = hotelAdministratorManager.getHotelAdminByHotelId(hotel.getHotelId());
        if (hotelAdministrator.getUser().getEmail() != null && !hotelAdministrator.getUser().getEmail().trim().equals("")) {
            //ccList.add(hotelAdministrator.getUser().getEmail());
            hotelAdministratorEmail = hotelAdministrator.getUser().getEmail();
        }
        if (hotel.getContactPersonEmail1() != null && !hotel.getContactPersonEmail1().trim().equals("")) {
            ccList.add(hotel.getContactPersonEmail1());
        }
        if (hotel.getContactPersonEmail2() != null && !hotel.getContactPersonEmail2().trim().equals("")) {
            ccList.add(hotel.getContactPersonEmail2());
        }
        try {
            EmailSender.getInstance().sendEmail(email, "Booking Confirmation", emailData, WudstayConstants.BOOKING_CANCELLATION_EMAIL_BODY_HOTEL, ccList);
        }catch (Exception ex){
            ex.printStackTrace();
        }
        //---------------------------------------
    }

    public static BookingDetailsVO getBookingDetailsVO(IHotelBookingManager hotelBookingManager, Long bookingId) {

        HotelBooking hotelBooking = hotelBookingManager.getById(bookingId);
        String checkIn = dispalyDateFormat.format(hotelBooking.getCheckIn());
        String checkOut = dispalyDateFormat.format(hotelBooking.getCheckOut());
        Integer rooms = hotelBooking.getNoOfRooms();
        Integer persons = hotelBooking.getNoOfPeople();
        Hotel hotel = hotelBooking.getHotel();
        String city = hotel.getLocation().getCity().getCityName();

        return WudstayUtil.getBookingDetailsVO(city, checkIn, checkOut, rooms, persons, hotel);
		/*$GUEST	$BOOKING_ID		$HOTEL_DISPLAY_NAME		$ROOM_COUNT		$NIGHT_COUNT	$TOTAL_PRICE	$PAID	$CHECK_IN	$CHECK_OUT*/
    }
}
