package com.queppelin.wudstay.util;

/**
 * Created by hp on 11/15/2015.
 */

import com.queppelin.wudstay.vo.HdfcTranLogVO;
import com.queppelin.wudstay.vo.custom.BookingDetailsVO;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by hp on 11/15/2015.
 */
public class HdfcPaymentUtil {
    //public static Map<String, String> credentialsParamMap = new HashMap<String, String>();
    public static final String SECURE_SECRET = "3772d0d22ace578ad693f519060c6ffd"; // your secret key;
    public static final String V3URL =  "https://secure.ebs.in/pg/ma/payment/request";
    public static final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");

    public static final String account_id = "17878";
    public static final String channel    = "10";
    public static final String currency   = "INR";
    //public static final String return_url = "http://54.251.116.126:8080/onlinepayment/response.jsp";
    public static final String mode       = "LIVE";
    public static final String algo       = "MD5";



    /*static{
        credentialsParamMap.put("account_id",  "17878");
        credentialsParamMap.put("channel",     "10");
        credentialsParamMap.put("currency",    "INR");
        credentialsParamMap.put("return_url",  "http://54.251.116.126:8080/onlinepayment/response.jsp");
        credentialsParamMap.put("mode",        "LIVE");
        credentialsParamMap.put("algo",        "MD5");
    }*/

    private static String md5HashData(String str) throws Exception {
        MessageDigest m = MessageDigest.getInstance("MD5");
        byte[] data = str.getBytes();
        m.update(data,0,data.length);
        BigInteger i = new BigInteger(1,m.digest());
        String hash = String.format("%1$032X", i);
        return hash;
    }

    public static HashMap<String, String> fetchParamMap(HdfcTranLogVO tranLogVO){
        HashMap<String, String> testMap = new HashMap<String, String>();

        testMap.put("account_id",  account_id);
        testMap.put("channel",     channel);
        testMap.put("currency",    currency);
        testMap.put("return_url",  tranLogVO.getReturnUrl()); //testMap.put("return_url",  return_url);
        testMap.put("mode",        mode);
        testMap.put("algo",        algo);

        testMap.put("name",         tranLogVO.getName());
        testMap.put("email",        tranLogVO.getEmail());
        testMap.put("phone",        tranLogVO.getPhone());

        testMap.put("reference_no", tranLogVO.getReferenceNo());
        testMap.put("amount",       tranLogVO.getAmount());
        testMap.put("description",  tranLogVO.getDescription());

        testMap.put("address",     tranLogVO.getAddress());
        testMap.put("city",        tranLogVO.getCity());
        testMap.put("state",       tranLogVO.getState());
        testMap.put("postal_code", tranLogVO.getPostalCode());
        testMap.put("country",     tranLogVO.getCountry());

        /*testMap.put("ship_name",        tranLogVO.getShipName());
        testMap.put("ship_phone",       tranLogVO.getShipPhone());
        testMap.put("ship_address",     tranLogVO.getShipAddress());
        testMap.put("ship_city",        tranLogVO.getShipCity());
        testMap.put("ship_state",       tranLogVO.getShipState());
        testMap.put("ship_postal_code", tranLogVO.getShipPostalCode());
        testMap.put("ship_country",     tranLogVO.getShipCountry());*/

        return testMap;
    }

    public static String getHdfcTransactionDescription(Long logId, String referenceNo, BookingDetailsVO bookingDetailsVO, HashMap<String, Object> searchParamMap) {

        StringBuffer buffer = new StringBuffer();

        String udf1 = WudstayUtil.getUDFBookingDetails(bookingDetailsVO);
        String udf2 = WudstayUtil.getUDFSearchParam(searchParamMap);

        buffer.append((logId==null? "NULL": logId.longValue()+""));
        buffer.append(WudstayConstants.SEPARATOR_1);

        buffer.append(referenceNo);
        buffer.append(WudstayConstants.SEPARATOR_1);

        buffer.append(udf1);
        buffer.append(WudstayConstants.SEPARATOR_1);

        buffer.append(udf2);
        buffer.append(WudstayConstants.SEPARATOR_1);

        return buffer.toString();
    }

    public static HdfcTranLogVO setMd5Hashedvalue(HdfcTranLogVO tranLogVO){
        String md5HashData = new String(SECURE_SECRET);
        //Sort the HashMap
        Map<String, String> requestFields = new TreeMap<String, String>(fetchParamMap(tranLogVO));

        // append all fields in a data string
        for (Iterator i = requestFields.keySet().iterator(); i.hasNext(); ) {
            String key = (String) i.next();
            String value = (String) requestFields.get(key);
            md5HashData += "|" + value;
            System.out.println("md5HashData : " + md5HashData);
            System.out.println("--------------");//md5HashData : 3772d0d22ace578ad693f519060c6ffd|17878|Mansarover|MD5|2|10
            System.out.println("key : " + key + ",   value: " + value);
        }

        //String hvalue = credentialsParamMap.get("algo");
        String hashedvalue ="";
        if ( algo.equals("MD5") ){
            try {
                hashedvalue = md5HashData(md5HashData);
            } catch (Exception e) {
                e.printStackTrace();
                hashedvalue="ERROR";
            }
            System.out.println("md5(md5HashData) = " + hashedvalue);
        }
        requestFields.put("md5HashData", md5HashData);
        requestFields.put("secure_hash", hashedvalue);
        tranLogVO.setSecureHash(hashedvalue);
        //return requestFields;
        return tranLogVO;

    }
    /*
    public static HdfcPaymentParamDto md5HashParamData(HdfcPaymentParamDto dto){ // Map<String, String> md5HashParamData(HdfcPaymentParamDto dto){
        String md5HashData = new String(SECURE_SECRET);

        //Sort the HashMap
        Map<String, String> requestFields = new TreeMap<String, String>(dto.fetchParamMap());

        // append all fields in a data string
        for (Iterator i = requestFields.keySet().iterator(); i.hasNext(); ) {
            String key = (String) i.next();
            String value = (String) requestFields.get(key);
            md5HashData += "|" + value;
            System.out.println("md5HashData : " + md5HashData);
            //System.out.println("--------------");//md5HashData : 3772d0d22ace578ad693f519060c6ffd|17878|Mansarover|MD5|2|10
            System.out.println("key : " + key + ",   value: " + value);
        }

        String hvalue = credentialsParamMap.get("algo");
        String hashedvalue ="";
        if ( hvalue.equals("MD5") ){
            try {
                hashedvalue = md5HashData(md5HashData);
            } catch (Exception e) {
                e.printStackTrace();
                hashedvalue="ERROR";
            }
            System.out.println("md5(md5HashData) = " + hashedvalue);
        }
        requestFields.put("md5HashData", md5HashData);
        requestFields.put("secure_hash", hashedvalue);
        dto.setSecureHash(hashedvalue);
        //return requestFields;
        return dto;
    }

    public static String getCurrentTimeStamp() {
        / *Date now = new Date();
        String strDate = sdf.format(now);
        return strDate;* /
        return "123";
    }
*/

}
