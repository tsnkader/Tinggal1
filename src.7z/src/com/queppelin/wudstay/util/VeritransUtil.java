package com.queppelin.wudstay.util;

import com.queppelin.wudstay.vo.custom.BookingDetailsVO;

import java.io.*;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Date;
import java.util.Locale;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
/**
 * Created by hp on 3/7/2016.
 *
 * https://github.com/veritrans/veritrans-java
 * http://docs.veritrans.co.id/veritrans-java/site/index.html#notification-handler-notification-url
 *
 *
 * Configuration
 * Payment Notification URL*: http://tinggal.com/veritrans/notificationByveritrans.do
 * Finish Redirect URL*:      http://tinggal.com/veritrans/finish
 * Unfinish Redirect URL*:    http://tinggal.com/veritrans/unfinish
 * Error Redirect URL*:       http://tinggal.com/veritrans/error
 *
 *
 * Test notification callback
 * We will send you a notification callback to test your endpoint.
 * Notification url: http://tinggal.com/veritrans/notificationByveritrans.do
 * JSON body:        {
                         "status_code":        "200",
                         "status_message":     "Veritrans payment notification",
                         "transaction_id":     "8495635e-639b-428a-bcbb-04069cd136df",
                         "order_id":           "76DC611D6EBAAFC66CC0879C71B5DB5C",
                         "payment_type":       "permata",
                         "transaction_time":   "2016-05-15 17:00:14 +0700",
                         "transaction_status": "settlement",
                         "gross_amount":       "736000.00",
                         "signature_key":      "3f97a9e3fe38f9d42a1642aadba9260412d319c726e3f44a9b5d3353c0e85077b88f3fc4d0062c0f7a015b6e2a6ef440c30290a83364b49b5b7ebd512a4e9891"
                      }
 * Method: POST
 *
 *
 *
 * {
     "status_code": "200",
     "status_message": "Veritrans payment notification",
     "transaction_id": "a7cee49c-ba08-4a28-ade9-7011e95d0f8f",
*     "masked_card": "455633-6607",
     "order_id": "069059B7EF840F0C74A814EC9237B6EC",
     "gross_amount": "616000.00",
*     "payment_type": "credit_card",
     "transaction_time": "2016-05-15 14:42:38",
     "transaction_status": "settlement",
*     "fraud_status": "accept",
*     "approval_code": "003248",
     "signature_key": "ba3686ab39c33cfb36f7b20cb244e289f3ad6e1391c989307735c1e5807c0c1f6559ca9ece01b706a18011c340c338d7ac64fe73c34b448a7afbc63a3cd7fdcf",
*     "bank": "bni",
*     "eci": "05"
     }
 *
 *
 *


 * {
     "status_code": "200",
     "status_message": "Veritrans payment notification",
     "transaction_id": "8495635e-639b-428a-bcbb-04069cd136df",
     "order_id": "76DC611D6EBAAFC66CC0879C71B5DB5C",
     "gross_amount": "736000.00",
     "payment_type": "bank_transfer",
     "transaction_time": "2016-05-15 17:00:14",
     "transaction_status": "settlement",
 *    "permata_va_number": "8778004376194263",
     "signature_key": "3f97a9e3fe38f9d42a1642aadba9260412d319c726e3f44a9b5d3353c0e85077b88f3fc4d0062c0f7a015b6e2a6ef440c30290a83364b49b5b7ebd512a4e9891"
   }
 *
 *
 *
 *
 * @RequestParam (required = false)  String order_id,
 * @RequestParam (required = false)  String status_code,
 * @RequestParam (required = false)  String transaction_status,
 */


public class VeritransUtil implements Serializable {
    private static final String USER_AGENT = "Mozilla/5.0";
    private static final Boolean isProduction = Boolean.FALSE; //Boolean.FALSE;
    //Veritrans_Config
    private static final String SANDBOX_BASE_URL    = "https://api.sandbox.veritrans.co.id/v2";
    private static final String SANDBOX_MERCHANT_ID = "M079202";
    private static final String SANDBOX_CLIENT_KEY = "VT-client-6QpkCb2FhV_T6amT";
    private static final String SANDBOX_SERVER_KEY = "VT-server-1QfSAaQ4wz_U-XvWefmXy2Yv";
    private static final String SANDBOX_SERVER_KEY_BASE64FORMAT_ENCODED = "VlQtc2VydmVyLTFRZlNBYVE0d3pfVS1YdldlZm1YeTJZdjo=";


    private static final String PRODUCTION_BASE_URL = "https://api.veritrans.co.id/v2";
    private static final String PRODUCTION_MERCHANT_ID = "M079202";
    private static final String PRODUCTION_CLIENT_KEY = "VT-client-3aaRH68MeVQMNVu5";
    private static final String PRODUCTION_SERVER_KEY = "VT-server-8Gcx2gSKopoYTTkz3J7Nz8jN";
    private static final String PRODUCTION_SERVER_KEY_BASE64FORMAT_ENCODED = "VlQtc2VydmVyLThHY3gyZ1NLb3BvWVRUa3ozSjdOejhqTjo=";


    public static String getBaseUrl() {
        String url = (isProduction == Boolean.TRUE ? PRODUCTION_BASE_URL :  SANDBOX_BASE_URL) + "/charge";
        System.out.println("BASE_URL: " + url);
        return url;
    }
    public static String getServerKey() {
        String key = isProduction == Boolean.TRUE ? PRODUCTION_SERVER_KEY :  SANDBOX_SERVER_KEY ;
        System.out.println("SERVER_KEY: " +  key);
        return key;
    }

    public static String veritransBase64FormatedKey(){
        String key = getServerKey() + ":" ; //Note: Make sure there is ":" character after server key!
        String decodeKey = new String(Base64.encode(key));
        System.out.println("SERVER_KEY_BASE64FORMAT_ENCODED: " + decodeKey);
        return decodeKey;
    }

    public static String getJsonBody(String orderRefId, Integer amount, String bookingId,
                                     String first_name_20, String last_name_20, String email_45, String phone_19 ){
                                     //, String custom_field1, String custom_field2, String custom_field2,){
/*   	    ZonedDateTime.now();
   	    String zonedateTime =ZonedDateTime.now().format(DateTimeFormatter.RFC_1123_DATE_TIME);
   	    int minute = ZonedDateTime.now().getMinute();//now.get(zonedateTime.MINUTE);
   		String format3 = ZonedDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH));
*/
  	   DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss Z");
  	   //get current date time with Date()
  	   Date date = new Date();
  	  // System.out.println(dateFormat.format(date));
  	   String zonedateTime =dateFormat.format(date);
  	  /// String mn =dateFormat.format(date.getDay());
  	   int minute =date.getMinutes();
  	  // String mn = (String)minute;
  	   //get current date time with Calendar()
  	  // Calendar cal = Calendar.getInstance();
  	  // System.out.println(dateFormat.format(cal.getTime()));
  	   
        StringBuilder sb = new StringBuilder();
        /*sb.append("{\"payment_type\":\"vtweb\",");
        //sb.append(" \"custom_field1\":\"" + custom_field1 + "\",");
        //sb.append(" \"custom_field2\":\"" + custom_field2 + "\",");
        //sb.append(" \"custom_field3\":\"" + custom_field3 + "\",");
        sb.append(" \"vtweb\":{\"credit_card_3d_secure\":true},");
        sb.append(" \"transaction_details\":{\"gross_amount\":" + amount + ",\"order_id\":\"" + orderRefId + "\"},");
        sb.append(" \"customer_details\":{\"first_name\":\"" + first_name_20 + "\",\"last_name\":\"" + last_name_20 + "\",\"email\":\"" + email_45 + "\",\"phone\":\"" + phone_19 + "\",");
        sb.append("                       \"billing_address\":{\"first_name\":\"" + first_name_20 + "\",\"last_name\":\"" + last_name_20 + "\",\"address\":\"-\",\"city\":\"Jakarta\",\"postal_code\":\"16602\",\"phone\":\"" + phone_19 + "\",\"country_code\":\"IDN\"},");
        sb.append("                       \"shipping_address\":{\"first_name\":\"" + first_name_20 + "\",\"last_name\":\"" + last_name_20 + "\",\"address\":\"-\",\"city\":\"Jakarta\",\"postal_code\":\"16601\",\"phone\":\"" + phone_19 + "\",\"country_code\":\"IDN\"},");
        sb.append(" \"custom_expiry\":{\"order_time\":" + zonedateTime + ",\"expiry_duration\":48,\"unit\":\"" + minute + "\"}},");
        sb.append(" \"item_details\":[{\"id\":\"" + bookingId + "\",\"price\":" + amount + ",\"quantity\":1,\"name\":\"Rooms Booking\"}]}");*/

        sb.append("{\"payment_type\":\"vtweb\",");
        //sb.append(" \"custom_field1\":\"" + custom_field1 + "\",");
        //sb.append(" \"custom_field2\":\"" + custom_field2 + "\",");
        //sb.append(" \"custom_field3\":\"" + custom_field3 + "\",");
        sb.append(" \"vtweb\":{\"credit_card_3d_secure\":true},");
        sb.append(" \"transaction_details\":{\"gross_amount\":" + amount + ",\"order_id\":\"" + orderRefId + "\"},");
        sb.append(" \"customer_details\":{\"first_name\":\"" + first_name_20 + "\",\"last_name\":\"" + last_name_20 + "\",\"email\":\"" + email_45 + "\",\"phone\":\"" + phone_19 + "\",");
        sb.append("                       \"billing_address\":{\"first_name\":\"" + first_name_20 + "\",\"last_name\":\"" + last_name_20 + "\",\"address\":\"-\",\"city\":\"Jakarta\",\"postal_code\":\"16602\",\"phone\":\"" + phone_19 + "\",\"country_code\":\"IDN\"},");
        sb.append("                       \"shipping_address\":{\"first_name\":\"" + first_name_20 + "\",\"last_name\":\"" + last_name_20 + "\",\"address\":\"-\",\"city\":\"Jakarta\",\"postal_code\":\"16601\",\"phone\":\"" + phone_19 + "\",\"country_code\":\"IDN\"}},");
       // sb.append(" \"custom_expiry\":{\"order_time\":\"" + zonedateTime +"\",\"expiry_duration\":48,\"unit\":\"" + minute + "\"}},");
        sb.append(" \"item_details\":[{\"id\":\"" + bookingId + "\",\"price\":" + amount + ",\"quantity\":1,\"name\":\"Rooms Booking\"}]}");

        //{"payment_type":"vtweb", "vtweb":{"credit_card_3d_secure":false},
        //      "transaction_details":{"gross_amount":199000,"order_id":123},
        //      "customer_details":{"first_name":"Test","last_name":"Booking","email":"surender.r@wudstay.com","phone":"62822 8539 0099",
        //      "billing_address":{"first_name":"Andri","last_name":"Litani","address":"Mangga 20","city":"Jakarta","postal_code":"16602","phone":"081122334455","country_code":"IDN"},
        //      "shipping_address":{"first_name":"Obet","last_name":"Supriadi","address":"Manggis 90","city":"Jakarta","postal_code":"16601","phone":"08113366345","country_code":"IDN"}},
        //      "item_details":[{"id":"Book_123","price":199000,"quantity":1,"name":"Rooms Booking"}]}

        return sb.toString();
    }



    public static VeritransResponse getRedirectUrlForPayment(String orderRefId, Integer amount, String bookingId,
                                                  String name, String email, String mobileNumber ) throws Exception {
        VeritransResponse vo=null;
        URL url;
        HttpURLConnection connection = null;
        try {
            String first_name_20 = name;
            String last_name_20 = "-";
            String email_45 = email;
            String phone_19 = mobileNumber;
            if (name.length() >= 20) {
                first_name_20 = name.substring(0, 20);
                last_name_20 = name.substring(20, 20);
            }

            String paramsJSON = getJsonBody(orderRefId, amount, bookingId, first_name_20, last_name_20, email_45,  phone_19 );
            System.out.println("JSON: " + paramsJSON);
            //Create connection
            url = new URL(getBaseUrl());
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            //connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            //connection.setRequestProperty("Content-Length", "" + Integer.toString(urlParameters.getBytes().length));
            //connection.setRequestProperty("Content-Language", "en-US");
            connection.setRequestProperty("Content-type", "application/json"); //Content-Type  = application/json
            connection.setRequestProperty("Accept", "application/json"); //Accept  = application/json
            connection.setRequestProperty("Authorization", veritransBase64FormatedKey());

            connection.setUseCaches(false);
            connection.setDoInput(true);
            connection.setDoOutput(true);

            //Send request
            DataOutputStream wr = new DataOutputStream(connection.getOutputStream());
            wr.writeBytes(paramsJSON);
            wr.flush();
            wr.close();

            //Get Response
            InputStream is = connection.getInputStream();
            BufferedReader rd = new BufferedReader(new InputStreamReader(is));
            String line;
            StringBuffer response = new StringBuffer();
            while ((line = rd.readLine()) != null) {
                System.out.println(line);
                response.append(line);
                // response.append('\r');
            }
            rd.close();
            String jsonResponse = response.toString();
            vo = new VeritransResponse(jsonResponse);
            System.out.println(vo.toString());
        } catch (Exception e) {
            e.printStackTrace();
            //return null;
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
        return vo;
    }

    public static void main(String[] args) {
        String orderRefId=  WudstayUtil.getUniqueId();    //"C4CA4238A0B923820DCC509A6F75849B"; //"123";
        Integer amount = 199000;
        String bookingId = "Book_123";
        String name  = "Test Booking";
        String email_45 = "surender.r@wudstay.com";
        String phone_19 = "62822 8539 0099";
        //String paymentUrl = "";
        VeritransResponse payment=null;
        try {
            //System.out.println("veritransBase64FormatedKey: " + veritransBase64FormatedKey());
            //System.out.println(getJsonBody(orderRefId, amount, bookingId, first_name_20, last_name_20, email_45,  phone_19 ));
            payment = getRedirectUrlForPayment(orderRefId, amount, bookingId, name, email_45, phone_19);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("paymentUrl: " + payment.getRedirect_url());
    	////////////"2015-09-08 11:06:53 +0700"
/* 	   DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
 	   //get current date time with Date()
 	   Date date = new Date();
 	  /// System.out.println(dateFormat.format(date));
 	  String zonedateTime =dateFormat.format(date);
 	  
 	 System.out.println(zonedateTime);
	  int minute =date.getMinutes();
	 System.out.println(minute);
 	   //get current date time with Calendar()
 	   Calendar cal = Calendar.getInstance();*/
    	
    	

    }
    

 	  /// System.out.println(dateFormat.format(cal.getTime()));
 	   
  	   /* ZonedDateTime.now();
  	    String zonedateTime =ZonedDateTime.now().format(DateTimeFormatter.RFC_1123_DATE_TIME);
  	    int minute = ZonedDateTime.now().getMinute();//now.get(zonedateTime.MINUTE);
  	    System.out.println(zonedateTime);
  	  System.out.println(minute);
  	
	String format3 = ZonedDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH));
	System.out.println(format3);*/

 	  
    
    /*
    VlQtc2VydmVyLTFRZlNBYVE0d3pfVS1YdldlZm1YeTJZdjo=
veritransBase64FormatedKey: VlQtc2VydmVyLTFRZlNBYVE0d3pfVS1YdldlZm1YeTJZdjo=
JSON: {"payment_type":"vtweb", "vtweb":{"credit_card_3d_secure":false}, "transaction_details":{"gross_amount":199000,"order_id":"6F335AAD-E10A-467E-909B-BB63F5D41E8A"}, "customer_details":{"first_name":"Test Booking","last_name":"-","email":"surender.r@wudstay.com","phone":"62822 8539 0099",                       "billing_address":{"first_name":"Test Booking","last_name":"-","address":"-","city":"Jakarta","postal_code":"16602","phone":"62822 8539 0099","country_code":"IDN"},                       "shipping_address":{"first_name":"Test Booking","last_name":"-","address":"-","city":"Jakarta","postal_code":"16601","phone":"62822 8539 0099","country_code":"IDN"}}, "item_details":[{"id":"Book_123","price":199000,"quantity":1,"name":"Rooms Booking"}]}
VlQtc2VydmVyLTFRZlNBYVE0d3pfVS1YdldlZm1YeTJZdjo=
{
  "status_code" : "201",
  "status_message" : "OK, success do VTWeb transaction, please go to redirect_url",
  "redirect_url" : "https://vtweb.sandbox.veritrans.co.id/v2/vtweb/ee3bfaa4-fcda-4260-b01c-16c25720f5f5"
}
VeritransResponse{status_code='201', status_message='OK, success do VTWeb transaction, please go to redirect_url', redirect_url='https://vtweb.sandbox.veritrans.co.id/v2/vtweb/ee3bfaa4-fcda-4260-b01c-16c25720f5f5'}
paymentUrl: https://vtweb.sandbox.veritrans.co.id/v2/vtweb/ee3bfaa4-fcda-4260-b01c-16c25720f5f5
     */


    /*
    VlQtc2VydmVyLThHY3gyZ1NLb3BvWVRUa3ozSjdOejhqTjo=
veritransBase64FormatedKey: VlQtc2VydmVyLThHY3gyZ1NLb3BvWVRUa3ozSjdOejhqTjo=
JSON: {"payment_type":"vtweb", "vtweb":{"credit_card_3d_secure":false}, "transaction_details":{"gross_amount":199000,"order_id":"8BCFAC78-8A6B-4608-A35B-8A83B2225C04"}, "customer_details":{"first_name":"Test Booking","last_name":"-","email":"surender.r@wudstay.com","phone":"62822 8539 0099",                       "billing_address":{"first_name":"Test Booking","last_name":"-","address":"-","city":"Jakarta","postal_code":"16602","phone":"62822 8539 0099","country_code":"IDN"},                       "shipping_address":{"first_name":"Test Booking","last_name":"-","address":"-","city":"Jakarta","postal_code":"16601","phone":"62822 8539 0099","country_code":"IDN"}}, "item_details":[{"id":"Book_123","price":199000,"quantity":1,"name":"Rooms Booking"}]}
VlQtc2VydmVyLThHY3gyZ1NLb3BvWVRUa3ozSjdOejhqTjo=
java.io.FileNotFoundException: https://api.veritrans.co.id/v2
	at sun.net.www.protocol.http.HttpURLConnection.getInputStream(HttpURLConnection.java:1625)
	at sun.net.www.protocol.https.HttpsURLConnectionImpl.getInputStream(HttpsURLConnectionImpl.java:254)
	at com.queppelin.wudstay.util.VeritransUtil.getRedirectUrlForPayment(VeritransUtil.java:115)
	at com.queppelin.wudstay.util.VeritransUtil.main(VeritransUtil.java:151)
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:57)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:606)
	at com.intellij.rt.execution.application.AppMain.main(AppMain.java:134)
Exception in thread "main" java.lang.NullPointerException
	at com.queppelin.wudstay.util.VeritransUtil.main(VeritransUtil.java:155)
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:57)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:606)
	at com.intellij.rt.execution.application.AppMain.main(AppMain.java:134)
     */

    public static String md5HashData(String str) {
        try {
            MessageDigest m = MessageDigest.getInstance("MD5");
            byte[] data = str.getBytes();
            m.update(data, 0, data.length);
            BigInteger i = new BigInteger(1, m.digest());
            String hash = String.format("%1$032X", i);
            return hash;
        }catch (Exception ex){
           return  null;
        }
    }
    public static String getHdfcTransactionDescription(Long logId, String referenceNo, BookingDetailsVO bookingDetailsVO, HashMap<String, Object> searchParamMap) {

        StringBuffer buffer = new StringBuffer();

        String udf1 = WudstayUtil.getUDFBookingDetails(bookingDetailsVO);
        String udf2 = WudstayUtil.getUDFSearchParam(searchParamMap);

        buffer.append((logId==null? "NULL": logId.longValue()+""));
        buffer.append(WudstayConstants.SEPARATOR_1);

        buffer.append(referenceNo);
        buffer.append(WudstayConstants.SEPARATOR_1);

        buffer.append(udf1);
        buffer.append(WudstayConstants.SEPARATOR_1);

        buffer.append(udf2);
        buffer.append(WudstayConstants.SEPARATOR_1);

        return buffer.toString();
    }

}

