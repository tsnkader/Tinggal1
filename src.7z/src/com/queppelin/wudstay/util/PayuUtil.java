package com.queppelin.wudstay.util;

import com.queppelin.wudstay.exception.CustomGenericException;
import com.queppelin.wudstay.vo.custom.BookingDetailsVO;
import com.queppelin.wudstay.vo.custom.PayUVO;
import org.apache.commons.lang.RandomStringUtils;

import java.security.MessageDigest;
import java.util.HashMap;

/**
 * Created by hp on 12/3/2015.
 */
public class PayuUtil {


    public static PayUVO getPayUVO(String name, String email, String mobileNumber,
                                   BookingDetailsVO bookingDetailsVO, HashMap<String, Object> searchParamMap) {
        PayUVO payUVO = new PayUVO();
        try {
            payUVO.setFirstName(name);
            payUVO.setEmail(email);
            payUVO.setAmount(bookingDetailsVO.getTotalPrice());
            payUVO.setMerchantKey(WudstayConstants.LIVE_MERCHANT_KEY);
            payUVO.setProductInfo("Hotel Booking");
            payUVO.setSalt(WudstayConstants.LIVE_SALT);
            String transactionId = RandomStringUtils.randomAlphanumeric(15).toUpperCase();
            payUVO.setTransactionId(transactionId);
            payUVO.setPhone(mobileNumber);
            payUVO.setCurl(WudstayConstants.BASE_URL + WudstayMappings.PAYU_PAYMENT_CANCEL);
            payUVO.setSurl(WudstayConstants.BASE_URL + WudstayMappings.PAYU_PAYMENT_SUCCESS);
            payUVO.setFurl(WudstayConstants.BASE_URL + WudstayMappings.PAYU_PAYMENT_FAILURE);

            StringBuffer buffer = new StringBuffer();
            buffer.append(payUVO.getMerchantKey());
            buffer.append("|");
            buffer.append(payUVO.getTransactionId());
            buffer.append("|");
            buffer.append(payUVO.getAmount());
            buffer.append("|");
            buffer.append(payUVO.getProductInfo());
            buffer.append("|");
            buffer.append(payUVO.getFirstName());
            buffer.append("|");
            buffer.append(payUVO.getEmail());

            buffer.append("|");
            payUVO.setUdf1(WudstayUtil.getUDFBookingDetails(bookingDetailsVO));
            buffer.append(payUVO.getUdf1());

            buffer.append("|");
            payUVO.setUdf2(WudstayUtil.getUDFSearchParam(searchParamMap));
            buffer.append(payUVO.getUdf2());

            buffer.append("|||||||||");
            buffer.append(payUVO.getSalt());

            MessageDigest md = MessageDigest.getInstance("SHA-512");
            md.update(buffer.toString().getBytes());

            byte byteData[] = md.digest();

            //convert the byte to hex format method 1
            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < byteData.length; i++) {
                sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
            }

            payUVO.setHash(sb.toString());
            //session.setAttribute(WudstayConstants.PAYU_DETAILS, payUVO);
        } catch (Exception e) {
            e.printStackTrace();
            throw new CustomGenericException(e.getClass().toString(), e.getClass().toString());
        }
        return payUVO;
    }

}
