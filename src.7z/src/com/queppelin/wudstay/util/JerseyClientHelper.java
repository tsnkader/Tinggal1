package com.queppelin.wudstay.util;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.client.urlconnection.HTTPSProperties;

import javax.net.ssl.*;
import java.security.SecureRandom;

/**
 *
 * @author : https://gist.github.com/outbounder/1069465
 * Modified 
 */
public class JerseyClientHelper {
	public static ClientConfig configureClient() {
		
		System.setProperty("https.protocols", "TLSv1");
		
		SSLContext ctx = null;
		try {
			TrustManager[ ] certs = new TrustManager[]{DummyTrustManager.getInstance()};
			ctx = SSLContext.getInstance("TLS");
			ctx.init(new KeyManager[0], certs, new SecureRandom());
		} catch (java.security.GeneralSecurityException ex) {
			ex.printStackTrace();
		}
		
		HttpsURLConnection.setDefaultSSLSocketFactory(ctx.getSocketFactory());

		ClientConfig config = new DefaultClientConfig();
		try {
			config.getProperties().put(HTTPSProperties.PROPERTY_HTTPS_PROPERTIES, new HTTPSProperties(
				new HostnameVerifier() {
					
					public boolean verify(String hostname, SSLSession session) {
						return true;
					}
				}, 
				ctx
			));
		} catch(Exception e) {
		}
		return config;
	}
	
	public static Client createClient() {
		return Client.create(JerseyClientHelper.configureClient());
	}
}
