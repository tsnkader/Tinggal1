package com.queppelin.wudstay.util;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;

import com.queppelin.wudstay.manager.IHotelBookingManager;
import com.queppelin.wudstay.manager.IHotelManager;
import com.queppelin.wudstay.vo.*;
import com.queppelin.wudstay.vo.custom.*;
import com.queppelin.wudstay.webservice.vo.WSHotelVO;
import com.queppelin.wudstay.manager.IPgHotelManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;


public class WudstayUtil {
	private static final Logger logger = LoggerFactory.getLogger(WudstayUtil.class);

	public static final SimpleDateFormat CHECK_IN_CHECK_OUT_DATE_FORMAT = new SimpleDateFormat("dd MMM yyyy"); // 23 sept 2015 dd MMM yyyy WudstayUtil.CHECK_IN_CHECK_OUT_DATE_FORMAT

	//For Tinggal SMS
	public static final String SMS_TIN_loginId = "2000159224";//"2000159224"; ///"2000154258";
	public static final String SMS_TIN_password = "jhUbeGhNs";//"jhUbeGhNs";////"yfFEyFcGw";

   //	WudstayUtil.exceptionPrintStackTrace
	public static String exceptionPrintStackTrace(Throwable aThrowable) {
		final Writer result = new StringWriter();
		final PrintWriter printWriter = new PrintWriter(result);
		aThrowable.printStackTrace(printWriter);
		return result.toString();
	}

	public static String getRoomsAndPersons(Integer rooms, Integer persons) {
		if(persons != null && rooms != null && !persons.equals(WudstayConstants.BLANK) && !rooms.equals(WudstayConstants.BLANK)) {
			StringBuilder builder = new StringBuilder();
			builder.append(persons);
			builder.append(WudstayConstants.SPACE);
			builder.append(WudstayConstants.GUESTS);
			builder.append(WudstayConstants.SPACE);
			builder.append(WudstayConstants.IN);
			builder.append(WudstayConstants.SPACE);
			builder.append(rooms);
			builder.append(WudstayConstants.SPACE);
			builder.append(WudstayConstants.ROOMS);
			return builder.toString();
		}

		return WudstayConstants.BLANK;
	}

	public static List<Long> getRoomTypeIdList(String roomTypeIds) {
		List<Long> roomTypleIdList = new ArrayList<Long>();
		if(roomTypeIds != null && !roomTypeIds.equals(WudstayConstants.BLANK)) {
			String[] splittedIds = roomTypeIds.split(WudstayConstants.COMMA_REGEX);
			for (String id : splittedIds) {
				roomTypleIdList.add(Long.valueOf(id));
			}
		}
		return roomTypleIdList;
	}

	public static String getStayPeriod(String fromDate, String toDate) throws ParseException {
		if(fromDate != null && toDate != null) {
			if(!fromDate.equals(WudstayConstants.BLANK) && !toDate.equals(WudstayConstants.BLANK)) {
				Calendar checkInDateCalendar = Calendar.getInstance();
				Calendar checkOutDateCalendar = Calendar.getInstance();
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				checkInDateCalendar.setTime(dateFormat.parse(fromDate));
				checkOutDateCalendar.setTime(dateFormat.parse(toDate));

				int checkInMonth = checkInDateCalendar.get(Calendar.MONTH);
				int checkOutMonth = checkOutDateCalendar.get(Calendar.MONTH);

				int checkInYear = checkInDateCalendar.get(Calendar.YEAR);
				int checkOutYear = checkOutDateCalendar.get(Calendar.YEAR);

				int checkInDate = checkInDateCalendar.get(Calendar.DATE);;
				int checkOutDate = checkOutDateCalendar.get(Calendar.DATE);;
				StringBuilder builder = new StringBuilder();
				if(checkInMonth == checkOutMonth && checkInYear == checkOutYear) {
					Format formatter = new SimpleDateFormat("MMM");

					builder.append(checkInDate);
					builder.append(WudstayConstants.SPACE);
					builder.append(WudstayConstants.TO);
					builder.append(WudstayConstants.SPACE);
					builder.append(checkOutDate);
					builder.append(WudstayConstants.SPACE);
					builder.append(formatter.format(dateFormat.parse(fromDate)));
					builder.append(WudstayConstants.SPACE);
					builder.append(checkOutYear);
				} else if(checkInMonth != checkOutMonth && checkInYear == checkOutYear) {
					Format formatter = new SimpleDateFormat("MMM");
					builder.append(checkInDate);
					builder.append(WudstayConstants.SPACE);
					builder.append(formatter.format(dateFormat.parse(fromDate)));
					builder.append(WudstayConstants.SPACE);
					builder.append(WudstayConstants.TO);
					builder.append(WudstayConstants.SPACE);
					builder.append(checkOutDate);
					builder.append(WudstayConstants.SPACE);
					builder.append(formatter.format(dateFormat.parse(toDate)));
					builder.append(WudstayConstants.SPACE);
					builder.append(checkOutYear);
				} else if(checkInMonth != checkOutMonth && checkInYear != checkOutYear) {
					Format formatter = new SimpleDateFormat("MMM");
					builder.append(checkInDate);
					builder.append(WudstayConstants.SPACE);
					builder.append(formatter.format(dateFormat.parse(fromDate)));
					builder.append(WudstayConstants.SPACE);
					builder.append(checkInYear);
					builder.append(WudstayConstants.SPACE);
					builder.append(WudstayConstants.TO);
					builder.append(WudstayConstants.SPACE);
					builder.append(checkOutDate);
					builder.append(WudstayConstants.SPACE);
					builder.append(formatter.format(dateFormat.parse(toDate)));
					builder.append(WudstayConstants.SPACE);
					builder.append(checkOutYear);
				}

				return builder.toString();
			}
		}
		return WudstayConstants.BLANK;
	}

	/*public static void setAmenitiesForHotel(List<HotelRoom> hotelRoomList) {

		for (HotelRoom hotelRoom : hotelRoomList) {
			List<HotelAmenity> hotelAmenities = hotelRoom.getHotel().getHotelAmenities();
			if (hotelAmenities.size() > 0) {
				Collections.sort(hotelAmenities, new Comparator<HotelAmenity>() {
					
					public int compare(final HotelAmenity object1, final HotelAmenity object2) {
						return object1.getAmenityListingOrder().compareTo(object2.getAmenityListingOrder());
					}
				});
				StringBuilder builder = new StringBuilder();
				for (HotelAmenity hotelAmenity : hotelAmenities) {
					builder.append(hotelAmenity.getAmenity().getAmenityName());
					builder.append(WudstayConstants.COMMA);
					builder.append(WudstayConstants.SPACE);
				}
				hotelRoom.setHotelAmenities(builder.substring(0, builder.lastIndexOf(WudstayConstants.COMMA)));
			}
		}

	}*/

	public static void setAmenitiesForHotel(List<Hotel> hotelList) {

		for (Hotel hotel : hotelList) {
			List<HotelAmenity> hotelAmenities = hotel.getHotelAmenities();
			if (hotelAmenities.size() > 0) {
				Collections.sort(hotelAmenities, new Comparator<HotelAmenity>() {
					
					public int compare(final HotelAmenity object1, final HotelAmenity object2) {
						return object1.getAmenityListingOrder().compareTo(object2.getAmenityListingOrder());
					}
				});
				StringBuilder builder = new StringBuilder();
				for (HotelAmenity hotelAmenity : hotelAmenities) {
					builder.append(hotelAmenity.getAmenity().getAmenityName());
					builder.append(WudstayConstants.COMMA);
					builder.append(WudstayConstants.SPACE);
				}
				hotel.setHotelAmenity(builder.substring(0, builder.lastIndexOf(WudstayConstants.COMMA)));
			}
		}

	}

	/*public static void setAmenitiesForHotel(List<HotelRoom> hotelRoomList, IHotelManager hotelManager) {
		HashMap<Long, String> hotelIdMap = new HashMap<Long, String>();
		for (HotelRoom hotelRoom : hotelRoomList) {
			hotelIdMap.put(hotelRoom.getHotelId(), hotelRoom.getHotelName());
		}

		Iterator iterator = hotelIdMap.entrySet().iterator();
		while (iterator.hasNext()) {
			Map.Entry pair = (Map.Entry)iterator.next();
			Long hotelId = (Long) pair.getKey();
			Hotel hotel = hotelManager.getById(hotelId);

			List<HotelAmenity> hotelAmenities = hotel.getHotelAmenities();
			if (hotelAmenities.size() > 0) {
				Collections.sort(hotelAmenities, new Comparator<HotelAmenity>() {
					
					public int compare(final HotelAmenity object1, final HotelAmenity object2) {
						return object1.getAmenityListingOrder().compareTo(object2.getAmenityListingOrder());
					}
				});
				StringBuilder builder = new StringBuilder();
				for (HotelAmenity hotelAmenity : hotelAmenities) {
					builder.append(hotelAmenity.getAmenity().getAmenityName());
					builder.append(WudstayConstants.COMMA);
					builder.append(WudstayConstants.SPACE);
				}
				for (HotelRoom hotelRoom : hotelRoomList) {
					if(hotelRoom.getHotelId().equals(hotelId)) {
						hotelRoom.setHotelAmenities(builder.substring(0, builder.lastIndexOf(WudstayConstants.COMMA)));
					}
				}
			}

		}

	}*/

	public static void setAmenitiesForHotel(List<Hotel> hotelList, IHotelManager hotelManager) {
		HashMap<Long, String> hotelIdMap = new HashMap<Long, String>();
		for (Hotel hotel : hotelList) {
			hotelIdMap.put(hotel.getHotelId(), hotel.getHotelName());
		}

		Iterator iterator = hotelIdMap.entrySet().iterator();
		while (iterator.hasNext()) {
			Map.Entry pair = (Map.Entry)iterator.next();
			Long hotelId = (Long) pair.getKey();
			Hotel hotel = hotelManager.getById(hotelId);

			List<HotelAmenity> hotelAmenities = hotel.getHotelAmenities();
			if (hotelAmenities.size() > 0) {
				Collections.sort(hotelAmenities, new Comparator<HotelAmenity>() {
					
					public int compare(final HotelAmenity object1, final HotelAmenity object2) {
						return object1.getAmenityListingOrder().compareTo(object2.getAmenityListingOrder());
					}
				});
				StringBuilder builder = new StringBuilder();
				for (HotelAmenity hotelAmenity : hotelAmenities) {
					builder.append(hotelAmenity.getAmenity().getAmenityName());
					builder.append(WudstayConstants.COMMA);
					builder.append(WudstayConstants.SPACE);
				}
				for (Hotel hotel1 : hotelList) {
					if(hotel1.getHotelId().equals(hotelId)) {
						hotel1.setHotelAmenity(builder.substring(0, builder.lastIndexOf(WudstayConstants.COMMA)));
					}
				}
			}

		}

	}
	public static void setAmenitiesForPgHotel(List<PgHotel> hotelList, IPgHotelManager pgHotelManager) {
		HashMap<Long, String> hotelIdMap = new HashMap<Long, String>();
		for (PgHotel hotel : hotelList) {
			hotelIdMap.put(hotel.getId(), hotel.getName());
		}

		Iterator iterator = hotelIdMap.entrySet().iterator();
		while (iterator.hasNext()) {
			Map.Entry pair = (Map.Entry)iterator.next();
			Long hotelId = (Long) pair.getKey();
			PgHotel hotel = pgHotelManager.getById(hotelId);

			List<PgHotelAmenity> hotelAmenities = hotel.getHotelAmenities();
			if (hotelAmenities.size() > 0) {
				Collections.sort(hotelAmenities, new Comparator<PgHotelAmenity>() {
					
					public int compare(final PgHotelAmenity object1, final PgHotelAmenity object2) {
						return object1.getAmenityListingOrder().compareTo(object2.getAmenityListingOrder());
					}
				});
				StringBuilder builder = new StringBuilder();
				for (PgHotelAmenity hotelAmenity : hotelAmenities) {
					builder.append(hotelAmenity.getAmenity().getAmenityName());
					builder.append(WudstayConstants.COMMA);
					builder.append(WudstayConstants.SPACE);
				}
				for (PgHotel hotel1 : hotelList) {
					if(hotel1.getId().equals(hotelId)) {
						hotel1.setHotelAmenity(builder.substring(0, builder.lastIndexOf(WudstayConstants.COMMA)));
					}
				}
			}

		}
		//---------------------
		/*for (PgHotel hotel : hotelList) {
			List<PgHotelAmenity> hotelAmenities = hotel.getHotelAmenities();
			if (hotelAmenities.size() > 0) {
				Collections.sort(hotelAmenities, new Comparator<PgHotelAmenity>() {
					
					public int compare(final PgHotelAmenity object1, final PgHotelAmenity object2) {
						return object1.getAmenityListingOrder().compareTo(object2.getAmenityListingOrder());
					}
				});
				StringBuilder builder = new StringBuilder();
				for (PgHotelAmenity hotelAmenity : hotelAmenities) {
					builder.append(hotelAmenity.getAmenity().getAmenityName());
					builder.append(WudstayConstants.COMMA);
					builder.append(WudstayConstants.SPACE);
				}
				hotel.setHotelAmenity(builder.substring(0, builder.lastIndexOf(WudstayConstants.COMMA)));
			}
		}*/

	}

	public static void processAmenityList(List<Amenity> amenitiyList,
			List<HotelAmenity> hotelAmenityList) {
		for (Amenity amenity : amenitiyList) {
			for (HotelAmenity hotelAmenity : hotelAmenityList) {
				if(amenity.getAmenityId().equals(hotelAmenity.getAmenity().getAmenityId())) {
					amenity.setIsAvailable(Boolean.TRUE);
					break;
				}
			}
		}
	}

	public static List<RoomTypeVO> processRoomTypeVOList(List<RoomType> roomTypeList,
			List<RoomTypeVO> roomTypeVOList) {
		Boolean isFound = Boolean.FALSE;
		List<RoomTypeVO> updatedRoomTypeVOList = new ArrayList<RoomTypeVO>();
		for (RoomType roomType : roomTypeList) {
			isFound = Boolean.FALSE;
			for (RoomTypeVO roomTypeVO : roomTypeVOList) {
				if(roomType.getRoomTypeId().equals(roomTypeVO.getRoomTypeId())) {
					isFound = Boolean.TRUE;
					updatedRoomTypeVOList.add(roomTypeVO);
					break;
				}
			}
			if(!isFound) {
				RoomTypeVO roomTypeVO = new RoomTypeVO();
				roomTypeVO.setRoomTypeId(roomType.getRoomTypeId());
				roomTypeVO.setRoomType(roomType.getRoomType());
				updatedRoomTypeVOList.add(roomTypeVO);
			}
		}

		return updatedRoomTypeVOList;
	}

	public static String getDefaultCheckInDate() {
		Calendar checkInDate = new GregorianCalendar();
		checkInDate.set(Calendar.HOUR_OF_DAY, 12);
		checkInDate.set(Calendar.MINUTE, 0);
		checkInDate.set(Calendar.SECOND, 0);
		checkInDate.add(Calendar.DAY_OF_MONTH, 0);
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String formattedCheckInDate = format.format(checkInDate.getTime());
		return formattedCheckInDate;
	}

	public static String getDefaultCheckOutDate() {
		Calendar checkOutDate = new GregorianCalendar();
		checkOutDate.set(Calendar.HOUR_OF_DAY, 11);
		checkOutDate.set(Calendar.MINUTE, 0);
		checkOutDate.set(Calendar.SECOND, 0);
		checkOutDate.add(Calendar.DAY_OF_MONTH, 1);
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String formattedCheckOutDate = format.format(checkOutDate.getTime());
		return formattedCheckOutDate;
	}

	public static String getFormattedCheckInDate(String fromDate) throws ParseException {
		Calendar checkInDate = Calendar.getInstance();
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		checkInDate.setTime(dateFormat.parse(fromDate));
		checkInDate.set(Calendar.HOUR_OF_DAY, 12);
		checkInDate.set(Calendar.MINUTE, 0);
		checkInDate.set(Calendar.SECOND, 0);
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String formattedCheckInDate = format.format(checkInDate.getTime());
		return formattedCheckInDate;
	}

	public static String getFormattedCheckOutDate(String toDate) throws ParseException {
		Calendar checkOutDate = Calendar.getInstance();
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		checkOutDate.setTime(dateFormat.parse(toDate));
		checkOutDate.set(Calendar.HOUR_OF_DAY, 11);
		checkOutDate.set(Calendar.MINUTE, 0);
		checkOutDate.set(Calendar.SECOND, 0);
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String formattedCheckOutDate = format.format(checkOutDate.getTime());
		return formattedCheckOutDate;
	}

	public static Date getFormattedCheckInDateObject(String fromDate) throws ParseException {
		Calendar checkInDate = Calendar.getInstance();
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		checkInDate.setTime(dateFormat.parse(fromDate));
		checkInDate.set(Calendar.HOUR_OF_DAY, 12);
		checkInDate.set(Calendar.MINUTE, 0);
		checkInDate.set(Calendar.SECOND, 0);
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String formattedCheckInDate = format.format(checkInDate.getTime());
		//return formattedCheckInDate;
		return format.parse(formattedCheckInDate);
	}

	public static Date getFormattedCheckOutDateObject(String toDate) throws ParseException {
		Calendar checkOutDate = Calendar.getInstance();
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		checkOutDate.setTime(dateFormat.parse(toDate));
		checkOutDate.set(Calendar.HOUR_OF_DAY, 11);
		checkOutDate.set(Calendar.MINUTE, 0);
		checkOutDate.set(Calendar.SECOND, 0);
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String formattedCheckOutDate = format.format(checkOutDate.getTime());
		//return formattedCheckOutDate;
		return format.parse(formattedCheckOutDate);
	}



	public static BookingDetailsVO getBookingDetailsVO(String city, String checkIn, String checkOut, Integer rooms, Integer persons, Hotel hotel) {
		BookingDetailsVO bookingDetailsVO = new BookingDetailsVO();
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

		try {
			Date checkInDate = dateFormat.parse(checkIn.trim());
			Date checkOutDate = dateFormat.parse(checkOut.trim());
			long diff = checkOutDate.getTime() - checkInDate.getTime();
			int nights = (int) TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
			bookingDetailsVO.setNights(nights);

			dateFormat = new SimpleDateFormat("EEEE, dd MMMMM yyyy");
			bookingDetailsVO.setCheckInDate(dateFormat.format(checkInDate));
			bookingDetailsVO.setCheckOutDate(dateFormat.format(checkOutDate));
			//bookingDetailsVO.setPrice(hotel.getPrice());
			bookingDetailsVO.setHotelDisplayName(hotel.getHotelDisplayName());
			bookingDetailsVO.setHotelName(hotel.getHotelName());
			bookingDetailsVO.setCity(city);
			bookingDetailsVO.setAddress(hotel.getHotelAddress());
			bookingDetailsVO.setDisplayAddress(hotel.getHotelDisplayAddress());
			bookingDetailsVO.setHotelId(hotel.getHotelId());
			bookingDetailsVO.setMaxBookingPerMobNum(hotel.getMaxBookingPerMobNum());
			bookingDetailsVO.setMapLink(hotel.getMapLink());
			bookingDetailsVO.setRoomTypeMaster(hotel.getRoomTypeMaster().getDescription());

			List<RoomDetailsVO> roomDetailsVOList = new ArrayList<RoomDetailsVO>();
			RoomDetailsVO roomDetailsVO = null;
			int paxInEachRoom = persons/rooms;
			for(int i = 1; i <= rooms; i++) {
				roomDetailsVO = new RoomDetailsVO();
				roomDetailsVO.setPax(paxInEachRoom);
				roomDetailsVO.setRoomName("Room " + i);
				if(paxInEachRoom == 1) {
					//roomDetailsVO.setTotalRoomPrice(hotel.getSingleOccupancyPrice() * nights);
					roomDetailsVO.setRoomPrice(nights, hotel.getSingleOccupancyPrice(), hotel.getSingleOccupancyContractualPrice());
				} else if(paxInEachRoom == 2) {
					//roomDetailsVO.setTotalRoomPrice(hotel.getDoubleOccupancyPrice() * nights);
					roomDetailsVO.setRoomPrice(nights, hotel.getDoubleOccupancyPrice(), hotel.getDoubleOccupancyContractualPrice());
				} else if(paxInEachRoom == 3) {
					//roomDetailsVO.setTotalRoomPrice(hotel.getTripleOccupancyPrice() * nights);
					roomDetailsVO.setRoomPrice(nights, hotel.getTripleOccupancyPrice(), hotel.getTripleOccupancyContractualPrice());
				}
				//roomDetailsVO.setTotalRoomPrice(hotel.getPrice() * nights);
				roomDetailsVOList.add(roomDetailsVO);
			}

			int remainingPax = persons%rooms;
			roomDetailsVO = null;
			for(int i = remainingPax; i > 0; i--) {
				roomDetailsVO = roomDetailsVOList.get(i - 1);
				roomDetailsVO.setPax(roomDetailsVO.getPax() + 1);
				if(roomDetailsVO.getPax() == 1) {
					//roomDetailsVO.setTotalRoomPrice(hotel.getSingleOccupancyPrice() * nights);
					roomDetailsVO.setRoomPrice(nights, hotel.getSingleOccupancyPrice(), hotel.getSingleOccupancyContractualPrice());
				} else if(roomDetailsVO.getPax() == 2) {
					//roomDetailsVO.setTotalRoomPrice(hotel.getDoubleOccupancyPrice() * nights);
					roomDetailsVO.setRoomPrice(nights, hotel.getDoubleOccupancyPrice(), hotel.getDoubleOccupancyContractualPrice());
				} else if(roomDetailsVO.getPax() == 3) {
					//roomDetailsVO.setTotalRoomPrice(hotel.getTripleOccupancyPrice() * nights);
					roomDetailsVO.setRoomPrice(nights, hotel.getTripleOccupancyPrice(), hotel.getTripleOccupancyContractualPrice());
				}
			}
			int totalPrice = 0;
			int totalContractualPrice = 0;

			for (RoomDetailsVO roomDetails : roomDetailsVOList) {
				try { //Should be handel in case of "roomDetails.getTotalRoomPrice()" is null    :: SSR 28092015
					totalPrice += roomDetails.getTotalRoomPrice();
					totalContractualPrice += roomDetails.getTotalRoomContractualPrice();
					if (roomDetails.getPax().equals(Integer.valueOf(1))) {
						roomDetails.setOccupancy("Single Occupancy");
					} else if (roomDetails.getPax().equals(Integer.valueOf(2))) {
						roomDetails.setOccupancy("Double Occupancy");
					} else {
						roomDetails.setOccupancy("Triple Occupancy");
					}
				}catch (Exception ex){
					ex.printStackTrace();
				}
			}
			bookingDetailsVO.setTotalPrice(totalPrice );
			bookingDetailsVO.setTotalPriceContractual(totalContractualPrice);
			bookingDetailsVO.setRoomDetailsVOList(roomDetailsVOList);
			bookingDetailsVO.setRoomTypeMaster(hotel.getRoomTypeMaster().getDescription());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return bookingDetailsVO;
	}

	public static void sendVerificationCode(NumberVerification numberVerification) {
		try {
			String msg = "Dear Customer, your Tinggal verification code is" + numberVerification.getVerificationCode();
			
			System.out.println("Verification Code: "  + numberVerification.getVerificationCode() + " ON MobileNo: " + numberVerification.getMobileNumber());
			System.out.println("SMS LOG: MESSAGE: " + msg);
			String data = ""; 
			data += "method=sendMessage"; 
			data += "&userid=" + SMS_TIN_loginId; // your loginId
			data += "&password=" + URLEncoder.encode(SMS_TIN_password, "UTF-8"); // your password
			//data += "&msg=" + URLEncoder.encode("Dear Customer, your Tinggal verification code is " + numberVerification.getVerificationCode(), "UTF-8");
			data += "&msg=" + URLEncoder.encode( new String(msg) , "UTF-8");
			data += "&send_to=" + URLEncoder.encode(  numberVerification.getMobileNumber(), "UTF-8"); // a valid 10 digit phone no.
			data += "&v=1.1" ; 
			data += "&msg_type=TEXT"; // Can by "FLASH" or "UNICODE_TEXT" or �BINARY�

			data += "&auth_scheme=PLAIN";
			System.out.println("DATA: "+ data);
			System.out.println("URL: http://enterprise.smsgupshup.com/GatewayAPI/rest?"+ data);
			URL url = new URL("http://enterprise.smsgupshup.com/GatewayAPI/rest?" + data); 
			HttpURLConnection conn = (HttpURLConnection)url.openConnection();
			conn.setRequestMethod("GET");
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setUseCaches(false);
			conn.connect();
			BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String line;
			StringBuffer buffer = new StringBuffer();
			while ((line = rd.readLine()) != null){
				buffer.append(line).append("\n");
			}
			String res = buffer.toString();
			logger.info("SMS LOG: data" + data );
			logger.info("SMS LOG: Res: "+ res);

			System.out.println("SMS LOG: data" + data);
			System.out.println("SMS LOG: Res: " + res);

			rd.close();
			conn.disconnect(); 
		} catch(Exception e){
			e.printStackTrace();
		}
	}



	public static WSHotelVO getHotelWS(Hotel hotel, String baseUrl, int minPax,HttpServletRequest request) {
		WSHotelVO wsHotelVOList = null;
		WSHotelVO wsHotelVO = new WSHotelVO();
		wsHotelVO = new WSHotelVO();
		wsHotelVO.setHotelAddress(hotel.getHotelAddress());
		wsHotelVO.setHotelDisplayName(hotel.getHotelDisplayName());
		wsHotelVO.setHotelId(hotel.getHotelId());
		wsHotelVO.setHotelName(hotel.getHotelName());
		wsHotelVO.setLatitude(hotel.getLatitude());
		wsHotelVO.setLongitude(hotel.getLongitude());
		wsHotelVO.setLocationId(hotel.getLocation().getLocationId());
		wsHotelVO.setAmenityList(getAmenityList(hotel.getHotelAmenity()));
		wsHotelVO.setHotelContactPerson1("+62822 8539 0099");

		if(minPax == 1) {
			wsHotelVO.setPrice(hotel.getSingleOccupancyPrice());
		} else if(minPax == 2) {
			wsHotelVO.setPrice(hotel.getDoubleOccupancyPrice());
		} else if(minPax == 3) {
			wsHotelVO.setPrice(hotel.getTripleOccupancyPrice());
		}

		wsHotelVO.setSingleOccupancyPrice(hotel.getSingleOccupancyPrice());
		wsHotelVO.setDoubleOccupancyPrice(hotel.getDoubleOccupancyPrice());
		wsHotelVO.setTripleOccupancyPrice(hotel.getTripleOccupancyPrice());
		wsHotelVO.setRoomImage(baseUrl + "hotel_images" + File.separator + hotel.getHotelId() + File.separator + "rooms" + File.separator + "room.png");
		wsHotelVO.setHotelImageList(getHotelImagesList(hotel.getHotelId(), baseUrl,request));
		wsHotelVO.setStarRating(hotel.getStarRating());
		wsHotelVO.setRoomType(hotel.getRoomType().getRoomType());
		wsHotelVO.setHotelDisplayAddress(hotel.getHotelDisplayAddress());
		try { //ssr 16 10 2015
			Location location = hotel.getLocation();
			wsHotelVO.setHotelCity(location.getCity().getCityName());
			wsHotelVO.setHotelCityId(hotel.getLocation().getCity().getCityId()); // Hemraj 19 12 2015
		}catch (Exception ex){
			ex.printStackTrace();
		}

		return wsHotelVO;
	}
	public static List<WSHotelVO> getHotelListWS(List<Hotel> hotelList, String baseUrl, int minPax,HttpServletRequest request) {
		List<WSHotelVO> wsHotelVOList = new ArrayList<WSHotelVO>();
		WSHotelVO wsHotelVO = new WSHotelVO();
		for (Hotel hotel : hotelList) {
			wsHotelVO = new WSHotelVO();
			wsHotelVO.setHotelAddress(hotel.getHotelAddress());
			wsHotelVO.setHotelDisplayName(hotel.getHotelDisplayName());
			wsHotelVO.setHotelId(hotel.getHotelId());
			wsHotelVO.setHotelName(hotel.getHotelName());
			wsHotelVO.setLatitude(hotel.getLatitude());
			wsHotelVO.setLongitude(hotel.getLongitude());
			wsHotelVO.setLocationId(hotel.getLocation().getLocationId());
			wsHotelVO.setAmenityList(getAmenityList(hotel.getHotelAmenity()));
			wsHotelVO.setHotelContactPerson1("+62822 8539 0099");
			if(minPax == 1) {
				wsHotelVO.setPrice(hotel.getSingleOccupancyPrice());
			} else if(minPax == 2) {
				wsHotelVO.setPrice(hotel.getDoubleOccupancyPrice());
			} else if(minPax == 3) {
				wsHotelVO.setPrice(hotel.getTripleOccupancyPrice());
			}
			wsHotelVO.setSingleOccupancyPrice(hotel.getSingleOccupancyPrice());
			wsHotelVO.setDoubleOccupancyPrice(hotel.getDoubleOccupancyPrice());
			wsHotelVO.setTripleOccupancyPrice(hotel.getTripleOccupancyPrice());
			wsHotelVO.setRoomImage(baseUrl + "hotel_images" + File.separator + hotel.getHotelId() + File.separator + "rooms" + File.separator + "room.png");
			wsHotelVO.setHotelImageList(getHotelImagesList(hotel.getHotelId(), baseUrl,request));
			wsHotelVO.setStarRating(hotel.getStarRating());
			wsHotelVO.setRoomType(hotel.getRoomType().getRoomType());
			wsHotelVO.setHotelDisplayAddress(hotel.getHotelDisplayAddress());
			try { //ssr 16 10 2015
				Location location = hotel.getLocation();
				wsHotelVO.setHotelCity(location.getCity().getCityName());
			}catch (Exception ex){
				ex.printStackTrace();
			}

			wsHotelVOList.add(wsHotelVO);
		}
		return wsHotelVOList;
	}

	public static List<String> getHotelImagesList(Long hotelId, String baseUrl,HttpServletRequest request) {
		List<String> hotelImageList = new ArrayList<String>();
		String directoryPath =  request.getRealPath("/")+"hotel_images/"+hotelId+"/others/";
		//String directoryPath = WudstayUtil.getOtherImagesDirPath(hotelId);
		File directory = new File(directoryPath);
		File[] listOfFiles = directory.listFiles();

		if(listOfFiles != null) {
			for (int i = 0; i < listOfFiles.length; i++) {
				if (listOfFiles[i].isFile()) {
					hotelImageList.add(baseUrl + "hotel_images" + File.separator + hotelId + File.separator + "others" + File.separator + listOfFiles[i].getName());
				}
			}
		}
		Collections.sort(hotelImageList);
		return hotelImageList;
	}

	private static List<String> getAmenityList(String hotelAmenity) {
		List<String> hotelAmenityList = new ArrayList<String>();
		String[] amenityArray = hotelAmenity.split(",");
		for (String amenity : amenityArray) {
			hotelAmenityList.add(amenity);
		}
		return hotelAmenityList;
	}

	public static String getOtherImagesDirPath(Long hotelId) {
		StringBuffer buffer = new StringBuffer();
		buffer.append(File.separator);
		buffer.append("home");
		buffer.append(File.separator);
		buffer.append("ubuntu");
		buffer.append(File.separator);
		buffer.append("wudstay");
		buffer.append(File.separator);
		buffer.append("hotel_images");
		buffer.append(File.separator);
		buffer.append(hotelId);
		buffer.append(File.separator);
		buffer.append("others");
		return buffer.toString();
	}

	public static String getRoomImageDirPath(Long hotelId) {
		StringBuffer buffer = new StringBuffer();
		buffer.append(File.separator);
		buffer.append("home");
		buffer.append(File.separator);
		buffer.append("ubuntu");
		buffer.append(File.separator);
		buffer.append("wudstay");
		buffer.append(File.separator);
		buffer.append("hotel_images");
		buffer.append(File.separator);
		buffer.append(hotelId);
		buffer.append(File.separator);
		buffer.append("rooms");
		return buffer.toString();
	}

	public static List<String> getHotelImages(Long hotelId, HttpServletRequest request) {
		List<String> hotelImageList = new ArrayList<String>();
		String directoryPath =  request.getRealPath("/")+"hotel_images/"+hotelId+"/others/";
		//String directoryPath = WudstayUtil.getOtherImagesDirPath(hotelId);
		File directory = new File(directoryPath);
		File[] listOfFiles = directory.listFiles();

		if(listOfFiles != null) {
			for (int i = 0; i < listOfFiles.length; i++) {
				if (listOfFiles[i].isFile()) {
					hotelImageList.add(listOfFiles[i].getName());
				}
			}
		}
		Collections.sort(hotelImageList);
		return hotelImageList;
	}
	/*public static String getNewUploadedFileName(File directory, String newUploadedFileName) {
		int indexOfNewFileInDirectory = 0 ;
		if(!directory.exists()) {
			directory.mkdirs();
		}
		try {
			File[] listOfFiles = directory.listFiles();
			indexOfNewFileInDirectory= listOfFiles.length+1;
			for(File file: listOfFiles){
				if(file.isFile()){

				}

			}
		}catch (Exception ex1){
			ex1.printStackTrace();
		}





		String ext = getFileExtension(newUploadedFileName);
		String name = file.getName();
		try {
			return name.substring(name.lastIndexOf(".") + 1);
		} catch (Exception e) {
			return "";
		}
	}*/
	public static String getFileExtension(String name) {
		try {
			return name.substring(name.lastIndexOf(".") + 1);
		} catch (Exception e) {
			return "";
		}
	}

	public static List<String> getPgHotelImages(Long hotelId) {
		List<String> hotelImageList = new ArrayList<String>();
		String directoryPath = WudstayUtil.getOtherImagesDirPath(hotelId)+"_pg";
		File directory = new File(directoryPath);
		File[] listOfFiles = directory.listFiles();

		if(listOfFiles != null) {
			for (int i = 0; i < listOfFiles.length; i++) {
				if (listOfFiles[i].isFile()) {
					hotelImageList.add(listOfFiles[i].getName());
				}
			}
		}
		Collections.sort(hotelImageList);
		return hotelImageList;
	}

	public static String getBookingId() {
		Random r = new Random();
		StringBuilder randomString = new StringBuilder();
		for (int i = 0; i < 4; ++i) {
			int j = 65 + r.nextInt(90-65);
			char c = (char) j;
			randomString.append(c);
		}
		int verificationCode = 0;

		while(String.valueOf(verificationCode).length() < 4) {
			verificationCode = (int) (Math.random() * 10000);
		}
		randomString.append(verificationCode);
		return randomString.toString();
	}

	public static List<Hotel> processHotelList(List<Hotel> hotelList, Integer rooms, Integer persons, IHotelBookingManager hotelBookingManager, String checkIn, String checkOut, IHotelManager hotelManager) {
		int i=0;
		List<Hotel> processedHotelList = new ArrayList<Hotel>();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			for (Hotel hotel : hotelList) {
				hotel.setSrNo(i++);
				/*int roomCount = hotel.getNoOfRooms(); // hotel.getHotelRooms().size();
				if(roomCount == 0) {
					//roomCount = hotelManager.getById(hotel.getHotelId()).getHotelRooms().size();
					roomCount = hotelManager.getById(hotel.getHotelId()).getNoOfRooms(); //.getHotelRooms().size();
				}
				List<HotelBooking> hotelBookingList = hotelBookingManager.getBookingsBetweenSelectedDates(hotel.getHotelId(), format.parse(checkIn), format.parse(checkOut));
				for (HotelBooking hotelBooking : hotelBookingList) {
					if(!hotelBooking.getIsCancelled()) {
						roomCount -= hotelBooking.getNoOfRooms();
					}
				}*/


				int roomCount = -1;
				Map<Long, RoomAvailabilityDayWise > roomAvailabilityMap = hotelBookingManager.getRoomAvailabilityDayWise(hotel.getHotelId(), format.parse(checkIn), format.parse(checkOut));
				for (Map.Entry<Long, RoomAvailabilityDayWise> roomEntry : roomAvailabilityMap.entrySet()) {
					//System.out.println(roomEntry.getKey() + "/" + roomEntry.getValue());
					RoomAvailabilityDayWise room = roomEntry.getValue();
					if(roomCount<0 || roomCount>room.getAvailableRooms()){
						roomCount=room.getAvailableRooms();
					}
				}
				if(roomCount<0){
					roomCount=0;
				}
				
				//if(roomCount >= rooms) {
					int pax = persons/rooms;
					if(pax == 1) {
						hotel.setPrice(hotel.getSingleOccupancyPrice());
					} else if(pax == 2) {
						hotel.setPrice(hotel.getDoubleOccupancyPrice());
					} else if(pax == 3) {
						hotel.setPrice(hotel.getTripleOccupancyPrice());
					}
					//processedHotelList.add(hotel);
				//}
				hotel.setRoomsAvailable((roomCount >= rooms) );
				processedHotelList.add(hotel);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return processedHotelList;
	}

	public static List<Hotel> moveSoldOutHotelAtTheEndOfList(List<Hotel> hotelList){
		/*int i=0;
		for(Hotel h: hotelList){
			h.setSrNo(i++);
		}*/
		Collections.sort(hotelList, new Comparator(){
			public int compare(Object o1, Object o2) {
				if(o1 instanceof Hotel && o2 instanceof Hotel){
					Hotel hotel1 = (Hotel)o1;
					Hotel hotel2 = (Hotel)o2;
					if(hotel1.getRoomsAvailable() == false &&  hotel2.getRoomsAvailable() == false){
						//return -1;
					}else if(hotel2.getRoomsAvailable() == false){
						return 1;
					}else if(hotel1.getRoomsAvailable() == false){
						return 1;
					}
					return hotel1.getSrNo() - hotel2.getSrNo();
				}
				return 0;
			}
		});
		return hotelList;
	}

	public static void sendConfirmationMessage(String message, String mobileNumber) {
		try {
			if(!mobileNumber.startsWith("+") ) {//|| mobileNumber.startsWith("+91") || mobileNumber.trim().startsWith("91") )
				mobileNumber = "+" + mobileNumber;
			}

			System.out.println("ConfirmationMessage: "  + message  + " ON MobileNo: " + mobileNumber );
			logger.info("ORG SMS LOG: MESSAGE: " + message);
			//Date mydate = new Date(System.currentTimeMillis()); 
			String data = ""; 
			data += "method=sendMessage"; 
			data += "&userid=" + SMS_TIN_loginId; // your loginId
			data += "&password=" + URLEncoder.encode(SMS_TIN_password, "UTF-8"); // your password
			data += "&msg=" + URLEncoder.encode(message, "UTF-8");
			data += "&send_to=" + URLEncoder.encode( mobileNumber, "UTF-8"); // a valid 10 digit phone no.
			data += "&v=1.1" ; 
			data += "&msg_type=TEXT"; // Can by "FLASH" or "UNICODE_TEXT" or �BINARY�

			data += "&auth_scheme=PLAIN";
			System.out.println("DATA: "+ data);
			System.out.println("URL: http://enterprise.smsgupshup.com/GatewayAPI/rest?"+ data);
			URL url = new URL("http://enterprise.smsgupshup.com/GatewayAPI/rest?" + data); 
			HttpURLConnection conn = (HttpURLConnection)url.openConnection();
			conn.setRequestMethod("GET");
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setUseCaches(false);
			conn.connect();
			BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String line;
			StringBuffer buffer = new StringBuffer();
			while ((line = rd.readLine()) != null){
				buffer.append(line).append("\n");
			}

			String res  = buffer.toString();
			logger.info("ORG SMS LOG: data" + data );
			logger.info("ORG SMS LOG: Res: " + res);

			System.out.println("ORG SMS LOG: data" + data);
			System.out.println("ORG SMS LOG: Res: " + res);

			rd.close();
			conn.disconnect();
			
			
		} catch(Exception e){
			logger.info("Error in sendConfirmationMessage ..." + e.getMessage());
			e.printStackTrace();
		}
		System.out.println("----- sendConfirmationMessage -----");
	}
	
	public static void sendConfirmationMail(String name, String email,
			BookingDetailsVO bookingDetailsVO, List<String> ccList, String bookingId, Integer paidAmount) throws MessagingException {
		Map<String, Object> bookingConfirmationBodyDetails = new HashMap<String, Object>();
		bookingConfirmationBodyDetails.put("GUEST", name);
		bookingConfirmationBodyDetails.put("CHECK_IN", bookingDetailsVO.getCheckInDate().split(",")[1].trim());
		bookingConfirmationBodyDetails.put("CHECK_OUT", bookingDetailsVO.getCheckOutDate().split(",")[1].trim());
		bookingConfirmationBodyDetails.put("HOTEL_DISPLAY_NAME", bookingDetailsVO.getHotelDisplayName());
		bookingConfirmationBodyDetails.put("BOOKING_ID", bookingId);
		bookingConfirmationBodyDetails.put("ROOM_COUNT", bookingDetailsVO.getRoomDetailsVOList().size());
		bookingConfirmationBodyDetails.put("NIGHT_COUNT", bookingDetailsVO.getNights());
		bookingConfirmationBodyDetails.put("TOTAL_PRICE", bookingDetailsVO.getTotalPrice());
		bookingConfirmationBodyDetails.put("PAID", paidAmount);
		//bookingConfirmationBodyDetails.put("MAP_LINK", bookingDetailsVO.getMapLink());
		EmailSender.getInstance().sendEmail(email, "Booking Confirmation", bookingConfirmationBodyDetails, WudstayConstants.BOOKING_CONFIRMATION_EMAIL_BODY, ccList);
	}
	
	public static List<HotelBookingVO> getHotelBookings(
			List<HotelBooking> hotelBookingList, String baseUrl) throws ParseException {
		
		List<HotelBookingVO> hotelBookingVOList = new ArrayList<HotelBookingVO>();
		for (HotelBooking hotelBooking : hotelBookingList) {
			HotelBookingVO hotelBookingVO = new HotelBookingVO();
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String checkIn = format.format(hotelBooking.getCheckIn().getTime());
			String checkOut = format.format(hotelBooking.getCheckOut().getTime());
			hotelBookingVO.setStayPeriod(WudstayUtil.getStayPeriod(checkIn, checkOut));
			hotelBookingVO.setCityName(hotelBooking.getHotel().getLocation().getCity().getCityName());
			hotelBookingVO.setHotelDisplayName(hotelBooking.getHotel().getHotelDisplayName());
			hotelBookingVO.setHotelDisplayAddress(hotelBooking.getHotel().getHotelDisplayAddress());
			hotelBookingVO.setPersons(hotelBooking.getNoOfPeople());
			hotelBookingVO.setRooms(hotelBooking.getNoOfRooms());
			hotelBookingVO.setTotalAmount(hotelBooking.getTotalAmount());
			hotelBookingVO.setIsCancelled(hotelBooking.getIsCancelled());
			hotelBookingVO.setHotelBookingId(hotelBooking.getBookingId());
			hotelBookingVO.setLatitude(hotelBooking.getHotel().getLatitude());
			hotelBookingVO.setLongitude(hotelBooking.getHotel().getLongitude());
			hotelBookingVO.setHotelContactPerson1("+62822 8539 0099");
			Calendar calendar = Calendar.getInstance();
			Date currentDate = calendar.getTime();
			if(!hotelBooking.getIsCancelled()) {
				if(currentDate.compareTo(hotelBooking.getCheckIn()) < 0) {
					hotelBookingVO.setStatus("CANCEL");
				} else if(currentDate.compareTo(hotelBooking.getCheckOut()) > 0) {
					hotelBookingVO.setStatus("STAY COMPLETE");
				} else {
					hotelBookingVO.setStatus("CANCEL");
				}
			} else {
				hotelBookingVO.setStatus("CANCELLED");
			}
			hotelBookingVO.setRoomImage(baseUrl + "hotel_images" + File.separator + hotelBooking.getHotel().getHotelId() + File.separator + "rooms" + File.separator + "room.png");

			hotelBookingVO.setOnlinePaid(hotelBooking.getIsPaid());
			hotelBookingVO.setPaidAmount(hotelBooking.getTotalAmount());

			hotelBookingVOList.add(hotelBookingVO);
		}
		return hotelBookingVOList;
	}

	public static HotelAvailabilityVO isAvailable(Hotel hotel, Integer rooms,
											String checkIn, String checkOut, IHotelBookingManager hotelBookingManager) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		HotelAvailabilityVO hotelAvailabilityVO = new HotelAvailabilityVO();
		Date toDate = null;
		Date fromDate = null;
		try {
			int roomCount = -1;
			toDate = format.parse(checkOut);
			fromDate = format.parse(checkIn);
			Map<Long, RoomAvailabilityDayWise > roomAvailabilityMap = hotelBookingManager.getRoomAvailabilityDayWise(hotel.getHotelId(), fromDate, toDate );
			for (Map.Entry<Long, RoomAvailabilityDayWise> roomEntry : roomAvailabilityMap.entrySet()) {
				//System.out.println(roomEntry.getKey() + "/" + roomEntry.getValue());
				RoomAvailabilityDayWise room = roomEntry.getValue();
				if(roomCount<0 || roomCount>room.getAvailableRooms()){
					roomCount=room.getAvailableRooms();
				}
			}
			if(roomCount<0){
				roomCount=0;
			}

			if(roomCount >= rooms) {
				hotelAvailabilityVO.setIsAvailable(Boolean.TRUE);
				hotelAvailabilityVO.setRooms(roomCount);
			} else {
				hotelAvailabilityVO.setIsAvailable(Boolean.FALSE);
				hotelAvailabilityVO.setRooms(roomCount);
				//hotelAvailabilityVO.setErrMsg("Room(s) not Availabile");
			}
			hotelAvailabilityVO.setStatus(Boolean.TRUE);
		} catch (Exception e) {
			hotelAvailabilityVO.setStatus(Boolean.FALSE);
			e.printStackTrace();
		}
		try {
			City city = hotel.getLocation().getCity();
			Long cityId = city.getCityId();
			//Date checkOutDate  = toDate;//WudstayUtil.getFormattedCheckOutDateObject(checkOut.trim());
			// WudstayUtil.getFormattedCheckInDateObject(checkIn.trim())
			DateUtil dt = new DateUtil(toDate);
			boolean isBlackoutDateForCheckOut = hotelBookingManager.isBlackoutDateForCheckOut(toDate, cityId);
			if (isBlackoutDateForCheckOut){
				hotelAvailabilityVO.setStatus(Boolean.FALSE);
				hotelAvailabilityVO.setErrMsg(dt.getRdNdStFormate() + " checkout not allowed in " + city.getCityName());
			}else{
				/*isBlackoutDateForCheckOut = hotelBookingManager.isBlackoutDateForPayAtHotel(fromDate, toDate, cityId);
				if (isBlackoutDateForCheckOut){
					hotelAvailabilityVO.setStatus(Boolean.FALSE);
					hotelAvailabilityVO.setErrMsg("On selected date pay at hotel not allowed  in " + city.getCityName());
				}*/
			}
		}catch (Exception ex){
			ex.printStackTrace();
		}

		return hotelAvailabilityVO;
	}
	public static HotelAvailabilityVO isAvailable(Long cityId, String cityName, Long hotelId, Integer rooms,
												  String checkIn, String checkOut, IHotelBookingManager hotelBookingManager) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		HotelAvailabilityVO hotelAvailabilityVO = new HotelAvailabilityVO();
		Date toDate = null;
		Date fromDate = null;
		try {
			int roomCount = -1;
			toDate = format.parse(checkOut);
			fromDate = format.parse(checkIn);
			Map<Long, RoomAvailabilityDayWise > roomAvailabilityMap = hotelBookingManager.getRoomAvailabilityDayWise(hotelId, fromDate, toDate );
			for (Map.Entry<Long, RoomAvailabilityDayWise> roomEntry : roomAvailabilityMap.entrySet()) {
				//System.out.println(roomEntry.getKey() + "/" + roomEntry.getValue());
				RoomAvailabilityDayWise room = roomEntry.getValue();
				if(roomCount<0 || roomCount>room.getAvailableRooms()){
					roomCount=room.getAvailableRooms();
				}
			}
			if(roomCount<0){
				roomCount=0;
			}

			if(roomCount >= rooms) {
				hotelAvailabilityVO.setIsAvailable(Boolean.TRUE);
				hotelAvailabilityVO.setRooms(roomCount);
			} else {
				hotelAvailabilityVO.setIsAvailable(Boolean.FALSE);
				hotelAvailabilityVO.setRooms(roomCount);
			}
			hotelAvailabilityVO.setStatus(Boolean.TRUE);
		} catch (Exception e) {
			hotelAvailabilityVO.setStatus(Boolean.FALSE);
			e.printStackTrace();
		}
		try {
			//Date checkOutDate  = toDate;//WudstayUtil.getFormattedCheckOutDateObject(checkOut.trim());
			// WudstayUtil.getFormattedCheckInDateObject(checkIn.trim())
			DateUtil dt = new DateUtil(toDate);
			boolean isBlackoutDateForCheckOut = hotelBookingManager.isBlackoutDateForCheckOut(toDate, cityId);
			if (isBlackoutDateForCheckOut){
				hotelAvailabilityVO.setStatus(Boolean.FALSE);
				hotelAvailabilityVO.setErrMsg(dt.getRdNdStFormate() + " checkout not allowed in " + cityName);
			}else{
				/*isBlackoutDateForCheckOut = hotelBookingManager.isBlackoutDateForPayAtHotel(fromDate, toDate, cityId);
				if (isBlackoutDateForCheckOut){
					hotelAvailabilityVO.setStatus(Boolean.FALSE);
					hotelAvailabilityVO.setErrMsg("On selected date pay at hotel not allowed  in " + city.getCityName());
				}*/
			}
		}catch (Exception ex){
			ex.printStackTrace();
		}

		return hotelAvailabilityVO;
	}
	public static HotelAvailabilityVO isAvailable_26102015(Hotel hotel, Integer rooms,
												  String checkIn, String checkOut, IHotelBookingManager hotelBookingManager) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		HotelAvailabilityVO hotelAvailabilityVO = new HotelAvailabilityVO();
		try {
			//int roomCount = hotel.getHotelRooms().size();
			int roomCount =0;
				/*for(HotelRoom room : hotel.getHotelRooms()){
					if(room.getIsActive())
						roomCount=roomCount+1;
				}*/
			roomCount = roomCount + hotel.getNoOfRooms();

			List<HotelBooking> hotelBookingList = hotelBookingManager.getBookingsBetweenSelectedDates(hotel.getHotelId(), format.parse(checkIn), format.parse(checkOut));
			for (HotelBooking hotelBooking : hotelBookingList) {
				roomCount -= hotelBooking.getNoOfRooms();
			}
			if(roomCount >= rooms) {
				hotelAvailabilityVO.setIsAvailable(Boolean.TRUE);
				hotelAvailabilityVO.setRooms(roomCount);
			} else {
				hotelAvailabilityVO.setIsAvailable(Boolean.FALSE);
				hotelAvailabilityVO.setRooms(roomCount);
			}
			hotelAvailabilityVO.setStatus(Boolean.TRUE);
		} catch (Exception e) {
			hotelAvailabilityVO.setStatus(Boolean.FALSE);
			e.printStackTrace();
		}
		return hotelAvailabilityVO;
	}

	public static String getUDFBookingDetails(BookingDetailsVO bookingDetailsVO) {
		StringBuffer buffer = new StringBuffer();
		buffer.append(bookingDetailsVO.getCheckInDate());
		buffer.append(WudstayConstants.HASH);
		buffer.append(bookingDetailsVO.getCheckOutDate());
		buffer.append(WudstayConstants.HASH);
		buffer.append(bookingDetailsVO.getHotelId());
		buffer.append(WudstayConstants.HASH);
		buffer.append(bookingDetailsVO.getNights());
		buffer.append(WudstayConstants.HASH);
		buffer.append(bookingDetailsVO.getTotalPrice());
		try{// Extra parametrs for the  VERITRANS
			buffer.append(WudstayConstants.HASH);
			buffer.append(bookingDetailsVO.getTotalPriceContractual());
			buffer.append(WudstayConstants.HASH);
			buffer.append(bookingDetailsVO.getRoomTypeMaster());
		}catch (Exception ex){
			ex.printStackTrace();
		}
		return buffer.toString();
	}

	public static String getUDFSearchParam(
			HashMap<String, Object> searchParamMap) {
		StringBuffer buffer = new StringBuffer();
		buffer.append(searchParamMap.get("checkIn").toString());
		buffer.append(WudstayConstants.HASH);
		buffer.append(searchParamMap.get("checkOut").toString());
		buffer.append(WudstayConstants.HASH);
		buffer.append(searchParamMap.get("rooms").toString());
		buffer.append(WudstayConstants.HASH);
		buffer.append(searchParamMap.get("persons").toString());
		return buffer.toString();
	}

	public static BookingDetailsVO getBookingDetailsVOPayU(
		String bookingDetailsUDF, IHotelManager hotelManager, Integer rooms, Integer persons) {
		String[] bookingDetailsSplit = bookingDetailsUDF.split(WudstayConstants.HASH);
		String checkInDate = bookingDetailsSplit[0];
		String checkOutDate = bookingDetailsSplit[1];
		Long hotelId = Long.valueOf(bookingDetailsSplit[2]);
		Integer nights = Integer.valueOf(bookingDetailsSplit[3]);
		Integer totalPrice2 = Integer.valueOf(bookingDetailsSplit[4]);
		Integer totalContractualPrice2 = totalPrice2;
		String roomTypeMaster2 = "-";
		try {
			totalContractualPrice2 = Integer.valueOf(bookingDetailsSplit[5]);
			roomTypeMaster2 =  bookingDetailsSplit[6] ;
		}catch (Exception ex){

		}
		
		Hotel hotel = hotelManager.getById(hotelId);
		BookingDetailsVO bookingDetailsVO = new BookingDetailsVO();

		bookingDetailsVO.setNights(nights);
		bookingDetailsVO.setPersons(persons);
		bookingDetailsVO.setCheckInDate(checkInDate);
		bookingDetailsVO.setCheckOutDate(checkOutDate);
		//bookingDetailsVO.setPrice(hotel.getPrice());
		bookingDetailsVO.setHotelDisplayName(hotel.getHotelDisplayName());
		bookingDetailsVO.setHotelName(hotel.getHotelName());
		bookingDetailsVO.setCity(hotel.getLocation().getCity().getCityName());
		bookingDetailsVO.setAddress(hotel.getHotelAddress());
		bookingDetailsVO.setDisplayAddress(hotel.getHotelDisplayAddress());
		bookingDetailsVO.setHotelId(hotel.getHotelId());
		bookingDetailsVO.setMaxBookingPerMobNum(hotel.getMaxBookingPerMobNum());
		bookingDetailsVO.setMapLink(hotel.getMapLink());

		List<RoomDetailsVO> roomDetailsVOList = new ArrayList<RoomDetailsVO>();
		RoomDetailsVO roomDetailsVO = null;
		int paxInEachRoom = persons/rooms;
		for(int i = 1; i <= rooms; i++) {
			roomDetailsVO = new RoomDetailsVO();
			roomDetailsVO.setPax(paxInEachRoom);
			roomDetailsVO.setRoomName("Room " + i);
			if(paxInEachRoom == 1) {
				//roomDetailsVO.setTotalRoomPrice(hotel.getSingleOccupancyPrice() * nights);
				roomDetailsVO.setRoomPrice(nights, hotel.getSingleOccupancyPrice(), hotel.getSingleOccupancyContractualPrice());
			} else if(paxInEachRoom == 2) {
				//roomDetailsVO.setTotalRoomPrice(hotel.getDoubleOccupancyPrice() * nights);
				roomDetailsVO.setRoomPrice(nights, hotel.getDoubleOccupancyPrice(), hotel.getDoubleOccupancyContractualPrice());
			} else if(paxInEachRoom == 3) {
				//roomDetailsVO.setTotalRoomPrice(hotel.getTripleOccupancyPrice() * nights);
				roomDetailsVO.setRoomPrice(nights, hotel.getTripleOccupancyPrice(), hotel.getTripleOccupancyContractualPrice());
			}
			//roomDetailsVO.setTotalRoomPrice(hotel.getPrice() * nights);
			roomDetailsVOList.add(roomDetailsVO);
		}

		int remainingPax = persons%rooms;
		roomDetailsVO = null;
		for(int i = remainingPax; i > 0; i--) {
			roomDetailsVO = roomDetailsVOList.get(i - 1);
			roomDetailsVO.setPax(roomDetailsVO.getPax() + 1);
			if(roomDetailsVO.getPax() == 1) {
				//roomDetailsVO.setTotalRoomPrice(hotel.getSingleOccupancyPrice() * nights);
				roomDetailsVO.setRoomPrice(nights, hotel.getSingleOccupancyPrice(), hotel.getSingleOccupancyContractualPrice());
			} else if(roomDetailsVO.getPax() == 2) {
				//roomDetailsVO.setTotalRoomPrice(hotel.getDoubleOccupancyPrice() * nights);
				roomDetailsVO.setRoomPrice(nights, hotel.getDoubleOccupancyPrice(), hotel.getDoubleOccupancyContractualPrice());
			} else if(roomDetailsVO.getPax() == 3) {
				//roomDetailsVO.setTotalRoomPrice(hotel.getTripleOccupancyPrice() * nights);
				roomDetailsVO.setRoomPrice(nights, hotel.getTripleOccupancyPrice(), hotel.getTripleOccupancyContractualPrice());
			}
		}
		int totalPrice = 0;
		int totalContractualPrice = 0;

		for (RoomDetailsVO roomDetails : roomDetailsVOList) {
			try { //Should be handel in case of "roomDetails.getTotalRoomPrice()" is null    :: SSR 28092015
				totalPrice += roomDetails.getTotalRoomPrice();
				totalContractualPrice += roomDetails.getTotalRoomContractualPrice();
				if (roomDetails.getPax().equals(Integer.valueOf(1))) {
					roomDetails.setOccupancy("Single Occupancy");
				} else if (roomDetails.getPax().equals(Integer.valueOf(2))) {
					roomDetails.setOccupancy("Double Occupancy");
				} else {
					roomDetails.setOccupancy("Triple Occupancy");
				}
			}catch (Exception ex){
				ex.printStackTrace();
			}
		}

		if( (totalPrice2!=null && totalPrice2.intValue() != totalPrice) ||
				(totalContractualPrice2!=null && totalContractualPrice2.intValue() != totalContractualPrice2) ||
				(!"-".equals(roomTypeMaster2)  && roomTypeMaster2.equalsIgnoreCase(hotel.getRoomTypeMaster().getDescription())) ){
			//ERROR
		}
		bookingDetailsVO.setTotalPrice(totalPrice2 );
		bookingDetailsVO.setTotalPriceContractual(totalContractualPrice2);
		bookingDetailsVO.setRoomDetailsVOList(roomDetailsVOList);
		bookingDetailsVO.setRoomTypeMaster(roomTypeMaster2);

		return bookingDetailsVO;
	}
	static public String getUniqueId() {   //Generating unique ID
		UUID uuid = UUID.randomUUID();
		return uuid.toString().toUpperCase();
	}

	public static void setAmenitiesForPgHotel(List<PgHotel> hotelList) {

		for (PgHotel hotel : hotelList) {
			List<PgHotelAmenity> hotelAmenities = hotel.getHotelAmenities();
			if (hotelAmenities.size() > 0) {
				Collections.sort(hotelAmenities, new Comparator<PgHotelAmenity>() {
					
					public int compare(final PgHotelAmenity object1, final PgHotelAmenity object2) {
						return object1.getAmenityListingOrder().compareTo(object2.getAmenityListingOrder());
					}
				});
				StringBuilder builder = new StringBuilder();
				for (PgHotelAmenity hotelAmenity : hotelAmenities) {
					builder.append(hotelAmenity.getAmenity().getAmenityName());
					builder.append(WudstayConstants.COMMA);
					builder.append(WudstayConstants.SPACE);
				}
				hotel.setHotelAmenity(builder.substring(0, builder.lastIndexOf(WudstayConstants.COMMA)));
			}
		}

	}

	public static List<PgHotel> processPgHotelList(List<PgHotel> hotelList, Integer rooms, Integer persons) {
		List<PgHotel> processedHotelList = new ArrayList<PgHotel>();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			for (PgHotel hotel : hotelList) {
				int pax = persons/rooms;
				if(pax == 1) {
					hotel.setPrice(hotel.getSingleOccupancyWudstayPrice()); // getSingleOccupancyPrice());
				} else if(pax == 2) {
					hotel.setPrice(hotel.getDoubleOccupancyWudstayPrice()); //getDoubleOccupancyPrice());
				} else if(pax == 3) {
					hotel.setPrice(hotel.getTripleOccupancyWudstayPrice()); //getTripleOccupancyPrice());
				}
				processedHotelList.add(hotel);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return processedHotelList;
	}
	//WudstayUtil.rupiahCurrencyFormat(Integer number)
	public static String rupiahCurrencyFormat(Integer number){
		/*DecimalFormat kursIndonesia = (DecimalFormat) DecimalFormat.getCurrencyInstance();
		DecimalFormatSymbols formatRp = new DecimalFormatSymbols();

		formatRp.setCurrencySymbol("Rp. ");
		formatRp.setMonetaryDecimalSeparator(',');
		formatRp.setGroupingSeparator('.');

		kursIndonesia.setDecimalFormatSymbols(formatRp);
		System.out.printf("Harga Rupiah: %s %n", kursIndonesia.format(harga));*/

		try {
			DecimalFormat numFormat = new DecimalFormat("###,###,###");
			return numFormat.format(number);
		}catch (Exception ex){
			ex.printStackTrace();
			return number+"";
		}
	}
}
