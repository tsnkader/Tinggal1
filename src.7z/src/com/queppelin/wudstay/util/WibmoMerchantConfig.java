package com.queppelin.wudstay.util;

import com.queppelin.wudstay.vo.custom.wibmo.MerchantInfo;

/**
 * Created by hp on 11/17/2015.
 * WibmoMerchantConfig.merchantID  WibmoMerchantConfig.currency
 */
public class WibmoMerchantConfig {

    public static String W2FA_DATAPICKUP_PATH    = "/v1/w2fa/pickup";
    public static String PAYMENT_TYPE_VISA       = "w.ds.pt.card_visa";
    public static String PAYMENT_TYPE_MASTERCARD = "w.ds.pt.card_mastercard";

    //Valid types supported in wibmo :
    public static final String[] supportedPaymentType = new String[]{PAYMENT_TYPE_VISA, PAYMENT_TYPE_MASTERCARD};
    //supportedPaymentType public static final String[] Merchant_supported_PaymentType = {"w.ds.pt.card_visa", "w.ds.pt.card_mastercard"};

    public static String currency = "356";
    public static final String merchantDefaultCountryCode = "IN";
    public static final String Merchant_transaction_Currency ="356";
    public static final String Merchant_Name = "Wudstay"; //"Wudstay Travels Pvt Ltd";
    //Provided to merchant when merchant account is created in wibmo
    /* //IN TEST credentials
    public static final String merchantID     = "35507426706359493372";
    public static final String merchantAppID  = "7980";
    public static final String wibmoSecretKey = "11355074267065407458";
    public static String wibmoDomain = "https://wallet.pc.enstage-sas.com"; //Staging IN TEST credentials:
    */
    public static final String merchantID     = "232551525987518435303"; //"223208916611434578259"; //IN TEST credentials: "35507426706359493372";
    public static final String merchantAppID  = "9547";                  // "1683";                 //IN TEST credentials: "7980";
    public static final String wibmoSecretKey = "132325515259877096958"; //"052232089166116482797"; //IN TEST credentials: "11355074267065407458";
    public static String wibmoDomain = "https://www.wibmo.com"; //Production  https://www.wibmo.com/v1/wPay/pickup

    //Depending on which you can choose to skip the certificate or ....
    private final boolean testMode = true;

    /*
    public static final String Secret_Key = "11355074267065407458";
    public static final String PG_Merchant_ID = "55989473";
    public static final String PG_Hash_Key = "F200B17FBBE4735C";
    public static final String User_ID = "admin";
    public static final String Password = "password123";
    public static final String Pgname = "hdfcpg";

    public static final String Merchant_Account_ID = "17878";
     */



    public boolean isTestMode() {
        return testMode;
    }

    public String getMerchantID() {
        return merchantID;
    }

    public void setMerchantID(String merchantID) {
        //this.merchantID = merchantID;
    }

    public String getMerchantAppID() {
        return merchantAppID;
    }

    public void setMerchantAppID(String merchantAppID) {
        //this.merchantAppID = merchantAppID;
    }

    public String getWibmoSecretKey() {
        return wibmoSecretKey;
    }

    public void setWibmoSecretKey(String wibmoSecretKey) {
        //this.wibmoSecretKey = wibmoSecretKey;
    }

    public String[] getSupportedPaymentType() {
        return supportedPaymentType;
    }

    public void setSupportedPaymentType(String[] supportedPaymentType) {
        //this.supportedPaymentType = supportedPaymentType;
    }

    public String getWibmoDomain() {
        return wibmoDomain;
    }

    public void setWibmoDomain(String wibmoDomain) {
        this.wibmoDomain = wibmoDomain;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public static String getSupportedPaymentTypeCSV() {
        StringBuilder supportedTypeCSV = new StringBuilder("");
        if (supportedPaymentType != null && supportedPaymentType.length > 0) {
            supportedTypeCSV.append(supportedPaymentType[0]);
            for (int i = 1; i < (supportedPaymentType.length); i++) {
                supportedTypeCSV.append(",").append(supportedPaymentType[i]);
            }
        }
        return supportedTypeCSV.toString();
    }

    public static MerchantInfo getMerchantInfo() {
        MerchantInfo merchantInfo = new MerchantInfo(WibmoMerchantConfig.merchantID, WibmoMerchantConfig.merchantAppID, WibmoMerchantConfig.merchantDefaultCountryCode);
        return merchantInfo;
    }
}