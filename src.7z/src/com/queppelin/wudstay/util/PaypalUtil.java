package com.queppelin.wudstay.util;

import java.io.Serializable;

import paypal.payflow.PayflowConstants;
import paypal.payflow.SDKProperties;

/**
 * Created by hp on 3/7/2016.
 *
 PayPal account credentials:
     user:arjun@tinggal.com
     PW: OneGroup#101010
 *
     Business information: OneStandard Group Pte Ltd
     Merchant account ID: UPWNCPTMMXB2Y
 *
 * Mar 06, 2016
     App Name: tinggalpayment
     Sandbox account: arjun-facilitator@tinggal.com
     Client ID: AUyMniFvJVTBNLOYE_wOBCjupE1iw974t6mRAIZ1QAZxBLs-gK-zdRSzXBlD8wm4yCsKkS24QKBdo_0D
     Secret: EGK5jeofe2pSEewWYzQIsUMcX_jJTCzbKE7BYhTl9na6fr5bwvSG-0arFaGMPx73ZK3pDsegLRhGDPX3
     Return URL --> http://tinggal.com/sandboxreturnurl
        (Where users will be redirected after test transactions. Please allow up to 3 hours for the change to go into effect.)

 ===========================================================
 URL: https://manager.paypal.com/
 Merchant name : WS032016
 Password :      Hello1234
 Partner name :  PayPal
 */
public class PaypalUtil implements Serializable {
    private static final String MERCHANT_NAME = "WS032016";
    private static final String PASSWORD = "Hello1234";
    private static final String PARTNER_NAME = "PayPal";

    public static final String HOSTADDRESSTEST = "pilot-payflowpro.paypal.com";
    public static final String HOSTADDRESSPRODUCTION = "payflowpro.paypal.com";
    public static final int HOSTPORT = 443;
    public static final int TIMEOUT = 20;
    public static final String LOGFILENAME = "..\\standalone\\log\\payflow_java.log";
    public static final int LOGGINGLEVEL = PayflowConstants.SEVERITY_ERROR;
    public static final int MAXLOGFILESIZE = 1000000;
    //private static final String CLASS_NAME = PayPalProcessor.class.getPackage()	+ "." + PayPalProcessor.class.getName();
    public static final String SUCCESS = "success";


}
