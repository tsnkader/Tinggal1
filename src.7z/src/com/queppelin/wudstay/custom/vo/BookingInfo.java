package com.queppelin.wudstay.custom.vo;

import com.queppelin.wudstay.util.WudstayUtil;
import com.queppelin.wudstay.vo.Hotel;
import com.queppelin.wudstay.vo.HotelBooking;
import com.queppelin.wudstay.webservice.vo.WSHotelVO;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by hp on 9/17/2015.
 */
public class BookingInfo implements java.io.Serializable {
    private Long bookingId;
    private String bookersName;
    private String checkIn;
    private String checkOut;
    private Integer noOfRooms;
    private Integer noOfPeople;
    private String contactNumber;
    private String email;
    private String bookingDate;
    private String displayBookingId;
    private Integer totalAmount;

    private Boolean isActive;
    private String lastUpdatedBy;
    private Date lastUpdatedDate;
    private Boolean isPaid;
    private Boolean isCancelled;
    private String payuTransactionId;
    private String transactionId;
    private Integer nights;

    private WSHotelVO hotel;
    private String status = "CANCEL";

    public BookingInfo(){}
    public BookingInfo(HotelBooking objBooking, WSHotelVO hotel, String hotelBookingStatus) {
        status=hotelBookingStatus;
        this.bookingId = objBooking.getBookingId() ;
        this.bookersName = objBooking.getBookersName();
        this.checkIn = objBooking.getCheckIn()==null ? " ": WudstayUtil.CHECK_IN_CHECK_OUT_DATE_FORMAT.format(objBooking.getCheckIn());
        this.checkOut = objBooking.getCheckOut()==null ? " ": WudstayUtil.CHECK_IN_CHECK_OUT_DATE_FORMAT.format(objBooking.getCheckOut());
        this.noOfRooms = objBooking.getNoOfRooms();
        this.noOfPeople = objBooking.getNoOfPeople();
        this.contactNumber = objBooking.getContactNumber();
        this.email = objBooking.getEmail();
        this.bookingDate = objBooking.getBookingDate()==null ? " ": WudstayUtil.CHECK_IN_CHECK_OUT_DATE_FORMAT.format(objBooking.getBookingDate());

        this.displayBookingId =  objBooking.getDisplayBookingId();
        this.totalAmount = objBooking.getTotalAmount();

        this.isPaid = objBooking.getIsPaid();
        this.isActive = objBooking.getIsActive();
        this.lastUpdatedBy = objBooking.getLastUpdatedBy();
        this.lastUpdatedDate = objBooking.getLastUpdatedDate();
        this.isCancelled = objBooking.getIsCancelled();
        this.payuTransactionId = objBooking.getPayuTransactionId();
        this.transactionId = objBooking.getTransactionId();
        this.nights = objBooking.getNights();

        this.hotel = hotel;

    }

    public Long getBookingId() {
        return bookingId;
    }

    public void setBookingId(Long bookingId) {
        this.bookingId = bookingId;
    }

    public String getBookersName() {
        return bookersName;
    }

    public void setBookersName(String bookersName) {
        this.bookersName = bookersName;
    }

    public String getCheckIn() {
        return checkIn;
    }

    public void setCheckIn(String checkIn) {
        this.checkIn = checkIn;
    }

    public String getCheckOut() {
        return checkOut;
    }

    public void setCheckOut(String checkOut) {
        this.checkOut = checkOut;
    }

    public Integer getNoOfRooms() {
        return noOfRooms;
    }

    public void setNoOfRooms(Integer noOfRooms) {
        this.noOfRooms = noOfRooms;
    }

    public Integer getNoOfPeople() {
        return noOfPeople;
    }

    public void setNoOfPeople(Integer noOfPeople) {
        this.noOfPeople = noOfPeople;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(String bookingDate) {
        this.bookingDate = bookingDate;
    }

    public String getDisplayBookingId() {
        return displayBookingId;
    }

    public void setDisplayBookingId(String displayBookingId) {
        this.displayBookingId = displayBookingId;
    }

    public Integer getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(Integer totalAmount) {
        this.totalAmount = totalAmount;
    }



    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public Date getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate(Date lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }

    public Boolean getIsPaid() {
        return isPaid;
    }

    public void setIsPaid(Boolean isPaid) {
        this.isPaid = isPaid;
    }

    public Boolean getIsCancelled() {
        return isCancelled;
    }

    public void setIsCancelled(Boolean isCancelled) {
        this.isCancelled = isCancelled;
    }

    public String getPayuTransactionId() {
        return payuTransactionId;
    }

    public void setPayuTransactionId(String payuTransactionId) {
        this.payuTransactionId = payuTransactionId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public Integer getNights() {
        return nights;
    }

    public void setNights(Integer nights) {
        this.nights = nights;
    }

    public WSHotelVO getHotel() {
        return hotel;
    }

    public void setHotel(WSHotelVO hotel) {
        this.hotel = hotel;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
