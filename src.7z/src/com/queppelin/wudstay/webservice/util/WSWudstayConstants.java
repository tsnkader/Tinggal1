package com.queppelin.wudstay.webservice.util;

public class WSWudstayConstants {

	public static final String ERROR_MESSAGE = "Please contact support.";
	public static final String ERROR_TITLE = "Error";
	public static final String BLANK = "";
	public static final String NO_BOOKINGS_FOUND = "No bookings found.";
	public static final String NO_DISCOUNT_FOUND = "This coupon code is invalid or has expired.";
	public static final String VALID_ONLY_FOR_ONLINE_PAYMENT = "This coupon code is valid for online payment only. Would you like to continue?";
}
