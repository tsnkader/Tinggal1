package com.queppelin.wudstay.webservice.util;

public class WSWudstayMappings {

	public static final String GET_All_CITIES = "getAllCities.do";

	public static final String SEARCH_HOTELS = "searchHotels.do";

	public static final String SEND_MOBILE_NUMBER_VERIFICATION_CODE = "sendMobileNumberVerificationCode.do";

	public static final String VERIFY_MOBILE_NUMBER = "verifyMobileNumber.do";

	public static final String CONFIRM_BOOKING = "confirmBooking.do";

	public static final String GET_BOOKINGS_BY_CONTACT_NUMBER = "getBookingsByContactNumber.do";

	public static final String CANCEL_BOOKING = "cancelBooking.do";

	public static final String GET_NEW_UPDATE_IS_MANDATORY = "getNewUpdateIsMandatory.do";

	public static final String GET_BOOKINGS_INFORMATION = "getInformationByBookingId.do";

	public static final String GET_CALCULATE_COUPON_DISCOUNT = "getCalculateCouponDiscount.do";

	public static final String GET_HOTEL_AVAILABILITY = "getHotelAvailability.do";

	public static final String GENERATE_WPAY_INIT_REQ_HASH = "generateWPayInitReqHash.do";
	public static final String PICKUP_WPAY_DATA_FROM_WIBMO_SERVER = "pickupWpayDataFromWibmoServer.do";

	public static final String PAYZAPP_PROCESS_INITIATE = "initiatePayZappProcesses.do";
	public static final String PAYU_PROCESS_START = "startProcessPayU.do";
	public static final String PAYU_TEST_PROCESS_START = "startTestProcessPayU.do";
	public static final String PAYU_PROCESS_START_Android = "startProcessPayUAndroid.do";
	public static final String PAYU_TEST_PROCESS_START_Android = "startTestProcessPayUAndroid.do";

	public static final String PAYU_PAYMENT_RESPONSE = "getPayuResponse.do";
	public static final String PAYZAPP_PAYMENT_RESPONSE = "getPayZappResponse.do";

}
