package com.queppelin.wudstay.webservice;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.queppelin.wudstay.custom.vo.BookingInfo;
import com.queppelin.wudstay.manager.*;
import com.queppelin.wudstay.util.*;
import com.queppelin.wudstay.vo.*;
import com.queppelin.wudstay.vo.custom.DiscountCouponInfo;
import com.queppelin.wudstay.vo.custom.HotelAvailabilityVO;

import com.queppelin.wudstay.vo.custom.wibmo.DataPickupRequest;
import com.queppelin.wudstay.vo.custom.wibmo.InAppPickupData;
import com.queppelin.wudstay.vo.custom.wibmo.MerchantInfo;
import com.queppelin.wudstay.vo.custom.wibmo.WPayDataPickupResponse;
import org.apache.commons.lang.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.queppelin.wudstay.vo.custom.BookingDetailsVO;
import com.queppelin.wudstay.vo.custom.HotelBookingVO;
import com.queppelin.wudstay.web.controller.EndUserController;
import com.queppelin.wudstay.webservice.util.WSWudstayConstants;
import com.queppelin.wudstay.webservice.util.WSWudstayMappings;
import com.queppelin.wudstay.webservice.vo.WSHotelVO;
import com.queppelin.wudstay.webservice.vo.WSResponseWrapper;
import com.queppelin.wudstay.webservice.vo.WSSearchVO;

//import sun.misc.JavaAWTAccess;

@Controller
@RequestMapping("/webservice")
public class EndUserService {

	public static final Logger logger = LoggerFactory.getLogger(EndUserController.class);

	@Autowired
	ICityManager cityManager;
	
	@Autowired
	ILocationManager locationManager;

	@Autowired
	IHotelManager hotelManager;

	@Autowired
	INumberVerificationManager numberVerificationManager;
	
	@Autowired
	IHotelBookingManager hotelBookingManager;

	@Autowired
	IHotelAdministratorManager hotelAdministratorManager;

	@Autowired
	IAppVersionManager appVersionManager;

	@Autowired
	ICouponCodeManager couponCodeManager;

	@Autowired
	IPayuMobTranManager payuMobTranManager;

	@RequestMapping(method = RequestMethod.GET, value = WSWudstayMappings.GET_All_CITIES)
	public @ResponseBody WSResponseWrapper getAllCities(HttpServletRequest request, HttpServletResponse response,HttpSession session) {
		List<City> cityList = new ArrayList<City>();
		WSResponseWrapper wsResponseWrapper = new WSResponseWrapper();
		try {
			cityList = cityManager.getAllCities();
			wsResponseWrapper.setResponseCode(new Integer(1));
			wsResponseWrapper.setMessage(WSWudstayConstants.BLANK);
			wsResponseWrapper.setTitle(WSWudstayConstants.BLANK);
			wsResponseWrapper.setResponseObject(cityList);
		} catch (Exception e) {
			wsResponseWrapper.setResponseCode(new Integer(0));
			wsResponseWrapper.setMessage(WSWudstayConstants.ERROR_MESSAGE);
			wsResponseWrapper.setTitle(WSWudstayConstants.ERROR_TITLE);
		}
		return wsResponseWrapper;
	}

	@RequestMapping(method = RequestMethod.GET, value = WSWudstayMappings.SEARCH_HOTELS)
	public @ResponseBody WSResponseWrapper searchHotels(@RequestParam String checkIn, @RequestParam String checkOut, @RequestParam Integer rooms,
			@RequestParam Integer persons, @RequestParam Long cityId, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		List<WSHotelVO> wsHotelVOList = new ArrayList<WSHotelVO>();
		WSResponseWrapper wsResponseWrapper = new WSResponseWrapper();
		try {
			List<Hotel> hotelList = hotelManager.getHotelByCityId(cityId, persons/rooms);

			hotelList = WudstayUtil.processHotelList(hotelList, rooms, persons, hotelBookingManager, WudstayUtil.getFormattedCheckInDate(checkIn), WudstayUtil.getFormattedCheckOutDate(checkOut), hotelManager);
			WudstayUtil.setAmenitiesForHotel(hotelList);

			String base = getBaseUrl(request);
			List<Location> locationList = locationManager.getLocationsByCityId(cityId);
			wsHotelVOList = WudstayUtil.getHotelListWS(hotelList, base, persons/rooms);
			wsResponseWrapper.setResponseCode(new Integer(1));
			wsResponseWrapper.setMessage(WSWudstayConstants.BLANK);
			wsResponseWrapper.setTitle(WSWudstayConstants.BLANK);
			WSSearchVO wsSearchVO = new WSSearchVO();
			wsSearchVO.setLocationList(locationList);
			wsSearchVO.setWsHotelVOList(wsHotelVOList);
			wsResponseWrapper.setResponseObject(wsSearchVO);

		} catch (Exception e) {
			wsResponseWrapper.setResponseCode(new Integer(0));
			wsResponseWrapper.setMessage(WSWudstayConstants.ERROR_MESSAGE);
			wsResponseWrapper.setTitle(WSWudstayConstants.ERROR_TITLE);
		}

		return wsResponseWrapper;
	}

	private String getBaseUrl(HttpServletRequest request) {
		StringBuffer url = request.getRequestURL();
		String uri = request.getRequestURI();
		String ctx = request.getContextPath();
		String base = url.substring(0, url.length() - uri.length() + ctx.length()) + File.separator;
		return base;
	}

	@RequestMapping(method = RequestMethod.GET, value = WSWudstayMappings.SEND_MOBILE_NUMBER_VERIFICATION_CODE)
	public @ResponseBody WSResponseWrapper sendVerificationCode(@RequestParam String mobileNumber, @RequestParam String name, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		WSResponseWrapper wsResponseWrapper = new WSResponseWrapper();
		try {
			int verificationCode = 0;
			while(String.valueOf(verificationCode).length() < 6) {
				verificationCode = (int) (Math.random() * 1000000);
			}
			NumberVerification numberVerification = new NumberVerification();
			numberVerification.setMobileNumber(mobileNumber);
			numberVerification.setCustomerName(name);
			// numberVerification.setCustomerEmail(email);
			numberVerification.setVerificationCode(String.valueOf(verificationCode));
			numberVerification.setIsActive(Boolean.TRUE);
			numberVerificationManager.save(numberVerification);
			WudstayUtil.sendVerificationCode(numberVerification);
			wsResponseWrapper.setResponseCode(new Integer(1));
			wsResponseWrapper.setMessage(WSWudstayConstants.BLANK);
			wsResponseWrapper.setTitle(WSWudstayConstants.BLANK);
			wsResponseWrapper.setResponseObject(Boolean.TRUE);
		} catch (Exception e) {
			wsResponseWrapper.setResponseCode(new Integer(0));
			wsResponseWrapper.setMessage("Failed to send verification code.");
			wsResponseWrapper.setTitle(WSWudstayConstants.ERROR_TITLE);
		}
		return wsResponseWrapper;
	}
	
	@RequestMapping(method = RequestMethod.GET, value = WSWudstayMappings.VERIFY_MOBILE_NUMBER)
	public @ResponseBody WSResponseWrapper verifyMobileNumber(@RequestParam String verificationCode, String mobileNumber, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		WSResponseWrapper wsResponseWrapper = new WSResponseWrapper();
		try {
			Boolean isVerified = numberVerificationManager.verifyMobileNumber(verificationCode, mobileNumber);
			wsResponseWrapper.setResponseCode(new Integer(1));
			wsResponseWrapper.setMessage(WSWudstayConstants.BLANK);
			wsResponseWrapper.setTitle(WSWudstayConstants.BLANK);
			wsResponseWrapper.setResponseObject(isVerified);
		} catch (Exception e) {
			wsResponseWrapper.setResponseCode(new Integer(0));
			wsResponseWrapper.setMessage(WSWudstayConstants.ERROR_MESSAGE);
			wsResponseWrapper.setTitle(WSWudstayConstants.ERROR_TITLE);
		}
		return wsResponseWrapper;
	}
	@RequestMapping(method = RequestMethod.GET, value = WSWudstayMappings.GET_HOTEL_AVAILABILITY)
	public @ResponseBody WSResponseWrapper getHotelAvailability(@RequestParam String checkIn,  @RequestParam String checkOut, 
																@RequestParam Integer rooms, @RequestParam Long hotelId,
																HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		WSResponseWrapper wsResponseWrapper = new WSResponseWrapper();
		try {
			HotelAvailabilityVO hotelAvailabilityVO = checkHotelAvailability(checkIn, checkOut, rooms, hotelId);
			
			/*if(hotelAvailabilityVO.getStatus()!= null && hotelAvailabilityVO.getStatus()== Boolean.FALSE){
				wsResponseWrapper.setResponseCode(new Integer(0));
				wsResponseWrapper.setMessage(hotelAvailabilityVO.getErrMsg());
				wsResponseWrapper.setTitle(WSWudstayConstants.ERROR_TITLE);
			}else*/ if(!hotelAvailabilityVO.getIsAvailable()){
				wsResponseWrapper.setResponseCode(new Integer(0));
				wsResponseWrapper.setMessage("Only " + hotelAvailabilityVO.getRooms() + " room(s) are Available");
				wsResponseWrapper.setTitle(WSWudstayConstants.ERROR_TITLE);
			}else {			
				wsResponseWrapper.setResponseCode(new Integer(1));
				wsResponseWrapper.setMessage(WSWudstayConstants.BLANK);
				wsResponseWrapper.setTitle(WSWudstayConstants.BLANK);
			}
			wsResponseWrapper.setResponseObject(hotelAvailabilityVO);
		} catch (Exception e) {
			wsResponseWrapper.setResponseCode(new Integer(0));
			wsResponseWrapper.setMessage(WSWudstayConstants.ERROR_MESSAGE);
			wsResponseWrapper.setTitle(WSWudstayConstants.ERROR_TITLE);
		}
		return wsResponseWrapper;
	}
	
	public HotelAvailabilityVO checkHotelAvailability(String checkIn, String checkOut, Integer rooms, Long hotelId) {
		HotelAvailabilityVO hotelAvailabilityVO = new HotelAvailabilityVO();
		try {
			Hotel hotel = hotelManager.getById(hotelId);
			if(hotel.getIsActive()) {
				String checkInDate = WudstayUtil.getFormattedCheckInDate(checkIn.trim());
				String checkOutDate = WudstayUtil.getFormattedCheckOutDate(checkOut.trim());
				hotelAvailabilityVO = WudstayUtil.isAvailable(hotel, rooms, checkInDate, checkOutDate, hotelBookingManager);
			}else{
				hotelAvailabilityVO.setIsAvailable(Boolean.FALSE);
				hotelAvailabilityVO.setRooms(0);
			}
		} catch (Exception e) {
			e.printStackTrace();
			hotelAvailabilityVO.setStatus(Boolean.FALSE);
		}
		return hotelAvailabilityVO;
	}

	/*@RequestMapping(method = RequestMethod.GET, value = WSWudstayMappings.CONFIRM_BOOKING)
	public @ResponseBody WSResponseWrapper confirmBooking(@RequestParam String checkIn, @RequestParam String checkOut, @RequestParam Integer rooms,
														  @RequestParam Integer persons, @RequestParam String mobileNumber, @RequestParam String name, @RequestParam Long hotelId, @RequestParam Integer totalAmount,
														  HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		String cityName = null;
		String email = null; cityName=jaipur&email=surender.r@wudstay.com
		return doConfirmBooking( checkIn,  checkOut,  rooms, persons, mobileNumber,  name, hotelId, totalAmount,
								 cityName, email, request,  response,  session);
	}*/
	@RequestMapping(method = RequestMethod.GET, value = WSWudstayMappings.CONFIRM_BOOKING)
	public @ResponseBody WSResponseWrapper confirmBooking(@RequestParam String checkIn,  @RequestParam String checkOut,     @RequestParam Integer rooms,
														  @RequestParam Integer persons, @RequestParam String mobileNumber, @RequestParam String name,   @RequestParam Long hotelId, @RequestParam Integer totalAmount,
														  @RequestParam(required=false) String cityName , @RequestParam(required=false) String email, @RequestParam(required=false) String couponCode, @RequestParam(required=false) String source,
														  HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		Integer discount =0;
		Boolean isPaid = Boolean.FALSE;
		Integer sourceOfBooking = WudstayConstants.getSourceOfBooking(source, WudstayConstants.SOURCE_OF_BOOKING_MOBILE);

		//--------------------------------------------
		HotelAvailabilityVO hotelAvailabilityVO = checkHotelAvailability(checkIn, checkOut, rooms, hotelId);
		if(!hotelAvailabilityVO.getIsAvailable()){
			WSResponseWrapper wsResponseWrapper = new WSResponseWrapper();
			wsResponseWrapper.setResponseCode(new Integer(0));
			wsResponseWrapper.setMessage("Only " + hotelAvailabilityVO.getRooms() + " room(s) are Available");
			wsResponseWrapper.setTitle(WSWudstayConstants.ERROR_TITLE);
			return wsResponseWrapper;
		}
		//--------------------------------------------
		if(couponCode==null || "".equals(couponCode.trim()) || "null".equalsIgnoreCase(couponCode.trim())){// No change in old functionality
			return doConfirmBooking(null, checkIn, checkOut, rooms, persons, mobileNumber, name, hotelId, totalAmount, discount, isPaid,sourceOfBooking,
					cityName, email, request, response, session);
		}else{
			BookingDetailsVO bookingDetailsVO = doCalculateCouponCodeDiscount(checkIn,  checkOut, rooms, persons, hotelId, couponCode, mobileNumber, sourceOfBooking);
			Integer totalPrice = bookingDetailsVO.getTotalPrice();
			if( bookingDetailsVO.getTotalPrice() == bookingDetailsVO.getTotalPriceBeforeDiscount() && !totalAmount.equals(totalPrice)) {
				WSResponseWrapper wsResponseWrapper = new WSResponseWrapper();
				wsResponseWrapper.setResponseCode(new Integer(0));
				wsResponseWrapper.setMessage(WSWudstayConstants.NO_DISCOUNT_FOUND);
				wsResponseWrapper.setTitle(WSWudstayConstants.BLANK);
				return wsResponseWrapper;
			}else {
				return doConfirmBooking(bookingDetailsVO, checkIn, checkOut, rooms, persons, mobileNumber, name, hotelId, totalAmount,discount, isPaid,sourceOfBooking,
						cityName, email, request, response, session);
			}
		}
		/*WSResponseWrapper wsResponseWrapper2 = validationBeforeConfirmBooking(checkIn, checkOut, rooms, persons, hotelId, totalAmount, couponCode, source);
		if(wsResponseWrapper2.getResponseCode()==1){
			return doConfirmBooking(checkIn, checkOut, rooms, persons, mobileNumber, name, hotelId, totalAmount, discount, isPaid, sourceOfBooking,
					cityName, email, request, response, session);
		}else{
			return wsResponseWrapper2;
		}*/
	}

	public WSResponseWrapper validationBeforeConfirmBooking(String checkIn, String checkOut, Integer rooms, Integer persons, Long hotelId, Integer totalAmount, String couponCode, String source, String mobileNumber){
		WSResponseWrapper wsResponseWrapper = new WSResponseWrapper();
		wsResponseWrapper.setResponseCode(new Integer(1));
		wsResponseWrapper.setMessage(WSWudstayConstants.BLANK);
		wsResponseWrapper.setTitle(WSWudstayConstants.BLANK);

		Integer discount = 0;
		Integer sourceOfBooking = WudstayConstants.getSourceOfBooking(source, WudstayConstants.SOURCE_OF_BOOKING_MOBILE);
		//--------------------------------------------
		HotelAvailabilityVO hotelAvailabilityVO = checkHotelAvailability(checkIn, checkOut, rooms, hotelId);
		if (!hotelAvailabilityVO.getIsAvailable()) {
			// WSResponseWrapper wsResponseWrapper = new WSResponseWrapper();
			wsResponseWrapper.setResponseCode(new Integer(0));
			wsResponseWrapper.setMessage("Only " + hotelAvailabilityVO.getRooms() + " room(s) are Available");
			wsResponseWrapper.setTitle(WSWudstayConstants.ERROR_TITLE);
			return wsResponseWrapper;
		}
		//--------------------------------------------
		if (couponCode == null || "".equals(couponCode.trim()) || "null".equalsIgnoreCase(couponCode.trim())) {// No change in old functionality
			return wsResponseWrapper;
		} else {
			BookingDetailsVO bookingDetailsVO = doCalculateCouponCodeDiscount(checkIn, checkOut, rooms, persons, hotelId, couponCode, mobileNumber, sourceOfBooking);
			Integer totalPrice = bookingDetailsVO.getTotalPrice();
			if (bookingDetailsVO.getTotalPrice() == bookingDetailsVO.getTotalPriceBeforeDiscount() && !totalAmount.equals(totalPrice)) {
				//WSResponseWrapper wsResponseWrapper = new WSResponseWrapper();
				wsResponseWrapper.setResponseCode(new Integer(0));
				wsResponseWrapper.setMessage(WSWudstayConstants.NO_DISCOUNT_FOUND);
				wsResponseWrapper.setTitle(WSWudstayConstants.BLANK);
				return wsResponseWrapper;
			} else {
				return wsResponseWrapper;
			}
		}
	}


	

	public  WSResponseWrapper doConfirmBooking(BookingDetailsVO couponBookingDetails,  String checkIn,  String checkOut,  Integer rooms,
			Integer persons, String mobileNumber,  String name, Long hotelId, Integer totalAmount, Integer discount, Boolean isPaid, Integer sourceOfBooking,
			String cityName, String email,
			HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		WSResponseWrapper wsResponseWrapper = new WSResponseWrapper();
		try {

			String bookingId = hotelBookingManager.makeBookingFromMobile( couponBookingDetails, name, mobileNumber, email, WudstayUtil.getFormattedCheckInDate(checkIn), WudstayUtil.getFormattedCheckOutDate(checkOut),
					rooms, persons, hotelId, totalAmount, discount, isPaid, sourceOfBooking);
			Hotel hotel = hotelManager.getById(hotelId);
			
			WudstayUtil.sendConfirmationMessage("Dear " + name + ", your Tinggal booking has been confirmed from " + checkIn + " to "
					+ checkOut + " at " + hotel.getHotelName() + ". The address is "
												+ hotel.getHotelAddress() + " and your booking id is " + bookingId + ". You can locate the stay at Google Maps on "
														+ "the link " + hotel.getMapLink() + ". For any assistance you can call us anytime at +62822 8539 0099. Please carry a valid govt. address and ID proof when you checkin.", mobileNumber);
			// ----------------- ------- Send email notification ---------- -----------------
			if(cityName !=null && email != null && !"NULL".equals(cityName) && !"NULL".equals(email)) {
				List<String> ccList = new ArrayList<String>();

				BookingDetailsVO bookingDetailsVO = WudstayUtil.getBookingDetailsVO(cityName, checkIn, checkOut, rooms, persons, hotel);

				sendConfirmationMail(name, email, bookingDetailsVO, ccList, bookingId, new Integer(0));

				String hotelAdministratorEmail = null;
				HotelAdministrator hotelAdministrator = hotelAdministratorManager.getHotelAdminByHotelId(bookingDetailsVO.getHotelId());
				if (hotelAdministrator.getUser().getEmail() != null && !hotelAdministrator.getUser().getEmail().trim().equals("")) {
					//ccList.add(hotelAdministrator.getUser().getEmail());
					hotelAdministratorEmail = hotelAdministrator.getUser().getEmail();
				}

				if (hotel.getContactPersonEmail1() != null && !hotel.getContactPersonEmail1().trim().equals("")) {
					ccList.add(hotel.getContactPersonEmail1());
				}
				if (hotel.getContactPersonEmail2() != null && !hotel.getContactPersonEmail2().trim().equals("")) {
					ccList.add(hotel.getContactPersonEmail2());
				}

				//sendConfirmationMail(name, email, bookingDetailsVO, ccList, bookingId, new Integer(0));
				sendConfirmationMail(name, hotelAdministratorEmail, bookingDetailsVO, ccList, bookingId, new Integer(0));
			}
			// ----------------- ------- ----------------------- ---------- -----------------

			wsResponseWrapper.setResponseCode(new Integer(1));
			wsResponseWrapper.setMessage(WSWudstayConstants.BLANK);
			wsResponseWrapper.setTitle(WSWudstayConstants.BLANK);
			wsResponseWrapper.setResponseObject(Boolean.TRUE);
		} catch (Exception e) {
			wsResponseWrapper.setResponseCode(new Integer(0));
			wsResponseWrapper.setMessage(WSWudstayConstants.ERROR_MESSAGE);
			wsResponseWrapper.setTitle(WSWudstayConstants.ERROR_TITLE);
		}
		return wsResponseWrapper;
	}
	private void sendConfirmationMail(String name, String email,
									  BookingDetailsVO bookingDetailsVO, List<String> ccList, String bookingId, Integer paidAmount) throws MessagingException {
		Map<String, Object> bookingConfirmationBodyDetails = new HashMap<String, Object>();
		bookingConfirmationBodyDetails.put("GUEST", name);
		bookingConfirmationBodyDetails.put("CHECK_IN", bookingDetailsVO.getCheckInDate().split(",")[1].trim());
		bookingConfirmationBodyDetails.put("CHECK_OUT", bookingDetailsVO.getCheckOutDate().split(",")[1].trim());
		bookingConfirmationBodyDetails.put("HOTEL_DISPLAY_NAME", bookingDetailsVO.getHotelDisplayName());
		bookingConfirmationBodyDetails.put("BOOKING_ID", bookingId);
		bookingConfirmationBodyDetails.put("ROOM_COUNT", bookingDetailsVO.getRoomDetailsVOList().size());
		bookingConfirmationBodyDetails.put("NIGHT_COUNT", bookingDetailsVO.getNights());
		bookingConfirmationBodyDetails.put("TOTAL_PRICE", bookingDetailsVO.getTotalPrice());
		bookingConfirmationBodyDetails.put("PAID", paidAmount);
		//bookingConfirmationBodyDetails.put("MAP_LINK", bookingDetailsVO.getMapLink());
		EmailSender.getInstance().sendEmail(email, "Booking Confirmation", bookingConfirmationBodyDetails, WudstayConstants.BOOKING_CONFIRMATION_EMAIL_BODY, ccList);
	}
	
	@RequestMapping(method = RequestMethod.GET, value = WSWudstayMappings.GET_BOOKINGS_BY_CONTACT_NUMBER)
	public @ResponseBody WSResponseWrapper getHotelBookings(@RequestParam String mobileNumber, HttpServletRequest request, HttpSession session) {
		WSResponseWrapper wsResponseWrapper = new WSResponseWrapper();
		try {
			List<HotelBooking> hotelBookingList = hotelBookingManager.getBookingsByContactNumber(mobileNumber);
			String base = getBaseUrl(request);
			List<HotelBookingVO> hotelBookingVOList = WudstayUtil.getHotelBookings(hotelBookingList, base);
			if(hotelBookingVOList == null || hotelBookingVOList.size() == 0) {
				wsResponseWrapper.setResponseCode(new Integer(2));
				wsResponseWrapper.setMessage(WSWudstayConstants.NO_BOOKINGS_FOUND);
				wsResponseWrapper.setTitle(WSWudstayConstants.BLANK);
			} else {
				wsResponseWrapper.setResponseCode(new Integer(1));
				wsResponseWrapper.setMessage(WSWudstayConstants.BLANK);
				wsResponseWrapper.setTitle(WSWudstayConstants.BLANK);
			}
			wsResponseWrapper.setResponseObject(hotelBookingVOList);

		} catch (Exception e) {
			wsResponseWrapper.setResponseCode(new Integer(0));
			wsResponseWrapper.setMessage(WSWudstayConstants.ERROR_MESSAGE);
			wsResponseWrapper.setTitle(WSWudstayConstants.ERROR_TITLE);
		}
		return wsResponseWrapper;
	}
	
	@RequestMapping(method = RequestMethod.GET, value = WSWudstayMappings.CANCEL_BOOKING)
	public @ResponseBody WSResponseWrapper cancelBooking(@RequestParam Long hotelBookingId, @RequestParam String mobileNumber,
			HttpServletRequest request, HttpSession session) {
		WSResponseWrapper wsResponseWrapper = new WSResponseWrapper();
		try {
			HotelBooking hotelBooking = hotelBookingManager.getById(hotelBookingId);
			hotelBooking.setIsCancelled(Boolean.TRUE);
			hotelBookingManager.saveOrUpdate(hotelBooking);
			try{
				WudstayEmailUtil.sendCancellationMail(hotelBookingManager, hotelAdministratorManager, hotelBookingId);
			} catch (Exception e) {
				e.printStackTrace();
			}

			List<HotelBooking> hotelBookingList = hotelBookingManager.getBookingsByContactNumber(mobileNumber);
			String base = getBaseUrl(request);
			List<HotelBookingVO> hotelBookingVOList = WudstayUtil.getHotelBookings(hotelBookingList, base);
			wsResponseWrapper.setResponseCode(new Integer(1));
			wsResponseWrapper.setMessage(WSWudstayConstants.BLANK);
			wsResponseWrapper.setTitle(WSWudstayConstants.BLANK);
			wsResponseWrapper.setResponseObject(hotelBookingVOList);

		} catch (Exception e) {
			wsResponseWrapper.setResponseCode(new Integer(0));
			wsResponseWrapper.setMessage(WSWudstayConstants.ERROR_MESSAGE);
			wsResponseWrapper.setTitle(WSWudstayConstants.ERROR_TITLE);
		}
		return wsResponseWrapper;
	}

	@RequestMapping(method = RequestMethod.GET, value = WSWudstayMappings.GET_NEW_UPDATE_IS_MANDATORY)
	public @ResponseBody WSResponseWrapper getNewUpdateIsMandatory(@RequestParam String appType, @RequestParam String currentVersion, HttpServletRequest request, HttpServletResponse response,HttpSession session) {
		WSResponseWrapper wsResponseWrapper = new WSResponseWrapper();
		try {
			Map<String, Object> map = appVersionManager.newUpdateIsMandatory(appType, currentVersion);
			//Boolean isMandatory = Boolean.FALSE;  //appVersionManager.newUpdateIsMandatory(appType, currentVersion);
			map.put("MESSAGE_ON_MANDATORY_UPDATE", "We have made some serious changed to the WudStay app. Update now to witness the revolution." );
			map.put("MESSAGE_ON_NONE_MANDATORY_UPDATE", "Seems like you are on an older version. Update now?" );
			wsResponseWrapper.setResponseCode(new Integer(1));
			wsResponseWrapper.setMessage(WSWudstayConstants.BLANK);
			wsResponseWrapper.setTitle(WSWudstayConstants.BLANK);
			wsResponseWrapper.setResponseObject(map);
		} catch (Exception e) {
			wsResponseWrapper.setResponseCode(new Integer(0));
			wsResponseWrapper.setMessage(WSWudstayConstants.ERROR_MESSAGE);
			wsResponseWrapper.setTitle(WSWudstayConstants.ERROR_TITLE);
		}
		return wsResponseWrapper;
	}


	@RequestMapping(method = RequestMethod.GET, value = WSWudstayMappings.GET_BOOKINGS_INFORMATION)
	public @ResponseBody WSResponseWrapper getInformationByBookingId(@RequestParam Long hotelBookingId,  HttpServletRequest request, HttpServletResponse response,HttpSession session) {
		WSResponseWrapper wsResponseWrapper = new WSResponseWrapper();

		List<WSHotelVO> wsHotelVOList = new ArrayList<WSHotelVO>();
		try {
			HotelBooking hotelBooking = hotelBookingManager.getById(hotelBookingId);
			String hotelBookingStatus ="";
			try {
				Calendar calendar = Calendar.getInstance();
				Date currentDate = calendar.getTime();
				if (!hotelBooking.getIsCancelled()) {
					if (currentDate.compareTo(hotelBooking.getCheckIn()) < 0) {
						hotelBookingStatus = "CANCEL";
					} else if (currentDate.compareTo(hotelBooking.getCheckOut()) > 0) {
						hotelBookingStatus = "STAY COMPLETE";
					} else {
						hotelBookingStatus = "CANCEL";
					}
				} else {
					hotelBookingStatus = "CANCELLED";
				}
			}catch (Exception ex){
				ex.printStackTrace();
			}

			Hotel hotel = hotelBooking.getHotel();

			//WudstayUtil.setAmenitiesForHotel(hotelList);
			//------------  setAmenitiesForHotel   -------------
			List<HotelAmenity> hotelAmenities = hotel.getHotelAmenities();
			if (hotelAmenities.size() > 0) {
				Collections.sort(hotelAmenities, new Comparator<HotelAmenity>() {
					
					public int compare(final HotelAmenity object1, final HotelAmenity object2) {
						return object1.getAmenityListingOrder().compareTo(object2.getAmenityListingOrder());
					}
				});
				StringBuilder builder = new StringBuilder();
				for (HotelAmenity hotelAmenity : hotelAmenities) {
					builder.append(hotelAmenity.getAmenity().getAmenityName());
					builder.append(WudstayConstants.COMMA);
					builder.append(WudstayConstants.SPACE);
				}
				hotel.setHotelAmenity(builder.substring(0, builder.lastIndexOf(WudstayConstants.COMMA)));
			}
			//--------------------------------------------------
			String baseUrl = getBaseUrl(request);
			int minPax =1;
			//List<Location> locationList = locationManager.getLocationsByCityId(cityId);
			//wsHotelVOList = WudstayUtil.getHotelListWS(hotelList, base, persons/rooms);
			WSHotelVO wsHotelVO = WudstayUtil.getHotelWS(hotel, baseUrl, minPax);

			//wsHotelVO.setHotelImageList(WudstayUtil.getHotelImages(hotel.getHotelId()));
			wsHotelVO.setHotelImageList(WudstayUtil.getHotelImagesList(hotel.getHotelId(), baseUrl));

			BookingInfo hotelBookingDto = new BookingInfo( hotelBooking, wsHotelVO, hotelBookingStatus);
			//--------------------------------------------------
			wsResponseWrapper.setResponseCode(new Integer(1));
			wsResponseWrapper.setMessage(WSWudstayConstants.BLANK);
			wsResponseWrapper.setTitle(WSWudstayConstants.BLANK);
			//WSSearchVO wsSearchVO = new WSSearchVO();
			//wsSearchVO.setLocationList(locationList);
			//wsSearchVO.setWsHotelVOList(wsHotelVOList);
			wsResponseWrapper.setResponseObject(hotelBookingDto);

		} catch (Exception e) {
			wsResponseWrapper.setResponseCode(new Integer(0));
			wsResponseWrapper.setMessage(WSWudstayConstants.ERROR_MESSAGE);
			wsResponseWrapper.setTitle(WSWudstayConstants.ERROR_TITLE);
		}
		return wsResponseWrapper;
	}

	public BookingDetailsVO doCalculateCouponCodeDiscount(String checkIn,  String checkOut, Integer rooms, Integer persons, City city, Hotel hotel, String couponCode, String mobileNumber, Integer sourceOfBooking){
		BookingDetailsVO bookingDetailsVO = WudstayUtil.getBookingDetailsVO(city.getCityName(), checkIn, checkOut, rooms, persons, hotel);
		DiscountCouponInfo discountCoupon = getDiscountCouponInfo(couponCode, mobileNumber, sourceOfBooking, bookingDetailsVO, city);
		return bookingDetailsVO;
	}
	public BookingDetailsVO doCalculateCouponCodeDiscount(String checkIn,  String checkOut, Integer rooms, Integer persons, Long hotelId, String couponCode, String mobileNumber, Integer sourceOfBooking){
		//City city = cityManager.getById(cityId);
		Hotel hotel = hotelManager.getById(hotelId);
		City city = hotel.getLocation().getCity();
		return doCalculateCouponCodeDiscount(checkIn,  checkOut, rooms, persons, city, hotel, couponCode, mobileNumber, sourceOfBooking);
	}

	@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST}, value = WSWudstayMappings.GET_CALCULATE_COUPON_DISCOUNT)
	public @ResponseBody WSResponseWrapper calculateCouponCodeDiscount(@RequestParam String checkIn,  @RequestParam String checkOut,
																	   @RequestParam Integer rooms, @RequestParam Integer persons, @RequestParam Long cityId, @RequestParam Long hotelId,
																	   @RequestParam String couponCode, @RequestParam (required=false) String mobileNumber, @RequestParam(required=false) String source,
																	   HttpServletRequest request, HttpSession session) {
		WSResponseWrapper wsResponseWrapper = new WSResponseWrapper();
		try {
			Integer sourceOfBooking = WudstayConstants.getSourceOfBooking(source, WudstayConstants.SOURCE_OF_BOOKING_MOBILE);

			BookingDetailsVO bookingDetailsVO = doCalculateCouponCodeDiscount(checkIn, checkOut, rooms, persons, hotelId, couponCode, mobileNumber, sourceOfBooking);
			DiscountCouponInfo discountCoupon = bookingDetailsVO.getDiscountCoupon();

			if( bookingDetailsVO.getTotalPrice().equals(bookingDetailsVO.getTotalPriceBeforeDiscount())) {
				wsResponseWrapper.setResponseCode(new Integer(0));
				wsResponseWrapper.setMessage(WSWudstayConstants.NO_DISCOUNT_FOUND);
				wsResponseWrapper.setTitle(WSWudstayConstants.BLANK);
			}else{
				if(bookingDetailsVO.getDiscountCoupon().getOnlyForOnlinePayment()){
					wsResponseWrapper.setResponseCode(new Integer(2));
					wsResponseWrapper.setMessage(WSWudstayConstants.VALID_ONLY_FOR_ONLINE_PAYMENT);
				}else {
					wsResponseWrapper.setResponseCode(new Integer(1));
					wsResponseWrapper.setMessage(WSWudstayConstants.BLANK);
				}
				wsResponseWrapper.setTitle(bookingDetailsVO.getDiscountCoupon().getCouponCode());
			}
			wsResponseWrapper.setResponseObject(bookingDetailsVO);
		} catch (Exception e) {
			wsResponseWrapper.setResponseCode(new Integer(0));
			wsResponseWrapper.setMessage(WSWudstayConstants.ERROR_MESSAGE);
			wsResponseWrapper.setTitle(WSWudstayConstants.ERROR_TITLE);
		}
		return wsResponseWrapper;
	}

	private DiscountCouponInfo getDiscountCouponInfo(String couponCode, String mobileNumber, Integer sourceOfBooking, BookingDetailsVO bookingDetailsVO, City city ){
		DiscountCouponInfo discountCouponInfo = new DiscountCouponInfo();
		if(bookingDetailsVO.getTotalPrice()!=null && !bookingDetailsVO.getTotalPrice().equals( bookingDetailsVO.getTotalPriceBeforeDiscount())){
			bookingDetailsVO.setTotalPrice(bookingDetailsVO.getTotalPriceBeforeDiscount());
		}
		try {
			String strCheckOut = bookingDetailsVO.getCheckOutDate();
			DateFormat dateFormat = new SimpleDateFormat("EEEE, dd MMMMM yyyy");
			dateFormat.setLenient(false);
			Date dtCheckOut = dateFormat.parse(strCheckOut);
			Integer totalAmount = bookingDetailsVO.getTotalPrice();
			discountCouponInfo = couponCodeManager.calculateCouponCodeDiscount(city, couponCode, totalAmount, dtCheckOut, bookingDetailsVO.getNights(),mobileNumber, sourceOfBooking);
			bookingDetailsVO.setDiscountCoupon(discountCouponInfo);
			return discountCouponInfo;
		}catch (Exception ex){
			ex.printStackTrace();
			return discountCouponInfo;
		}
	}

	//-----------------------------------------------------------------------------------------------------------------------------
	@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST}, value = WSWudstayMappings.GENERATE_WPAY_INIT_REQ_HASH)
	public
	@ResponseBody
	WSResponseWrapper generateWPayInitReqHash(@RequestParam String transactionID, @RequestParam String extraAppData, @RequestParam String amountStr,
											  HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		WSResponseWrapper wsResponseWrapper = new WSResponseWrapper();
		try {
			String test_supportedPaymentType = WibmoMerchantConfig.getSupportedPaymentTypeCSV();

			Double d = Double.parseDouble(amountStr);
			long amt = Math.round(d * 100);
			String txnAmt = String.valueOf(amt);

			String generatedMsgHash = WibmoInAppMerchantUtility.generateWPayInitReqHash(
					WibmoMerchantConfig.merchantID, WibmoMerchantConfig.merchantAppID,
					transactionID, extraAppData, txnAmt,
					WibmoMerchantConfig.currency, WibmoMerchantConfig.getSupportedPaymentTypeCSV(),
					WibmoMerchantConfig.wibmoSecretKey, false);

			wsResponseWrapper.setResponseCode(new Integer(1));
			wsResponseWrapper.setMessage(WSWudstayConstants.BLANK);
			wsResponseWrapper.setTitle(WSWudstayConstants.BLANK);
			wsResponseWrapper.setResponseObject(generatedMsgHash);
		} catch (Exception e) {
			wsResponseWrapper.setResponseCode(new Integer(0));
			wsResponseWrapper.setMessage("Failed to generate WPayInitReqHash.");
			wsResponseWrapper.setTitle(WSWudstayConstants.ERROR_TITLE);
		}
		return wsResponseWrapper;
	}

	@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST}, value = WSWudstayMappings.PAYZAPP_PROCESS_INITIATE)
	public
	@ResponseBody
	WSResponseWrapper initiatePayZappProcesses(@RequestParam String name, @RequestParam String email, @RequestParam String mobileNumber,
											   @RequestParam String checkIn, @RequestParam String checkOut, @RequestParam Integer rooms, @RequestParam Integer persons, @RequestParam String cityName, @RequestParam Long hotelId, @RequestParam Integer totalAmount,
											   @RequestParam(required=false) String couponCode, @RequestParam(required=false) String source,
											   HttpServletRequest request, HttpServletResponse response, HttpSession session){

		WSResponseWrapper wsResponseWrapper2 = new WSResponseWrapper();
		wsResponseWrapper2.setResponseCode(new Integer(1));
		wsResponseWrapper2.setMessage(WSWudstayConstants.BLANK);
		wsResponseWrapper2.setTitle(WSWudstayConstants.BLANK);

		try {
			City city = cityManager.getByCityName(cityName);
			Hotel hotel = hotelManager.getById(hotelId);
			PayuPaymentUtil payuPaymentUtil = new PayuPaymentUtil(payuMobTranManager);
			String txnAmt = WibmoInAppMerchantUtility.transactionalAmount(totalAmount + "");
			PayuMobTran payuMobTran = payuPaymentUtil.saveMobPaymentTranLog(city, hotel, name, email, mobileNumber, checkIn, checkOut, rooms, persons, cityName, hotelId, totalAmount, couponCode, source, PayuPaymentUtil.PAYMENT_SOURCE_TYPE_PAYZAP);
			//String extraAppData = payuMobTran.getLogId() + WudstayConstants.HASH  +  totalAmount;
			String extraAppData = payuMobTran.getLogId() + " AMT "  +  totalAmount;
			String transactionId = RandomStringUtils.randomAlphanumeric(15).toUpperCase();
			String generatedMsgHash = WibmoInAppMerchantUtility.generateWPayInitReqHash( WibmoMerchantConfig.merchantID, WibmoMerchantConfig.merchantAppID,
					transactionId, extraAppData, txnAmt, WibmoMerchantConfig.currency, WibmoMerchantConfig.getSupportedPaymentTypeCSV(), WibmoMerchantConfig.wibmoSecretKey, false);
			HashMap<String, Object> map = new HashMap<String, Object>();

			map.put("PayZappLogId", payuMobTran.getLogId());
			map.put("merchantTxnId", transactionId);
			map.put("ActualAmount", totalAmount);
			map.put("txnAmt", txnAmt);
			map.put("extraAppData", extraAppData );
			map.put("msgHash", generatedMsgHash);

			map.put("merchantID",          WibmoMerchantConfig.merchantID);
			map.put("merchantAppID",      WibmoMerchantConfig.merchantAppID);
			map.put("merchantCountryCode", WibmoMerchantConfig.merchantDefaultCountryCode);
			map.put("merchantName",        WibmoMerchantConfig.Merchant_Name);
			map.put("merchantTransactionCurrency", WibmoMerchantConfig.Merchant_transaction_Currency);
			map.put("merchantSupportedPaymentType", WibmoMerchantConfig.supportedPaymentType);
			map.put("transactionDescription", "Hotel Booking: " + hotelId + " @ "+ totalAmount);

			wsResponseWrapper2.setResponseObject(map);
		}catch (Exception ex){
			wsResponseWrapper2.setResponseCode(new Integer(0));
			wsResponseWrapper2.setMessage(WSWudstayConstants.ERROR_MESSAGE);
			wsResponseWrapper2.setTitle(WSWudstayConstants.ERROR_TITLE);
		}

		return wsResponseWrapper2;

	}
	@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST}, value = WSWudstayMappings.PICKUP_WPAY_DATA_FROM_WIBMO_SERVER)
	public
	@ResponseBody
	WSResponseWrapper pickupWpayDataFromWibmoServer(@RequestParam String transactionID, @RequestParam String dataPickupCode, @RequestParam String wPayTxnId,
													HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		WSResponseWrapper wsResponseWrapper = new WSResponseWrapper();
		try {
			MerchantInfo merchantInfo = WibmoMerchantConfig.getMerchantInfo();
			String wpayPickupReqMsgHash = WibmoInAppMerchantUtility.generateWpayPickupReqMsgHash(merchantInfo, transactionID, wPayTxnId, dataPickupCode,WibmoMerchantConfig.wibmoSecretKey, false);
			DataPickupRequest dataPickupRequest = new DataPickupRequest(wpayPickupReqMsgHash, wPayTxnId, dataPickupCode, transactionID, merchantInfo);
			WPayDataPickupResponse wPayDataPickupResponse = WibmoInAppMerchantUtility.pickupWpayDataFromWibmoServer(WibmoMerchantConfig.wibmoDomain, dataPickupRequest);

			wsResponseWrapper.setResponseCode(new Integer(1));
			wsResponseWrapper.setMessage(WSWudstayConstants.BLANK);
			wsResponseWrapper.setTitle(WSWudstayConstants.BLANK);
			wsResponseWrapper.setResponseObject(wPayDataPickupResponse);
		} catch (Exception e) {
			wsResponseWrapper.setResponseCode(new Integer(0));
			wsResponseWrapper.setMessage("Failed to generate WPayInitReqHash.");
			wsResponseWrapper.setTitle(WSWudstayConstants.ERROR_TITLE);
		}
		return wsResponseWrapper;
	}


	@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST}, value = WSWudstayMappings.PAYZAPP_PAYMENT_RESPONSE)
	public
	@ResponseBody
	WSResponseWrapper getPayZappResponse(@RequestParam String payZappLogId, @RequestParam String merchantTxnId,
										 @RequestParam String dataPickupCode, @RequestParam String wPayTxnId,
										 HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		WSResponseWrapper wsResponse = new WSResponseWrapper();
		try{
			Long id = Long.parseLong(payZappLogId.trim());
			PayuMobTran payuMobTran = payuMobTranManager.getById(id);
			if(payuMobTran==null){
				return wsResponse.resetError(WSWudstayConstants.ERROR_TITLE + " (Invalid Transaction Id: " + payZappLogId + ")", WSWudstayConstants.ERROR_MESSAGE);
			}
			wsResponse.resetMessage(1);
			//-------------------------------------------------------------------------------------------------------------------------------------------------------
			try {
				MerchantInfo merchantInfo = WibmoMerchantConfig.getMerchantInfo();
				String wpayPickupReqMsgHash = WibmoInAppMerchantUtility.generateWpayPickupReqMsgHash(merchantInfo, merchantTxnId, wPayTxnId, dataPickupCode,WibmoMerchantConfig.wibmoSecretKey, false);
				DataPickupRequest dataPickupRequest = new DataPickupRequest(wpayPickupReqMsgHash, wPayTxnId, dataPickupCode, merchantTxnId, merchantInfo);
				WPayDataPickupResponse wPayDataPickupResponse = WibmoInAppMerchantUtility.pickupWpayDataFromWibmoServer(WibmoMerchantConfig.wibmoDomain, dataPickupRequest);

				//String resCode = wPayDataPickupResponse.getResCode();
				String resDesc = wPayDataPickupResponse.getResDesc();
				if("SUCCESS".equalsIgnoreCase(resDesc)){
					//----------------------------------------------------------------------------------------------------------
					try{
						InAppPickupData pickupData = wPayDataPickupResponse.getData();
						payuMobTran.setTransactionId(pickupData.getMerTxnId());
						payuMobTran.setPayuTransactionId(pickupData.getWibmoTxnId() + " " + WudstayConstants.SEPARATOR_1 + " " + pickupData.getPgTxnId()  + " " + WudstayConstants.SEPARATOR_1 + " " + pickupData.getTxnAmt());
						Integer intPayuAmount=0;
						try {
							String amt = pickupData.getTxnAmt().trim();
							amt = amt.substring(0, amt.length() - 2);
							intPayuAmount = Integer.parseInt(amt);
						}catch (Exception ex){
							ex.printStackTrace();
							intPayuAmount=0;
						}
						payuMobTran.setPayuAmount(intPayuAmount + "");

						PayuPaymentUtil payuPaymentUtil = new PayuPaymentUtil(payuMobTranManager);
						payuMobTran = payuPaymentUtil.autoConfirmMobileBooking(payuMobTran, hotelManager, hotelBookingManager, hotelAdministratorManager);
						wsResponse.setResponseObject(payuMobTran);
					}catch(Exception ex){
						wsResponse.resetError();
						ex.printStackTrace();
					}
					//----------------------------------------------------------------------------------------------------------
				}else{
					wsResponse.resetError(WSWudstayConstants.ERROR_TITLE, "ResCode:"+ wPayDataPickupResponse.getResCode() + ", resDesc:" + wPayDataPickupResponse.getResDesc());
					wsResponse.setResponseObject(wPayDataPickupResponse);
				}
			} catch (Exception e) {
				wsResponse.resetError();
			}
		} catch (Exception ex) {
			wsResponse.resetError();
		}
		return wsResponse;
	}
	//-------------------------------------------------------------------------------------------------------------------------------------

	@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST}, value = WSWudstayMappings.PAYU_PROCESS_START)
	public
	@ResponseBody
	WSResponseWrapper processPayNow(@RequestParam String name, @RequestParam String email, @RequestParam String mobileNumber,
									@RequestParam String checkIn, @RequestParam String checkOut, @RequestParam Integer rooms, @RequestParam Integer persons, @RequestParam String cityName, @RequestParam Long hotelId, @RequestParam Integer totalAmount,
									@RequestParam(required=false) String couponCode, @RequestParam(required=false) String source,
									HttpServletRequest request, HttpServletResponse response, HttpSession session) {

		Integer discount =0;
		Boolean isPaid = Boolean.FALSE;
		Integer sourceOfBooking = WudstayConstants.getSourceOfBooking(source, WudstayConstants.SOURCE_OF_BOOKING_MOBILE);

		WSResponseWrapper wsResponseWrapper2 = new WSResponseWrapper();
		wsResponseWrapper2.setResponseCode(new Integer(1));
		wsResponseWrapper2.setMessage(WSWudstayConstants.BLANK);
		wsResponseWrapper2.setTitle(WSWudstayConstants.BLANK);
		//WSResponseWrapper wsResponseWrapper2 = validationBeforeConfirmBooking(checkIn, checkOut, rooms, persons, hotelId, totalAmount, couponCode, source);
		try {
			City city = cityManager.getByCityName(cityName);
			Hotel hotel = hotelManager.getById(hotelId);
			PayuPaymentUtil payuPaymentUtil = new PayuPaymentUtil(payuMobTranManager);
			String user_credentials="";
			HashMap<String, Object> map = payuPaymentUtil.doProcessPayNow(city, hotel, name, email, mobileNumber,
					checkIn, checkOut, rooms, persons, cityName, hotelId, totalAmount, couponCode, source,
					WudstayConstants.LIVE_SALT, WudstayConstants.LIVE_MERCHANT_KEY, user_credentials);
			wsResponseWrapper2.setResponseObject(map);
		}catch (Exception ex){
			wsResponseWrapper2.setResponseCode(new Integer(0));
			wsResponseWrapper2.setMessage(WSWudstayConstants.ERROR_MESSAGE);
			wsResponseWrapper2.setTitle(WSWudstayConstants.ERROR_TITLE);
		}

		return wsResponseWrapper2;

	}

	@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST}, value = WSWudstayMappings.PAYU_TEST_PROCESS_START)
	public
	@ResponseBody
	WSResponseWrapper processPayNowTest(@RequestParam String name, @RequestParam String email, @RequestParam String mobileNumber,
										@RequestParam String checkIn, @RequestParam String checkOut, @RequestParam Integer rooms, @RequestParam Integer persons, @RequestParam String cityName, @RequestParam Long hotelId, @RequestParam Integer totalAmount,
										@RequestParam String couponCode, @RequestParam String source,
										HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		Integer discount = 0;
		Boolean isPaid = Boolean.FALSE;
		Integer sourceOfBooking = WudstayConstants.getSourceOfBooking(source, WudstayConstants.SOURCE_OF_BOOKING_MOBILE);

		WSResponseWrapper wsResponseWrapper2 = new WSResponseWrapper();
		wsResponseWrapper2.setResponseCode(new Integer(1));
		wsResponseWrapper2.setMessage(WSWudstayConstants.BLANK);
		wsResponseWrapper2.setTitle(WSWudstayConstants.BLANK);
		//WSResponseWrapper wsResponseWrapper2 = validationBeforeConfirmBooking(checkIn, checkOut, rooms, persons, hotelId, totalAmount, couponCode, source);
		try {
			City city = cityManager.getByCityName(cityName);
			Hotel hotel = hotelManager.getById(hotelId);
			PayuPaymentUtil payuPaymentUtil = new PayuPaymentUtil(payuMobTranManager);
			String user_credentials="";

			HashMap<String, Object> map = payuPaymentUtil.doProcessPayNow(city, hotel, name, email, mobileNumber,
					checkIn, checkOut, rooms, persons, cityName, hotelId, totalAmount, couponCode, source,
					WudstayConstants.TEST_SALT, WudstayConstants.TEST_MERCHANT_KEY, user_credentials);
			wsResponseWrapper2.setResponseObject(map);
		} catch (Exception ex) {
			wsResponseWrapper2.setResponseCode(new Integer(0));
			wsResponseWrapper2.setMessage(WSWudstayConstants.ERROR_MESSAGE);
			wsResponseWrapper2.setTitle(WSWudstayConstants.ERROR_TITLE);
		}

		return wsResponseWrapper2;
	}

	// Step 1: For PauU payment
	@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST}, value = WSWudstayMappings.PAYU_PROCESS_START_Android)
	public
	@ResponseBody
	WSResponseWrapper processPayNowAndroid(@RequestParam String name, @RequestParam String email, @RequestParam String mobileNumber,
									@RequestParam String checkIn, @RequestParam String checkOut, @RequestParam Integer rooms, @RequestParam Integer persons, @RequestParam String cityName, @RequestParam Long hotelId, @RequestParam Integer totalAmount,
									@RequestParam(required=false) String couponCode, @RequestParam(required=false) String source, @RequestParam(required=false) String user_credentials,
									HttpServletRequest request, HttpServletResponse response, HttpSession session) {

		Integer discount =0;
		Boolean isPaid = Boolean.FALSE;
		Integer sourceOfBooking = WudstayConstants.getSourceOfBooking(source, WudstayConstants.SOURCE_OF_BOOKING_MOBILE);

		WSResponseWrapper wsResponseWrapper2 = new WSResponseWrapper();
		wsResponseWrapper2.setResponseCode(new Integer(1));
		wsResponseWrapper2.setMessage(WSWudstayConstants.BLANK);
		wsResponseWrapper2.setTitle(WSWudstayConstants.BLANK);
		//WSResponseWrapper wsResponseWrapper2 = validationBeforeConfirmBooking(checkIn, checkOut, rooms, persons, hotelId, totalAmount, couponCode, source);
		try {
			City city = cityManager.getByCityName(cityName);
			Hotel hotel = hotelManager.getById(hotelId);
			PayuPaymentUtil payuPaymentUtil = new PayuPaymentUtil(payuMobTranManager);

			HashMap<String, Object> map = payuPaymentUtil.doProcessPayNow(city, hotel, name, email, mobileNumber,
					checkIn, checkOut, rooms, persons, cityName, hotelId, totalAmount, couponCode, source,
					WudstayConstants.LIVE_SALT, WudstayConstants.LIVE_MERCHANT_KEY, user_credentials);



			wsResponseWrapper2.setResponseObject(map);
		}catch (Exception ex){
			wsResponseWrapper2.setResponseCode(new Integer(0));
			wsResponseWrapper2.setMessage(WSWudstayConstants.ERROR_MESSAGE);
			wsResponseWrapper2.setTitle(WSWudstayConstants.ERROR_TITLE);
		}

		return wsResponseWrapper2;

	}

	@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST}, value = WSWudstayMappings.PAYU_TEST_PROCESS_START_Android)
	public
	@ResponseBody
	WSResponseWrapper processPayNowTestAndroid(@RequestParam String name, @RequestParam String email, @RequestParam String mobileNumber,
										@RequestParam String checkIn, @RequestParam String checkOut, @RequestParam Integer rooms, @RequestParam Integer persons, @RequestParam String cityName, @RequestParam Long hotelId, @RequestParam Integer totalAmount,
										@RequestParam String couponCode, @RequestParam String source, @RequestParam(required=false) String user_credentials,
										HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		Integer discount = 0;
		Boolean isPaid = Boolean.FALSE;
		Integer sourceOfBooking = WudstayConstants.getSourceOfBooking(source, WudstayConstants.SOURCE_OF_BOOKING_MOBILE);

		WSResponseWrapper wsResponseWrapper2 = new WSResponseWrapper();
		wsResponseWrapper2.setResponseCode(new Integer(1));
		wsResponseWrapper2.setMessage(WSWudstayConstants.BLANK);
		wsResponseWrapper2.setTitle(WSWudstayConstants.BLANK);
		//WSResponseWrapper wsResponseWrapper2 = validationBeforeConfirmBooking(checkIn, checkOut, rooms, persons, hotelId, totalAmount, couponCode, source);
		try {
			City city = cityManager.getByCityName(cityName);
			Hotel hotel = hotelManager.getById(hotelId);
			PayuPaymentUtil payuPaymentUtil = new PayuPaymentUtil(payuMobTranManager);
			HashMap<String, Object> map = payuPaymentUtil.doProcessPayNow(city, hotel, name, email, mobileNumber,
					checkIn, checkOut, rooms, persons, cityName, hotelId, totalAmount, couponCode, source,
					WudstayConstants.TEST_SALT, WudstayConstants.TEST_MERCHANT_KEY, user_credentials);
			wsResponseWrapper2.setResponseObject(map);
		} catch (Exception ex) {
			wsResponseWrapper2.setResponseCode(new Integer(0));
			wsResponseWrapper2.setMessage(WSWudstayConstants.ERROR_MESSAGE);
			wsResponseWrapper2.setTitle(WSWudstayConstants.ERROR_TITLE);
		}

		return wsResponseWrapper2;
	}

	@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST}, value = WSWudstayMappings.PAYU_PAYMENT_RESPONSE)
	public
	@ResponseBody
	WSResponseWrapper processPayNowAndroid(@RequestParam String payuMobTranID, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		WSResponseWrapper wsResponseWrapper2 = new WSResponseWrapper();
		try{
			Long id = Long.parseLong(payuMobTranID.trim());
			PayuMobTran payuMobTran = payuMobTranManager.getById(id);
			wsResponseWrapper2.setResponseCode(new Integer(1));
			wsResponseWrapper2.setMessage(WSWudstayConstants.BLANK);
			wsResponseWrapper2.setTitle(WSWudstayConstants.BLANK);
			String payuResponse = "WAITING";
			try{
				payuResponse = payuMobTran.getPayuResponse().trim();
			}catch (Exception ex){
				payuResponse = "WAITING";
				wsResponseWrapper2.setMessage(WSWudstayConstants.ERROR_TITLE);
			}
			if("SUCCESS".equalsIgnoreCase(payuResponse)){
				payuResponse = "Transaction succeeded.";
				wsResponseWrapper2.setTitle("SUCCESS");
			}else if("WAITING".equalsIgnoreCase(payuResponse)){
				payuResponse = "Please wait, while we are fetching your transaction data.";
				wsResponseWrapper2.setTitle("WAITING");
			}else if("FAILURE".equalsIgnoreCase(payuResponse)){
				payuResponse = "Transaction failed, your amount will be reverted back in your account.";
				wsResponseWrapper2.setTitle("FAILURE");
			}else if("CANCEL".equalsIgnoreCase(payuResponse)){
				payuResponse = "Transaction cancelled.";
				wsResponseWrapper2.setTitle("CANCEL");
			}
			wsResponseWrapper2.setMessage(payuResponse);
			wsResponseWrapper2.setResponseObject(payuMobTran);
		} catch (Exception ex) {
			wsResponseWrapper2.setResponseCode(new Integer(0));
			wsResponseWrapper2.setMessage(WSWudstayConstants.ERROR_MESSAGE);
			wsResponseWrapper2.setTitle(WSWudstayConstants.ERROR_TITLE);
		}
		return wsResponseWrapper2;
	}
}
