package com.queppelin.wudstay.webservice.vo;


import com.queppelin.wudstay.webservice.util.WSWudstayConstants;

public class WSResponseWrapper {
	
	private String message;
	
	private String title;
	
	private int responseCode;
	
	private Object responseObject;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(int responseCode) {
		this.responseCode = responseCode;
	}

	public Object getResponseObject() {
		return responseObject;
	}

	public void setResponseObject(Object responseObject) {
		this.responseObject = responseObject;
	}

	public WSResponseWrapper resetError() {
		return reset(new Integer(0), WSWudstayConstants.ERROR_TITLE, WSWudstayConstants.ERROR_MESSAGE);
	}
	public WSResponseWrapper resetError(String title, String message ) {
		return reset(new Integer(0), title, message);
	}
	public WSResponseWrapper resetMessage(String title, String message ) {
		return reset(new Integer(1), title, message);
	}
	public WSResponseWrapper resetMessage(int responseCode) {
		return reset(responseCode, WSWudstayConstants.BLANK, WSWudstayConstants.BLANK);
	}
	public WSResponseWrapper resetMessage() {
		return reset(new Integer(1), WSWudstayConstants.BLANK, WSWudstayConstants.BLANK);
	}
	public WSResponseWrapper reset(int responseCode, String title, String message ) {
		this.message = message;
		this.title = title;
		this.responseCode = responseCode;
		return this;
	}
}
