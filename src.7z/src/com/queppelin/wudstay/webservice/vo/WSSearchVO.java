package com.queppelin.wudstay.webservice.vo;

import java.io.Serializable;
import java.util.List;

import com.queppelin.wudstay.vo.Location;

public class WSSearchVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4498633445329000945L;
	
	private List<Location> locationList = null;
	
	private List<WSHotelVO> wsHotelVOList = null;

	public List<Location> getLocationList() {
		return locationList;
	}

	public void setLocationList(List<Location> locationList) {
		this.locationList = locationList;
	}

	public List<WSHotelVO> getWsHotelVOList() {
		return wsHotelVOList;
	}

	public void setWsHotelVOList(List<WSHotelVO> wsHotelVOList) {
		this.wsHotelVOList = wsHotelVOList;
	}
	
	
}
