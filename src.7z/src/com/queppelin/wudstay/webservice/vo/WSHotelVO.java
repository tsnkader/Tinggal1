package com.queppelin.wudstay.webservice.vo;

import java.io.Serializable;
import java.util.List;

public class WSHotelVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3681489381480686453L;

	private Long hotelId;

	private List<String> amenityList;
	
	private String hotelName;

	private String hotelAddress;
	
	private String hotelDisplayAddress;

	private Double latitude;
	
	private Double longitude;
	
	private String hotelDisplayName;

	private String hotelCity; //ssr 16 10 2015

	private Long hotelCityId; //Hemraj 19 12 2015
	
	private Integer price;
	
	private Integer singleOccupancyPrice;
	
	private Integer doubleOccupancyPrice;
	
	private Integer tripleOccupancyPrice;
	
	private List<String> hotelImageList;
	
	private String roomImage;
	
	private Integer starRating;
	
	private String roomType;
	
	private Long locationId;

	private String hotelContactPerson1;
	
	public Long getHotelId() {
		return hotelId;
	}

	public void setHotelId(Long hotelId) {
		this.hotelId = hotelId;
	}

	public List<String> getAmenityList() {
		return amenityList;
	}

	public void setAmenityList(List<String> amenityList) {
		this.amenityList = amenityList;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public String getHotelAddress() {
		return hotelAddress;
	}

	public void setHotelAddress(String hotelAddress) {
		this.hotelAddress = hotelAddress;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public String getHotelDisplayName() {
		return hotelDisplayName;
	}

	public void setHotelDisplayName(String hotelDisplayName) {
		this.hotelDisplayName = hotelDisplayName;
	}

	public String getHotelCity() {
		return hotelCity;
	}

	public void setHotelCity(String hotelCity) {
		this.hotelCity = hotelCity;
	}//ssr 16 10 2015

	public Long getHotelCityId() {
		return hotelCityId;
	}

	public void setHotelCityId(Long hotelCityId) {
		this.hotelCityId = hotelCityId;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public List<String> getHotelImageList() {
		return hotelImageList;
	}

	public void setHotelImageList(List<String> hotelImageList) {
		this.hotelImageList = hotelImageList;
	}

	public String getRoomImage() {
		return roomImage;
	}

	public void setRoomImage(String roomImage) {
		this.roomImage = roomImage;
	}

	public Integer getStarRating() {
		return starRating;
	}

	public void setStarRating(Integer starRating) {
		this.starRating = starRating;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public Long getLocationId() {
		return locationId;
	}

	public void setLocationId(Long locationId) {
		this.locationId = locationId;
	}

	public String getHotelDisplayAddress() {
		return hotelDisplayAddress;
	}

	public void setHotelDisplayAddress(String hotelDisplayAddress) {
		this.hotelDisplayAddress = hotelDisplayAddress;
	}

	public Integer getSingleOccupancyPrice() {
		return singleOccupancyPrice;
	}

	public void setSingleOccupancyPrice(Integer singleOccupancyPrice) {
		this.singleOccupancyPrice = singleOccupancyPrice;
	}

	public Integer getDoubleOccupancyPrice() {
		return doubleOccupancyPrice;
	}

	public void setDoubleOccupancyPrice(Integer doubleOccupancyPrice) {
		this.doubleOccupancyPrice = doubleOccupancyPrice;
	}

	public Integer getTripleOccupancyPrice() {
		return tripleOccupancyPrice;
	}

	public void setTripleOccupancyPrice(Integer tripleOccupancyPrice) {
		this.tripleOccupancyPrice = tripleOccupancyPrice;
	}
	
	public String getHotelContactPerson1() {
		return hotelContactPerson1;
	}

	public void setHotelContactPerson1(String hotelContactPerson1) {
		this.hotelContactPerson1 = hotelContactPerson1;
	}

}
